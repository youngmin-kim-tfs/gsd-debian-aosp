#!/bin/bash -e

### Defaults
   flavor=${1:-CI}
   build=${2:-lastSuccessfulBuild}
   urls=(
       http://monarch.buildmaster.apps.thermofisher.com/job/Monarch_InstrumentServer_${flavor}/${build}/artifact/Monarch/instrument-server-seqstudio.tar.gz
       )
       


### Change working directory to the folder containing the IS
    scriptsfolder=${0%/*}
    if [ "${scriptsfolder}" ]; then
        cd ${scriptsfolder}/../..
    else
        cd /opt/Monarch
    fi

### Display currently-installed version
    if [ -e InstrumentServer/Config/version.ini ]; then
        echo "--- Currently installed:"    
        (while read line; do echo "    ${line}"; done) < InstrumentServer/Config/version.ini
    fi


### Retrieve and unpack new version into TEMP folder
    tempfolder=tmp.$$
    mkdir ${tempfolder}

    if [ -x /usr/bin/wget ]; then
        retrieve="/usr/bin/wget -q -O -"
    elif [ -x /usr/bin/curl ]; then 
        retrieve="/usr/bin/curl -s -S"
    else
        echo "--- You don't seem to have ether 'wget' or 'curl' installed on this system.  Cannot proceed." >&2
        exit 1
    fi

    (for url in "${urls[@]}"; do ${retrieve} "${url}" && break; done) | tar -x -z -C ${tempfolder} -f -



### Replace currently-installed version with new version
    echo "--- Installing new build in ${scriptsfolder}"
    for item in ${tempfolder}/*
    do
        basename=$(basename "${item}")
        rm -rf "${basename}"
        mv "${item}" .
    done

### Remove TEMP folder
    rm -rf ${tempfolder}

### Display new version
    if [ -e InstrumentServer/Config/version.ini ]; then
        echo "--- Upgraded to:"
        (while read line; do echo "    ${line}"; done) < InstrumentServer/Config/version.ini
    fi

### Display info
    echo ""
    echo "### Please restart the IS to complete the upgrade."

#!/bin/bash

usage() {
    status=0

    if [ "$@" ]; then
	echo "$@"
	status=1
    fi

    echo "Usage: $0 -o <output>.csv <logfiles> ..." 
    echo "Example: $0 -o eptdata.csv /var/log/Monarch/IS/*2016-02-25*"

    exit ${status}
}


output=""

while [ "$1" ]; do
    case "$1" in
	-h)
	    usage
	    ;;
	    
	-o)
	    [ "$2" ] || usage "Missing output file"
	    output="$2"
	    shift
	    ;;

	-*)
	    usage "Unknown option: $1"
	    ;;

	*)  break
	    ;;
    esac
    shift
done

if [ ! "${output}" ]; then
    usage "Missing output file"
fi

output=${output%.csv}.csv

/opt/Monarch/InstrumentServer/Tools/logExtractor.py -t ' EPT:' -n DATE -m '\d{4}-\d{2}-\d{2}' -o "${output}" "$@"

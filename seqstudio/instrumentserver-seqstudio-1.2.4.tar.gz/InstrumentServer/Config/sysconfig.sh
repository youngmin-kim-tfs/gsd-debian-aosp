########################################################################
### FILE:	sysconfig.sh
### PURPOSE:	System Configuration file for Magnum Instrument Server
########################################################################


### Instrument class. This is used to set search paths and other parameters.
### Uncomment ONE of these.
export SYSCONFIG
SYSCONFIG=${SYSCONFIG:-Production}
#SYSCONFIG=Simulator	# Simulator

### LLAC Transport.  Uncomment one, depending on CANbus device in use.
export LLACTRANSPORT
#LLACTRANSPORT=${LLACTRANSPORT:-llac2esd}
LLACTRANSPORT=${LLACTRANSPORT:-llac2ana}
#LLACTRANSPORT=llac2ixxat  # IXXAT USB-to-CAN Compact
#LLACTRANSPORT=llac2esd    # ESD (PCI, PICe or USB) 
#LLACTRANSPORT=llacSimulator  # Simulated LLAC transport

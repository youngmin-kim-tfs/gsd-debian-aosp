########################################################################
### FILE:	linux.py
### PURPOSE:	Generic Network Configuration for Linux systems
### HISTORY:
###  2013-01-20 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################


from base       import addProvider, \
    GlobalProvider, NetDeviceProvider, NetInterfaceProvider

from os.path    import exists, isdir, join
from os         import listdir
from re         import findall
from sys        import platform
from time       import gmtime, strftime, sleep, time
from logging    import debug
from socket     import socket, AF_INET, SOCK_DGRAM, inet_ntoa
from struct     import pack, unpack
from array      import array
try:
    from fcntl      import ioctl
    gotIOCTL = True
except ImportError:
    gotIOCTL = False
    

class LinuxTimeProvider (GlobalProvider):
    KEYS = (TIME,) = ("time",)
    DATECOMMAND = "date"
    HWCLOCK = "hwclock"

    def isRelevant (self):
        try:
            ### Are we running GNU "date"?
            self.runcommand((self.DATECOMMAND, "--version"))
        except self.ExitStatus, e:
            return False
        else:
            return True

    def get (self):
        return time()

    def configure (self, valuemap):
        timestamp = valuemap.get(self.TIME)
        string = strftime("%m%d%H%M%Y.%S", gmtime(timestamp))
        self.runcommand((self.DATECOMMAND, "-u", string))
        self.runcommand((self.HWCLOCK, "-u", "-w"))
        return True


addProvider(LinuxTimeProvider)


class LinuxNetDeviceProvider (NetDeviceProvider):

    DEVICEFOLDER = "/sys/class/net"
    KEYS = (INTERFACE, MAC, CARRIER, ENABLED, WIRELESS) = \
        ('interface', 'mac', 'carrier', 'enabled', 'wireless')


    def isRelevant (self):
        return isdir(self.DEVICEFOLDER)


    def isValidInterface (self, ifname):
        return isdir(join(self.DEVICEFOLDER, ifname))


    def getInterfaces (self, types=None):
        if not types:
            devices = listdir(self.DEVICEFOLDER)
        else:
            devices = []
            for interface in listdir(self.DEVICEFOLDER):
                path = join(self.DEVICEFOLDER, interface, "type")
                tp = int(file(path).read().strip())
                if not types or tp in types:
                    devices.append(interface)

        devices.sort()
        return devices
        

    def listValues (self, arg):
        if arg == self.INTERFACE:
            return self.getInterfaces(types=(1,))



    def get (self, interface, enable=False, current=None):
        enabled  = self.getEnabled(interface)
        wireless = isdir("/".join((self.DEVICEFOLDER, interface, "wireless")))

        if enable and not enabled:
            debug("Bringing up interface %s...")
            self.setEnabled(interface, True)
            sleep(2)

        if enable or enabled:
            carrier = self.getprop(interface, "operstate", None) == "up"
        else:
            carrier = False

        if enable and not enabled:
            self.setEnabled(interface, False)

        mac = self.getprop(interface, "address", None)

        return { self.MAC      : mac,
                 self.ENABLED  : enabled,
                 self.CARRIER  : carrier,
                 self.WIRELESS : wireless }



    def setEnabled (self, interface, enabled, ignoreMissing=False):
        flagsfile   = "/".join((self.DEVICEFOLDER, interface, "flags"))
        try:
            flags  = int(file(flagsfile).read().strip(), 0)
            flags &= 0xFFFFFFFE
            flags |= enabled and 0x0001 or 0x0000
            file(flagsfile, 'w').write("0x%04X\n"%flags)
        except EnvironmentError, e:
            if not ignoreMissing:
                raise


    def getEnabled (self, interface):
        flags = int(self.getprop(interface, "flags", 0), 0)
        return flags & 0x0001
    

    def getprop (self, interface, prop, *default):
        path  = "/".join((self.DEVICEFOLDER, interface, prop))
        fp    = file(path)
        try:
            return fp.read().strip()
        except EnvironmentError, e:
            if default:
                return default[0]
            else:
                raise
            

    def configure (self, valuemap, interface):
        if self.ENABLED in valuemap:
            self.setEnabled(interface, valuemap[self.ENABLED])

        return True


addProvider(LinuxNetDeviceProvider)




class LinuxIfStateProvider (NetInterfaceProvider, LinuxNetDeviceProvider):
    KEYS = (STATE, MODE, ADDRESS, NETMASK) = \
         ("state", "mode", "address", "netmask")

    _socket = None
    (SIOCGIFCONF, SIOCGIFADDR, SIOCGIFNETMASK) = (0x8912, 0x8915, 0x891b)

    def isRelevant (self):
        return gotIOCTL and LinuxNetDeviceProvider.isRelevant(self)


    def ioctl_address (self, interface, signal):
        if self._socket is None:
            self._socket = socket(AF_INET, SOCK_DGRAM)

        try:
            record = ioctl(self._socket, signal, pack('256s', interface))
        except IOError, e:
            return None
        else:
            return inet_ntoa(record[20:24])


    def ioctl_iflist (self):
        if self._socket is None:
            self._socket = socket(AF_INET, SOCK_DGRAM)

        buf = array('B', '\0'*(128*32))
        bufaddr, bufsize = buf.buffer_info()

        try:
             response = ioctl(self._socket, self.SIOCGIFCONF, pack('iL', bufsize, bufaddr))
             outsize, outaddr = unpack('iL', response)
        except IOError, e:
            return []
        else:
            return [ (buf.tostring()[i:i+16].rstrip('\0'), inet_ntoa(buf[i+20:i+24]))
                     for i in range(0, outsize, 40) ]


    def getstate (self, interface):
        enabled  = self.getEnabled(interface)
        address  = None
        netmask  = None

        if enabled:
            for (name, addr) in self.ioctl_iflist():
                if (name+':').startswith(interface+':'):
                    address  = addr
                    netmask  = self.ioctl_address(name, self.SIOCGIFNETMASK)

        return {
            self.STATE   : enabled and self.ENABLED or self.DISABLED,
            self.MODE    : None,
            self.ADDRESS : address,
            self.NETMASK : netmask }




class LinuxIfStateProvider_Legacy (NetInterfaceProvider, LinuxNetDeviceProvider):
    KEYS = (STATE, MODE, ADDRESS, NETMASK) = \
         ("state", "mode", "address", "netmask")

    _socket = None
    (SIOCGIFADDR, SIOCGIFNETMASK) = (0x8915, 0x891b)

    def isRelevant (self):
        return gotIOCTL and LinuxNetDeviceProvider.isRelevant(self)


    def ioctl_address (self, interface, signal):
        if self._socket is None:
            self._socket = socket(AF_INET, SOCK_DGRAM)

        try:
            record = ioctl(self._socket, signal, pack('256s', interface))
        except IOError, e:
            return None
        else:
            return inet_ntoa(record[20:24])


    def getstate (self, interface):
        enabled  = self.getEnabled(interface)

        if enabled:
            address = self.ioctl_address(interface, self.SIOCGIFADDR)
            netmask = self.ioctl_address(interface, self.SIOCGIFNETMASK)
        else:
            address = None
            netmask = None

        return {
            self.STATE   : enabled and self.ENABLED or self.DISABLED,
            self.MODE    : None,
            self.ADDRESS : address,
            self.NETMASK : netmask }



addProvider(LinuxIfStateProvider)



class LinuxGWProvider (NetInterfaceProvider, LinuxNetDeviceProvider):
    ROUTETABLE = '/proc/net/route'
    KEYS = (GATEWAY, ) = ("gateway",)

    def isRelevant (self):
        return exists(self.ROUTETABLE)


    def getstate (self, interface):
        for line in file(self.ROUTETABLE):
            iface, destination, gw, flags, rest = line.split(None, 4)
            if (iface == interface) and (int(destination, 16) == 0) and (int(flags, 16) & 0x0002 != 0x0000):
                gateway = inet_ntoa(pack('<L', int(gw, 16)))
                break
        else:
            gateway = None

        return { self.GATEWAY : gateway }
            


addProvider(LinuxGWProvider)




########################################################################
### FILE:	samba.py
### PURPOSE:	Configuration provider for SAMBA
### HISTORY:
###  2013-01-31 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

import os
import os.path
import logging
import base
import re



class SambaProvider (base.NetNameProvider):
    
    KEYS = (WORKGROUP, WINSSERVERS) =\
        ('workgroup', 'winsservers')

    OPTIONS = (('global', 'workgroup'), ('global', 'wins server'))


    CONFFILE = "/etc/samba/smb.conf"
    SECTION  = 'global'

    def isRelevant (self):
        return os.path.isfile(self.CONFFILE)


    RX  = re.compile(r"\s*(?:\[(\w+)\]|([^;#=]+?)\s*=\s*([^;#\n]*))")
    

    def readConfig (self):
        valuemap = {}
        valuemap, currentsection = self._readConfig(self.CONFFILE, valuemap, None)
        return valuemap


    def _readConfig (self, conffile, valuemap, currentsection):
        try:
            scope = currentsection and "nested" or "top-level"
            fp = file(conffile)
        except EnvironmentError, e:
            logging.debug("Not reading %s SMB configuration file %r: %s"%
                          (scope, conffile, e.strerror))
        else:
            logging.debug("Reading %s SMB configuration file %r..."%
                          (scope, conffile))
            
            for line in file(conffile):
                match = self.RX.match(line)
                if match:
                    section, option, value = match.groups()
                    if section:
                        currentsection = section
                        valuemap.setdefault(section, {})

                    elif option == "include":
                        valuemap, currentsection = self._readConfig(value, valuemap, currentsection)

                    elif currentsection:
                        valuemap[currentsection][option] = value

        return valuemap, currentsection



    def updateConfig (self, valuemap):
        valuemap       = valuemap.copy()
        currentsection = {}
        lines  = []

        if os.path.isfile(self.CONFFILE):
            for line in file(self.CONFFILE):
                match = self.RX.match(line)
                if match:
                    section, option, value = match.groups()

                    if section:
                        if currentsection:
                            self.insertMissing(lines, currentsection)
                            
                        currentsection = valuemap.pop(section, {}).copy()

                    elif option in currentsection:
                        value = currentsection.pop(option)
                        line  = "    %s = %s\n"%(option, value)

                lines.append(line)


            if currentsection:
                self.insertMissing(lines, currentsection)

        for section, optionmap in valuemap.iteritems():
            if lines and lines[-1].strip() and not lines[-1].strip():
                lines.append("\n")
                
            lines.append("[%s]\n"%section)
            self.insertMissing(lines, optionmap)

        self.safeSave(self.CONFFILE, lines)

        

    NONEMPTY = re.compile(r"\s*([^\s#;]+)")

    def insertMissing (self, lines, valuemap):
        index = len(lines)
        while index > 0 and not self.NONEMPTY.match(lines[index-1]):
            index -= 1

        for item in valuemap.iteritems():
            lines.insert(index, "    %s = %s\n"%item)


    def get (self):
        config      = self.readConfig()
        section     = config.get(self.SECTION, {})
        workgroup   = section.get("workgroup")
        winsservers = [ address.split(":")[-1]
                        for address in section.get("wins server", "").replace(",", " ").split() ]

        return {
            self.WORKGROUP   : workgroup,
            self.WINSSERVERS : winsservers }


    def validate (self, valuemap):
        if valuemap.get(self.WORKGROUP):
            self.check(valuemap[self.WORKGROUP], "workgroup", fqdn=False)

        for server in valuemap.get(self.WINSSERVERS, []):
            if not self.isValidIP(server):
                raise self.InvalidAddress(key="WINS server address", value=server)

        return True


    def configure (self, valuemap, optionmap=None):
        if optionmap is None:
            optionmap = {}

        if not isfile(self.CONFFILE):
            optionmap['interfaces'] = "*"

        if self.WORKGROUP in valuemap:
            optionmap['workgroup'] = valuemap.get(self.WORKGROUP)

        if self.WINSSERVERS in valuemap:
            optionmap['wins server'] = ", ".join(valuemap.get(self.WINSSERVERS))

        self.updateConfig({self.SECTION: optionmap})
        return True


    def apply (self, valuemap):
        pass
    

base.addProvider(SambaProvider)


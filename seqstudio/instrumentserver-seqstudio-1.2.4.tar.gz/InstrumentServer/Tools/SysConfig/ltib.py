########################################################################
### FILE:	ltib.py
### PURPOSE:	System Configuration Plugin for LTIB
### HISTORY:
###  2013-01-25 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights Reserved.
########################################################################

from os.path    import join, exists, isfile, islink
from signal     import SIGTERM
from re         import findall, subn
from time       import gmtime, strftime
from logging    import debug
from process    import signames

from base       import addProvider, \
    GlobalProvider, NetNameProvider, NetInterfaceProvider, SysConfigError

from linux      import LinuxNetDeviceProvider
from samba      import SambaProvider

try:
    from os         import kill, listdir, readlink
    gotLink = True
except ImportError, e:
    gotLink = False


class LTIB (object):
    CONFFILE  = "/etc/rc.d/rc.conf"

    def isRelevant (self):
        return exists(self.CONFFILE)


    def readConfig (self):
        text = file(self.CONFFILE).read()
        items = findall(r'(?:^|\n)export\s+(\w+)="?([^"\n]+)"?', text)
        return dict(items)
        

    def setValues (self, items):
        text = file(self.CONFFILE).read()

        logtext = [ "Saving values to %s:"%(self.CONFFILE,) ]

        for key, value in items:
            text, count = subn(r'((?:^|\n)export\s+%s=).*\n?'%key,
                               r'\1"%s"\n'%value,
                               text)
            if not count:
                text = text.rstrip() + '\nexport %s="%s"\n'%(key, value)

            logtext.append('export %s="%s" (%s)'%(key, value, count and "replace" or "add"))
 

        debug("\n  >>".join(logtext))
        self.safeSave(self.CONFFILE, text)



class LTIBDateProvider (GlobalProvider):
    KEYS = (TIME,) = ("time",)
    DATECOMMAND = "/bin/date"
    HWCLOCK = "/sbin/hwclock"

    def isRelevant (self):
        ### Busybox provided "date" command
        return gotLink and islink(self.DATECOMMAND) and readlink(self.DATECOMMAND).endswith("busybox")
            

    def configure (self, valuemap):
        timestamp = valuemap.get(self.TIME)
        string = strftime("%Y-%m-%d %H:%M:%S", gmtime(timestamp))
        self.runcommand((self.DATECOMMAND, "-u", string))
        self.runcommand((self.HWCLOCK, "-u", "-w"))
        return True



addProvider(LTIBDateProvider)




class LTIBNameProvider (LTIB, NetNameProvider):

    KEYS = (HOSTNAME, NTPSERVER) = ('hostname', 'ntpserver')
    LTIBKEYS = {
        HOSTNAME  : "HOSTNAME",
        NTPSERVER : "NTP_SERVER" }


    def validate (self, valuemap):
        if self.HOSTNAME in valuemap:
            self.check(valuemap[self.HOSTNAME], "host name")

        if self.NTPSERVER in valuemap:
            self.check(valuemap[self.NTPSERVER], "NTP server", fqdn=True)

        return True


    def confKey (self, key, *args, **kwargs):
        return self.LTIBKEYS[key]


    def get (self, *args, **kwargs):
        confmap  = self.readConfig()
        valuemap = {}
        for key in self.KEYS:
            confKey = self.confKey(key, *args, **kwargs)
            valuemap[key] = confmap.get(confKey)

        return valuemap


    def configure (self, valuemap, *args, **kwargs):
        confItems = [ (self.confKey(key, *args, **kwargs), value or '')
                      for (key, value) in valuemap.iteritems() ]

        self.setValues(confItems)
        return True


    def apply (self, valuemap, *args, **kwargs):
        if self.HOSTNAME in valuemap:
            self.runcommand(("/bin/hostname", valuemap[self.HOSTNAME]))

        if self.NTPSERVER in valuemap:
            self.runcommand(("/bin/ntpclient", "-s", "-h", valuemap[self.NTPSERVER]))





addProvider(LTIBNameProvider)


class LTIBNetInterface (LTIB, NetInterfaceProvider, LinuxNetDeviceProvider):

    IFKEYS = (IFENABLE, IFNAME, IFADDR, IFNETMASK, IFGATEWAY) = \
        ('SYSCFG_IFACE%d', 'INTERFACE%d', 'IPADDR%d', 'NETMASK%d', 'GATEWAY%d')


    ### Unfortunately, the LTIB system does not provide a clean
    ### mechanism to stop/start a single network interface.
    ### To (re)start we need to run "/etc/rc.d/init.d/network",
    ### which brings up ALL configured interfaces.
    ### Likewise, to stop, we need to kill ALL "udhcpc" instances.


    STARTCOMMAND = ". /etc/rc.d/rc.conf; /etc/rc.d/init.d/network start"
    STOPCOMMAND  = "pkill udhcpc; ifconfig %(interface)s 0.0.0.0 down || true"

    DHCPSTOP  = r"udhcpc\0.*\0-i\0%(interface)s\0"
    DHCPSTART = ("udhcpc", "-n", "-O", "wins", "-O", "ntpsrv", "-O", "timezone", "-i")

    IFCONFIG, ROUTE = ("ifconfig", "route")
    


    class InterfaceNotSupported (SysConfigError):
        '''Network interface %(interface)r is not supported on this system'''

    class NoLease (SysConfigError):
        '''Could not obtain network settings from DHCP server'''


    def isValidInterface (self, ifname):
        exists = LinuxNetDeviceProvider.isValidInterface(self, ifname)
        return self.getifindex(ifname, new=exists) is not None
        


    def getifindex (self, interface, confmap=None, new=False):
        if confmap is None:
            confmap = self.readConfig()

        empty = None
        
        for index in range(4):
            ifname = confmap.get(self.IFNAME%index)
            if ifname == interface:
                return index

            elif not ifname and empty is None:
                empty = index


        if new and (empty is not None):
            return empty
        else:
            return None
        


    def getconfig (self, interface):
        confmap  = self.readConfig()
        index    = self.getifindex(interface, confmap)

        enabled  = (index is not None and
                    confmap.get(self.IFENABLE%index, "").lower() == "y")
        valuemap = { self.STATE: self.STATES[enabled] }
        state    = self.STATES[enabled]
        mode     = None
        address  = None
        netmask  = None
        gateway  = None

        if enabled:
            address  = confmap.get(self.IFADDR%index)

            if address == "dhcp":
                mode    = self.DHCP
                address = None

            else:
                mode    = self.STATIC
                netmask = confmap.get(self.IFNETMASK%index)
                gateway = confmap.get(self.IFGATEWAY%index)


        return { self.STATE   : self.STATES[enabled],
                 self.MODE    : mode,
                 self.ADDRESS : address,
                 self.NETMASK : netmask,
                 self.GATEWAY : gateway }



    def configure (self, valuemap, interface):
        index   = self.getifindex(interface, new=True)
        enabled = valuemap.get(self.STATE)
        items   = [ (self.IFNAME%index, interface) ]

        if self.STATE in valuemap:
            enable = (valuemap[self.STATE] == self.ENABLED) and "y" or "n"
            items.append((self.IFENABLE%index, enable))


        if valuemap.get(self.MODE) == self.DHCP:
            items.append((self.IFADDR%index, "dhcp"))

        else:
            self.additem(self.ADDRESS, valuemap, self.IFADDR%index, items)
            self.additem(self.NETMASK, valuemap, self.IFNETMASK%index, items)
            self.additem(self.GATEWAY, valuemap, self.IFGATEWAY%index, items)

        self.setValues(items)
        return True


    def additem (self, key, valuemap, variable, items):
        if key in valuemap:
            items.append((variable, valuemap[key] or ''))



    def stop (self, valuemap, interface):
        self.killproc(self.DHCPSTOP%locals())
        self.setEnabled(interface, False, ignoreMissing=True)
        return True


    def start (self, valuemap, interface):
        confmap  = self.getconfig(interface)

        if confmap[self.STATE] == self.ENABLED:
            if confmap[self.MODE] == self.DHCP:
                cmdline = self.DHCPSTART + (interface,)
                try:
                    self.runcommand(cmdline)
                except self.ExitStatus:
                    raise self.NoLease(interface=interface)

            elif confmap[self.MODE] == self.STATIC:
                cmdline = [ self.IFCONFIG, interface, confmap[self.ADDRESS] ]

                if self.NETMASK in confmap:
                    cmdline.append("netmask")
                    cmdline.append(confmap[self.NETMASK])

                self.runcommand(cmdline)

                if self.GATEWAY in confmap:
                    cmdline = [ self.ROUTE, "add", "default", "gw", confmap.get(self.GATEWAY), interface ]
                    self.runcommand(cmdline)



    def killproc (self, commandspec, signal=SIGTERM):
        pidlist = self.findpid(commandspec)
        if pidlist:
            debug("SysConfig: Sending %s to processes matching \"%s\": %s"%
                  (signames.get(signal, "signal %s"%signal), commandspec, pidlist))

            for pid in pidlist:
                try:
                    kill(pid, signal)
                except EnvironmentError, e:
                    pass
        

    def findpid (self, commandspec):
        pidlist = []

        for pid in listdir("/proc"):
            if pid.isdigit():
                path    = join("/proc", pid, "cmdline")
                try:
                    cmdline = file(path, "rb").read()
                except EnvironmentError, e:
                    pass
                else:
                    if findall(commandspec, cmdline):
                        pidlist.append(int(pid))
                    
        return pidlist


addProvider(LTIBNetInterface)


class LTIBSambaProvider (SambaProvider, LinuxNetDeviceProvider):
    CONFFILE = "/usr/lib/smb.conf"

    def isRelevant (self):
        return isfile(LTIB.CONFFILE)


addProvider(LTIBSambaProvider)

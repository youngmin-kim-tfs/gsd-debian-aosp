########################################################################
### FILE:	wlan.py
### PURPOSE:	Wireless Local Area Network (WiFi) support.
### HISTORY:
###  2013-04-15 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

import re
import os
import os.path
import time
import logging
import base
import linux

class WiFiScanProvider (linux.LinuxNetDeviceProvider):
    
    KEYS = (SSIDSCAN,) = ('ssidscan',)

    IWLIST = "iwlist"

    ATTRIBUTES = \
        (MAC, PROTOCOL, SSID, MODE, QUALITY, SIGNAL, NOISE,
         FREQUENCY, CHANNEL, BITRATE, ENCRYPTION, AUTHENTICATION, WPASUITE) = \
         ('mac', 'protocol', 'ssid', 'mode', 'quality', 'signal', 'noise',
          'frequency', 'channel', 'bitrate', 'encryption', 'authentication', 'wpa')

    parseStrings = (
        r'.*Address:\s+(\S+)',                    # Mac
        r'Protocol:(\S+)',                        # Protocol
        r'\w*SSID:\"([^\"]*)\"',                  # SSID
        r'Mode:(\S+)',                            # Ad-Hoc or Managed
        r'Quality=(\d+/\d+)',                     # Link quality (nn/nn)
        r'Signal level=(\S+)\s+\S+',              # Signal (dBm)
        r'Noise level=(\S+)\s+\S+',               # Noise (dBm)
        r'Frequency:(\S+)\s+\S+',                 # Frequency (GHz)
        r'\(Channel\s(\d+)\)',                    # Channel (1-11)
        r'Bit Rates:.*(\d+)\s+\S+$',              # Bit rate (Mbps)
        r'Encryption key:(\S+)',                  # Encryption key (on/off)
        r'Authentication Suites[^:]*:\s*(\S+)',   # Authentication (EAP, PSK)
        r'IE: (.*WPA.*)')                         # WPA flavor


    parseString = r'(?:\s+(?:%s|.*))+'%'|'.join(parseStrings)
    rx_blockparse = re.compile(parseString)
    rx_blocksplit = re.compile(r'\s+Cell\s+\d+\s+.*(?:\s{16,}.*)+')


    def isRelevant (self):
        ### Return True if this provider supports the current OS/configuration.
        try:
            self.runcommand((self.IWLIST, "--version"))
            return True
        except self.ExitStatus:
            return False
            

    def listValues (self, key):
        ### Return a list of possible values for "key".
        ### This is optional.
        pass


        

    def ssidmap (self, interface):
        text   = self.runcommand((self.IWLIST, interface, "scan"))
#        text = file("/home/tor/iwlist.txt").read()
        qualitymap = {}
        networkmap = {}
        
        for block in self.rx_blocksplit.findall(text):
            try:
                groups  = self.rx_blockparse.search(block).groups()
                items   = zip(self.ATTRIBUTES, groups)
                apinfo  = dict(items)
                ssid    = apinfo.pop(self.SSID).decode('string-escape')
                quality = eval("1.0 * %s"%(apinfo.pop(self.QUALITY, '0')))

            except AttributeError:
                logging.info('IWList output block did not contain usable information: %s'%block)

            except KeyError:
                logging.info('IWList output contains no SSID: %r'%(block.replace('\n', '\n  >>')))

            except Exception, e:
                logging.info('Error parsing signal quality in IWList output %r: [%s] %s'%
                             (block, e.__class__.__name__, e))

            else:
                if ssid and (ssid[0] != '\0') and (quality > qualitymap.get(ssid)):
                    qualitymap[ssid] = quality
                    authentication   = apinfo.pop(self.AUTHENTICATION, None)

                    if apinfo.pop(self.ENCRYPTION, None) == 'on':
                        if apinfo.get(self.WPASUITE):
                            encryption  = 'WPA'
                            negotiation = 'PSK'
                        else:
                            encryption  = 'WEP'
                            negotiation = 'OPEN'

                        if authentication == '802.1x':
                            negotiation = 'EAP'

                        authentication = "-".join((encryption, negotiation))

                    else:
                        authentication = "NONE"
                        
                    apinfo.update(authentication=authentication, quality=quality)
                    networkmap[ssid] = [(key, apinfo[key]) for key in self.ATTRIBUTES
                                        if apinfo.get(key) is not None]



        return networkmap


    def get (self, interface, uptime=5):
        if uptime:
            flagsfile = "/".join((self.DEVICEFOLDER, interface, "flags"))
            flags     = int(file(flagsfile).read().strip(), 0)
            enabled  = flags & 0x0001

            if not enabled:
                logging.debug("Bringing up interface %s for %s seconds..."%(interface, uptime))
                file(flagsfile, 'w').write("0x%04X\n"%(flags | 0x0001))
                time.sleep(uptime)

        else:
            enabled = True


        ssidmap = self.ssidmap(interface)

        if not enabled:
            file(flagsfile, 'w').write("0x%04X\n"%(flags))

        return { self.SSIDSCAN: ssidmap }


    def validate (self, valuemap={}, *args, **opts):
        ### Validate any keys supplied in "valuemap"
        ### Return True if authorative validation has been performed.
        ### Raise SysConfigError if arguments are invalid.
        pass

    def configure (self, valuemap={}, *args, **opts):
        ### Update system configuration with new values.
        ### Return True if this provider was able to make the change.
        pass

    def apply (self, valuemap, *args, **opts):
        ### Apply any changes that were made to system configuration.
        ### This is only invoked if "configure()" returned True, and if "apply"
        ### was specified in the "SysConfig.set()" invocation.
        pass
    


base.addProvider(WiFiScanProvider)

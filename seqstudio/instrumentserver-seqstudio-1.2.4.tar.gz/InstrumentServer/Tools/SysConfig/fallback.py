########################################################################
### FILE:	avahi.py
### PURPOSE:	AVAHI daemon SysConfig plugin
### HISTORY:
###  2016-10-31 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

import os
import logging
import base


class FallbackProvider (base.GlobalProvider):
    '''Return default values if no better provider exists'''
    
    KEYS = (PROXY, PROXYEXEC) = ('proxy', 'proxyexec') 

    def isRelevant (self):
        return True


    def listValues (self, key):
        ### Return a list of possible values for "key".
        ### This is optional.
        pass


    def get (self, *args, **opts):
        ### Return a dictionary with keys from "self.KEYS",
        ### filling in values from actual system settings.
        valuemap = {}.fromkeys(self.keys(), None)

        ### Do Stuff
        return valuemap


    def validate (self, valuemap={}, *args, **opts):
        ### Validate any keys supplied in "valuemap"
        ### Return True if authorative validation has been performed.
        ### Raise SysConfigError if arguments are invalid.
        pass

    def configure (self, valuemap={}, *args, **opts):
        ### Update system configuration with new values.
        ### Return True if a call to "apply()" is needed for changes to take effect.
        pass

    def apply (self, valuemap, *args, **opts):
        ### Apply any changes that were made to system configuration.
        ### This is only invoked if "configure()" returned True, and if "apply"
        ### was specified in the "SysConfig.set()" invocation.
        pass
    

base.addProvider(FallbackProvider)

########################################################################
### FILE:	timezone.py
### PURPOSE:	Generic Network Configuration for Linux systems
### HISTORY:
###  2013-01-20 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################


from base import addProvider, GlobalProvider, NetInterfaceProvider, SysConfigError

import os
import time
import logging


class PythonZoneProvider (GlobalProvider):
    KEYS   = (TIMEZONE, ) = ('timezone',)

    class NoSuchZone (SysConfigError):
        "Invalid timezone: %(zone)r"

    try:
        from pytz import common_timezones as tzlist
        gotPYTZ = True
    except ImportError:
        gotPYTZ = False

    def isRelevant (self):
        return self.gotPYTZ

    def listValues (self, key):
        return self.tzlist

    def validate (self, keys):
        if self.TIMEZONE in keys:
            zone = keys[self.TIMEZONE]
            if not zone in self.tzlist:
                raise self.NoSuchZone(zone=zone)

        return True



# Disable for now, we want the full list of zones in /usr/share/zoneinfo (below)
#addProvider(PythonZoneProvider)



class PosixZoneProvider (GlobalProvider):
    KEYS   = (TIMEZONE, ) = ('timezone',)
    TZROOT = "/usr/share/zoneinfo"
    TZLINK = "/etc/localtime"
    TZSKIP = len(TZROOT) + len(os.path.sep)
    TZFILE = "/etc/timezone"
    CCFILE = "zone.tab"
    CNFILE = "iso3166.tab"

    areaMap = {
        "America" : "Americas",
        "Pacific" : "Pacific Ocean",
        "Atlantic": "Atlantic Ocean",
        "Arctic"  : "Arctic Ocean",
        "Indian"  : "Indian Ocean" }

    areaList = [ "America", "Atlantic",
                 "Europe", "Africa", "Asia",
                 "Indian", "Australia", "Pacific",
                 "Arctic", "Antarctica", None ]

    countryList = { "America": [ "US", "CA", "MX" ] }
    genericList = [ ("GMT", "Universal Time") ]


    countryNames = {}
    zonesByAreaAndCountry = {}


    class NoSuchZone (SysConfigError):
        "No such zone exists on this system: %(zone)s"

    def isRelevant (self):
        return os.path.isdir(self.TZROOT)



    def mapZone (self, countryCode=None, coordinates=None, zoneName=None, description=None):
        zone = dict(countryCode=countryCode, coordinates=coordinates,
                    zoneName=zoneName, description=description)

        try:
            area, city = zoneName.split("/", 1)
        except ValueError:
            area, aname  = None, "-",
        else:
            aname = self.areaMap.get(area, area)


        cname = self.countryNames.get(countryCode, countryCode)
        zone.update(areaName=aname, countryName=cname)

        if description == None:
            zone.update(description=cname)

        clist = self.countryList.setdefault(area, [])
        if not countryCode in clist:
            clist.append(countryCode)

        if not area in self.areaList:
            logging.info("Adding previously unknown timezone area %r"%area)
            self.areaList.append(area)

        self.zonesByAreaAndCountry.setdefault(area, {}).setdefault(countryCode, []).append(zone)



    def mapZones (self):
        if not self.countryNames:
            filename = os.path.join(self.TZROOT, self.CNFILE)
            for line in file(filename):
                if not line.startswith("#"):
                    try:
                        code, name = line.rstrip().split('\t')
                    except ValueError:
                        logging.warning("Country Name File %s contains malformatted line: %s"%
                                        (filename, repr(line.rstrip('\r\n'))))
                    else:
                        self.countryNames[code] = name

        if not self.zonesByAreaAndCountry:
            filename = os.path.join(self.TZROOT, self.CCFILE)
            for line in file(filename):
                if not line.startswith("#"):
                    self.mapZone(*line.rstrip().split('\t'))

            for zonename, description in self.genericList:
                self.mapZone("-", "-",  zonename, description)
                        




    def listValues (self, key, areaName=None, countryCode=None, countryName=None, verbose=False):
        self.mapZones()

        if areaName is not None:
            areas = []
            lowerArea = areaName.lower()
            for area in self.areaList:
                if self.areaMap.get(area, area or "").lower() == lowerArea:
                    areas.append(area)
                    break
        else:
            areas = self.areaList


        if countryCode:
            cc = countryCode.upper()
            
        elif countryName:
            lowerName = countryName.lower()
            for code, name in self.countryNames.iteritems():
                if name.lower() == lowerName:
                    cc = countryCode
                    break
            else:
                cc = '..'

        else:
            cc = None


        zones = []
        for area in areas:
            zonesByCountry = self.zonesByAreaAndCountry.get(area, {})
            
            if cc:
                countries = [cc]
            else:
                countries = self.countryList.get(area, [])

            for country in countries:
                zones.extend(zonesByCountry.get(country, []))


        if verbose:
            return zones
        else:
            return [ zone["zoneName"] for zone in zones ]





    def validate (self, valuemap):
        if self.TIMEZONE in valuemap:
            zone   = valuemap[self.TIMEZONE]
            tzfile = os.path.join(self.TZROOT, *zone.split('/'))
        
            if not os.path.isfile(tzfile):
                raise self.NoSuchZone(zone=zone)
        


    def configure (self, valuemap):
        if self.TIMEZONE in valuemap:
            zone   = valuemap[self.TIMEZONE]
            tzfile = os.path.join(self.TZROOT, *zone.split('/'))
        
            if os.path.lexists(self.TZLINK):
                os.remove(self.TZLINK)

            os.symlink(tzfile, self.TZLINK)

            if os.path.isfile(self.TZFILE):
                try:
                    file(self.TZFILE, "w").write("%s\n"%(zone,))
                except EnvironmentError, e:
                    logging.warning("Unable to save timezone to file %s: %s"%(e.filename, e))

            if 'TZ' in os.environ:
                os.environ['TZ'] = zone

            return True
        

    def apply (self, valuemap):
        try:
            time.tzset()
        except AttributeError, e:
            logging.warning("Unable to reload new timezone after update: %s"%e)            


    def get (self, current=False):
        if not current:
            value = self.getConfiguredZone()
            return { self.TIMEZONE: value }


    def getZoneFromPath (self, path):
        parts = []
        while path and not os.path.exists(os.path.join(path, self.CCFILE)):
            path, base = os.path.split(path)
            parts.insert(0, base)
        return os.path.join(*parts)


    def getConfiguredZone (self):
        ### If /etc/localtime is a symbolic link, see where it points
        if os.path.islink(self.TZLINK):
            abspath = os.path.join(os.path.dirname(self.TZLINK), os.readlink(self.TZLINK))
            return self.getZoneFromPath(abspath)

        ### Otherwise, compare contents of /etc/localtime with contents
        ### of every file in /usr/share/zoneinfo and return first match
        elif os.path.isfile(self.TZLINK):
            tzdef = hash(file(self.TZLINK).read())
            for top, folders, files in os.walk(self.TZROOT):
                for name in files:
                    filename = os.path.join(top, name)
                    if not os.path.islink(filename) and (hash(file(filename).read()) == tzdef):
                        return filename[self.TZSKIP:]
        return None



addProvider(PosixZoneProvider)

        
class CurrentZoneProvider (GlobalProvider):

    KEYS = (TIMEZONE, ) = ("timezone",)


    def isRelevant (self):
        return bool(time.tzname)


    def get (self, current=False):
        if current:
            value = "".join([c for c in time.tzname[time.localtime()[-1]] if c.isupper()])
            return { self.TIMEZONE: value }

addProvider(CurrentZoneProvider)

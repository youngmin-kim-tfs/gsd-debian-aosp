########################################################################
### FILE:	proxychains.py
### PURPOSE:	ProxyChains SysConfig plugin
### HISTORY:
###  2019-03-28 Tor Slettnes
###             Created
###
### Copyrights (C) 2019 ThermoFisher Scientific.  All rights reserved.
########################################################################

import os
import logging
import base
import re
#import urllib
import socket

class ProxyChains4Config (base.NetNameProvider):
    KEYS = (PROXY,) = ('proxy',)
    
    fields = ('type', 'server', 'port', 'username', 'password', 'proxydns')
    (TYPE, SERVER, PORT, USER, PASSWORD, PROXYDNS) = range(len(fields))
    
    CONFIGFILE = "/etc/proxychains4.conf"
    PROXYTYPES = (HTTP, SOCKS4, SOCKS5) = ('http', 'socks4', 'socks5')
    
    (PROXY_DNS, PROXY_LIST) = ('proxy_dns', 'ProxyList')

    _rx_comment   = re.compile(r'\s*#.*$', re.S)
    #_rx_uncomment = re.compile(r'\s*(.*\S)\s*#.*$', re.S)
    _rx_proxydns  = re.compile(r'\s*(\#*)\s*(' + PROXY_DNS + r'(?:\#|\s|$))')
    _rx_proxylist = re.compile(r'\s*\[' + PROXY_LIST + '\](?:\#|\s|$)')

    class InvalidProxyType (base.NetNameProvider.NetConfigError):
        "Invalid %(key)s: %(value)s"

    def isRelevant (self):
        ### Return True if this provider supports the current OS/configuration.
        return os.path.exists(self.CONFIGFILE)

    def listValues (self, key):
        ### Return a list of possible values for "key".
        ### This is optional.
        pass


    def loadconf (self):
        proxytype, server, port, user, password = None, None, None, None, None
        dnsproxy = False
        inlist  = False
        with file(self.CONFIGFILE) as configfile:
            for line in configfile:
                proxyListMatch = self._rx_proxylist.match(line)
                proxyDNSMatch  = self._rx_proxydns.match(line)
                words = self._rx_comment.sub('', line).split(None, 4)

                if proxyDNSMatch and not proxyDNSMatch.group(1):
                    dnsproxy = True
                elif proxyListMatch:
                    inlist = True
                elif inlist and words:
                    try:
                        proxytype, server, port, user, password = words
                    except ValueError:
                        try:
                            proxytype, server, port = words
                        except ValueError:
                            continue
#                    else:
#                        user = urllib.unquote(user)
#                        password =  urllib.unquote(password)

                    try:
                        port = int(port)
                        break
                    except ValueError:
                        logging.warning("Invalid port number %r in proxy spec: %s (%s)"%(port, words, line.strip()))


        return proxytype, server, port, user, password, dnsproxy


    def saveconf (self, proxytype=None, server=None, port=None, username=None, password=None, dnsproxy=False):
        lines = []
        foundProxyDNS  = False
        inlist  = False

        with file(self.CONFIGFILE) as configfile:
            for line in configfile:
                proxyListMatch = self._rx_proxylist.match(line)
                proxyDNSMatch  = self._rx_proxydns.match(line)

                if proxyDNSMatch and not foundProxyDNS:
                    line = ('#','')[dnsproxy] + proxyDNSMatch.group(2)
                    foundProxyDNS = True

                elif proxyListMatch:
                    if dnsproxy and not foundProxyDNS:
                        lines.append(self.PROXY_DNS + '\n\n')
                        foundProxyDNS = True

                    inlist = True

                elif inlist and self._rx_comment.sub('', line):
                    continue

                lines.append(line)

        if not None in (proxytype, server):
            words = (proxytype, server,
                     str(port or 80),
                     username, password)
#                     urllib.quote(username or ''),
#                     urllib.quote(password or ''))
            lines.append('\t'.join(filter(None, words)) + '\n')

        with file(self.CONFIGFILE, 'w') as configfile:
            configfile.writelines(lines)

    def getAddressInfo (self, server, port):
        info = socket.getaddrinfo(server, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
        af, socktype, proto, canonname, sockaddr = info[0]
        return sockaddr

    def get (self):
        return self.loadconf()

    def validate (self, valuemap={}, *args, **opts):
        values = valuemap.get(self.PROXY) or ()

        if values:
            if values[self.TYPE] is not None:
                if not values[self.TYPE] in self.PROXYTYPES:
                    raise self.InvalidProxyType(key='proxy type', value=values[self.TYPE])
                self.getAddressInfo(values[self.SERVER], values[self.PORT])
        return True

    def configure (self, valuemap={}, *args, **opts):
        values = list(valuemap.get(self.PROXY) or [])

        if len(values) > self.PORT:
            addrinfo = self.getAddressInfo(values[self.SERVER], values[self.PORT])
            values[self.SERVER], values[self.PORT] = addrinfo

        self.saveconf(*values)
        return True


    def apply (self, valuemap, *args, **opts):
        ### Apply any changes that were made to system configuration.
        ### This is only invoked if "configure()" returned True, and if "apply"
        ### was specified in the "SysConfig.set()" invocation.
        pass
    

base.addProvider(ProxyChains4Config)


class ProxyChains4Executable (ProxyChains4Config):
    KEYS = (PROXYEXEC,) = ('proxyexec',)
    executable = '/usr/bin/proxychains'

    def get (self):
        return self.executable


base.addProvider(ProxyChains4Executable)
    

########################################################################
### FILE:	posix.py
### PURPOSE:	Configuration provider for POSIX compatible systems
### HISTORY:
###  2013-01-25 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

from base    import GlobalProvider, NetNameProvider, NetInterfaceProvider, addProvider
from os.path import isfile
from re      import findall, subn

try:
    from os      import statvfs
    gotFSTAT = True
except ImportError:
    gotFSTAT = False



class HostLookupProvider (NetNameProvider):

    HOSTSFILE = "/etc/hosts"
    KEYS = (HOSTNAME, ) = ('hostname', )


    def isRelevant (self):
        return isfile(self.HOSTSFILE)


    def configure (self, valuemap):
        try:
            text = file(self.HOSTSFILE).read()
        except EnvironmentError:
            text = ''

        if self.HOSTNAME in valuemap:
            text, count = subn(r'((?:^|\n)127.0.1.1)[ \t].*\n?',
                               r'\1\t%(hostname)s\n'%valuemap,
                               text)
            if not count:
                text += '\n127.0.1.1\t%(hostname)s\n'%valuemap

        self.safeSave(self.HOSTSFILE, text)


addProvider(HostLookupProvider)


class DomainNameServiceProvider (NetInterfaceProvider):

    KEYS = (DNSSERVERS, DNSSEARCH) =\
        ('dnsservers', 'dnssearch')

    RESOLVCONF = "/etc/resolv.conf"
    NSSWITCH   = "/etc/nsswitch.conf"

    def isRelevant (self):
        return isfile(self.RESOLVCONF) or isfile(self.NSSWITCH)


    def get (self, interface, current=False):
        try:
            text = file(self.RESOLVCONF).read()
        except IOError:
            text = ""

        dns     = findall(r'nameserver\s+(\S+)', text)
        suffix  = findall(r'(?:domain|search)\s+(\S+)', text)
        search  = findall(r'(?:search\s+(\S+))+', text)

        return { self.DNSSERVERS: dns,
                 self.DNSSEARCH : search }


    def validate (self, valuemap, interface):
        servers = valuemap.get(self.DNSSERVERS)
        search = valuemap.get(self.DNSSEARCH)

        if servers:
            for server in servers:
                if not self.isValidIP(server):
                    raise self.InvalidAddress(key="DNS server address", value=server)

        if search:
            for search in valuemap.get(self.DNSSEARCH, []):
                self.check(search, "search domain", fqdn=True)

        return True


    def configure (self, valuemap, interface):
        settings = self.get(interface)
        for key, value in valuemap.items():
            if value is not None:
                settings.update(valuemap)

        text = []

        servers = settings.get(self.DNSSERVERS)
        search = settings.get(self.DNSSEARCH)

        if servers:
            for server in servers:
                text.append('nameserver %s\n'%server)


        if search:
            for search in search:
                text.append('search %s\n'%search)


        self.safeSave(self.RESOLVCONF, text)
        return True



addProvider(DomainNameServiceProvider)



class PosixStorageProvider (GlobalProvider):
    KEYS = ('totalspace', 'usedspace', 'availablespace')
    TOTAL, USED, AVAILABLE = KEYS


    def isRelevant (self):
        return gotFSTAT


    def get (self, path):
        f = statvfs(path)

        return {
            self.TOTAL: f.f_bsize * f.f_blocks,
            self.USED: f.f_bsize * (f.f_blocks - f.f_bavail),
            self.AVAILABLE: f.f_bsize * f.f_bavail }


addProvider(PosixStorageProvider)

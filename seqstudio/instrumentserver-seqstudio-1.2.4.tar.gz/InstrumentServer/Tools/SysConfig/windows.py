########################################################################
### FILE:	windows.py
### PURPOSE:	Configuration provider for Windows compatible systems
### HISTORY:
###  2014-03-29 Tor Slettnes
###             Created
###
### Copyrights (C) 2015 Life Technologies.  All rights reserved.
########################################################################

from base    import GlobalProvider, addProvider

import platform

if platform.system() == 'Windows':
    from ctypes import windll, c_ulonglong, c_wchar_p, pointer
    gotDLL = True
else:
    gotDLL = False


class WindowsStorageProvider (GlobalProvider):
    KEYS = ('totalspace', 'usedspace', 'availablespace')
    TOTAL, USED, AVAILABLE = KEYS


    def isRelevant (self):
        return gotDLL
        

    def get (self, path):
        avail = c_ulonglong(0)
        total = c_ulonglong(0)
        free  = c_ulonglong(0)
        
        windll.kernel32.GetDiskFreeSpaceExW(c_wchar_p(path),
                                            pointer(avail),
                                            pointer(total),
                                            pointer(free))

        return {
            self.TOTAL     : total.value,
            self.USED      : total.value - free.value,
            self.AVAILABLE : free.value }
            

addProvider(WindowsStorageProvider)

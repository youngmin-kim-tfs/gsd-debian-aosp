########################################################################
### FILE:	pythonzones.py
### PURPOSE:	Generic Network Configuration for Linux systems
### HISTORY:
###  2013-01-20 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################


########################################################################
### FILE:	avahi.py
### PURPOSE:	AVAHI daemon SysConfig plugin
### HISTORY:
###  2016-10-31 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

import os
import logging
import base


class MyProvider (base.GlobalProvider):
    
    KEYS = (KEY1, KEY2) =\
        ('mdns', 'key2')


    def isRelevant (self):
        ### Return True if this provider supports the current OS/configuration.
        return False


    def listValues (self, key):
        ### Return a list of possible values for "key".
        ### This is optional.
        pass


    def get (self, *args, **opts):
        ### Return a dictionary with keys from "self.KEYS",
        ### filling in values from actual system settings.
        valuemap = {}.fromkeys(self.keys(), None)

        ### Do Stuff
        return valuemap


    def validate (self, valuemap={}, *args, **opts):
        ### Validate any keys supplied in "valuemap"
        ### Return True if authorative validation has been performed.
        ### Raise SysConfigError if arguments are invalid.
        pass

    def configure (self, valuemap={}, *args, **opts):
        ### Update system configuration with new values.
        ### Return True if this configuration is authoriative, i.e.,
        ### if the specified items can now be considered configured.
        pass

    def apply (self, valuemap, *args, **opts):
        ### Apply any changes that were made to system configuration.
        ### This is only invoked if "configure()" returned True, and if "apply"
        ### was specified in the "SysConfig.set()" invocation.
        pass
    


base.addProvider(MyProvider)


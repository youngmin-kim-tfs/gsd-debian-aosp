########################################################################
### FILE:	sysconfigBase.py
### PURPOSE:	Abstract system configuration interface.
###             This module is not normally used loaded directly; 
###             instead, implementation modules need to be supplied
###             for each supported target OS (e.g: "sysconfigDebian").
### HISTORY:
###  2013-01-20 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################



from base  import DOMAINS, GLOBAL, NETIF
from base  import Provider, SysConfigError, getProviders

import logging
import providers

class SysConfig (object):
    '''System Configuration Interface'''

    class NoProvider (SysConfigError):
        'There is no mechanism to %(action)s %(key)r on this system'

    def __init__ (self, domain, *args):
        self.pending   = []
        self.domain    = domain
        self.providers = None
        self.args      = args
        self.hooks     = {}

    def initProviders (self, domain):
        self.providers = {}

        for provider in base.getProviders(domain, []):
            keys = provider.keys()
            logging.debug("Attaching %r SysConfig provider to domain %r, keys: %s"%
                          (domain, provider.name, ", ".join(keys)))
            for key in keys:
                self.providers.setdefault(key, []).append(provider)
    

    def getProviders (self, key):
        if self.providers is None:
            self.initProviders(self.domain)

        return self.providers.get(key, [])


    def getProvider (self, key, ignoreMissing=False):
        providers = self.getProviders(key)
        if providers:
            return providers[0]
        elif not ignoreMissing:
            raise self.NoProvider(action="access", key=key, domain=self.domain)


    def listValues (self, key, *args, **kwargs):
        for provider in self.getProviders(key):
            try:
                return provider.listValues(key, *args, **kwargs)
            except NotImplementedError:
                pass
        else:
            raise self.NoProvider(action="enumerate", key=key, domain=self.domain)


    def get (self, keys, *args, **kwargs):
        if isinstance(keys, (tuple, list)):
            return self.getvalues(keys, *args, **kwargs)
        else:
            return self.getvalue(keys, *args, **kwargs)


    def getvalues (self, keys, *args, **kwargs):
        valuemap = self.getdict(keys, *args, **kwargs)
        return tuple([ valuemap.get(k) for k in keys ])


    def getvalue (self, key, *args, **kwargs):
        valuemap = self.getdict((key,), *args, **kwargs)
        return valuemap.get(key)


    def getdict (self, keys, *args, **kwargs):
        valuemap = {}
        calledProviders = set()
        providermap = {}

        for key in keys:
            for provider in self.getProviders(key):
                if not key in valuemap and not provider in calledProviders:
                    try:
                        update = provider.get(*args, **kwargs)

                    except NotImplementedError:
                        pass

                    except Exception, e:
                        logging.warning("SysConfig: Failed to get key %r from provider %r: [%s] %s"%
                                        (key, provider.name, e.__class__.__name__, e))
                        raise

                    else:
                        if isinstance(update, dict):
                            for k, v in update.items():
                                valuemap.setdefault(k, v)

                        elif update is not None:
                            if len(provider.keys()) == 1:
                                valuemap.setdefault(key, update)
                            else:
                                raise AssertionError("Provider %s returned non-dictionary value %r"
                                                     "in response to request for: %s."%
                                                     (provider.__class__.__name__,
                                                      update, ",".join(keys)))

                        calledProviders.add(provider)


            if not key in valuemap:
                raise self.NoProvider(action="get", key=key, domain=self.domain)


        return valuemap


    def set (self, valuemap, apply=True, **kwargs):
        self.validate(valuemap, **kwargs)
        self.configure(valuemap, apply=apply, **kwargs)


    def validate (self, valuemap, *args, **kwargs):
        calledProviders = set()
        validatedKeys   = set()

        for key in valuemap:
            candidates = self.getProviders(key)

            for provider in candidates:
                if not provider in calledProviders:
                    providermap = dict([(k, valuemap[k])
                                        for k in provider.keys()
                                        if k in valuemap ])

                    providerkeys = set(providermap)

                    if providerkeys - validatedKeys:
                        logging.debug("SysConfig: Invoking %s provider %s to validate keys: %s"%
                                      (self.domain,
                                       provider.__class__.__name__,
                                       ",".join(sorted(providerkeys))))

                        try:
                            if provider.validate(providermap, *args, **kwargs):
                                validatedKeys |= providerkeys
                        except Exception, e:
                            logging.warning("SysConfig: Provider %r failed to validate keys %s: [%s] %s"%
                                            (provider.name, ",".join(providerkeys), e.__class__.__name__, e))
                            raise

                    calledProviders.add(provider)

        missing = set(valuemap) - validatedKeys
        return not missing


    def configure (self, valuemap, apply, *args, **kwargs):
        calledProviders = set()
        configuredKeys  = set()
        pending = []
        locked  = []

        allproviders = set()
        for key in valuemap:
            allproviders.update(self.getProviders(key))

        try:
            for provider in allproviders:
                provider.lock()
                locked.append(provider)


            for key in valuemap:
                candidates = self.getProviders(key)

                for provider in candidates:
                    if not provider in calledProviders:
                        providermap = dict([(k, valuemap[k])
                                            for k in provider.keys()
                                            if k in valuemap ])

                        try:
                            logging.debug("SysConfig: Invoking %s provider %s to configure keys: %s"%
                                          (self.domain, provider.__class__.__name__, ",".join(sorted(providermap))))

                            if ((not apply or provider.reset(providermap, *args, **kwargs)) and
                                provider.configure(providermap, *args, **kwargs)):
                                configuredKeys |= set(providermap)
                                task = (provider, providermap, args, kwargs)
                                if apply and not task in pending:
                                    pending.append(task)

                        except NotImplementedError:
                            pass

                        except Exception, e:
                            logging.warning("SysConfig: Provider %r failed to configure keys %s: [%s] %s"%
                                            (provider.name, ",".join(sorted(providermap)), e.__class__.__name__, e))
                            raise
                            
                        
                        calledProviders.add(provider)

            unset = sorted(set(valuemap) - configuredKeys)

            if unset:
                raise self.NoProvider(action="configure", key="/".join(unset), domain=self.domain)

            if apply:
                for provider, keymap, args, kwargs in pending:
                    logging.debug("SysConfig: Invoking %s provider %s to apply changes to keys: %s"%
                                  (self.domain,
                                   provider.__class__.__name__,
                                   ", ".join(sorted(keymap))))

                    provider.apply(keymap, *args, **kwargs)

        finally:
            for provider in locked:
                provider.unlock()

        if apply:
            self.runhooks(valuemap)


    def runhooks_single (self, valuemap):
        argmap = {}
        for key, method in self.hooks.items():
            try:
                callbacks.setdefault(method, {})[key] = valuemap[key]
            except KeyError:
                pass

        for method, localdata in callbacks.iteritems():
            logging.debug("SysConfig: Invoking command hook for domain %r: %s(%s)"%
                          (self.domain, method.__name__, localdata))
            method(localdata)

            
    def runhooks (self, valuemap):
        callbacks = {}
        for key, invocation in self.hooks.items():
            try:
                method, args = invocation
                callbacks.setdefault((method, tuple(args)), {})[key] = valuemap[key]
            except KeyError:
                pass

        for invocation, localdata in callbacks.iteritems():
            method, args = invocation
            logging.debug("SysConfig: Invoking command hook for domain %r: %s(%s%s)"%
                          (self.domain,
                           method.__name__,
                           ", ".join([repr(arg) for arg in args]),
                           "".join([", %s=%r"%item for item in valuemap.items()])))
            method(*args, **valuemap)


sysconfig = SysConfig(GLOBAL)
netconfig = SysConfig(NETIF, 'interface')
SysConfigDomains = {GLOBAL:sysconfig, NETIF:netconfig}


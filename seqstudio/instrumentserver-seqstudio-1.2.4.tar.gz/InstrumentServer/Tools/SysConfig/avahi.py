########################################################################
### FILE:	avahi.py
### PURPOSE:	AVAHI daemon SysConfig plugin
### HISTORY:
###  2016-10-31 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

import base
import xmlGenerator

import os
import os.path
import logging
import xml.dom.minidom
import htmlentitydefs
import re
import pyexpat
import cgi

#try:
#    import xml.etree.ElementTree
#    gotElementTree = True
#except ImportError:
#    gotElementTree = False



class AvahiProvider (base.GlobalProvider):
    DEFAULT_TYPE = "_abi-instrument._tcp"
    

class AvahiDaemon (AvahiProvider):
    AVAHIDAEMON = "/usr/sbin/avahi-daemon"

    KEYS = (TYPE_KEY, PORT_KEY, NAME_KEY,
            PRODUCT, MODEL, DESCRIPTION, VERSION, SERIALNUMBER, HOSTNAME) = \
           ('servicetype', 'serviceport', 'servicename',
            'product', 'model', 'description', 'version', 'serialnumber', 'hostname')

    DEFAULT_PORT = "7000"
    DEFAULT_NAME = "%h"
    
    TAGS = {
        TYPE_KEY : "type",
        PORT_KEY : "port",
        NAME_KEY : "name"
    }


    AVAHIDAEMON = "/usr/sbin/avahi-daemon"
    RELOAD      = (AVAHIDAEMON, "--reload")
    #RESTART     = ("/usr/sbin/service", "avahi-daemon", "restart")
    SERVICEDIR  = "/etc/avahi/services"
    SERVICEFILE = SERVICEDIR + "/instrument.service"
    ENCODING    = 'utf-8'

    ordX      = re.compile(r'&#(\d+);')
#    escapeX   = re.compile(r'([&\<\>\"\x7F-\xFF]|[^\x00-\xFF])')
    unescapeX = re.compile(r'(&(?:\w+|#\d+);)')

#    escapes    = {}
    unescapes  = {}
    for (code, char) in htmlentitydefs.entitydefs.items():
        string = '&%s;'%code
        if len(char) == 1:
#            escapes[char] = string
            unescapes[string] = char
        else:
            match = ordX.match(char)
            if match:
                c = unichr(int(match.group(1)))
#                escapes[c] = string
                unescapes[string] = unescapes[char] = c

    def isRelevant (self):
        return os.path.exists(self.AVAHIDAEMON) and os.path.isdir(self.SERVICEDIR)

    def listValues (self, key):
        pass

    def getText (self, node):
        strings = []
        for child in node.childNodes:
            if child.nodeType == child.TEXT_NODE:
                strings.append(child.data)

        return ''.join(strings)

    def escapeString (self, string):
        if not isinstance(string, unicode):
            string = string.decode(self.ENCODING)

#        parts = []
#        for i, part in enumerate(self.escapeX.split(string)):
#            if i % 2 == 1:
#                part = self.escapes.get(part, part)
#            parts.append(part)
#
#        return ''.join(parts).encode(self.ENCODING)

        return cgi.escape(string).encode('ascii', 'xmlcharrefreplace')

    def unescapeString (self, string):
        parts = []
        for i, part in enumerate(self.unescapeX.split(string)):
            if i % 2 == 1:
                part = self.unescapes.get(part, part)
            parts.append(part)
        return ''.join(parts)


    def get (self, *args, **opts):
        valuemap = {}.fromkeys((self.NAME_KEY, self.TYPE_KEY, self.PORT_KEY))

        try:
            doc = xml.dom.minidom.parse(self.SERVICEFILE)
        except (EnvironmentError, pyexpat.ExpatError), e:
            logging.warning("Unable to parse Avahi service file: [%s] %s"%(e.__class__.__name__, e))
        else:
            for key, tagname in self.TAGS.items():
                for element in  doc.getElementsByTagName(tagname):
                    valuemap[key] = self.getText(element)

            for element in doc.getElementsByTagName('txt-record'):
                try:
                    key, value = self.getText(element).split('=', 1)
                except ValueError:
                    pass
                else:
                    valuemap[key] = self.unescapeString(value)

            doc.unlink()

        return valuemap


    def validate (self, valuemap={}, *args, **opts):
        try:
            int(valuemap[self.PORT_KEY])
        except (KeyError, TypeError):
            pass
        except ValueError:
            raise base.SysConfigError("Invalid value for key %r: %r"%
                                      (self.PORT_KEY, valuemap[PORT_KEY]))


    def configure (self, valuemap={}, *args, **opts):
        map = self.get()
        map.update(valuemap)

        servicename = valuemap.get(self.NAME_KEY, map.pop(self.HOSTNAME, map.pop(self.NAME_KEY))) or self.DEFAULT_NAME
        servicetype = map.pop(self.TYPE_KEY) or self.DEFAULT_TYPE
        serviceport = map.pop(self.PORT_KEY) or self.DEFAULT_PORT

        xml = xmlGenerator.XMLDocument('service-group', system='avahi-service.dtd', encoding=self.ENCODING)
        name = xml.name(servicename, replace_wildcards='yes')

        service = xml.service()
        service.type(servicetype)
        service.port(str(serviceport))

        for key, value in map.items():
            if value is not None:
                xmlvalue = self.escapeString(value)
                service.txt_record('%s=%s'%(key, xmlvalue))

        lines = xml()
        fp = file(self.SERVICEFILE, 'w')
        text = ''.join(lines).encode(self.ENCODING)
        file(self.SERVICEFILE, 'w').write(text)
        return True


    def addElement (self, parent, name, type=xml.dom.minidom.Element, text=None, **attributes):
        child = xml.dom.minidom.Element(name)
        for key, value in attributes.items():
            child.setAttribute(key, value)

        if text is not None:
            textnode = xml.dom.minidom.Text(text)
            child.appendChild(textnode)

        return parent.appenChild(child)


#    def configure_dom (self, valuemap={}, *args, **opts):
#        map = self.get()
#        map.update(valuemap)
#        
#        servicename = map.pop(self.NAME_KEY, None)
#        servicetype = map.pop(self.TYPE_KEY, None)
#        serviceport = map.pop(self.PORT_KEY, None)
#        hostname    = map.pop(self.HOSTNAME, None)
#
#        ### New XML document
#        doc = xml.dom.minidom.Document()
#
#        dt = doc.appendChild(xml.dom.minidom.DocumentType('service-group'))
#        dt.systemId = 'avahi-service.dtd'
#
#        sg = doc.appendChild(doc.createElement('service-group'))
#
#        name = sg.appendChild(doc.createElement('name'))
#        name.setAttribute('replace-wildcards', 'yes')
#        name.appendChild(doc.createTextNode((servicename, '%h')[servicename is None]))
#
#        svc = sg.appendChild(doc.createElement('service'))
#        for item in map.items():
#            txt = svc.appendChild(doc.createElement('txt-record'))
#            txt.appendChild(doc.createTextNode("%s=%s"%item))
#
#        doc.writexml(file(self.SERVICEFILE, 'w'), addindent="  ", newl="\n", encoding=self.ENCODING)
#        doc.unlink()
#        return True

    def apply (self, valuemap, *args, **opts):
        #if 'hostname' in valuemap:
        #    self.runcommand(self.RESTART)
        #else:
        try:
            self.runcommand(self.RELOAD)
        except self.ExitStatus, e:
            logging.warning("Unable to reload daemon after applying settings %s, invocation=%s: [%s] %s"%
                            (valuemap, self.RELOAD, type(e).__name__, e))
            


base.addProvider(AvahiDaemon)


class AvahiBrowser (AvahiProvider):
    AVAHIBROWSER = "/usr/bin/avahi-browse"
    KEYS = (MDNSBROWSE,) = ("mdnsbrowse",)

    INVOCATION = (AVAHIBROWSER, "-r", "-p", "-t", "%(servicetype)s")

    def isRelevant (self):
        try:
            text = self.runcommand((self.AVAHIBROWSER, '-V'))
        except self.ExitStatus, e:
            logging.debug("SysConfig: Not enabling mDNS browsing: [%s] %s"%(e.__class__.__name__, e))
            return False
        else:
            return True


    def get (self, servicetype=AvahiProvider.DEFAULT_TYPE):
        command = [ fmt%locals() for fmt in self.INVOCATION ]
        output  = self.runcommand(command)
        hosts   = {}

        for line in output.splitlines():
            try:
                resolved, interface, protocol, name, servicetype, domain, fullname, address, port, text = line.split(";")
            except ValueError:
                pass
            else:
                host = hosts.setdefault(name.lower(), {})
                host[protocol.lower()] = address
                host.update(serviceport=port)
                host.update(filter(lambda i: len(i) == 2, [ item.split("=",1) for item in text.strip('"').split('" "') ]))

        return { self.MDNSBROWSE : hosts }

base.addProvider(AvahiBrowser)

########################################################################
### FILE:	debian.py
### PURPOSE:	System Configuration for Debian-like OSes
### HISTORY:
###  2013-01-20 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################


import base
import linux
import os.path
import re
import time
import socket
import logging


class DebianProvider (base.GlobalProvider):

    KEYS        = ("distribution",)
    VERSIONFILE = "/etc/debian_version"

    def isRelevant (self):
        return os.path.exists(self.VERSIONFILE)

    def get (self):
        return "Debian %s"%file(self.VERSIONFILE).read().strip()


base.addProvider(DebianProvider)


class DebianHostnameProvider (base.NetNameProvider):

    KEYS = (HOSTNAME,) = ('hostname',)
    HOSTFILE     = "/etc/hostname"
    HOSTCOMMAND  = "/bin/hostname"

    def isRelevant (self):
        return os.path.exists(self.HOSTFILE)


    def validate (self, valuemap):
        if self.HOSTNAME in valuemap:
            return self.check(valuemap[self.HOSTNAME], "host name")

    def configure (self, valuemap):
        self.safeSave(self.HOSTFILE, "%(hostname)s\n"%valuemap)
        return True
    
    def get (self):
        return file(self.HOSTFILE).read().strip()

    def apply (self, valuemap):
        self.runcommand((self.HOSTCOMMAND, "-F", self.HOSTFILE))



base.addProvider(DebianHostnameProvider)



class DebianHTPDateProvider (base.NetNameProvider):
    KEYS = (HTP, HTPSERVER, HTPPROXY, HTPOPTIONS) = ('htp', 'htpserver', 'htpproxy', 'htpoptions')
    CONFFILE = "/etc/default/htpdate"
    HTPDATE = "/usr/sbin/htpdate"
    DAEMONOPTION = "D"
    ENABLEDOPTIONS = "-D -s"
    DISABLEDOPTIONS = "-s"
    PROXYOPTION = "-P "
    UPDATECOMMAND = ("service", "htpdate", "restart")

    KEYMAP = {
        HTPSERVER  : "HTP_SERVERS",
        HTPPROXY   : "HTP_PROXY",
        HTPOPTIONS : "HTP_OPTIONS"
    }

    def isRelevant (self):
        return os.path.exists(self.CONFFILE) and os.path.exists(self.HTPDATE)


    def validate (self, valuemap):
        if self.HTPSERVER in valuemap:
            self.check(valuemap[self.HTPSERVER], "HTP server", fqdn=True)
        return True


    def readConfig (self):
        text  = file(self.CONFFILE).read()
        items = re.findall(r'(?:^|\n)\s*(\w+)="?([^"\n]+)"?', text)
        lines = re.findall(r'(?:^|\n)\s*(\w[^=\n]*$)', text, re.M)
        return dict(items), lines


    def setValues (self, items, addlines=(), removelines=()):
        logtext = [ "Saving values to %s:"%(self.CONFFILE,) ]
        rx      = re.compile(r'^\s*(?:(\w+)\s*=\s*"?([^"\n]*)"?|(\w[^=\n]*))')
        text    = file(self.CONFFILE).read()
        if not text.endswith("\n"):
            text += '\n'

        for key, value in items:
            text, count = re.subn(r'((?:^|\n)\s*%s=).*\n'%key,
                                  r'\1"%s"\n'%value,
                                  text)
            if not count:
                text += '%s="%s"\n'%(key, value)

            logtext.append('%s="%s" (%s)'%(key, value, count and "replace" or "add"))


        oldlines = re.findall(r'(?:^|\n)(\s*\w[^=]*$)', text, re.M)

        for line in oldlines:
            if line.strip() in removelines:
                text = text.replace(line, '')
                logtext.append("%s (remove)"%(line.rstrip(),))

        oldlines = [ line.strip() for line in oldlines ]

        for line in addlines:
            if not line.strip() in oldlines:
                text += line + '\n'
                logtext.append("%s (append)"%(line,))

        logging.debug("\n  >>".join(logtext))
        self.safeSave(self.CONFFILE, text)


    def get (self, *args, **kwargs):
        options, lines = self.readConfig()
        valuemap = {}

        for key in self.KEYMAP:
            option = self.KEYMAP[key]
            value  = options.get(option)
            valuemap[key] = value

        valuemap[self.HTP] = self.DAEMONOPTION in valuemap[self.HTPOPTIONS]

        # Strip off option flag, if starts with flag
        if valuemap.get(self.HTPPROXY) is not None:
            if valuemap[self.HTPPROXY].startswith(self.PROXYOPTION):
                valuemap[self.HTPPROXY] = valuemap[self.HTPPROXY][len(self.PROXYOPTION):]

        return valuemap


    def configure (self, valuemap):
        enable = valuemap.get(self.HTP)

        if enable is not None:
            valuemap[self.HTPOPTIONS] = (self.DISABLEDOPTIONS, self.ENABLEDOPTIONS)[enable]

        # Prepend option flag, if has something
        if valuemap.get(self.HTPPROXY):
            valuemap[self.HTPPROXY] = self.PROXYOPTION + valuemap[self.HTPPROXY]

        options = [ (self.KEYMAP[key], value)
                    for (key, value) in valuemap.items()
                    if key in self.KEYMAP ]

        self.setValues(options)
        return True


    def apply (self, valuemap):
        self.runcommand(self.UPDATECOMMAND)



base.addProvider(DebianHTPDateProvider)



class DebianNTPDateProvider (base.NetNameProvider):
    KEYS = (NTP, NTPSERVER) = ('ntp', 'ntpserver')
    CONFFILE = "/etc/default/ntpdate"
    NTPDATE = "/usr/sbin/ntpdate-debian"
    UPDATECOMMAND = (NTPDATE, "-b")
    HWCLOCK = "hwclock"

    USE_NTP_CONF  = "NTPDATE_USE_NTP_CONF"
    DISABLED = "exit 0"

    KEYMAP = {
        NTPSERVER : "NTPSERVERS",
    }

    def isRelevant (self):
        return os.path.exists(self.CONFFILE) and os.path.exists(self.NTPDATE)


    def validate (self, valuemap):
        if self.NTPSERVER in valuemap:
            self.check(valuemap[self.NTPSERVER], "NTP server", fqdn=True)
        return True


    def readConfig (self):
        text  = file(self.CONFFILE).read()
        items = re.findall(r'(?:^|\n)\s*(\w+)="?([^"\n]+)"?', text)
        lines = re.findall(r'(?:^|\n)\s*(\w[^=\n]*$)', text, re.M)
        return dict(items), lines
        

    def setValues (self, items, addlines=(), removelines=()):
        logtext = [ "Saving values to %s:"%(self.CONFFILE,) ]
        rx      = re.compile(r'^\s*(?:(\w+)\s*=\s*"?([^"\n]*)"?|(\w[^=\n]*))')
        text    = file(self.CONFFILE).read()
        if not text.endswith("\n"):
            text += '\n'

        for key, value in items:
            text, count = re.subn(r'((?:^|\n)\s*%s=).*\n'%key,
                                  r'\1"%s"\n'%value,
                                  text)
            if not count:
                text += '%s="%s"\n'%(key, value)

            logtext.append('%s="%s" (%s)'%(key, value, count and "replace" or "add"))


        oldlines = re.findall(r'(?:^|\n)(\s*\w[^=]*$)', text, re.M)

        for line in oldlines:
            if line.strip() in removelines:
                text = text.replace(line, '')
                logtext.append("%s (remove)"%(line.rstrip(),))

        oldlines = [ line.strip() for line in oldlines ]

        for line in addlines:
            if not line.strip() in oldlines:
                text += line + '\n'
                logtext.append("%s (append)"%(line,))

        logging.debug("\n  >>".join(logtext))
        self.safeSave(self.CONFFILE, text)


    def get (self, *args, **kwargs):
        options, lines = self.readConfig()
        valuemap = {}


        for key in self.KEYMAP:
            option = self.KEYMAP[key]
            value  = options.get(option)
            valuemap[key] = value

        valuemap[self.NTP] = self.DISABLED not in lines
        return valuemap


    def configure (self, valuemap):
        addlines, removelines = [], []
        enable = valuemap.get(self.NTP)

        if enable is not None:
            if enable:
                removelines.append(self.DISABLED)
            else:
                addlines.append(self.DISABLED)

        options = [ (self.KEYMAP[key], value)
                    for (key, value) in valuemap.items()
                    if key in self.KEYMAP ]

        options.append((self.USE_NTP_CONF, "no"))
        self.setValues(options, addlines, removelines)
        return True


    def apply (self, valuemap):
        self.runcommand(self.UPDATECOMMAND)
        self.runcommand((self.HWCLOCK, "-u", "-w"))



base.addProvider(DebianNTPDateProvider)



class DebianNetworkProvider (base.NetInterfaceProvider, linux.LinuxNetDeviceProvider):

    iffile  = "/etc/network/interfaces"
    enabled = None

    KEYS = (DNSSERVERS, DNSSEARCH) = ("dnsservers", "dnssearch")
    KEYS = base.NetInterfaceProvider.KEYS + KEYS

    KEYMAP = {
        DNSSERVERS : "dns-nameservers",
        DNSSEARCH  : "dns-search" }


    def isRelevant (self):
        return os.path.exists(self.iffile)

    def reset (self, valuemap, interface):
        self.stop(valuemap, interface)
        return True

    def configure (self, valuemap, interface):
        state        = valuemap.get(self.STATE)
        mode         = valuemap.get(self.MODE)
        interfaces   = [ ]
        stanzamap    = { }
        defaults     = { }
        instanza     = None
        newifs       = [ ]
        replacements = ('address', 'netmask', 'gateway', 'dns-nameservers', 'dns-search', 'hostname')

        if mode:
            newifs.append(interface)

        for line in file(self.iffile):
            words = line.split()

            if not words:
                ### Skip empty lines
                pass

            elif words[:2] in (['auto', interface], ['allow-auto', interface], ['allow-hotplug', interface]):
                instanza = None

                if state is None:
                    state = (self.ENABLED, self.HOTPLUG)['hotplug' in words[0]]

                if not interface in interfaces:
                    interfaces.append(interface)

            elif (len(words) >= 2 and
                (words[0] in ('auto', 'iface', 'mapping') or words[0].startswith('allow-'))):
                
                instanza = words[1]
                if not instanza in interfaces:
                    interfaces.append(instanza)

                if not instanza in newifs:
                    stanzamap.setdefault(instanza, []).append(line)

            elif (instanza == interface) and (words[0] == 'wpa-roam'):
                if self.MODE in valuemap:
                    stanzamap['default'] = self.stanzalines('default', None, valuemap[self.MODE], valuemap, defaults)
                    newifs.append('default')

                if state == self.HOTPLUG:
                    state = self.ENABLED

                if mode is not None:
                    mode  = self.MANUAL

                stanzamap.setdefault(instanza, []).append(line)

            elif (instanza in newifs) and (words[0] in replacements):
                defaults.setdefault(words[0], []).extend(words[1:])

            elif (not interfaces or (instanza is not None)):
                stanzamap.setdefault(instanza, []).append(line)


        stanzamap[interface] = self.stanzalines(interface, state, mode, valuemap, defaults) + stanzamap.get(interface, [])

        lines = stanzamap.pop(None, [])
        for interface in interfaces:
            if lines:
                lines.append("\n")
            lines.extend(stanzamap.pop(interface))

        for stanza in stanzamap.values():
            if lines:
                lines.append("\n")
            lines.extend(stanza)

        self.enabled = state in (self.ENABLED, self.HOTPLUG)
        self.safeSave(self.iffile, lines)
        return True


    def stanzalines (self, interface, state, mode, valuemap, defaults):
        stanza = []

        if state == self.ENABLED:
            stanza.append('auto %s\n'%interface)
        elif state == self.HOTPLUG:
            stanza.append('allow-hotplug %s\n'%interface)

        if mode:
            stanza.append('iface %s inet %s\n'%(interface, mode))

            if mode == self.STATIC:
                for statement, key, required in (('address', 'address', True),
                                                 ('netmask', 'netmask', True),
                                                 ('gateway', 'gateway', False),
                                                 ('dns-nameservers', 'dnsservers', False),
                                                 ('dns-search', 'dnssearch', False)):
                    try:
                        value = valuemap[key]
                    except KeyError, e:
                        value = defaults.get(key)
                    else:
                        if isinstance(value, (tuple, list)):
                            value = ' '.join(value)

                    if value:
                        stanza.append('    %-15s %s\n'%(statement, value))
                    elif required:
                        raise self.NetConfigError("Cannot configure network interface %s: %s mode requires %r"%
                                                  (interface, mode, key))

            elif mode == self.DHCP:
                hostname = valuemap.get(self.HOSTNAME, socket.gethostname().split('.')[0])
                stanza.append('    hostname\t%s\n'%hostname)

        return stanza


    def apply (self, valuemap, interface):
        if self.enabled:
            self.start(valuemap, interface)

    def stop (self, valuemap, interface):
        self.runcommand(("/sbin/ifconfig", interface, "0.0.0.0"))
        self.runcommand(("/sbin/ifdown", interface))
        time.sleep(1)

    def start (self, valuemap, interface):
        self.runcommand(("/sbin/ifup", interface))


    def getconfig (self, interface):
        instanza  = False
        valuemap  = {"state":self.DISABLED, "mode":None, "address":None, "netmask":None, "gateway":None}
        state     = self.DISABLED
        hotplug   = False

        revmap = dict([(value, key) for (key, value) in self.KEYMAP.items()])

        try:
            for line in file(self.iffile):
                words = line.split()

                if not words:
                    pass

                elif (len(words) > 3) and (words[:3] == ['iface', interface, 'inet']):
                    try:
                        valuemap.update(mode=words[3])
                    except (IndexError, ValueError):
                        pass
                    instanza = True

                elif words[:2] == [ 'auto', interface ]:
                    instanza = False
                    state    = self.ENABLED

                elif words[:2] == [ 'allow-hotplug', interface ]:
                    instanza = False
                    state    = self.HOTPLUG

                elif words[0] in ('auto', 'iface', 'mapping') or \
                     words[0].startswith('allow-'):
                    instanza = False

                elif instanza and words[0] == 'wpa-roam':
                    valuemap.update(self.getconfig('default'))

                elif instanza:
                    try:
                        statement, value = line.split(None, 1)
                    except ValueError:
                        pass
                    else:
                        key = revmap.get(statement, statement)
                        if key in (self.DNSSERVERS, self.DNSSEARCH):
                            words = value.split()
                            valuemap[key] = words

                        elif key in self.KEYS:
                            valuemap[key] = value.rstrip()

        except IOError:
            pass


        valuemap.update(state=state)
        return valuemap


        
base.addProvider(DebianNetworkProvider)

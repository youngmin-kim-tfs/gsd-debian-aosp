########################################################################
### FILE:	connman.py
### PURPOSE:	System Configuration for Intel's Connection Manager
### HISTORY:
###  2016-12-30 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

import base
import time
import threading
import logging
import os, os.path, stat
import ConfigParser

try:
    import dbus, dbus.service, dbus.mainloop.glib, dbus.exceptions, gi.repository.GLib

except ImportError as e:
    sbus = None

else:
#    class ConnCanceledException(dbus.DBusException):
#        _dbus_error_name = "net.connman.Error.Canceled"

#    dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
#    _loop = gi.repository.GLib.MainLoop()
#    _thread = threading.Thread(None, _loop.run, "GLibMainLoop")
#    _thread.daemon = True
#    _thread.start()

    sbus = dbus.SystemBus()



class Connman (base.Provider):
    CONNMAN      = "net.connman"
    MANAGER      = CONNMAN + ".Manager"
    SERVICE      = CONNMAN + ".Service"
    TECHNOLOGY   = CONNMAN + ".Technology"
    
    ETH_PROPS    = (E_INTERFACE, E_ADDRESS) = ('Interface', 'Address')
    TECHNOLOGIES = (T_ETHERNET, T_WIFI) = ('ethernet', 'wifi')

    ROOT_PATH    = "/"
    TECH_PATH    = "/net/connman/technology/"

    ConnectionStates = (C_ONLINE, C_READY, C_IDLE) = ('online', 'ready', 'idle')

    PROPERTIES   = (P_TYPE, P_NAME, P_STATE, P_SECURITY,
                    P_IPV4, P_IPV6, P_IPV4_CONFIG, P_IPV6_CONFIG,
                    P_DOMAINS, P_DOMAINS_CONFIG, P_NAMESERVERS, P_NAMESERVERS_CONFIG,
                    P_ETHERNET, P_STRENGTH, P_AUTOCONNECT) \
                 = ("Type", "Name", "State", "Security",
                    "IPv4", "IPv6", "IPv4.Configuration", "IPv6.Configuration",
                    "Domains", "Domains.Configuration", "Nameservers", "Nameservers.Configuration",
                    "Ethernet", "Strength", "AutoConnect")

    DEVICEFOLDER = "/sys/class/net"

    manager = None

    class NotConnected (base.SysConfigError):
        '''Not currently connected to any %(technology)s network'''

    class NoSuchNetwork (base.SysConfigError):
        '''Network %(name)r does not exist'''


    class DBusException (base.SysConfigError):
        '''%(message)s'''

    def __init__ (self, *args, **kwargs):
        base.Provider.__init__(self, *args, **kwargs)
        self.init()

    def init (self):
        if sbus and not self.manager:
            try:
                Connman.manager = self.dbusInterface(component=self.MANAGER, path=self.ROOT_PATH)
            except self.DBusException as e:
                logging.warning("DBUS exception on connect: [%s] %s"%(e.__class__.__name__, e))


    def dbusInterface (self, destination=CONNMAN, component=MANAGER, path=ROOT_PATH):
        try:
            obj  = sbus.get_object(destination, path)
            logging.debug('Obtained DBUS interface, destination=%r, component=%r, path=%r'%
                          (destination, component, path))
            return dbus.Interface(obj, component)
        except dbus.exceptions.DBusException, e:
            raise self.DBusException(message=e)


    def isRelevant (self):
        self.init()
        return self.manager is not None


    def isValidInterface (self, ifname):
        return os.path.isdir(os.path.join(self.DEVICEFOLDER, ifname))


    def decompose (self, obj):
        if isinstance(obj, basestring):
            return str(obj)
        elif isinstance(obj, bool):
            return bool(obj)
        elif isinstance(obj, int):
            return int(obj)
        elif isinstance(obj, float):
            return float(obj)
        elif isinstance(obj, dict):
            return dict([ (self.decompose(k), self.decompose(v)) for (k, v) in obj.items() ])
        elif isinstance(obj, tuple):
            return tuple([ self.decompose(element) for element in obj ])
        elif isinstance(obj, list):
            return [ self.decompose(element) for element in obj ]
        else:
            return obj
            
    def compose (self, obj):
        if isinstance(obj, basestring):
            return dbus.String(obj)
        elif isinstance(obj, bool):
            return bus.Boolean(obj)
        elif isinstance(obj, int):
            return obj
        elif isinstance(obj, float):
            return obj
        elif isinstance(obj, dict):
            return dbus.Dictionary([(self.compose(k), self.compose(v)) for (k, v) in obj.items()],
                                   signature=dbus.Signature('sv'))
        elif isinstance(obj, (tuple, list)):
            return dbus.Array([ self.compose(i) for i in obj ],
                              signature=dbus.Signature('s'))
        else:
            return obj
            


    def getTechnology (self, interface):
        if interface.startswith('w') or os.path.isdir("/sys/class/net/%s/wireless"%(interface,)):
            return self.T_WIFI
                                                       
        elif interface.startswith('e'):
            return self.T_ETHERNET

        else:
            return 'unknown'


    def getTechnologies (self):
        return dict(self.manager.GetTechnologies())

    def scan (self):
        tech = self.dbusInterface(component=self.TECHNOLOGY, path=self.TECH_PATH + self.technology)
        tech.Scan()


    def getServices (self):
        return self.manager.GetServices()


    def getServicesByInterface (self, interface):
        services = []

        for key, props in self.getServices():
            try:
                if props[self.P_ETHERNET][self.E_INTERFACE] == interface:
                    services.append((key, props))
            except KeyError:
                pass

        return services
        

    def getServiceByName (self, name):
        for path, props in self.getServices():
            try:
                if props[self.P_NAME] == name:
                    return path, props
            except KeyError:
                pass
        else:
            raise self.NoSuchNetwork(name=name)


    def getActiveService (self, interface):
        for path, props in self.getServicesByInterface(interface):
            if props[self.P_STATE] in (self.C_ONLINE, self.C_READY):
                return path, props
        else:
            tech = self.getTechnology(interface)
            raise self.NotConnected(technology=tech)


    def listValues (self, key, interface):
        nets = []
        for key, dbprops in self.getServicesByInterface(interface):
            try:
                name     = dbprops[self.P_NAME]
                enabled  = dbprops[self.P_AUTOCONNECT]
            except KeyError:
                pass
            else:
                if enabled:
                    nets.append(name)

        return nets



class Connman_WifiBase (Connman, base.NetDeviceProvider):
    SECURITY_SCHEMES = [
        ("ieee8021x", "WPA-EAP"),
        ("psk",       "WPA-PSK"),
        ("wep",       "WEP-OPEN"),
        ("wep",       "WEP-SHARED"),
        ("none",      "NONE") ]

    technology = 'wifi'


    def isValidInterface (self, ifname):
        return os.path.isdir(os.path.join(self.DEVICEFOLDER, ifname, 'wireless'))


class Connman_WifiScan (Connman_WifiBase):
    KEYS = (SCAN, ) = \
           ('ssidscan',)
    
    ATTRIBUTES = \
        (MAC, SSID, MODE, SIGNAL, CONNECTION, AUTHENTICATION) = \
         ('mac', 'ssid', 'mode', 'signal', 'connection', 'authentication')

    def get (self, interface, uptime=None):
        networkmap = {}
        signalmap  = {}

        if uptime is not None:
            tech = self.dbusInterface(component=self.TECHNOLOGY, path=self.TECH_PATH + self.technology)
            tech.Scan()
            time.sleep(uptime)

        for key, dbprops in self.getServicesByInterface(interface):
            try:
                ssid     = dbprops[self.P_NAME]
                signal   = dbprops[self.P_STRENGTH]
                conn     = dbprops[self.P_STATE]
                schemes  = dbprops[self.P_SECURITY]
                iface    = dbprops[self.P_ETHERNET][self.E_INTERFACE]
                mac      = dbprops[self.P_ETHERNET][self.E_ADDRESS]
            except KeyError:
                pass
            else:
                if signal >= signalmap.get(ssid, 0):
                    signalmap[ssid]  = signal
                    networkmap[ssid] = props = [
                        (self.SSID,       ssid),
                        (self.MODE,       ('Ad-Hoc', 'Managed')['managed' in key]),
                        (self.MAC,        mac),
                        (self.CONNECTION, conn), 
                        (self.SIGNAL,     signal) ]

                    for cmscheme, isscheme in self.SECURITY_SCHEMES:
                        if cmscheme in schemes:
                            props.append((self.AUTHENTICATION, isscheme))
                            break

        return { self.SCAN: self.decompose(networkmap) }

base.addProvider(Connman_WifiScan)


class Connman_Wifi_DBus (Connman, base.NetDeviceProvider):

    class NoSuchSSID (base.SysConfigError):
        '''SSID %(ssid)r does not exist'''

    class InvalidSSID (base.SysConfigError):
        '''Invalid SSID %(ssid)r'''

    class InvalidWEPKey (base.SysConfigError):
        '''WEP key should be 10 or 26 hexadecimal digits, or 5 or 13 arbitrary characters'''

    class InvalidWPAKey (base.SysConfigError):
        '''WPA key/passphrase should contain at least 8 characters'''

    KEYS = \
        (SSID, AUTH, IDENTITY, KEY, KEYINDEX) = \
        ("ssid", "authentication", "identity", "key", "keyindex")

    AGENT_PATH  = "/com/thermofisher/instrumentserver/agent"
    agent       = None
    technology  = 'wifi'

    if sbus is not None:
        class Connman_Agent(dbus.service.Object):
            @dbus.service.method(Connman.CONNMAN + ".Agent", in_signature='', out_signature='')
            def Release (self):
                pass

            @dbus.service.method(Connman.CONNMAN + ".Agent", in_signature='', out_signature='')
            def RequestInput(self, path, fields):
                print("path = %s"%(path,))
                print("requested = %s"%([str(key) for key in fields.keys()]))
                print("fields = %s"%(fields,))

                response = {}
                for key in fields:
                    if key in self.response:
                        response[key] = dbus.String(self.response[key])
                    elif fields[key].get("Requirement", None).lower() == 'mandatory':
                        raise ConnCancelledException("Madatory key %r is not supplied"%(key,))

                print("response = %s"%(response,))
                return dbus.Dictionary(response)

            def setResponse (self, **response):
                self.response = response


            def __getattr__ (self, attr):
                print("__getattr__(%r)"%(attr,))
                return dbus.service.Object.__getattr__(self, attr)
            


    def startAgent (self):
        agentPath = '/test/agent'
        self.agent = self.Connman_Agent(sbus, agentPath)
        self.manager.RegisterAgent(agentPath)
        return self.agent
        

    def addwifi (self, ssid, identity, key, keyindex):
        path, props = self.getServiceByName(ssid)

        if self.agent is None:
           self.startAgent()

        self.agent.setResponse(Name=ssid,
                               Identity=identity, Username=identity,
                               Passphrase=key, Password=key)
        
        service = self.dbusInterface(component=self.SERVICE, path=path)

        try:
            service.Connect(timeout=1000)
        except dbus.exceptions.DBusException, e:
            raise self.DBusException(message=e)


class Connman_Wifi (Connman_WifiBase):

    class NoSuchSSID (base.SysConfigError):
        '''SSID %(ssid)r does not exist'''

    class InvalidSSID (base.SysConfigError):
        '''Invalid SSID %(ssid)r'''

    class InvalidWEPKey (base.SysConfigError):
        '''WEP key should be 10 or 26 hexadecimal digits, or 5 or 13 arbitrary characters'''

    class InvalidWPAKey (base.SysConfigError):
        '''WPA key/passphrase should contain at least 8 characters'''

    class InvalidAuthentication (base.SysConfigError):
        '''WLAN authentication scheme %(authentication)r is not supported'''
        
    class UnsupportedAuthentication (base.SysConfigError):
        '''SSID does not support authentication scheme %(requested)r'''


    KEYS = \
        (SSID, AUTH, IDENTITY, KEY, KEYINDEX) = \
        ("ssid", "authentication", "identity", "key", "keyindex")

    WLAN_AUTHENTICATION = \
        (AUTH_NONE, AUTH_WEP_OPEN, AUTH_WEP_SHARED, AUTH_WEP_EAP, AUTH_WPA_PSK, AUTH_WPA_EAP) = \
        ("NONE", "WEP-OPEN", "WEP-SHARED", "WEP-EAP", "WPA-PSK", "WPA-EAP")

    SECURITY = \
        (S_NONE, S_WEP, S_PSK, S_EAP) = \
        ("none", "wep", "psk", "ieee8021x")

    AUTHMAP = {
        AUTH_NONE       : S_NONE,
        AUTH_WEP_OPEN   : S_WEP,
        AUTH_WEP_SHARED : S_WEP,
        AUTH_WEP_EAP    : S_EAP,
        AUTH_WPA_PSK    : S_PSK,
        AUTH_WPA_EAP    : S_EAP }


    svcdir = "/var/lib/connman"
    svc_uid = 0
    svc_gid = 0




        
    def getStatus (self, interface, pending=True):
        status = {}
        try:
            path, props = self.getActiveService(interface)
        except self.NotConnected as e:
            pass
        else:
            status[self.SSID] = props.get(self.P_NAME, "")

        return status


    def disconnect (self, interface):
        try:
            path, props = self.getActiveService(interface)
            service = self.dbusInterface(component=self.SERVICE, path=path)
            service.Disconnect()
        except (self.NotConnected, dbus.exceptions.DBusException):
            pass


    def saveConfig (self, filename, path, **attributes):
        fp = file(filename, 'w')
        os.fchmod(fp.fileno(), stat.S_IREAD)
        os.fchown(fp.fileno(), self.svc_uid, self.svc_gid)
            
        obj = ConfigParser.SafeConfigParser()
        obj.optionxform = str
        section = "service_"+path
        obj.add_section(section)
        obj.set(section, 'Type', 'wifi')

        for key, value in attributes.items():
            if value is not None:
                obj.set(section, key, value)
    
        obj.write(fp)
        fp.close()



    def configure (self, valuemap, interface, save=True):
        self.addNetwork(**valuemap)


    def addNetwork (self, ssid, authentication, identity, key, keyindex):
        path, props = self.getServiceByName(ssid)
        schemes  = props.get(self.P_SECURITY, [])

        try:
            scheme   = self.AUTHMAP[authentication]

        except KeyError:
            raise self.InvalidAuthentication(authentication=authentication)

        else:
            if not scheme in schemes:
                raise self.UnsupportedAuthentication(requested=scheme,
                                                     supported=",".join(schemes))

        svcname = os.path.basename(path)
        svcpath = os.path.join(self.svcdir, svcname+".config")
        self.saveConfig(svcpath, svcname,
                        Name=ssid,
                        Identity=identity,
                        Passphrase=key)

        service = self.dbusInterface(component=self.SERVICE, path=path)

        try:
            service.Connect(timeout=1000)
        except dbus.exceptions.DBusException, e:
            raise self.DBusException(message=e)


    def removeNetwork (self, interface, ssid, save=True, required=True):
        try:
            path, props = self.getServiceByName(ssid)
            service = self.dbusInterface(component=self.SERVICE, path=path)
            service.Remove()

        except self.NoSuchNetwork, e:
            if required:
                raise

        except dbus.exceptions.DBusException, e:
            raise self.DBusException(message=e)



    def clearNetworks (self, interface, save=True):
        for path, props in self.getServicesByInterface(interface):
            try:
                service = self.dbusInterface(component=self.SERVICE, path=path)
                service.Remove()
            except dbus.exceptions.DBusException, e:
                raise self.DBusException(message=e)


base.addProvider(Connman_Wifi)



class Connman_StateConfig (Connman, base.NetInterfaceProvider):

    KEYS = (STATE,) = ('state',)

    def getconfig (self, interface):
        return { self.STATE: (self.DISABLED, self.ENABLED)[self.getEnabled(interface)] }

    def configure (self, valuemap, interface, **kwargs):
        enable  = valuemap.get(self.STATE)
        enabled = self.getEnabled(interface)

        if enable != enabled:
            self.setEnabled(enable, interface)

        return True


    def getEnabled (self, interface):
        technology = self.getTechnology(interface)

        for tech, props in self.getTechnologies().items():
            if os.path.basename(tech) == technology:
                isenabled = bool(props.get('Powered'))
                break
        else:
            isenabled = None

        return isenabled
        

    def setEnabled (self, enabled, interface):
        interface  = self.dbusInterface(component=self.TECHNOLOGY, path=self.TECH_PATH + technology)
        interface.SetProperty('Powered', self.compose(bool(enabled)))


base.addProvider(Connman_StateConfig)


class Connman_IPConfig (Connman, base.NetInterfaceProvider):
    KEYS = ('mode', 'address', 'netmask', 'gateway')
    IPConfigKeys = (C_METHOD, C_ADDRESS, C_NETMASK, C_GATEWAY) = \
                   ('Method', 'Address', 'Netmask', 'Gateway')


    def configure (self, valuemap, interface, **kwargs):
        mode   = valuemap.get(self.MODE)
        method = None
        ipconfig  = {}
        dnsconfig = {}

        if mode is not None:
            config[self.C_METHOD] = ('manual', 'dhcp')[mode == self.DHCP]

        for ckey in (self.C_ADDRESS, self.C_NETMASK, self.C_GATEWAY):
            value = valuemap.get(ckey.lower())
            if value:
                config[ckey] = dbus.String(value, variant_level=1)

        if config:
            path, props = self.getActiveService(interface)
            service = self.dbusInterface(component=self.SERVICE, path=path)

            try:
                service.SetProperty(self.P_IPV4_CONFIG, self.compose(config))
            except dbus.exceptions.DBusException as e:
                raise self.DBusException(message=e)


    def apply (self, valuemap, interface, **kwargs):
        pass


    def get (self, interface, current=False):
        try:
            path, props = self.getActiveService(interface)
        except self.NotConnected:
            valuemap = { self.STATE : self.DISABLED }
        else:
            configkey = (self.P_IPV4_CONFIG, self.P_IPV4)[current]
            propmap   = props[configkey]

            mode = ('static', 'dhcp')[propmap[self.C_METHOD] == 'dhcp']

            valuemap = { self.STATE : self.ENABLED,
                         self.MODE  : mode }

            for ckey in (self.C_ADDRESS, self.C_NETMASK, self.C_GATEWAY):
                if ckey in propmap:
                    valuemap[ckey.lower()] = str(propmap[ckey])


        return valuemap



base.addProvider(Connman_IPConfig)


class Connman_DNSConfig (Connman, base.NetInterfaceProvider):
    KEYS = ('dnssearch', 'dnsservers')
    StateKeys  = (Connman.P_DOMAINS, Connman.P_NAMESERVERS)
    ConfigKeys = (Connman.P_DOMAINS_CONFIG, Connman.P_NAMESERVERS_CONFIG)


    def configure (self, valuemap, interface, **kwargs):
        config = {}
        for (key, prop) in zip(self.KEYS, self.ConfigKeys):
            if valuemap.get(key) is not None:
                config[prop] = valuemap[key]

        if config:
            path, props = self.getActiveService(interface)
            service = self.dbusInterface(component=self.SERVICE, path=path)

            try:
                for prop, value in config.items():
                    service.SetProperty(prop, self.compose(value))
            except dbus.exceptions.DBusException as e:
                raise self.DBusException(message=e)


    def apply (self, valuemap, interface, **kwargs):
        pass


    def get (self, interface, current=False):
        try:
            path, props = self.getActiveService(interface)
        except self.NotConnected:
            return {}
        else:
            propkeys = (self.ConfigKeys, self.StateKeys)[current]
            items = [ (key, self.decompose(props[propkey]))
                      for (key, propkey) in zip(self.KEYS, propkeys) ]
            return dict(items)


base.addProvider(Connman_DNSConfig)

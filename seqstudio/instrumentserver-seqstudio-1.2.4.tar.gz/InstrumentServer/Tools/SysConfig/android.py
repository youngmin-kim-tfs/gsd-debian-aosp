########################################################################
### FILE:	avahi.py
### PURPOSE:	AVAHI daemon SysConfig plugin
### HISTORY:
###  2016-10-31 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

import os
import os.path
import logging
import base

class AndroidPropertiesProvider (base.GlobalProvider):

    CHROOT = "/android"
    GETPROP = "/system/bin/getprop"
    SETPROP = "/system/bin/setprop"

    KEYS = (TIMEZONE, ) = ('timezone', )

    PROPMAP = {
        TIMEZONE   : "persist.sys.timezone"
        }


    def isRelevant (self):
        return os.path.exists(os.path.join(self.CHROOT+self.GETPROP))


    def listValues (self, key):
        ### Return a list of possible values for "key".
        ### This is optional.
        pass


    def get (self, *args, **opts):
        valuemap = {}
        for key in self.keys():
            valuemap[key] = self.getprop(key)

        return valuemap


    def validate (self, valuemap={}, *args, **opts):
        ### Validate any keys supplied in "valuemap"
        ### Return True if authorative validation has been performed.
        ### Raise SysConfigError if arguments are invalid.
        pass

    def configure (self, valuemap={}, *args, **opts):
        for key, value in valuemap.items():
            self.setprop(key, value)

        return True


    def apply (self, valuemap, *args, **opts):
        ### Apply any changes that were made to system configuration.
        ### This is only invoked if "configure()" returned True, and if "apply"
        ### was specified in the "SysConfig.set()" invocation.
        pass
    
    def getprop (self, key):
        prop = self.PROPMAP.get(key, key)
        return self.runcommand((self.GETPROP, prop), chroot=self.CHROOT)

    def setprop (self, key, value):
        prop = self.PROPMAP.get(key, key)
        return self.runcommand((self.SETPROP, prop, value), chroot=self.CHROOT)
        

base.addProvider(AndroidPropertiesProvider)


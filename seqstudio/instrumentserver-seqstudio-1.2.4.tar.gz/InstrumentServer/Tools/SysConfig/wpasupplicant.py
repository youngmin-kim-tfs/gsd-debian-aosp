########################################################################
### FILE:	wlan.py
### PURPOSE:	Wireless Local Area Network (WiFi) support.
### HISTORY:
###  2013-04-15 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

import re
import os
import os.path
import stat
import logging
import base
import socket
import time
import hashlib
import binascii

WLAN_AUTHENTICATION = \
    (AUTH_NONE, AUTH_WEP_OPEN, AUTH_WEP_SHARED, AUTH_WEP_EAP, AUTH_WPA_PSK, AUTH_WPA_EAP) = \
    ("NONE", "WEP-OPEN", "WEP-SHARED", "WEP-EAP", "WPA-PSK", "WPA-EAP")


class HiddenString (str):
    pass


class WPA_Supplicant (base.NetDeviceProvider):

    class WPASupplicantFailure (base.SysConfigError):
        pass

    class WPANotRunning (base.SysConfigError):
        '''WPA Supplicant is not running. Try bringing up interface '%(interface)s' in manual mode first.'''

    class NoSuchSSID (base.SysConfigError):
        '''SSID %(ssid)r is not configured'''

    class InvalidSSID (base.SysConfigError):
        '''Invalid SSID %(ssid)r'''

    class InvalidWEPKey (base.SysConfigError):
        '''WEP key should be 10 or 26 hexadecimal digits, or 5 or 13 arbitrary characters'''

    class InvalidWPAKey (base.SysConfigError):
        '''WPA key/passphrase should contain at least 8 characters'''

    class AssociationFailure (base.SysConfigError):
        '''Association attempt with SSID %(ssid)r timed out after %(timeout)s seconds'''

    class AuthenticationFailure (base.SysConfigError):
        '''Unable to authenticate with SSID %(ssid)r'''


    KEYS = \
        (SSID, AUTH, IDENTITY, KEY, KEYINDEX, SCAN_SSID) = \
        ("ssid", "authentication", "identity", "key", "keyindex", "scan_ssid")

    WPA_SUPPLICANT = "wpa_supplicant"
    CONTROL_DIR  = "/var/run/" + WPA_SUPPLICANT
    CONTROL_FILE = CONTROL_DIR + "/%(interface)s"

    AUTO_START   = False
    CONFIG_FILE  = "/etc/wpa_supplicant/wpa_supplicant.conf"

    DEVICEFOLDER = "/sys/class/net"

    WPA_CLI_OPS = \
        (GET_STATUS, SCAN, SCAN_RESULTS, LIST_NETWORKS,
         ADD_NETWORK, DISABLE_NETWORK, ENABLE_NETWORK, REMOVE_NETWORK,
         GET_NETWORK, SET_NETWORK, SELECT_NETWORK, DISCONNECT, RECONNECT, SAVE) = \
        ("STATUS", "SCAN", "SCAN_RESULTS", "LIST_NETWORKS",
         "ADD_NETWORK", "DISABLE_NETWORK", "ENABLE_NETWORK", "REMOVE_NETWORK",
         "GET_NETWORK", "SET_NETWORK", "SELECT_NETWORK", "DISCONNECT", "RECONNECT", "SAVE_CONFIG")

    WPA_CLI_VARS = \
        (SSID, SCAN_SSID, KEY_MGMT, IDENTITY, PASSWORD, PSK, WEP_KEYIDX, WEP_KEYX, WEP_AUTH) = \
        ("ssid", "scan_ssid", "key_mgmt", "identity", "password", "psk", "wep_tx_keyidx", "wep_key%s", "auth_alg")

    WPA_KEYMGMT = (NONE, WPA_PSK, WPA_EAP, IEEE8021X) = \
        ("NONE", "WPA-PSK", "WPA-EAP", "IEEE8021X")

    WEP_ALGO = (WEPALGO_OPEN, WEPALGO_SHARED) = ("OPEN", "SHARED")

    _sockets  = {}
    _networks = {}


    def isRelevant (self):
        try:
            text = self.runcommand((self.WPA_SUPPLICANT, '-v'))
        except self.ExitStatus, e:
            logging.debug('SysConfig: Not enabling wireless support: [%s] %s'%(e.__class__.__name__, e))
            return False
        else:
            return True


    def isValidInterface (self, ifname):
        return os.path.isdir(os.path.join(self.DEVICEFOLDER, ifname, 'wireless'))


    def wpa_control (self, interface):
        control = self.CONTROL_FILE%locals()
        if os.path.exists(control):
            return control


    def wpa_start (self, interface):
        propmap = locals()
        configfile  = self.CONFIG_FILE%propmap

        if not os.path.exists(configfile):
            fp = file(configfile, "w")
            fp.write("ctrl_interface=%s\n"%(self.CONTROL_DIR,))
            fp.write("update_config=1\n")
            fp.close()

        try:
            os.chmod(configfile, stat.S_IRUSR | stat.S_IWUSR)
        except EnvironmentError, e:
            logging.warning('Unable to change permissions on "%s": %s'%(configfile, e))


        self.runcommand((self.WPA_SUPPLICANT, "-i", interface, "-c", configfile, "-B"))


    def wpa_open (self, interface):
        controlfile = self.wpa_control(interface)
        if not controlfile:
            if self.AUTO_START:
                self.wpa_start(interface)
                controlfile = self.wpa_control(interface)
            else:
                raise self.WPANotRunning(interface=interface)

        sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        sock.bind("")
        sock.connect(controlfile)
        return sock


    def wpa_cli (self, interface, *arguments, **kwargs):
        text   = " ".join(arguments)
        debug  = kwargs.get('debug')
        info   = kwargs.get('info')

        if interface in self._sockets:
            socket = self._sockets[interface]
        else:
            socket = self._sockets[interface] = self.wpa_open(interface)

        try:
            socket.send(text)
            response = socket.recv(4096).decode('string-escape')
        except EnvironmentError, e:
            if info:
                info("Could not communicate with wpa_supplicant, reopening socket: [%s] %s: %s"%
                     (e.__class__.__name__, e, e.filename))
            socket = self._sockets[interface] = self.wpa_open(interface)
            socket.send(text)
            response = socket.recv(4096).decode('string-escape')

        logtext = " ".join([(a, "*")[isinstance(a, HiddenString)] for a in arguments])
        if debug:
            debug("wpa_supplicant: %s -> %s"%(logtext, ' | '.join(response.splitlines())))

        return response



    def wpa_get (self, interface, netid, variable, ignoreFailure=False):
        text = self.wpa_cli(interface, self.GET_NETWORK, netid, variable).strip()

        if text == "FAIL":
            if ignoreFailure:
                text = None
            else:
                raise self.WPASupplicantFailure("Failed to read %(variable)r",
                                                netid=netid, variable=variable)

        elif text.startswith('"') and text.endswith('"'):
            text = text[1:-1]

        return text


    def wpa_set (self, interface, netid, variable, value, string=False):
        if string and value and not '"' in value:
            value = value.__class__('"%s"'%value)

        text = self.wpa_cli(interface, self.SET_NETWORK, netid, variable, value)
        if text.strip() == "FAIL":
            raise self.WPASupplicantFailure("Failed to set %(variable)r to %(value)r",
                                            interface=interface,
                                            netid=netid,
                                            variable=variable,
                                            value=value)



    def wpa_passkey (self, interface, ssid, password, rounds=4096, length=32):
        try:
            psk = hashlib.pbkdf2_hmac('sha1', password, ssid, rounds, length)
            key = binascii.hexlify(psk)
        except AttributeError, e:
            key = HiddenString('"%s"'%password)

        return key



    def getNetworks (self, interface, reread=False):
        try:
            return self._networks[interface]

        except KeyError, e:
            text = self.wpa_cli(interface, self.LIST_NETWORKS)
            self._networks[interface] = ssidmap = {}
            for line in text.splitlines():
                try:
                    netid, netname, bssid, netflags = line.split("\t")
                except ValueError:
                    pass
                else:
                    if netid.isdigit():
                        ssidmap[netid] = netname
            return ssidmap


    def getNetID (self, interface, ssid, required=False):
        nets    = self.getNetworks(interface)
        flipped = dict(zip(nets.values(), nets.keys()))

        try:
            return flipped[ssid]
        except KeyError:
            if required:
                raise self.NoSuchSSID(interface=interface, ssid=ssid)



    def networkOps (self, interface, ssid, commands, save=True, required=True):
        netid = self.getNetID(interface, ssid, required=required)

        if netid is not None:
            for command in commands:
                self.wpa_cli(interface, command, netid)

            if save:
                self.save(interface)

        return netid


    def selectNetwork (self, interface, ssid, timeout=60.0, save=True, **junk):
        self.networkOps(interface, ssid,
                        (self.DISABLE_NETWORK,
                         self.ENABLE_NETWORK,
                         self.SELECT_NETWORK), save=save)

        if timeout:
            current  = time.time()
            deadline = current + timeout
            interval = 0.5
            wpastate = None
            associated = False

            while deadline > current:
                current += interval
                now      = time.time()
                time.sleep(max(0, min(deadline, current) - now))

                status      = self.getStatus(interface, pending=True)
                wpastate    = status.get('wpa_state')
                authstate   = status.get('suppPortStatus')

                if wpastate == "COMPLETED":
                    break

                elif wpastate == "ASSOCIATED":
                    associated = True

            else:
                if associated:
                    raise self.AuthenticationFailure(ssid=ssid,
                                                     authstate=authstate,
                                                     wpastate=wpastate)
                else:
                    raise self.AssociationFailure(ssid=ssid,
                                                  timeout=timeout,
                                                  wpastate=wpastate,
                                                  authstate=authstate)


    def addNetwork (self, interface, ssid, save=False):
        netid = self.wpa_cli(interface, self.ADD_NETWORK).strip()

        try:
            self.wpa_set(interface, netid, self.SSID, ssid, string=True)
        except self.WPASupplicantFailure, e:
            self.wpa_cli(interface, self.REMOVE_NETWORK, netid)
            raise self.InvalidSSID(ssid=ssid)

        if interface in self._networks:
            ### Networks on this interface are cached.
            ### Add new network ID to cache.
            self._networks[interface][netid] = ssid

        if save:
            self.save(interface)

        return netid

    def removeAddress (self, interface):
        self.runcommand(("/sbin/ifconfig", interface, "0.0.0.0"))

    def removeNetwork (self, interface, ssid, netid=None, save=True, required=True):
        if netid is None:
            netid = self.getNetID(interface, ssid, required=required)

        if netid:
            if self.getStatus(interface).get('ssid') == ssid:
                self.removeAddress(interface)

            self.wpa_cli(interface, self.REMOVE_NETWORK, netid)
            if interface in self._networks:
                self._networks[interface].pop(netid, None)

            if save:
                self.save(interface)

        return netid


    def clearNetworks (self, interface, save=True):
        self.wpa_cli(interface, self.REMOVE_NETWORK, "all")

        if interface in self._networks:
            self._networks[interface].clear()

        if save:
            self.save(interface)


    def disconnect (self, interface):
        self.wpa_cli(interface, self.DISCONNECT)


    def reconnect (self, interface):
        self.wpa_cli(interface, self.RECONNECT)


    def listValues (self, key, interface):
        if key == self.SSID:
            nets = self.getNetworks(interface)
            keys = sorted([ int(key) for key in nets ])
            return [ nets[str(key)] for key in keys ]


    def getStatus (self, interface, pending=True, debug=logging.debug):
        text   = self.wpa_cli(interface, self.GET_STATUS, debug=debug)
        record = {}
        if text:
            for line in text.splitlines():
                try:
                    key, value = line.split("=", 1)
                except ValueError:
                    pass
                else:
                    record[key] = value

        if pending or record.get('wpa_state') == 'COMPLETED':
            return record
        else:
            return {}



    def getAuthRecord (self, interface, netid, **defaults):
        record = {}.fromkeys(self.KEYS)
        record.update(defaults)

        keymgmt  = self.wpa_get(interface, netid, self.KEY_MGMT, False)

        if keymgmt == self.NONE:
            keyindex = self.wpa_get(interface, netid, self.WEP_KEYIDX, False) or "0"
            key      = self.wpa_get(interface, netid, self.WEP_KEYX%keyindex, True)

            if key:
                if self.wpa_get(interface, netid, self.WEP_AUTH) == self.WEPALGO_SHARED:
                    auth = AUTH_WEP_SHARED
                else:
                    auth = AUTH_WEP_OPEN

                record[self.AUTH]     = auth
                record[self.KEY]      = key
                record[self.KEYINDEX] = keyindex

            else:
                record[self.AUTH] = AUTH_NONE


        elif keymgmt == self.WPA_PSK:
            key = self.wpa_get(interface, netid, self.PSK, True)
            record[self.AUTH] = AUTH_WPA_PSK
            record[self.KEY]  = key

        elif keymgmt == self.WPA_EAP:
            record[self.AUTH]     = AUTH_WPA_EAP
            record[self.IDENTITY] = self.wpa_get(interface, netid, self.IDENTITY, True)
            record[self.KEY]      = self.wpa_get(interface, netid, self.PASSWORD, True)

        elif keymgmt == self.IEEE8021X:
            record[self.AUTH]     = AUTH_WEP_EAP
            record[self.IDENTITY] = self.wpa_get(interface, netid, self.IDENTITY, True)
            record[self.KEY]      = self.wpa_get(interface, netid, self.PASSWORD, True)


        return record


    _wepkey  = re.compile(r'^[0-9a-f]+$', re.I)


    def validAuthRecord (self, interface, ssid, authentication, identity=None, key=None, keyindex=0, scan_ssid=False):
        if authentication == AUTH_NONE:
            pass

        elif authentication in (AUTH_WEP_OPEN, AUTH_WEP_SHARED):
            if not key:
                raise self.WPASupplicantFailure("Authentication scheme %(authentication)s requires a key",
                                                authentication=authentication)

            if len(key) in (10, 26) and self._wepkey.match(key):
                isPassword = False
            elif len(key) in (5, 13):
                isPassword = True
            else:
                raise self.InvalidWEPKey()

        elif authentication == AUTH_WPA_PSK:
            if not key:
                raise self.WPASupplicantFailure("Authentication scheme %(authentication)s requires a key",
                                                authentication=authentication)

            elif len(key) < 8:
                raise self.InvalidWPAKey()


        elif authentication in (AUTH_WEP_EAP, AUTH_WPA_EAP):
            if not identity or not key:
                raise self.WPASupplicantFailure("Authentication scheme %(authentication)s requires identity and key",
                                                authentication=authentication)

        else:
            raise self.WPASupplicantFailure("Unknown authentication scheme: %(authentication)r",
                                            authentication=authentication)

        return True



    def setAuthRecord (self, interface, ssid,
                       authentication, identity=None, key=None, keyindex=0, scan_ssid=False, save=True):

        previous = self.getNetID(interface, ssid, required=False)
        netid    = self.addNetwork(interface, ssid)

        try:
            if authentication == AUTH_NONE:
                self.wpa_set(interface, netid, self.KEY_MGMT, self.NONE)
                self.wpa_set(interface, netid, self.WEP_KEYIDX, '')
                self.wpa_set(interface, netid, self.WEP_KEYX%str(keyindex), '')
                self.wpa_set(interface, netid, self.WEP_AUTH, self.WEPALGO_OPEN)


            elif authentication in (AUTH_WEP_OPEN, AUTH_WEP_SHARED):
                if len(key) in (10, 26) and self._wepkey.match(key):
                    isPassword = False
                elif len(key) in (5, 13):
                    isPassword = True

                algorithm  = self.WEP_ALGO[authentication == AUTH_WEP_SHARED]

                self.wpa_set(interface, netid, self.KEY_MGMT, self.NONE)
                self.wpa_set(interface, netid, self.WEP_KEYIDX, str(keyindex))
                self.wpa_set(interface, netid, self.WEP_KEYX%keyindex, HiddenString(key), isPassword)
                self.wpa_set(interface, netid, self.WEP_AUTH, algorithm)


            elif authentication == AUTH_WPA_PSK:
                psk = self.wpa_passkey(interface, ssid, key)
                self.wpa_set(interface, netid, self.KEY_MGMT, self.WPA_PSK)
                self.wpa_set(interface, netid, self.PSK, psk)


            elif authentication in (AUTH_WEP_EAP, AUTH_WPA_EAP):
                keymgmt = (self.IEEE8021X, self.WPA_EAP)[authentication == AUTH_WPA_EAP]
                self.wpa_set(interface, netid, self.KEY_MGMT, keymgmt)
                self.wpa_set(interface, netid, self.IDENTITY, identity, string=True)
                self.wpa_set(interface, netid, self.PASSWORD, HiddenString(key), string=True)


            self.wpa_set(interface, netid, self.SCAN_SSID, str(int(scan_ssid)))

        except Exception, e:
            self.removeNetwork(interface, ssid, netid, save=False)
            raise

        else:
            if previous:
                self.removeNetwork(interface, ssid, previous, save=False)
                logging.debug('Replaced network ID %s with ID %s for SSID "%s"'%(previous, netid, ssid))
            else:
                logging.debug('Added network ID %s for SSID "%s"'%(netid, ssid))

            if save:
                self.save(interface)

    def get (self, interface, ssid=None, required=True):
        if ssid:
            netid = self.getNetID(interface, ssid, required=required)
        else:
            status  = self.getStatus(interface)
            netid   = status.get('id')
            ssid    = status.get('ssid')

        if netid:
            values = self.getAuthRecord(interface, netid, ssid=ssid)
        else:
            values = {self.SSID: None}

        return values

    def validate (self, valuemap, interface, save=True):
        valid = self.isValidInterface(interface) and self.validAuthRecord(interface, **valuemap)

    def configure (self, valuemap, interface, save=True):
        self.setAuthRecord(interface, save=save, **valuemap)
        return True

    def apply (self, valuemap, interface, save=True):
        self.selectNetwork(interface, save=save, **valuemap)

    def save (self, interface):
        self.wpa_cli(interface, self.SAVE)

base.addProvider(WPA_Supplicant)


# class WPA_Status (WPA_Supplicant):
#     KEYS = (ENABLED, CARRIER) = ('enabled', 'carrier')
#
#     _status = None
#
#     def get (self, interface):
#         if self.isValidInterface(interface):
#             enabled = bool(self.wpa_control(interface))
#             carrier = enabled and (self.SSID in self.getStatus(interface, debug=None))
#             status = {self.ENABLED: enabled, self.CARRIER: carrier}
#             if status != self._status:
#                 logging.debug("SysConfig: %s WiFi status change: %s -> %s"%
#                               (self.name, self._status, status))
#                 self._status = status
#             return status
#
# base.addProvider(WPA_Status)


class WPA_Scan (WPA_Supplicant):
    KEYS = (SSIDSCAN,) = ("ssidscan",)

    ATTRIBUTES = \
        (MAC, SSID, MODE, QUALITY, SIGNAL, FREQUENCY, AUTHENTICATION) = \
            ('mac', 'ssid', 'mode', 'quality', 'signal', 'frequency', 'authentication')

    MODES = ('Ad-Hoc', 'Master')

    authmap = {
        AUTH_WPA_PSK  : r'WPA\w*-PSK-\S*',
        AUTH_WPA_EAP  : r'WPA\w*-EAP-\S*',
        AUTH_WEP_OPEN : r'WEP',
        AUTH_WEP_EAP  : r'IEEE8021X' }

    groups = [r'\[(%s)\]'%(authmap.get(auth, ''),) for auth in WLAN_AUTHENTICATION]
    rx_auth   = re.compile('|'.join(groups))
    rx_master = re.compile(r'\[ESS\]')

    def listValues (self, key):
        ### Return a list of possible values for "key".
        ### This is optional.
        pass


    def ssidmap (self, interface, rescan=True, timeout=15):
        if rescan:
            self.wpa_cli(interface, self.SCAN)
            countdown = timeout
            while (countdown > 0) and (self.getStatus(interface).get('wpa_state') == 'SCANNING'):
                time.sleep(1)
                countdown -= 1

        ssidmap = {}
        for line in self.wpa_cli(interface, self.SCAN_RESULTS).splitlines():
            try:
                mac, frequency, signal, flags, ssid = line.split("\t", 4)
            except ValueError:
                continue

            signal  = int(signal)
            ssid    = ssid.decode('string-escape')
            quality = (110.0+signal)/70.0

            match = self.rx_auth.search(flags)
            authindex = match and match.lastindex-1 or 0
            authentication = WLAN_AUTHENTICATION[authindex]
            mode = self.MODES[bool(self.rx_master.search(flags))]

            try:
                omac, omode, oquality, osignal, ofreq, oauth = ssidmap[ssid]
            except KeyError:
                pass
            else:
                if oquality > quality:
                    continue

            ssidmap[ssid] = [
                (self.MAC, mac),
                (self.MODE, mode),
                (self.QUALITY, quality),
                (self.SIGNAL, signal),
                (self.FREQUENCY, int(frequency)/1000.0),
                (self.AUTHENTICATION, authentication)]

        return ssidmap

    def get (self, interface):
        flagsfile = "/".join((self.DEVICEFOLDER, interface, "flags"))
        flags     = int(file(flagsfile).read().strip(), 0)
        enabled  = flags & 0x0001

        if not enabled:
            logging.debug("Bringing up interface %s for scanning..."%(interface))
            file(flagsfile, 'w').write("0x%04X\n"%(flags | 0x0001))

        ssidmap = self.ssidmap(interface)

        if not enabled:
            logging.debug("Bringing down interface %s after scanning."%(interface))
            file(flagsfile, 'w').write("0x%04X\n"%(flags))

        return { self.SSIDSCAN: ssidmap }


    def validate (self, valuemap={}, *args, **opts):
        ### Validate any keys supplied in "valuemap"
        ### Return True if authorative validation has been performed.
        ### Raise SysConfigError if arguments are invalid.
        pass

    def configure (self, valuemap={}, *args, **opts):
        ### Update system configuration with new values.
        ### Return True if this provider was able to make the change.
        pass

    def apply (self, valuemap, *args, **opts):
        ### Apply any changes that were made to system configuration.
        ### This is only invoked if "configure()" returned True, and if "apply"
        ### was specified in the "SysConfig.set()" invocation.
        pass

base.addProvider(WPA_Scan)

########################################################################
### FILE:	generic.py
### PURPOSE:	Configuration provider for "generic" systems
### HISTORY:
###  2013-01-25 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

import base
import config

import socket
import re
import logging


class HostnameProvider (base.GlobalProvider):

    KEYS = (HOSTNAME, ) = ('hostname',)

    def isRelevant (self):
        return True

    def get (self):
        return {self.HOSTNAME: socket.gethostname().split('.')[0]}

base.addProvider(HostnameProvider)


class InstrumentInfoProvider (base.GlobalProvider):
    KEYS = (PRODUCT, MODEL, DESCRIPTION, VERSION, BUILD) = \
           ('product', 'model', 'description', 'version', 'build')

    CONFIGFILES    = ('version.ini',)
    CONFIGSECTION  = 'server'

    class ReadOnly (base.SysConfigError):
        '''Cannot change read-only attribute: %(attribute)r'''

    def __init__ (self):
        base.GlobalProvider.__init__(self)
        self.instrumentinfo = config.Config(self.CONFIGFILES, autoLoad=False)
        self.loaded = False

    def isRelevant (self):
        return True

    def load (self):
        if not self.loaded:
            self.instrumentinfo.load()
            self.loaded = True

    def get (self):
        self.load()
        valuemap = {}.fromkeys(self.KEYS, '')
        valuemap.update(self.instrumentinfo[self.CONFIGSECTION])
        return valuemap




class InstrumentConfigProvider (InstrumentInfoProvider):
    KEYS = (SERIALNUMBER, NICKNAME, PRODUCT, DESCRIPTION) = \
        ('serialnumber', 'nickname', 'product', 'description')
    CONFIGFILES = ('instrument.ini',)

    class InvalidSerialNumber (base.SysConfigError):
        '''Invalid serial number: %(serialnumber)r'''

    class InvalidProductName (base.SysConfigError):
        '''Invalid product name: %(product)r'''

    def get (self):
        valuemap = InstrumentInfoProvider.get(self)
        for key in InstrumentInfoProvider.KEYS:
            if not valuemap.get(key):
                value = valuemap.pop(key, None)

        return valuemap


    def validate (self, valuemap, save=False):
        #for key in (self.VERSION, self.BUILD):
        #    if key in valuemap:
        #        raise self.ReadOnly(attribute=key)

        if self.SERIALNUMBER in valuemap:
            if not re.match(r'^[\w-]+$', valuemap[self.SERIALNUMBER]):
                raise self.InvalidSerialNumber(serialnumber=valuemap[self.SERIALNUMBER])

        if self.PRODUCT in valuemap:
            if not re.match(r'^[\w-]+$', valuemap[self.PRODUCT]):
                raise self.InvalidProductName(product=valuemap[self.PRODUCT])

        return True

    def configure (self, valuemap, save=False):
        self.load()
        for key, value in valuemap.items():
            self.instrumentinfo.set(self.CONFIGSECTION, key, value)
        if save:
            self.instrumentinfo.save()
        return True


base.addProvider(InstrumentConfigProvider)
base.addProvider(InstrumentInfoProvider)

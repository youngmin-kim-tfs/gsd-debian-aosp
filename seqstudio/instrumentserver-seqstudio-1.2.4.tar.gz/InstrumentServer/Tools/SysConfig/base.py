########################################################################
### FILE:	sysconfigBase.py
### PURPOSE:	Abstract system configuration interface.
###             This module is not normally used loaded directly; 
###             instead, implementation modules need to be supplied
###             for each supported target OS (e.g: "sysconfigDebian").
### HISTORY:
###  2013-01-20 Tor Slettnes
###             Created
###
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

import os
import struct
import re
import shutil
import tempfile
import errno
import logging
import threading

import process
import subscription

class SysConfigError (Exception):

    def __init__ (self, text=None, **kwargs):
        Exception.__init__(self)
        self.text   = (text or self.__class__.__doc__ or "")%kwargs
        self.kwargs = kwargs

    def __str__ (self):
        return self.text

    def __repr__ (self):
        return str(self)

DOMAINS   = \
    (GLOBAL, NETIF) = \
    ("global", "netif")


providermap = {}


def addProvider (provider):

    instance = provider()
    if instance.isRelevant():
        providermap.setdefault(provider.DOMAIN, []).append(instance)


def getProviders (domain, default=None):
    return providermap.get(domain, default)



class Provider (object):
    KEYS = ()
    ARGS = ()

    class ExitStatus (SysConfigError):
        pass

    def __init__ (self, _name=None):
        self.name = (_name or self.__class__.__name__)
        self.mutex = threading.RLock()
        

    def isRelevant (self):
        '''
        Return boolean indicating whether this provider is compatible 
        with the OS on which we are running.
        '''
        print ("Class %s does not provide isRelevant() method!!"%(self.__class__.__name__))


    def keys (self):
        '''
        Return a list of keys supported by this provider
        '''
        return self.KEYS


    def listValues (self, arg):
        raise NotImplementedError


    def get (self, *keys, **kwargs):
        raise NotImplementedError


    def validate (self, *args, **items):
        ### We cannot validate in base class; return false to check next possible provider.
        return False


    def lock (self):
        if not self.mutex.acquire(0):
            logging.debug("SysConfig.%s: Waiting for other instance to complete."%(self.name,))
            self.mutex.acquire()

    def unlock (self):
        self.mutex.release()

    def configure (self, valuemap, *args, **items):
        raise NotImplementedError

    def reset (self, valuemap, *args, **kwargs):
        return True

    def apply (self, valuemap, *args, **kwargs):
        pass

    def stop (self, valuemap, *args, **kwargs):
        pass

    def start (self, valuemap, *args, **kwargs):
        pass

    def runcommand (self, args, background=False, **kwargs):
        try:
            instance = process.launch(args, detached=background, **kwargs)
            if not background:
                stdout, stderr = process.communicate(instance)
                process.waitInstance(instance)
                return stdout

        except process.ProcessError, e:
            raise self.ExitStatus(e.strerror, status=e.errno, **e.attributes)



    def daemon (self, *args):
        pass


    def safeSave (self, filename, text):
        fd, tempname = tempfile.mkstemp()

        if isinstance(text, (list, tuple)):
            for line in text:
                os.write(fd, line)
        else:
            os.write(fd, text)

        os.close(fd)
        try:
            shutil.move(tempname, filename)
        except EnvironmentError, e:
            os.remove(tempname)
            raise


    def safeSave (self, filename, text):
        if isinstance(text, (list, tuple)):
            text = "".join(text)

#        logging.debug("SysConfig: Saving to %s:%s"%
#                      (filename, ("\n%s"%text.rstrip()).replace("\n", "\n  >>")))

        fp = file(filename, "w")
        fp.write(text)
        fp.close()
        


    def isValidIP (self, string, ismask=False):
        maxoct = ismask and 255 or 254

        try:
            octets = [ int(octet) for octet in string.split('.') ]
        except ValueError:
            return False

        if len(octets) != 4:
            return False

        if (min(octets) < 0) or (max(octets) > maxoct):
            return False

        return True





class GlobalProvider (Provider):
    DOMAIN = GLOBAL

class NetNameProvider (GlobalProvider):

    defs = { 'alnum' : "A-Za-z0-9",
             'alpha' : "A-Za-z" }
    
    fqdnTests = {
        True:  re.compile(r'(?:[%(alnum)s](?:[%(alnum)s\-]*[%(alnum)s])?\.?)+$'%defs),
        False: re.compile(r'[%(alnum)s](?:[%(alnum)s\-]*[%(alnum)s])?$'%defs)
        }

    class NetConfigError (SysConfigError):
        pass
    
    class InvalidAddress (NetConfigError):
        "Invalid %(key)s: %(value)s"


    class InvalidName (NetConfigError):
        '''Invalid %(key)s: %(name)s'''


    def check (self, name, key="name", fqdn=False):
        if not self.fqdnTests[fqdn].match(name):
            raise self.InvalidName(key=key, name=name)




class NetDeviceProvider (Provider):
    DOMAIN  = NETIF
    STATES  = (DISABLED, ENABLED, HOTPLUG) = ('disabled', 'enabled', 'hotplug')
    KEYS    = ()
    ARGS    = (INTERFACE,) = ('interface',)

    class NoSuchInterface (SysConfigError):
        '''No such interface exists: %(interface)s'''


    def isValidInterface (self, ifname):
        return ifname in self.listValues('interface')

    def validate (self, keys, interface, *args, **kwargs):
        return self.isValidInterface(interface)

    def get (self, interface, *args, **kwargs):
        if not self.isValidInterface(interface):
            raise self.NoSuchInterface(interface=interface)




class NetInterfaceProvider (NetDeviceProvider, NetNameProvider):

    class InvalidAddress (NetNameProvider.NetConfigError):
        "Invalid %(key)s: %(value)s"

    class MissingAddress (NetNameProvider.NetConfigError):
        "Missing %(key)s for IP configuration"

    class InvalidGateway (NetNameProvider.NetConfigError):
        "Gateway %(gateway)s is not reachable given address/netmask %(address)s/%(netmask)s"

    class NotInValidRange (NetNameProvider.NetConfigError):
        "Valid ranges for this interface are: %(validranges)s"


    DOMAIN = NETIF

    KEYS   = \
        (STATE, MODE, ADDRESS, NETMASK, GATEWAY, HOSTNAME, DNSSERVERS, DNSSEARCH) = \
        ('state', 'mode', 'address', 'netmask', 'gateway', 'hostname', 'dnsservers', 'dnssearch')


    METHODS = (DHCP, STATIC, LOOPBACK, MANUAL) = ('dhcp', 'static', 'loopback', 'manual')


    def validate (self, valuemap, interface, validranges=None, **kwargs):
        NetDeviceProvider.validate(self, valuemap, interface, **kwargs)

        if valuemap.get(self.MODE) == self.STATIC:
            address = valuemap.get(self.ADDRESS)
            netmask = valuemap.get(self.NETMASK)
            gateway = valuemap.get(self.GATEWAY)
            dnsservers = valuemap.get(self.DNSSERVERS)
            dnssearch = valuemap.get(self.DNSSEARCH)

#            if not address:
#                raise self.MissingAddress(key=self.ADDRESS)

#            if not netmask:
#                raise self.MissingAddress(key=self.NETMASK)

            if address and not self.isValidIP(address):
                raise self.InvalidAddress(key="IP address", value=address)
                    
            if netmask and not self.isValidIP(netmask, ismask=True):
                raise self.InvalidAddress(key="netmask", value=netmask)

            if address and not self.isWithinValidRange(address, validranges):
                raise self.NotInValidRanges(validranges=', '.join(validranges))

            if gateway:
                if not self.isValidIP(gateway):
                    raise InvalidAddress(key="gateway", value=gateway)

                if not self.isValidGateway(address, netmask, gateway):
                    raise self.InvalidGateway(address=address, netmask=netmask, gateway=gateway)

            if dnsservers:
                for server in dnsservers:
                    if not self.isValidIP(server, ismask=False):
                        raise self.InvalidAddress(key="dnsserver", value=server)

            if dnssearch:
                for domain in dnssearch:
                    self.check(domain, key="domain", fqdn=True)


    def configure (self, valuemap, interface, **kwargs):
        pass


    def apply (self, valuemap, interface, **kwargs):
        pass


    def get (self, interface, current=False):
       if current:
           return self.getstate(interface)
       else:
           return self.getconfig(interface)


    def getconfig (self, interface):
        pass

    def getstate (self, interface):
        pass


    def isWithinValidRange (self, address, validrange):
        addr = self.quad2num(address)

        if not validrange:
            return True

        for spec in validrange:
            try:
                vaddr, vmask = spec.split("/", 1)
            except ValueError:
                vaddr, nmask = spec, 0xFFFFFFFFL
            else:
                if self.isValidIP(vmask, ismask=True):
                    nmask = quad2num(vmask)
                else:
                    warning('Invalid mask "%s" in range specification "%s"'%
                            (vmask, spec))
                    continue

            if self.isValidIP(vaddr):
                naddr = quad2num(vaddr)
            else:
                warning('Invalid address "%s" in range specification "%s"'%
                        (vaddr, spec))

            if (addr & nmask) == (naddr & nmask):
                return True
        else:
            return False



    def isValidGateway (self, address, netmask, gateway):
        addr = self.quad2num(address)
        mask = self.quad2num(netmask)
        gw   = self.quad2num(gateway)

        return (addr & mask) == (gw & mask)


    def quad2num (self, address):
        octets = [ int(octet) for octet in address.split('.') ]
        return struct.unpack('>I', struct.pack('>4B', *octets))[0]

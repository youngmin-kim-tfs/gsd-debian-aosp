#!/usr/bin/env python
########################################################################
### FILE:	methodRun.py
### PURPOSE:	Tell a UNIFrame instrument to run one or more method
###             files.  These files must exist on the instrument 
###             filesystem.
###
### USAGE:	methodRun.py [options] {<module>|<directory>}...
###
### HISTORY:
###  2002-10-03	Tor Slettnes
###             Created
###
###  2005-01-18 Tor Slettnes
###             - Made host/port specification optional
###             - Allowed directories as arguments
###             - Allowed multiple arguments
###
### Copyrighted (C) 2002, Applied Biosystems.  All Rights Reserved.
########################################################################

from os.path     import isdir, exists
from os          import listdir
from sys         import argv, exit, stdout, stderr
from scpiClient  import SCPIClient, OK, NEXT, ERROR
    

def usage (progname, message=None):
    if message:
        retval = 1
        out    = stderr
        out.write('Error: %s'%message)
    else:
        retval = 0
        out    = stdout
        out.write("Tell a UNIFrame instrument to run the specified modules,\n")
        out.write("or in the case of directories, all modules within these.\n")


    print ("Usage: %s [options] {<module>|<directory>} ..." %progname)
    exit(retval)



def run (path):
    if isdir(path):
        stdout.write("In %s:\n"%(path,))
        ok = True
        dirlist = listdir(path)
        dirlist.sort()
        for name in dirlist:
            if not run("%s/%s"%(path, name)):
                ok = False

    elif exists(path):
        stdout.write("%25s: "%path[path.rfind("/")+1:])
        stdout.flush()
        status, reply = scpi.sendReceive("MODule %s"%(path,), )

        if status == OK:
            stdout.write("Success.\n")
            ok = True
        else:
            reply = reply.split(' <-- ')[-1]
            reply = reply.split(' --> ')[-1]

            stdout.write("Failed: %s\n"%reply)
            ok = False

    else:
        stderr.write("No such file or directory: %s\n"%path)
        ok = False

    return ok



########################################################################
### Main Body
########################################################################

progname = None
options  = { "host": "localhost",
             "port": 7000 }

args     = []

for arg in argv:
    if progname is None:
        progname = arg

    elif arg.startswith('-'):
        try:
            option, value = arg.lstrip('-').split('=', 1)
        except ValueError:
            option, value = arg.lstrip('-'), None

        current = options.get(option)
        
        if not option in options:
            usage(progname, 'Invalid option "-%s"'%option)

        elif value is None and current is not None:
            usage(progname,
                  'A value must be specified for the "-%s" option'%option)

        else:
            typeobject = type(current)
            try:
                options[option] = typeobject(value)
            except:
                usage(progname,
                      'Invalid value for option "-%s": %s'%(option, value))

    else:
        args.append(arg)

if not args:
    usage(progname)


try:
    scpi = SCPIClient((options['host'], options['port']))

except Exception, e:
    print ("Cannot connect to instrument \"%s\": %s" %
           (options['host'], e.args[0]))
    exit(-1)


#scpiComm.sendReceive("ACCess Full")

ok = True
for arg in args:
    if not run(arg):
        ok = False


exit ((-1, 0)[ok])

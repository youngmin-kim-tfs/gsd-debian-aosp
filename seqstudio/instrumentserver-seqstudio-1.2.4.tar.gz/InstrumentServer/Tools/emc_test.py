# -*- coding: utf-8 -*-
"""
Created on Mon Apr 10 07:43:56 2017

@author: habersmn
"""

import os
import sys
import time
import threading
import scpiClient

#SERVERNAME = '172.19.33.83'
SERVERNAME = 'localhost'
SERVERPORT = 7000
ACCESS = 'controller'
AUTHENTICATION ='MbmfSAtNA4f'

class TestThread(object):
    def __init__(self):
        self.scpi = scpiClient.SCPIClient(serveraddr=(SERVERNAME, SERVERPORT), 
                             access=ACCESS, 
                             authentication=AUTHENTICATION)
        self.thread = threading.Thread(target=self._run)
        self.cycle = 0
        self.name = 'TestThread'
        self.state = 'init'
        self.error = ''
        self.off()
        
    def turn_on(self):
        pass
    
    def turn_off(self):
        pass
    
    def repeat(self):
        pass
    
    def status_detail(self):
        return ''
    
    def on(self):
        try:
            self.turn_on()
        except:
            self.error = sys.exc_info()[0] 
            self.state = 'error'         
            return
        if not (self.repeat.__code__ is TestThread.repeat.__code__):
            self._start()
        else:
            self.state = 'on'
        
    def off(self):
        if not (self.repeat.__code__ is TestThread.repeat.__code__):
            self._stop()
        if self.state != 'error':
            try:
                self.turn_off()
            except:
                self.error = sys.exc_info()[0] 
                self.state = 'error'         
                return
        self.state = 'off'
        
    def status(self):
        name='%30s'%self.name
        if self.state == 'error':
            return '%s: error, %s'%(name, self.error)
        
        if not (self.repeat.__code__ is TestThread.repeat.__code__):
            status = '%s: %s, cycle=%d'%(name, self.state, self.cycle)
        else:
            status = '%s: %s'%(name, self.state)

        if not self.status_detail.__code__ is TestThread.status_detail.__code__:
            try:
                detail = self.status_detail()
            except:
                self.error = sys.exc_info()[0] 
                self.state = 'error'         
                return ''        
            return '%s, %s'%(status, detail)
        else:
            return status
          
    def _run(self):
        self.state = 'running'
        while self.state == 'running':
            self.cycle += 1
            try:
                self.repeat()
            except:
                self.error = sys.exc_info()[0] 
                self.state = 'error'         
                return
        self.state = 'stopped'
       
    def _start(self):
        self.thread.start()      
        
    def _stop(self):
        if self.thread.isAlive(): 
            self.state = 'stopping'
            self.thread.join()
            self.state = 'stopped'
    
    def __del__(self):
        self.scpi.disconnect()

class AutosamplerHome(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Autosampler Homing'
    def repeat(self):
        self.scpi.sendReceive('st:as:safehome', ignoreNext=True)

class CapAlignmentHome(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Cap Alignment Homing'
    def repeat(self):
        self.scpi.sendReceive('da:cap:home', ignoreNext=True)

class SpectrometerAcquire(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Spectrometer Acquisition'
    def repeat(self):
        self.scpi.sendReceive('da:acq -count=10', ignoreNext=True)

class LaserCW(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Laser CW'
    def turn_on(self):
        self.scpi.sendReceive('las:dev:sour:pow:lev:imm:ampl 0.020')
        self.scpi.sendReceive('las:on', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('las:off', ignoreNext=True)  
    def status_detail(self):
        status, power = self.scpi.sendReceive('las:pow?', ignoreNext=True)
        return 'power=%smW'%power

class InstrumetFan(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Instrument Fan'
    def turn_on(self):
        self.scpi.sendReceive('db:fan:inst:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('db:fan:inst:config 0xe101', ignoreNext=True)
        self.scpi.sendReceive('db:fan:inst:norm 1.0', ignoreNext=True)
        self.scpi.sendReceive('db:fan:inst:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('db:fan:inst:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, speed = self.scpi.sendReceive('db:fan:inst:speed?', ignoreNext=True)
        return 'speed=%srps'%speed

class LaserFan(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Laser Fan'
    def turn_on(self):
        self.scpi.sendReceive('db:fan:las:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('db:fan:las:config 0xe101', ignoreNext=True)
        self.scpi.sendReceive('db:fan:las:norm 1.0', ignoreNext=True)
        self.scpi.sendReceive('db:fan:las:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('db:fan:las:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, speed = self.scpi.sendReceive('db:fan:las:speed?', ignoreNext=True)
        return 'speed=%srps'%speed

class PolymerCoolerFan(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Polymer Cooler Fan'
    def turn_on(self):
        self.scpi.sendReceive('clb:fan:cpol:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('clb:fan:cpol:config 0xe101', ignoreNext=True)
        self.scpi.sendReceive('clb:fan:cpol:norm 1.0', ignoreNext=True)
        self.scpi.sendReceive('clb:fan:cpol:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('clb:fan:cpol:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, speed = self.scpi.sendReceive('clb:fan:cpol:speed?', ignoreNext=True)
        return 'speed=%srps'%speed

class OvenFan(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Oven Fan'
    def turn_on(self):
        self.scpi.sendReceive('epb:fan:cap:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('epb:fan:cap:config 0xe101', ignoreNext=True)
        self.scpi.sendReceive('epb:fan:cap:norm 1.0', ignoreNext=True)
        self.scpi.sendReceive('epb:fan:cap:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('epb:fan:cap:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, speed = self.scpi.sendReceive('epb:fan:cap:speed?', ignoreNext=True)
        return 'speed=%srps'%speed

class PolymerCooler(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Polymer Cooler'
    def turn_on(self):
        self.scpi.sendReceive('clb:cool:poly:ttem 10.0', ignoreNext=True)
        self.scpi.sendReceive('clb:cool:poly:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('clb:cool:poly:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('clb:cool:poly:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, polymer_temperature = self.scpi.sendReceive('clb:cool:poly:t?', ignoreNext=True)
        status, heatsink_temperature = self.scpi.sendReceive('clb:cool:poly:ths?', ignoreNext=True)
        status, current = self.scpi.sendReceive('clb:cool:poly:ctec?', ignoreNext=True)
        status, voltage = self.scpi.sendReceive('clb:cool:poly:vtec?', ignoreNext=True)
        return 'Tc=%.1fdegC, Th=%.1fdegC, V=%.1fV, I=%.1fA'%(float(polymer_temperature),
                                                             float(heatsink_temperature),
                                                             float(voltage),
                                                             float(current))

class CapillaryHeater(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Capillary Heater'
    def turn_on(self):
        self.scpi.sendReceive('epb:heat:cap:ctco 0.0', ignoreNext=True)
        self.scpi.sendReceive('epb:heat:cap:ttem 60.0', ignoreNext=True)
        self.scpi.sendReceive('epb:heat:cap:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('epb:heat:cap:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('epb:heat:cap:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, t1= self.scpi.sendReceive('epb:heat:cap:temp1?', ignoreNext=True)
        status, t2 = self.scpi.sendReceive('epb:heat:cap:temp2?', ignoreNext=True)
        status, th = self.scpi.sendReceive('epb:heat:cap:htem?', ignoreNext=True)
        status, current = self.scpi.sendReceive('epb:heat:cap:curr?', ignoreNext=True)
        status, voltage = self.scpi.sendReceive('epb:heat:cap:volt?', ignoreNext=True)
        return 'T1=%.1fdegC, T2=%.1fdegC, Th=%.1fdegC, V=%.1fV, I=%.1fA'%(float(t1),
                                                             float(t2),
                                                             float(th),
                                                             float(voltage),
                                                             float(current))

class SnoutHeater(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Snout Heater'
    def turn_on(self):
        self.scpi.sendReceive('db:heat:snout:ttem 60.0', ignoreNext=True)
        self.scpi.sendReceive('db:heat:snout:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('db:heat:snout:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('db:heat:snout:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, t= self.scpi.sendReceive('db:heat:snout:temp?', ignoreNext=True)
        return 'T=%.1fdegC'%(float(t))

class BufferHeater(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Buffer Heater'
    def turn_on(self):
        self.scpi.sendReceive('asb:heat:buff:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('asb:heat:buff:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('asb:heat:buff:comm 0x10', ignoreNext=True)        
    def status_detail(self):
        status, t= self.scpi.sendReceive('asb:heat:buff:temp?', ignoreNext=True)
        return 'T=%.1fdegC'%(float(t))

class HighVoltage(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'High Voltage'
    def turn_on(self):
        # load cartridge
        self.scpi.sendReceive('st:lc', ignoreNext=True)
        self.scpi.sendReceive('st:pd:vv:hom', ignoreNext=True)
        self.scpi.sendReceive('pdb:mot:vval:sdec 1000000', ignoreNext=True)
        self.scpi.sendReceive('st:pd:vv:move 20000', ignoreNext=True)
        status, position = self.scpi.sendReceive('st:pd:vv:pos?', ignoreNext=True)
        status, statreg = self.scpi.sendReceive('pdb:mot:vval:stat?', ignoreNext=True)
        if (18000 < int(position) < 20000) and ((eval(statreg) & 0x02000000)!=0):         
            self.scpi.sendReceive('epb:volt:cap:comm 0x2', ignoreNext=True)
            self.scpi.sendReceive('epb:volt:cap:rrat 13000', ignoreNext=True)        
            self.scpi.sendReceive('epb:volt:cap:tvol 13000', ignoreNext=True)
            self.scpi.sendReceive('epb:volt:cap:comm 0x11', ignoreNext=True)
            self.scpi.sendReceive('epb:volt:cap:comm 0x15', ignoreNext=True)
        else:
            raise RuntimeError('anode contact failed to close')
    def turn_off(self):
        self.scpi.sendReceive('epb:volt:cap:comm 0x10', ignoreNext=True)
        self.scpi.sendReceive('st:pd:vv:hom', ignoreNext=True)        
    def status_detail(self):
        status, voltage = self.scpi.sendReceive('epb:volt:cap:volt?', ignoreNext=True)
        status, cathode_current = self.scpi.sendReceive('epb:volt:cap:ccur?', ignoreNext=True)
        status, anode_current = self.scpi.sendReceive('epb:volt:cap:acur?', ignoreNext=True)
        return 'voltage=%.0fV, cathode_current=%.1fuA, anode_current=%.1fuA'%(float(voltage), float(cathode_current), float(anode_current))

class DoorLock(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Door Lock'
    def turn_on(self):
        self.scpi.sendReceive('asb:sol:door:comm 0x2', ignoreNext=True)
        self.scpi.sendReceive('asb:sol:door:comm 0x11', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('asb:sol:door:comm 0x10', ignoreNext=True)        

class CapillaryCurrents(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'Capillary Currents'
    def repeat(self):
        status, reply = self.scpi.sendReceive('cb:cc?', ignoreNext=True)        
        self.currents = [float(s)/1000 for s in reply.split(',')]
    def status_detail(self):
        status, t= self.scpi.sendReceive('asb:heat:buff:temp?', ignoreNext=True)
        return 'I1=%.1fdegC, I2=%.1fdegC, I3=%.1fdegC, I4=%.1fdegC,'%(tuple(self.currents))

class LED(TestThread):
    def __init__(self):
        TestThread.__init__(self)
        self.name = 'LED'
    def turn_on(self):
        self.scpi.sendReceive('db:ist:led:non 0x33CC', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:noff 0xCC00', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:nper 1.0', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:ndc 0.5', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:comm 0x14', ignoreNext=True)
    def turn_off(self):
        self.scpi.sendReceive('db:ist:led:non 0x33CC', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:noff 0xCC00', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:nper 0.0', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:ndc 0.0', ignoreNext=True)
        self.scpi.sendReceive('db:ist:led:comm 0x14', ignoreNext=True)
            
TESTS = [LED(),
         DoorLock(),
         AutosamplerHome(), 
         CapAlignmentHome(),
         SpectrometerAcquire(), 
         LaserCW(), 
         InstrumetFan(),
         LaserFan(),
         PolymerCoolerFan(),
         OvenFan(),
         PolymerCooler(),
         CapillaryHeater(),
         SnoutHeater(),
         BufferHeater(),
         HighVoltage(),
         CapillaryCurrents()]

def print_status_thread():
    while not stop:
        os.system('cls' if os.name == 'nt' else 'clear')
        for test in TESTS:
            print test.status()
        print   
        print 'Press <enter> to quit.'
        time.sleep(1)

stop=False
print_thread = threading.Thread(target=print_status_thread)
print_thread.start()

for test in TESTS:
    test.on()    

inp = raw_input()

stop = True
print_thread.join()
print 'quitting ...'
            
for test in reversed(TESTS):
    test.off()

print 'Program finished.'




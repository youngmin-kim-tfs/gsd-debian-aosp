########################################################################
### FILE:	rfidTag.py
### PURPOSE:	NFC Tag I/O Base Classes
### HISTORY:
###  2016-11-14 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################


class TagError (Exception):
    pass


class RFIDTag (object):
    TLV_TAG_TYPE   = 0x03
    TLV_LONG       = 0xFF
    TLV_TERMINATOR = 0xFE
    TLV_OFFSET     = 0x10

    def __init__ (self):
        self.tagdata = bytearray()
        self.start   = 0
        self.length  = 0

    def startRead (self, tagindex):
        '''To be optionally implemented in subclasses.
        Prepare to read.'''
        pass

    def readBytes (self, start, stop):
        '''To be implemented in subclasses.
        Return the next <count> or more available bytes, starting at <address>.
        '''
        raise NotImplementedError


    def finishRead (self, tagindex):
        '''To be implemented in subclases.
        Clean up after read.
        '''
        raise NotImplementedError


    def startWrite (self, tagindex):
        '''To be optionally implemented in subclasses.
        Prepare to write.'''
        pass

    def writeBytes (self, address, bytes):
        '''Write <bytes> bytes, starting at address <address>'''
        raise NotImplementedError


    def finishWrite (self, tagindex):
        '''To be optionally implemented in subclasses.
        Clean up after write.'''
        pass
    

    def __getdata (self):
        return self.tagdata[self.start:self.start+self.length]


    def __setdata (self, data):
        del self.tagdata[self.TLV_OFFSET:]
        self.tagdata.extend("\x00"*(self.TLV_OFFSET - len(self.tagdata)))
        self.tagdata.append(self.TLV_TAG_TYPE)

        length = len(data)
        if length < 0xFF:
            self.tagdata.append(length)
        else:
            self.tagdata.extend([ self.TLV_LONG, length & 0xFF, (length >> 8) & 0xFF ])

        self.tagdata.extend(data)
        self.tagdata.append(self.TLV_TERMINATOR)

    def __deldata (self):
        del self.tagdata[self.TLV_OFFSET:]

    data = property(__getdata, __setdata, __deldata)

    def readTag (self, tagindex, ignoreEmpty=False, ignoreMismatch=False):
        del self.tagdata[:]
        self.startRead(tagindex)
        try:
            self.tagdata.extend(self.readBytes(0, self.TLV_OFFSET+4))

            try:
                tagType, self.length = self.tagdata[self.TLV_OFFSET:self.TLV_OFFSET+2]

                if self.length == self.TLV_LONG:
                    self.start  = self.TLV_OFFSET+4
                    self.length = self.tagdata[self.TLV_OFFSET+2] | (self.tagdata[self.TLV_OFFSET+3] << 8)
                else:
                    self.start  = self.TLV_OFFSET+2

            except (IndexError, ValueError):
                if ignoreEmpty:
                    return
                else:
                    raise TagError("No tag data")

            if tagType != self.TLV_TAG_TYPE:
                if ignoreMismatch:
                    self.start  = 0
                    self.length = 0
                    return
                else:
                    raise TagError("Unknown tag format 0x%02X, expected 0x%02X"%(tagType, self.TLV_TAG_TYPE))

            if len(self.tagdata) <= self.start+self.length:
                self.tagdata.extend(self.readBytes(len(self.tagdata), self.start+self.length+1))

            try:
                tagEnd = self.tagdata[self.start+self.length]
            except IndexError:
                if ignoreEmpty:
                    return
                else:
                    raise TagError("Incomplete data in tag")

            if (tagEnd != self.TLV_TERMINATOR) and not ignoreMismatch:
                raise TagError("Missing terminator, expected 0x%02X at position %d"%
                               (self.TLV_TERMINATOR, self.start+self.length))

            return self.data
        finally:
            self.finishRead(tagindex)


    def writeTag (self, tagindex):
        self.startWrite(tagindex)
        try:
            self.writeBytes(self.TLV_OFFSET, self.tagdata[self.TLV_OFFSET:])
        finally:
            self.finishWrite(tagindex)
            

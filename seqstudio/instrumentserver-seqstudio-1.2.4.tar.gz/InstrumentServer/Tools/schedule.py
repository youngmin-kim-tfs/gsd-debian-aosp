########################################################################
### FILE:      schedule.py
### PURPOSE:   Schedule methods for periodic execution
########################################################################

import time, os

from sys           import exc_info
from thread        import error as ThreadError
from threading     import Lock, Condition, Event, currentThread
from threadControl import ControllableThread, stackTrace, Aborted, IGNORE, ALLOW
from subscription  import trace, debug, info, warning, notice, error

try:
    # Python 3 has math.inf, but does not allow sorting between numeric types and strings 
    from math import inf as infinity
except ImportError:
    # Python 2 does not have math.inf, but considers any number < any string.
    infinity = "infinity" 


TaskAlignment = ('none', 'local', 'utc')
A_NONE, A_LOCAL, A_UTC = range(len(TaskAlignment))

_nextcount        = 0
_tick             = 0.001
_maxsleep         = 0.1
_speedFactor      = 1.0
_timeshiftlimit   = 5.0
_retries          = {}
_mutex            = Lock()
_running          = True
_paused           = False
_starttime        = 0
_timerThread      = None
_dosleep          = True

_inactiveAlarms   = []
_locks            = { infinity:_inactiveAlarms }
_pendingStart     = {}
_pendingException = {}
_tasks            = {}



def start ():
    global _timerThread
    info('Starting task scheduler')
    _timerThread = ControllableThread(None, _timerloop, name='Task Scheduler', args=())
    _timerThread.setDaemon(True)
    _timerThread.setAbortable(IGNORE)
    _timerThread.setSuspendable(IGNORE)
    _timerThread.start()


def shutdown ():
    global _running, _timerThread
    info('Shutting down task scheduler')
    _running = False


def getUptime ():
    return time.time() - _starttime

def getStartTime ():
    return _starttime


def getAlignmentTime (interval, align=A_LOCAL, timestamp=None):
    if timestamp is None:
        timestamp = time.time()

    if align == A_UTC:
        tz  = 0
    elif align == A_LOCAL:
        dst = time.localtime(timestamp)[-1]
        tz  = (time.timezone, time.altzone)[dst]
    else:
        tz = _starttime

    return int(timestamp - ((timestamp - tz) % interval))


def setSpeedFactor (factor):
    global _speedFactor
    _speedFactor = factor

def getSpeedFactor ():
    return _speedFactor

def pause ():
    global _paused
    _paused = True


def resume ():
    global _paused, _nextcount

    with _mutex:
        _paused = False

        ### Reschedule all suspended tasks at the next time count
        _locks.setdefault(_nextcount, []).extend(_locks[infinity])
        del _locks[infinity][:]


def paused ():
    return _paused


def setalarm (timeout, lock, suspendable=False):
    with _mutex:
        _setalarm(timeout, lock, suspendable)


def _setalarm (timeout, lock, suspendable=False):
    count = _nextcount + max(0, _tickCount(timeout))
    _locks.setdefault(count, []).append(lock)


def clearalarm (lock):
    with _mutex:
        return _clearalarm(lock)
    

def _clearalarm (lock):
    for tasklist in _locks.values():
        try:
            tasklist.remove(lock)
            return True
        except ValueError:
            pass

    return False


def setSleep (enabled=True):
    global _dosleep
    _dosleep = enabled

def willSleep ():
    return _dosleep


def sleep (duration, suspendable=True, always=False):
    if _running and (always or _dosleep):
        thread = currentThread()
        lock   = Lock()
        lock.acquire()
        
        thread.addAbortAction(lock.release)
        setalarm(duration, lock, suspendable=suspendable)
        lock.acquire()
        clearalarm(lock)
        thread.delAbortAction(lock.release)


def scheduleList ():
    return [name for name, lock, thread in _tasks.values()]

def getTask (handle):
    name, lock, thread = _tasks[handle.lower()]
    return thread._Thread__args

def isStarted (handle):
    name, lock, thread = _tasks[handle.lower()]
    return thread._Thread__started


def reschedule (handle, delay=0):
    with _mutex:
        name, lock, thread = _tasks.pop(handle.lower())
        _clearalarm(lock)
        _setalarm(delay, lock)
        

def schedule (handle, interval, method, args=(), kwargs={}, count=None, retries=0,
              align=A_NONE, delay=0, synchronous=False, suspendable=False, abortable=False, waitstart=False):

    args = (handle, interval, method, args, kwargs, count, retries, align, delay, suspendable)

    ### Acquire task scheduling mutex; this will be released within
    ### the "_runTask" method.
    _mutex.acquire()

    if (synchronous):
        _runTask(*args)
    else:
        if waitstart:
            pending = _pendingStart[handle.lower()] = Event()

        thread = ControllableThread(None, _runTask, handle, args)
        thread.setDaemon(True)
        thread.setAbortable((IGNORE, ALLOW)[abortable])
        thread.start()

        if waitstart:
            pending.wait()
            exception = _pendingException.get(handle, None)

            if exception:
                exc, tb = exception
                raise type(exc), exc, tb

        
        

def unschedule (handle, wait=True):
    global _mutex

    with _mutex:
        name, lock, thread = _tasks.pop(handle.lower())
        _clearalarm(lock)
        try:
            lock.release()
        except ThreadError:
            pass


    ### Wait for schedule thread to complete before returning.
    if wait and (thread is not currentThread()):
        thread.join()
        
        




########################################################################
### METHOD:     _runTask
### PURPOSE:    Repeat a task within a separate thread according to its
###             specific schedule.
########################################################################
    


def _runTask (handle, interval, method, args, kwargs, repeats, maxretries, align, delay, suspendable):
    global _locks, _tick, _tasks, _tickCount, _pendingStart

    try:
        frequency  = max(1, _tickCount(interval))
        delaycount = _tickCount(delay)
        count      = 0
        failures   = 0
        lock       = Lock()
        lock.acquire()

        try:
            otherName, otherLock, otherThread = _tasks[handle.lower()]
        except KeyError:
            otherLock = None

        _tasks[handle.lower()] = thisHandle = handle, lock, currentThread()

        if otherLock:
            otherLock.release()

        nextslot = _nextcount + delaycount
        nexttime = _starttime + (_tick * nextslot)

        if align:
            aligntime  = getAlignmentTime(interval, align=align, timestamp=nexttime)
            nexttime   = aligntime + interval
            nextslot   = int((nexttime - _starttime) / _tick + 1)

        _locks.setdefault(nextslot, []).append(lock)

        debug("Scheduling task %r to run every %s seconds, starting at %s (local time %s)"%
              (handle, interval, nexttime,
               time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(nexttime))))

    finally:
        _mutex.release()


    pending = _pendingStart.pop(handle.lower(), None)

    while (repeats == None) or (repeats > 0):
        ### Acquire the timing lock. This will be released by _timerloop()
        lock.acquire()

        ### If we are no longer in the task list, we got unscheduled
        if _tasks.get(handle.lower()) is not thisHandle:
            break

        elif _paused and suspendable:
            nextslot = infinity

        else:
            try:
                trace("Invoking scheduled task %r"%(handle,))
                method(*args, **kwargs)
                failures = 0
                count += 1

            except Aborted:
                info("Aborted scheduled task %r"%(handle,))
                break
            
            except Exception, e:
                e_type, e_name, e_tb = exc_info()
                failures += 1

                if failures >= maxretries:
                    if pending:
                        _pendingException[handle] = (e, e_tb)
                    else:
                        notice("Scheduled task %r failed %d times, stopping: [%s]: %s"%
                               (handle, failures, getattr(e, 'name', e.__class__.__name__), e))
                        debug(stackTrace(method, args, kwargs, e_tb))
                    break
                else:
                    info("Scheduled task %r failed, %d retries remaining: [%s]"%
                         (handle, maxretries-failures, getattr(e, 'name', e.__class__.__name__)))
                    #debug(stackTrace(method, args, kwargs, e_tb))
            finally:
                if pending:
                    pending.set()
                    pending = None
                
            if repeats:
                repeats -= 1

        with _mutex:
            if nextslot < _nextcount:
                nextslot = _nextcount-1+frequency - (_nextcount-1-nextslot)%frequency

            _locks.setdefault(nextslot, []).append(lock)


    debug("Unscheduling task %r"%(handle,))

    if pending:
        pending.release()

    with _mutex:
        if _tasks.get(handle.lower()) is thisHandle:
            del _tasks[handle.lower()]

    
def _tickCount (time=None):
#    if time is None:
#        time = time.time()

    return int(time / _speedFactor / _tick)

    

def _timerloop ():
    global _starttime, _nextcount, _locks

    _starttime = nexttime = now = time.time()

    while _running:
        try:
            with _mutex:
                for lock in _locks.pop(_nextcount, []):
                    if _paused and suspendable:
                        _locks[infinity].append(lock)

                    else:
                        try:
                            lock.release()
                        except ThreadError:
                            pass

                now = time.time()

                if abs(now - nexttime) > _timeshiftlimit:
                    shift = now - nexttime
                    notice("Clock skew detected. Shifting time reference %.1f seconds (from %.1f to %.1f)"%
                           (shift, _starttime, _starttime+shift))
                    _starttime += shift

                maxticks   = _tickCount(now + _maxsleep - _starttime)
                _nextcount = min(min(_locks), maxticks)
                nexttime   = _starttime + (_tick * _nextcount)

            if (nexttime > now):
                time.sleep(nexttime - now)

        except Exception, e:
            error("Internal scheduler error: %s"%e)



def _runCommand (command):
    inp, outp, errp = os.popen3(command)
    inp.close()

    err = errp.read()
    errp.close()
    
    out = outp.read()
    outp.close()

    if err:
        raise OSError(err)

    return out



#start()

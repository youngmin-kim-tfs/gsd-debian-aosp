#!/usr/bin/python
########################################################################
### FILE:	pdaq_download.py
### PURPOSE:	Download the data from the PDAQ
### AUTHOR:	Richard D. Morris
###
### Copyrights (C) 2010 Life Technologies, Inc.  All rights reserved.
########################################################################

import re
import sys
import optparse
import scpiClient
import pdaq
import Gnuplot
import time


version = "0.1"

        
def getOptions (version, defaulthost="localhost", defaultport=7000):
    parser = optparse.OptionParser()

    parser.add_option(
        "-s", "--server",
        dest="server", nargs=1, default="localhost",
        help="Host on which the SCPI server is running [%default]")

    parser.add_option(
        "-p", "--port",
        dest="port", nargs=1, default=7000,
        help="TCP port on which the SCPI server is listening [%default]")

    parser.add_option(
        "-v", "--verbose",
        dest="verbose", action='store_true', default=False,
        help='Be verbose')

    options, args = parser.parse_args()
    return options, args


class SCPI_IO:
        def __init__(self,scpiClient):
            self.scpiClient = scpiClient

    
        def sendReceive(self, command, timeout=60.0):
            status, text = self.scpiClient.sendReceive(command, timeout=timeout)
            if None:
                if status != self. scpiClient.OK:
                    raise IOError, \
                        "SCPI server returned %s response to %s: %s"%\
                        (status, command, text)
            return text


def waitForNewData(scpi_io):
   while ( (int(scpi_io.sendReceive("mcb:pdaq:stat?"),0) & 0x00000404) != 0x000000004):
   	time.sleep(0.2)


def plotData(g, pdaq_io):
    header=pdaq_io.getHeader()
    data=pdaq_io.transferAndGetData()
    plots=[]
    for i in range(1,len(header)):
	plots+=[Gnuplot.Data(data[0],data[i],title=header[i],with_='lines')]
    g.xlabel(header[0])
    g.plot(*plots)

def printData(pdaq_io):
    print "Header: \n"
    print pdaq_io.getHeader()
    print "Data: \n"
    print pdaq_io.transferAndGetData()
    print     

def execute():
    options, args  = getOptions(version)

    scpi_connection = scpiClient.SCPIClient((options.server, int(options.port)))
    scpi_io = SCPI_IO(scpi_connection)
    pdaq_io = pdaq.PDAQ(scpi_connection)
    g = Gnuplot.Gnuplot(debug=1)
    
    scpi_io.sendReceive("ACCess CONTROLLER")

    while (True):
	waitForNewData(scpi_io)
	#printData(pdaq_io)
	plotData(g,pdaq_io)

if __name__ == '__main__':
    execute()

###############################################################################
### FILE:      camSimulator.py
### PURPOSE:   Windows Interface module with ArpLib.dll for Hamamatsu camera
### AUTHOR:    Terence Soh
###
### Copyrights (C) 2007-2008 Applied Biosystems.  All rights reserved
###############################################################################

#from ctypes import windll, pointer, create_string_buffer, c_long, c_double
from time    import sleep
from logging import debug

class CameraError (Exception):
    pass

class InitializationError (CameraError):
    pass

class AcquisitionError (CameraError):
    pass

class AccessError (CameraError):
    pass

class OutOfRange (CameraError):
    pass

class CameraNotOpen (CameraError):
    pass


_isopen = False

def open ():
    '''
        Opens and initialize camera hardware
    '''
    global _isopen
    _isopen = True


def close ():
    '''
        Closes camera interface
    '''
    global _isopen
    _isopen = False


def acquire ():
    '''
        Acquires camera image
    '''

    if not _isopen:
        raise CameraNotOpen


    x1, y1, x2, y2 = getimagearea()

    width   = (x2 - x1)
    height  = (y2 - y1)
    imgsize = (x2 - x1) * (y2 - y1) * ((getpixelsize() + 7) / 8)

#    sleeptime = (_exposureTime / 1000.0) + 1
#    sleep(sleeptime)

    return imgsize, width, height, "\0" * imgsize



_size = (640, 480)

def setsize (x, y):
    '''
       Sets dimension of Image acquired (Not implemented)
    '''
    global _size
    _size = (x, y)


def getsize ():
    '''
       Returns dimension of Image acquired
    '''
    return _size



_xoffset = 0
_yoffset = 0

def getoffset ():
    '''
       Returns x, y offset of CCD image acquisition (Not implemented)
    '''
    return _xoffset, _yoffset


def setoffset (x, y):
    '''
       Sets x, y offset of CCD image acquisition (Not implemented)
    '''
    global _xoffset, _yoffset
    _xoffset = x
    _yoffset = y


_bias = 0

def setbias (value):
    '''
       Sets bias of CCD sensor (Not implemented)
    '''
    global _bias
    _bias = value


def getbias ():
    '''
       Gets bias of CCD sensor (Not implemented)
    '''
    return _bias


def setdebug (enabled):
    pass
        

_gain = 1

def setgain (value):
    global _gain
    _gain = value

def getgain ():
    return _gain


_exposureTime = 0

def setexposuretime (time):
    '''
    Set Camera Exposure Time in ms
    '''
    global _exposureTime
    _exposureTime = time


def getexposuretime ():
    '''
        Get the current Exposure time in ms
    '''
    return _exposureTime


def setmode (modes):
    '''
        Image aquistion modes (Not implemented)
    '''
    pass

def gettemperature ():
    '''
        Get the current Exposure time in ms
    '''
    return 0.0

def settemperature (temperature):
    '''
        Set the camera temperature
    '''
    pass

def setthermistor ():
    '''
        Selected the desired board thermistor
    '''
    pass

def updatefirmware (firmware):
    '''
        Simulated camera firmware update
    '''
    pass


def getmodel ():
    return "Simulator-0.1"

def gethardwareversion ():
    return "1234"

def getlibraryversion ():
    return "0.1.2"

def getdriverversion ():
    return "333"


def getserial ():
    return "DEADBEEF"


def getpixelsize ():
    return 12


_imagearea = (0, 0, 0, 0)

def setimagearea (x1, y1, x2, y2):
    global _imagearea
    _imagearea = (x1, y1, x2, y2)

def getimagearea ():
    return _imagearea

def getmaximagearea ():
    return (0, 0, 2592, 1880)

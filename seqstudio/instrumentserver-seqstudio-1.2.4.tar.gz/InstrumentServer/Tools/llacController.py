#######################################################################
### FILE:	llacController.py
### PURPOSE:	LLAC I/O functions
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved
########################################################################

from threadControl import ControllableThread, safeInvoke, stackTrace, Aborted
from threading     import Lock
from locking       import Queue, Empty
from struct        import pack, unpack, error as StructError
from subscription  import addTopic, publish, warning, notice, TRACE, DEBUG, INFO, NOTICE
from time          import time, sleep
from sys           import exc_info


REGISTRATION_NODE = 0x00
BROADCAST_NODE    = 0xFF
MessageTypes = { }
mRefs = { }


### Event handler identifiers
(SYNC_HANDLER, )  = range(1)

SyncMode = "Synchronous", "Asynchronous"
(SYNCHRONOUS, ASYNCHRONOUS) = range(len(SyncMode))


def _packetDict (name, mt, dest, source, control, ref, msgid, data=None):
    return locals()


def _packetString (name, mt, dest, source, control, ref, msgid, data, delimiter=","):
    mtname     = MessageTypes.get(mt, 'Invalid message type %s'%(mt,))
    datastring = delimiter.join([ '0x%02X'%ord(c) for c in data ])
    refname    = mRefs.get(mt, 'ref')

    return ("%s, name=%s, dest=0x%02X, source=0x%02X, control=0x%02X, %s=0x%04X, msgid=0x%04X, data=[%s]"
            %(mtname, name or "(unknown)", dest, source, control, refname, ref, msgid, datastring))
              



class HEX8 (int):
    def __repr__ (self):
        return "0x%02X"%(self,)

class HEX16 (int):
    def __repr__ (self):
        return "0x%04X"%(self,)

class HEX32 (int):
    def __repr__ (self):
        return "0x%08X"%(self,)



########################################################################
### LLAC Controller class.
### Method naming conventions used in this class:
###   - Method names starting with an underscore ("_") are "private".
###
###   - Method names starting with a double underscore ("__"), except
###     python names like __init__(), are executed in a separate thread.


class LLACController (object):
    empty = '\x00' * 8

    class LLACError (Exception):
        "LLAC error in response to: %(request)s"

        def __init__ (self, *args, **kwargs):
            self.args   = args
            self.kwargs = kwargs

        def __str__ (self):
            return self.__class__.__doc__%self.kwargs


    class LLACTimeout (LLACError):
        def __init__ (self, timeout, request):
            self.timeout = timeout
            self.request = request

        def __str__ (self):
            return ('No reply after %fs in response to: %s'%
                    (self.timeout, _packetString(**self.request)))


    class LLACErrorResponse (LLACError):
        def __init__ (self, request, response):
            self.request      = request
            self.response     = response

        def __str__ (self):
            syncmode   = self.response['control'] & 0x01
            data       = self.response['data']
            datastring = ",".join([ '0x%02X'%ord(c) for c in data ])

            return ("Device 0x%02X returned %s %s with status code 0x%04X %s"
                    "in response to: %s"%
                    (self.response['source'],
                     SyncMode[syncmode], 
                     MessageTypes.get(self.response['mt'], "Invalid Message Type"),
                     self.response['ref'],
                     datastring and "(data=%s) "%datastring or "",
                     _packetString(**self.request)))


    class LLACNotOpenError (LLACError):
        "LLAC Transport is not open"


    class LLACTooManyPendingRequests (LLACError):
        "Too many LLAC pending requests, no message IDs available"


    def __init__ (self, transport, nodeAddr=0x00):
        self.isopen        = False
        self.sendLock      = Lock()
        self.nodeAddr      = nodeAddr
        self.requestID     = 0
        self.responses     = {}
        self.eventQueue    = Queue()
        self.handlers      = {}
        self.eventHandlers = {}
        self.transport     = transport
        self.blocked       = False
        self.logTopic      = "LLAC"
        self.logLevel      = None

        try:
            self.transportBuffer  = self.transport.DataBuffer()
            self.transport.activateBuffer(self.transportBuffer)
        except AttributeError:
            self.transportBuffer  = None
            self.databuffer       = []
            self.lastindex        = -1
            self.clearDataBuffer()


        MessageTypes.update({
                transport.MT_EVENT   : 'Event',
                transport.MT_WRITE   : 'WriteRequest',
                transport.MT_ACK     : 'Acknowledge',
                transport.MT_READ    : 'ReadRequest',
                transport.MT_REPLY   : 'ReadReply',
                transport.MT_REGREQ  : 'RegistrationRequest',
                transport.MT_TRANSFER: 'Transfer' })
        
        mRefs.update({
                transport.MT_EVENT    : 'id',
                transport.MT_WRITE    : 'reg',
                transport.MT_ACK      : 'status',
                transport.MT_READ     : 'reg',
                transport.MT_REPLY    : 'status' })


        self._setHandler(self.transport.MT_ACK,      self.__processResponse)
        self._setHandler(self.transport.MT_REPLY,    self.__processResponse)
        self._setHandler(self.transport.MT_EVENT,    self.__processEvent)
        self._setHandler(self.transport.MT_TRANSFER, self.__processTransfer)

        self.addEventHandler(SYNC_HANDLER, self.__handleSyncEvent,
                             control=0x80, controlMask=0x80)




    def _setHandler (self, messageType, handler):
        self.handlers[messageType] = handler

    def setLogging (self, level, topic):
        self.logLevel = level
        self.logTopic = topic


    def log (self, message, level=TRACE):
        publish("LLAC", message, level=level)

    def logPacket (self, prefix, name, args, level=None):
        if level is None:
            level = self.logLevel
            
        if level is not None:
            publish(self.logTopic,
                    ": ".join((prefix, _packetString(name, *args))),
                    level=level)


    def open (self):
        if not self.isopen:
            self.log("Opening LLAC transport %s" % (self.transport.__name__), level=INFO)
            self.transport.open(self.nodeAddr)
            self.isopen = True


        if self.transportBuffer:
            self.log("Using LLAC data buffer provided by transport", level=DEBUG)
        else:
            self.log("Using internal LLAC data buffer; none provided by transport", level=DEBUG)
            
        t = ControllableThread(None, self.__receiveLoop, 'LLAC-R')
        t.setDaemon(True)
        t.setAbortable(False)
        t.start()
        
        t = ControllableThread(None, self.__eventHandlerLoop, 'LLAC')
        t.setDaemon(True)
        t.setAbortable(False)
        t.start()


    def close (self):
        if self.isopen:
            self.log("Closing LLAC transport", level=INFO)
            self.isopen = False
            self.transport.close()
            self.eventQueue.cancel()



    def __receiveLoop (self):
        self.log('Starting LLAC receive thread', level=INFO)
        try:
            while self.isopen:
                self.blocked = True
                packet = self.transport.receive()
                self.blocked = False

                mt     = packet[0]
                try:
                    handler = self.handlers[mt]
                except KeyError:
                    self.logPacket("Received unexpected LLAC packet type", None, packet, level=NOTICE)
                else:
                    handler(*packet)

        except EOFError, e:
            pass

        except Exception, e:
            e_type, e_name, e_tb = exc_info()
            warning('In LLAC recieve thread: %s'%(stackTrace(traceback=e_tb)))

        self.log('Ending LLAC receive thread', level=DEBUG)
        self.close()



    def __processResponse (self, mt, dest, source, control, status, msgid, data):
        received = (mt, HEX8(dest), HEX8(source), HEX8(control), HEX16(status), HEX16(msgid), data)
        try:
            name, sent, queue = self.responses[msgid]

        except KeyError:
            self.logPacket("Ignoring response to unknown request", None, received, level=INFO)

        else:
            self.logPacket("Received", name, received)
            queue.put(received)


    def __processEvent (self, *args):
        """
        Process an event message.  Pass the event to the registered handler(s),
        and then send ACK back to the device.
        """
        self.logPacket("Received", None, args)
        self.eventQueue.put(args)
        


    def __eventHandlerLoop (self):
        self.log('Starting LLAC event thread', level=INFO)

        while self.isopen:
            try:
                mt, dest, source, control, eventid, msgid, data = event = self.eventQueue.get(abortable=False)
            except Empty:
                break
            else:
                for name, handler, args in self._getEventHandlers(dest, source, eventid, msgid, control):
                    args = (dest, source, eventid, msgid, control, data) + tuple(args)
                    safeInvoke(handler, args, {},
                               description='LLAC Event Handler "%s"'%(name,),
                               log=warning)

        self.log('Ending LLAC event thread', level=INFO)



    def __processTransfer (self, mt, dest, source, control, index, msgid, data):
        """
        Process a transfer packet.
        There is no ACK back to the device for this type of packet.
        """

        self.logPacket("Received", None, (mt, dest, source, control, index, msgid, data))

        self.databuffer[index] = data
        if self.lastindex != index:
            self.lastindex = index


    def fillDataBuffer (self, length):
        if self.transportBuffer:
            for idx in xrange(length):
                self.transportBuffer.set(idx, pack('!HHHH', *range(4*idx, 4*(idx+1))))

        else:
            for idx in xrange(length):
                self.databuffer[idx] = pack('!HHHH', *range(4*idx, 4*(idx+1)))
            self.lastindex = length


    def clearDataBuffer (self):
        if self.transportBuffer:
            self.transportBuffer.clear()

        else:
            self.databuffer[:] = [ self.empty ] * 0x10000
            self.lastindex = -1


    _transportBlockedWarning = False

    def isIdle (self):
        try:
            blocked = self.transport.waitingForInput()
        except AttributeError:
            if not self._transportBlockedWarning:
                self._transportBlockedWarning = True
                self.log("LLAC Transport %r lacks waitingForInput() method.  Spurious deregistrations may occur!"%
                         self.transport.__name__, level=DEBUG)

            blocked = self.blocked


        if not blocked:
            return False

        if self.eventQueue.queue:
            return False

#        for name, packet, queue in self.responses.values():
#            if queue.queue:
#                return False

        return True



    def getData (self, start=0, count=None):
        if self.transportBuffer:
            if count is None:
                count = self.transportBuffer.getIndex() - start;
                
            return self.transportBuffer.toString(start, count)
        else:
            end = self.getDataIndex()
            if end - start > count > None:
                end = start + count

            return ''.join(self.databuffer[start:end])
        

    def getDataIndex (self):
        if self.transportBuffer:
            return self.transportBuffer.getIndex()
        else:
            return self.lastindex + 1

    def getDataGaps (self):
        if self.transportBuffer:
            return self.transportBuffer.getGaps()
        else:
            return [ idx for idx, data in enumerate(self.databuffer) if data is self.empty ]
        

    def addEventHandler (self, handle,
                         function, args=(),
                         target=None,  targetMask=None,
                         source=None,  sourceMask=None,
                         id=None,      idMask=None,
                         msgid=None,   msgIdMask=None,
                         control=None, controlMask=None):
        """
        Add an event handler method. This will be invoked when an
        LLAC event message is received, and all of the following
        value pairs match after applying (ANDing with) the corresponding
        mask on both values:

         - The destination node matches 'target' after applying 'targetMask'
         - The originator node matches 'source' after applying 'sourceMask'
         - The event id matches 'id' after applying 'idMask'
         - The control bits match 'control' after applying 'controlMask'

        For each of these values, None indicates a wildcard match
        (any value will match, regardless of the mask).

        When a matching event message arrives, the handler is
        invoked as follows:

            handler(target, source, id, control, data, *args)

        where:
            target  = the 8-bit destination node address (ours)
            source  = the 8-bit node address of the originating peripheral
            id      = the 16-bit event ID
            control = the 8-bit control mask used in the event message
                      (bit #6 indicates a registration event)
            data    = up to 4 bytes of event data (d4 - d7)
        """
        self.eventHandlers[handle] = (function, args,
                                      (target,  targetMask),
                                      (source,  sourceMask),
                                      (id,      idMask),
                                      (msgid,   msgIdMask),
                                      (control, controlMask))




    def removeEventHandler (self, handle):
        del self.eventHandlers[handle]


    def listEventHandlers (self):
        handlers = [h for h in self.eventHandlers if isinstance(h, str)]
        handlers.sort()
        return handlers


    def getEventHandler (self, name):
        return self.eventHandlers.get(name)


    def _getEventHandlers (self, target, source, id, msgid, control):
        handlers = []
        for name, handler in self.eventHandlers.items():
            func, args, tspec, sspec, ispec, mspec, cspec = handler
            for value, spec in ((target,  tspec),
                                (source,  sspec),
                                (id,      ispec),
                                (msgid,   mspec),
                                (control, cspec)):

                if not self._match(value, *spec):
                    break
            else:
                handlers.append((name, func, args))

        return handlers


    def _match (self, value, match, mask):
        if match is None:
            return True
        elif mask is None:
            return value == match
        else:
            return (value & mask) == (match & mask)



    def __handleSyncEvent (self, target, source, id, msgid, control, data):
        self.__processResponse(self.transport.MT_EVENT, target, source, 0x01, 0, id, data)


    def sendRequest (self, name, mt, node, reg, data="", control=0x00):
        '''
        Send an LLAC request, after creating a Queue() object to
        handle responses.

        Any calls to this method MUST be matched with a call to
        finishRequest() after the response has been received, in order
        to delete the queue object (which, depending on implementation,
        may use machine resources such as file descriptors or threads).
        '''

        self.sendLock.acquire()

        try:
            ### Pick the next available message ID
            msgid = (self.requestID + 1) & 0x7FFF;
            while (self.responses.has_key(msgid) or not (msgid & 0xFF)) and (msgid != self.requestID):
                msgid = (msgid + 1) % 0x7FFF;

            if msgid == self.requestID:
                raise self.LLACTooManyPendingRequests()

            packet = mt, node, self.nodeAddr, control, reg, msgid, data

            if not self.isopen:
                request=_packetDict(name, *packet)
                raise self.LLACNotOpenError(request=request)

            self.responses[msgid]  = (name, packet, Queue())
            self.logPacket("Sending", name, packet)
            self.transport.send(*packet)

            self.requestID = msgid
            return HEX16(msgid)

        finally:
            self.sendLock.release()
            


    def resendRequest (self, requestID):
        try:
            self.sendLock.acquire()
            name, request, queue = self.responses[requestID]
            self.logPacket("Resending", name, request, level=INFO)
            self.transport.send(*request)
        finally:
            self.sendLock.release()


    def receiveResponse (self, requestID, timeout,
                         asynchronous=False, abortable=True, totalTimeout=None, retries=0):
        """
        Wait for an LLAC response with a request ID matching 'requestID'.
        """

        elapsed = 0

        while True:
            name, request, queue = self.responses[requestID]

            try:
                response = queue.get(True, timeout, suspendable=True, abortable=abortable)

            except Empty:
                elapsed += timeout
                failure = self.LLACTimeout(timeout=totalTimeout or elapsed,
                                           request=_packetDict(name, *request))
                if retries:
                    notice("%s -- retrying"%failure)
                    try:
                        self.sendLock.acquire()
                        self.transport.send(*request)
                    finally:
                        self.sendLock.release()

                    retries -= 1
                else:
                    raise failure

            else:
                mt, dest, source, control, status, msgid, data = response
                async = bool(control & 0x01)

                if status:
                    raise self.LLACErrorResponse(request=_packetDict(name, *request),
                                                 response=_packetDict(name, *response))

                elif async == asynchronous:
                    return data

                else:
                    notice('Expected %s response, got %s (in response to: %s)'%\
                           (SyncMode[asynchronous], SyncMode[async],
                            _packetString(name, *request)))


                    ### If we expected a synchronous response (Ack) but received
                    ### an asynchronous response (Completed), keep that response
                    ### for later.
                    if async:
                        queue.put(response)

                    return data



    def finishRequest (self, requestID):
        try:
            del self.responses[requestID]
        except KeyError:
            warning("Attempted to remove non-existing LLAC message ID 0x%04X. "
                    "Remaining message IDs are: %s"%
                    (requestID, ",".join(["0x%04X"%k for k in self.responses])))
        


    def write (self, name, node, register, data, control, timeout):
        """
        Write to an LLAC register, and wait for an acknowledgement.
        Returns True if ACK was received, False otherwise.
        May raise an LLACTimeout exception.
        """

        requestID = self.sendWrite(name, node, register, data, control)
        try:
            return self.receiveResponse(requestID, timeout, False)
        finally:
            self.finishRequest(requestID)


    def sendWrite (self, name, node, register, data, control):
        """
        Send a write request without waiting for a response.
        This may be used to 'burst' multiple writes.
        Returns the request ID; this may be used as an argument
        for subsequent 'receiveResponse()' calls - and MUST be
        used as an argument for a mandatory 'finishRequest()'
        call once any repsonses have been received.
        """
        return self.sendRequest(name, self.transport.MT_WRITE, node, register, data, control)


    def read (self, name, node, register, count, timeout):
        """
        Sends a read request and wait for the response.
        Returns the data bytes from the response.
        May raise an LLACTimeout exception.
        """

        requestID = self.sendRead(name, node, register, count)
        try:
            return self.receiveResponse(requestID, timeout, False)
        finally:
            self.finishRequest(requestID)



    def sendRead (self, name, node, register, count=4):
        """
        Sends a read request without waiting for a response.
        This may be used in the following situations:
         - To burst multiple read requests at once, and collect
           responses asynchronously.

         - To send a broadcast read request, or one that otherwise
           will receive multiple responses.

        Returns the request ID; this may be used as an argument
        for subsequent 'receiveResponse()' calls, and MUST be used
        as an argument for a mandatory 'finishRequest()' call once
        any responses have been received.
            
        """
        return self.sendRequest(name, self.transport.MT_READ, node, register, control=count)



    def sendRegistrationRequest (self, node=0xFF, control=0x00, ref=0x0000, data=""):
        """
        Sends a registration request to the specified node address.
        All devices will respond to node address 0xFF.
        """

        msgid = self.sendRequest("(RegRequest)", self.transport.MT_REGREQ, node, ref)
        self.finishRequest(msgid)



    def sendEvent (self, name, node, eventid, data, control):
        """
        Sends an event message.
        """
        return self.sendRequest(name, self.transport.MT_EVENT, node, eventid, data, control)



    def fallbackTransfer (self, source, destination, sequence, data, increment, delay):
        for index in xrange(0, len(data), 8):
            bytes = data[index:index+8]
            self.transport.send(self.transport.MT_TRANSFER,
                                destination, source, 0x00, sequence, 0x0000, bytes)
            sequence += increment
            if delay:
                sleep(delay)

        return sequence

    def transfer (self, node, sequence, data, increment=1, delay=0):
        """
        Send the given data to the given node and register,
        splitting up into several packets as neccessary.
        Each subsequent packet increments the value of 'register'
        by the value of 'increment'.
        """
        if not self.isopen:
            request=_packetDict(name=None, mt=self.transport.MT_TRANSFER,
                                dest=node, source=self.nodeAddr,
                                control=0x00, ref=sequence)
            raise self.LLACNotOpenError(request=request)

        self.sendLock.acquire()

        try:
            return self.transport.transfer(self.nodeAddr, node, sequence, data, increment, delay)
        except AttributeError as e:
            return self.fallbackTransfer(self.nodeAddr, node, sequence, data, increment, delay)
        finally:
            self.sendLock.release()



########################################################################
### FILE:	runplan.py
### PURPOSE:	Run a script in order
### HISTORY:
###  2016-07-28 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from logging       import debug
from threadControl import currentThread, ControllableThread

class RunPlan (object):
    def __init__ (self, title=None, legend=None, logMethod=debug):
        self.title     = title
        self.legend    = legend
        self.logMethod = logMethod
        self.steps     = []
        self.pending   = []
        self.laststep  = None

    def addStep (self, method, args=(), kwargs={}, sync=None, legend=None):
        self.steps.append((method, args, kwargs, sync, legend))
        
    def start (self):
        try:
            step = self.steps.pop(0)
        except IndexError:
            return False
        else:
            self.notify(self.legend)
            self.runStep(step)
            return True

    def runStep (self, step):
        method, args, kwargs, sync, legend = step
        self.notify(legend)

        ref = method(*args, **kwargs)
        if sync:
            if ref is None:
                ref = ()
            elif not isinstance(ref, tuple):
                ref = (ref,)

            self.pending.append((sync, ref))

        if isinstance(currentThread(), ControllableThread):
            currentThread().check()


    def notify (self, text):
        if text:
            self.logMethod(": ".join(filter(None, (self.title, text))))

    def sync (self):
        while True:
            try:
                sync, ref = self.pending.pop(0)
            except IndexError, e:
                break
            else:
                sync(*ref)
                    

    def complete (self):
        self.sync()

        while True:
            try:
                step = self.steps.pop(0)
            except IndexError:
                break
            else:
                self.runStep(step)
                self.sync()

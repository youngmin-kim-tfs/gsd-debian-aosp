########################################################################
### FILE:	ndefTag.py
### PURPOSE:	NFC/RFID tag with Ndef format
### HISTORY:
###  2016-11-14 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from rfidTag import RFIDTag, TagError

class NdefError (TagError):
    pass

class NdefMessage (object):
    MASK_TNF  = 0x07    # Type Name Format
    MASK_IL   = 0x08    # ID Length
    MASK_SR   = 0x10    # Short Record (1-byte payload length)
    MASK_CF   = 0x20    # Chunk Flag
    MASK_ME   = 0x40    # Message End (last record)
    MASK_MB   = 0x80    # Message Begin (first record)

    MASKS     = (MASK_TNF, MASK_IL, MASK_SR, MASK_CF, MASK_ME, MASK_MB)

    (TNF_EMPTY, TNF_WELLKNOWN, TNF_MIME, TNF_URL,
     TNF_EXTERNAL, TNF_UNKNOWN, TNF_UNCHANGED, TNF_RESERVED) = range(8)

    (WELLKNOWN_TEXT, WELLKNOWN_URI, WELLKNOWN_SMARTPOSTER) = ('T', 'U', 'Sp')

    def popRecord (self, bytestream):
        try:
            header = bytestream.pop(0)         # First byte is header

            tnf, il, sr, cf, me, mb \
                = [ header & mask for mask in self.MASKS ]

            typelength = bytestream.pop(0)     # Second byte is type length

            payloadlength = bytestream.pop(0)  # Third byte is payload length, and
            if not sr:                         # unless this is a "short" record,
                for i in range(1, 4):          # the next three bytes are also used
                    payloadlength |= bytestream.pop(0) << (8*i)  # for the length.

            # If the message has an ID, that comes next.
            idlength = il and bytestream.pop(0) or 0

            # The record type has varaiable length.
            recordtype = str(bytestream[:typelength])
            del bytestream[:typelength]

            # So does the record ID,
            if idlength:
                recordid = bytestream[:idlength]
                del bytestream[:idlength]
            else:
                recordid = None

            # and the payload.
            payload = bytestream[:payloadlength]
            del bytestream[:payloadlength]

        except IndexError:
            raise NdefError("Incomplete NDEF data")

        return (tnf, mb, me, recordtype, recordid, payload)



    def addRecord (self, bytestream, tnf, mb, me, recordtype, recordid, payload):
        header = tnf

        if mb:
            header |= self.MASK_MB;

        if me:
            header |= self.MASK_ME;

        if recordid is not None:
            header |= self.MASK_IL;

        if len(payload) < 0x100:
            header |= self.MASK_SR;
            payload_size = 1
        else:
            payload_size = 4
            
        bytestream.append(header)           # First byte is header
        bytestream.append(len(recordtype))  # Second byte is type

        payloadlength = len(payload)  # Next 1 or 4 bytes is payload length
        for n in range(payload_size):
            bytestream.append(payloadlength & 0xFF)
            payloadlength >>= 8

        if recordid is not None:
            bytestream.append(len(recordid)) # Record ID, if present

        bytestream.extend(recordtype)
        if recordid is not None:
            bytestream.extend(recordid)

        bytestream.extend(payload)


    def popMessage (self, bytestream):
        tnf, mb, me, recordtype, recordid, payload = self.popRecord(bytestream)

        if not mb:
            raise NdefError("First Ndef record is missing Message Begin flag")

        if not recordtype:
            raise NdefError("Ndef record type is missing")

        message = (message_tnf, message_type, message_id, message_data) = (tnf, recordtype, recordid, payload)

        while not me:
            if len(bytestream) == 0:
                raise NdefError("End of Ndef message reached with no Message End flag")


            tnf, mb, me, recordtype, recordid, payload = self.popRecord()

            if tnf != self.TNF_UNCHANGED:
                raise NdefError("Middle Ndef record type should be %d (Unchanged), not %d"%
                                (self.TNF_UNCHANGED, tnf))
            if recordtype:
                raise NdefError("Middle Ndef record should have no type, not %r"%
                                (recordtype,))

            message_data.extend(payload)

        return message


    def addMessage (self, tnf, recordtype, payload):
        message = bytearray()
        self.addRecord(message, tnf, True, True, recordtype, None, payload)
        return message



class NdefTag (NdefMessage, RFIDTag):
    tnf = None
    recordtype = None
    recordid = None
    payload = ()
    
    def readMessage (self, tagindex, ignoreEmpty=False, ignoreMismatch=False):
        if self.readTag(tagindex, ignoreEmpty=ignoreEmpty, ignoreMismatch=ignoreMismatch):
            return self.unpackMessage()

    def writeMessage (self, tagindex):
        self.packMessage()
        self.writeTag(tagindex)

    def packMessage (self):
        self.data = self.addMessage(self.tnf, self.recordtype, self.payload)

    def unpackMessage (self):
        bytes = self.data
        if bytes:
            message = self.popMessage(bytes)
        else:
            message = (None, None, None)
            
        self.tnf, self.recordtype, self.recordid, self.payload = message
        return message

########################################################################
### FILE:	llac2ana.py
### PURPOSE:	LLAC v10 bindings to the AnaGate CAN uno
### AUTHOR:	Sanket Chitagopkar
###
### Copyrights (C) 2014 Thermo Fisher Scientific.  All rights reserved.
########################################################################

from   struct        import pack, unpack
from   subscription  import debug, info, warning, error, publish, INFO
from   time          import sleep
import socket
import os
import inspect
try:
  import _winreg as wreg
except:
  pass

__closed = False
__restarting = False

__negResponse = {33281     :   'Open Communication command. AnaGate may not work correctly.',
                 33282     :   'Close Communication command.',
                 33283     :   'Send Data command. CAN comunication is not working.',
                 33285     :   'Set Config command.',
                 33287     :   'Set Globals command.'
               }
              
__messageTypes = (MT_EVENT, MT_WRITE, MT_ACK,
                 MT_READ, MT_REPLY, MT_REGREQ, MT_TRANSFER) = range(1,8)
__maxlen       = (-1, 4, 4, 0, 0, 4, 0, 8)

try:
  __s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
except socket.error, (val,msg):
  error('LLAC2ANA ERROR: ' + msg)
  raise

__frame = []
 
def open(node=0x00, mask=0xFF):
  "Set up logical connection to Anagate. Set config and globals"
  global __s
  global __restarting 
  if os.name == 'nt':
    try:
      key = wreg.CreateKey(wreg.HKEY_LOCAL_MACHINE, "Software\\AnaGate")
      ip = wreg.QueryValue(key, 'IPAddress')
    except:
      error('IP address of Anagate not found')
      raise
    key.Close()
  else:
    ip = file('/var/lib/anagate/ipadr.txt').read().strip()
    assert ip != '','IP address of Anagate not found'
    
  info('Connecting to AnaGate at '+ip)    
  __restarting = True
  try:
    __s.connect((ip, 5001))
    __s.sendall('\x05\x00\x0c\x02\x03\x00\x0d') #Restart AnaGate
    sleep(4)
    __s.close()
    __s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    __s.connect((ip, 5001))
    __restarting = False
    __s.sendall('\x05\x00\x01\x02\x01\x00\x02') #open CAN communication
    __s.sendall('\x07\x00\x05\x02\x04\x00\x01\x01\x03') #set config. data confirm/indication is set
  except socket.error, (val,msg):
    error('LLAC2ANA ERROR: Could not send command to AnaGate. ' + msg)
    raise   
    
def close():
  "Close logical connection to AnaGate"
  global __closed
  try:
    __s.sendall('\x05\x00\x02\x02\x01\x00\x01') #close CAN communication
    __closed = True    
    __s.sendall('\x05\x00\x0c\x02\x03\x00\x0d') #Restart AnaGate
  except socket.error, (val,msg):
    error('LLAC2ANA ERROR: ' + msg)
    raise
  sleep(2.5)
  __s.close()
    
def send(mt, dest, src, control, ref, msgid, data):
  """Send LLAC packet to AnaGate CAN uno"""
  
  assert mt in __messageTypes, 'Invalid LLAC message type'   
  assert len(data) <= __maxlen[mt] , 'Too many data bytes to fit in CAN packet'
  global __s
  d =  [ord(A) for A in data]
  
  if mt==MT_TRANSFER:
    can_id = (mt << 26) | (dest << 18) | ref
  else:
    can_id = (mt << 26) | (dest << 18) | (src << 8) | control
    d = [ref >> 8, ref & 0xFF, msgid >> 8, msgid & 0xFF] + d

  c = [len(d) + 10, 0, 3, 2, 1, 0] + [k for k in unpack('BBBB',pack('<I',can_id))] + [1] + d
  chksum = reduce(lambda x,y: x ^ y, c[2:])
  c.append(chksum)
  command = ''.join(chr(A) for A in c)
  
  try:
    __s.sendall(command)
  except:
    raise

def receive():
  """Receive CAN frames from AnaGate device
    Returns a tuple containing:
    - The ID/header
    - The data, up to 8 bytes
    """ 
  global __s
  global __frame
  
  if len(__frame) == 0:
    while 1:
      try:
        can_msgs = __s.recv(8192)
      except socket.error, (val,msg):
        if __closed or __restarting:
          pass
        else:
          error('LLAC2ANA ERROR: ' + msg)
          raise
      if len(can_msgs) >= 4:
        if unpack('<H',can_msgs[2:4])[0] == 0x203:
          j = 0
          while j < len(can_msgs):
            ana_len = unpack('<H',can_msgs[j+0:j+2])[0]
            can_len = ana_len - 10
            __frame.append(unpack('<I', can_msgs[j+6:j+10])[0])  # can_id
            __frame.append(can_len)                              # dlc
            __frame.append(unpack('<B', can_msgs[j+10])[0])      # rtr and ide
            for i in range(can_len):
              __frame.append(unpack('<B', can_msgs[j+11+i])[0])  # can_data
            j = j + ana_len + 2
          break
        else:
          if unpack('B', can_msgs[6])[0] != 0:
            warning('LLAC2ANA ERROR: Negative response from AnaGate to ' + __negResponse[unpack('<H', can_msgs[2:4])[0]])
        
  mt = (__frame[0] >> 26) & 0x7 
  if mt == MT_TRANSFER:
    dest    = (__frame[0] >> 18) & 0xFF
    src     = 0x00
    control = 0x00
    ref     = (__frame[0] >> 0) & 0xFFFF
    msgid   = 0x0000
    d       = ''.join(chr(A) for A in __frame[3:3+__frame[1]])

  else:
    dest    =  (__frame[0] >> 18) & 0xFF
    src     =  (__frame[0] >> 8) & 0xFF
    control =  (__frame[0]) & 0xFF
    ref     =  (__frame[3] << 8) | (__frame[4])
    msgid   =  (__frame[5] << 8) | (__frame[6])
    d = ''.join(chr(A) for A in __frame[7:3+__frame[1]])
    
  __frame = __frame[__frame[1]+3:]
  return (mt,dest,src,control,ref,msgid,d)

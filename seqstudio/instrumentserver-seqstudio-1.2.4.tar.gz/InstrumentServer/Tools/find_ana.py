#!/usr/bin/python
#### Find the anagate Ethernet to CAN device
####
#### Author: Sanket Chitagopkar
####
#### Date: Summer 2014
####
#### Copyright (C) Thermo Fisher Scientific, 2014
####


import re
import socket
import sys
try:
  import _winreg as wreg
except:
  pass
from   os         import name
from   subprocess import call
from   struct     import pack, unpack
from   time       import sleep

subnet = { '255.252' : '/30',
           '255.248' : '/29',
           '255.240' : '/28',
           '255.224' : '/27',
           '255.192' : '/26',
           '255.128' : '/25',
           '255.0'   : '/24',
           '254.0'   : '/23',
           '252.0'   : '/22',
           '248.0'   : '/21',
           '240.0'   : '/20',
           '224.0'   : '/19',
           '192.0'   : '/18',
           '128.0'   : '/17',
           '0.0'     : '/16',
           'fffc'    : '/30',
           'fff8'    : '/29',
           'fff0'    : '/28',
           'ffe0'    : '/27',
           'ffc0'    : '/26',
           'ff80'    : '/25',
           'ff00'    : '/24',
           'fe00'    : '/23',
           'fc00'    : '/22',
           'f800'    : '/21',
           'f000'    : '/20',
           'e000'    : '/19',
           'c000'    : '/18',
           '8000'    : '/17',
           '0000'    : '/16'               
         }       

def searchIP():
  fp = open('nmap.txt').read()
  entries = re.split('\n\n',fp)  
  ip = re.compile('([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+).*?open',re.S|re.I)
  matched = []
  for item in entries:
    if ip.search(item):
      matched.append(ip.search(item).group(1))
  return matched
  
def connectTo(fnd,m):
  received = ''
  for anaGate_ip in fnd:
    try:
      s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      s.settimeout(5.0)
      s.connect((anaGate_ip, 5001))
      s.sendall('\x05\x00\x09\x02\x01\x00\x0a')
      received = s.recv(8192)
      s.close()          
    except:
      print 'exception'
      pass
    if received:
      if len(received) != 26:           
        print 'Negative reply from possible AnaGate found at ' + anaGate_ip + '. Examine manually using web browser or try to run the scrpit again'
      else:
        reply_mac = unpack('BBBBBB',received[19:25])
        if set(reply_mac) == set(m):
          return anaGate_ip
  return ''

if __name__ == '__main__':
  
  if len(sys.argv) == 3 or len(sys.argv) == 2:  
    given_subnet = ''   
    mac = sys.argv[1]
    list_mac = [int(j,16) for j in mac.split(':')]
    if len(sys.argv) == 3:
      given_subnet = sys.argv[2]
      
    if name == 'nt':
      call('del /F nmap.txt > NUL 2> NUL',shell=True)
      call('del /F config.txt > NUL 2> NUL',shell=True)
      call('ipconfig >> config.txt',shell=True)
      f = open('config.txt').read()
      my_ip   = re.search('([0-9]+\.[0-9]+\.)[0-9]+\.[0-9]+',f).group()
      mask    = re.search('255\.255\.([0-9]+\.[0-9]+)',f).group(1)
      call('del /F config.txt > NUL',shell=True)      
      if given_subnet:
        command = 'nmap -n -sS -p5001 ' + given_subnet + '>> nmap.txt 2> NUL'
      else:
        command = 'nmap -n -sS -p5001 ' + my_ip + subnet[mask] + '>> nmap.txt 2> NUL'
        
    elif name == 'posix':
      call('rm -f nmap.txt > /dev/null 2> /dev/null',shell=True)
      call('rm -f config.txt > /dev/null 2> /dev/null',shell=True)
      call('sudo ifconfig >> config.txt',shell=True)
      f = open('config.txt').read()
      if sys.platform == 'darwin':
        entries = re.split('status: .*?e',f)
        ip = re.compile('en[0-9]+:.*?([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+).*?netmask.*?0xffff([a-fA-F0-9][a-fA-F0-9][a-fA-F0-9][a-fA-F0-9])',re.S)
        for item in entries:
          if ip.search(item):
              my_ip = ip.search(item).group(1)
              mask = ip.search(item).group(2)
      else:
        my_ip   = re.search('[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+',f).group()
        mask    = re.search('255\.255\.([0-9]+\.[0-9]+)',f).group(1)
      call('rm -f config.txt > /dev/null 2> /dev/null',shell=True)
      command1 = 'sudo nmap -n -sS -p5001 ' + my_ip + subnet[mask] + '>> nmap.txt 2> /dev/null'
      if given_subnet:
        command = 'sudo nmap -n -sS -p5001 ' + given_subnet + '>> nmap.txt 2> /dev/null'
      else:
        command = 'sudo nmap -n -sS -p5001 ' + my_ip + subnet[mask] + '>> nmap.txt 2> /dev/null'  

    else:
      print 'This script can be run only on NT or POSIX systems'
      sys.exit()
    
    call(command,shell=True)
    found = searchIP()
    ana = connectTo(found,list_mac)
    if ana:
      print 'AnaGate device with mac address ', mac, ' found at ', ana
      if name == 'nt':
        key = wreg.CreateKey(wreg.HKEY_LOCAL_MACHINE, "Software\\AnaGate")
        wreg.SetValue(key, 'IPAddress', wreg.REG_SZ, ana)
        key.Close()
        print 'Updated Windows registery HKEY_LOCAL_MACHINE\\Software\\AnaGate'
      else:
        call('sudo mkdir -p /var/lib/anagate/',shell=True)
        call('sudo touch /var/lib/anagate/ipadr.txt',shell=True)
        call('sudo chmod a+w /var/lib/anagate/ipadr.txt',shell=True)
        fp = open('/var/lib/anagate/ipadr.txt','w+')
        fp.write(ana)
        fp.close()
        print 'Updated the file /var/lib/anagate/ipadr.txt'  
    else:
      print 'AnaGate not found'  
      
    
  else:
    print 'Usage: find_ana.py mac address [subnet]'
    print 'eg: find_ana.py 00:00:0C:07:AC:6E 10.43.56.0/22 (if subnet mask is 255.255.252.0)'
    print '    find_ana.py 00:00:0C:07:AC:6E 10.43.56.0/24 (if subnet mask is 255.255.255.0)'
    print '    find_ana.py 00:00:0C:07:AC:6E'

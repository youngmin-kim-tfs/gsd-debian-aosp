########################################################################
### FILE:	llac_can_packet.py
### PURPOSE:	LLAC - CAN packet conversion
### AUTHOR:	Richard D. Morris
###
### Copyrights (C) 2009 Applied Biosystems.  All rights reserved.
########################################################################

import struct


class CAN_Packet:

    def __init__(self, id, data):
        self.id = id
        self.data = data
        self.len = len(data)


message_types = (MT_UNUSED, MT_EVENT, MT_WRITE, MT_ACK,
                 MT_READ, MT_REPLY, MT_REGREQ, MT_TRANSFER) = range(8)
message_types_ascii = ("Unused", "Event", "Write", "Ack",
                       "Read", "Reply", "Reg_Request", "Transfer")
control_ascii = ("Info", "Warning", "Fatal", "Unused")


class LLAC_Packet:

    SYNC_MASK = 0x81
    SEVERITY_MASK = 0x30
    SEVERITY_SHIFT = 4
    REGISTRATION_MASK = 0x40

    def __init__(self, cpkt):
        self.mt = (cpkt.id >> 26) & 0x7

        if self.mt == MT_TRANSFER:
            self.dest = (cpkt.id >> 18) & 0xFF
            self.src = 0x00
            self.control = 0x00
            self.ref = (cpkt.id >> 0) & 0xFFFF
            self.msgid = 0x0000
            self.s= ''.join([chr(A) for A in cpkt.data[0:cpkt.len]])
            self.data = cpkt.data
            self.len = len(self.data)
        else:
            self.dest =    (cpkt.id >> 18) & 0xFF
            self.src =     (cpkt.id >> 8) & 0xFF
            self.control = (cpkt.id >> 0) & 0xFF
            self.ref =     (cpkt.data[0] << 8) | (cpkt.data[1])
            self.msgid =   (cpkt.data[2] << 8) | (cpkt.data[3])
            self.s= ''.join([chr(A) for A in cpkt.data[4:cpkt.len]])
            self.data = cpkt.data[4:cpkt.len]
            self.len = len(self.data)

        self.sync = bool(self.control & LLAC_Packet.SYNC_MASK)
        self.registration = bool(self.control & LLAC_Packet.REGISTRATION_MASK)
        self.severity = (self.control & LLAC_Packet.SEVERITY_MASK) >> LLAC_Packet.SEVERITY_SHIFT



class LLAC_Packet_ASCII:


    def __init__(self, cmsg):
        self.cmsg = cmsg
        

    @staticmethod
    def title():
        result = "%12s %7s %6s %6s %6s %6s %s" % ("Type",
                                                  "Ctrl",
                                                  "Src",
                                                  "Dest",
                                                  "Reg",
                                                  "MsgId",
                                                  "Data")
        return result


    def type(self):
        return message_types_ascii[self.cmsg.mt]

    def src(self):
        return "0x%02x" % self.cmsg.src

    def dest(self):
        return "0x%02x" % self.cmsg.dest


    def control(self):
        result = ""
        if self.cmsg.sync:
            result += "Sync"

        if self.cmsg.registration:
            if len(result):
                result += " "
            result += "Reg"

        if self.cmsg.severity:
            if len(result):
                result += " "
            result += control_ascii[self.cmsg.severity]

        return result


    def ref(self):
        return "0x%04x" % self.cmsg.ref


    def msgid(self):
        return "0x%04x" % self.cmsg.msgid



    def int32(self):
        return str(struct.unpack('>i', struct.pack('%dB' % (len(self.cmsg.data),), *self.cmsg.data))[0])


    def uint32(self):
        return str(struct.unpack('>I', struct.pack('%dB' % (len(self.cmsg.data),), *self.cmsg.data))[0])


    def hex32(self):
        return "0x%%0%dx" % (len(self.cmsg.data) * 2,) % struct.unpack('>I', struct.pack('%dB' % (len(self.cmsg.data),), *self.cmsg.data))


    def bool32(self):
        return str(bool(self.uint32()))


    def float32(self):
        return str(struct.unpack('>f', struct.pack('%dB' % (len(self.cmsg.data),), *self.cmsg.data))[0])

        if len(self.cmsg.data) == 4:
            return str(struct.unpack('>f', struct.pack('4B', *self.cmsg.data))[0])
        else:
            return "Float:", str(self.cmsg.data)


    def text32(self):
        return struct.pack('%dB' % (len(self.cmsg.data),), *self.cmsg.data)


    def data(self):
        result = ""
        for byte in self.cmsg.data:
            if len(result):
                result += " "
            result += "0x%02x" % (byte,)
        return result


    def ascii(self):
        result = "%12s %7s %s %s %s %s" % (self.type(),
                                           self.control(),
                                           self.src(),
                                           self.dest(),
                                           self.ref(),
                                           self.msgid())

        if self.cmsg.mt == MT_TRANSFER:
            result += self.data()
        elif self.cmsg.len:
            result += " %s %s" % (self.uint32(), self.int32())

        return result

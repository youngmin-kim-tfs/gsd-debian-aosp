########################################################################
### FILE:	timezone.py
### Purpose:	Timezone access
########################################################################

import os, os.path, time

TZROOT = "/usr/share/zoneinfo"
TZLINK = "/etc/localtime"
TZTEXT = "/etc/timezone"

_TZSKIP = len(TZROOT) + len(os.sep)


class NoSuchZone (Exception):
    def __init__ (self, zone):
        Exception.__init__(self, "Invalid timezone: %s"%zone)



#try:
#    from pytz import common_timezones as tzlist

#except ImportError:



def gettimezones ():
    zones = []

    for top, folders, files in os.walk(TZROOT):
        relpath   = top[_TZSKIP:]
        parts     = relpath.split()
        haszones  = True

        for part in filter(None, parts):
            if not part[0].isupper():
                haszones = False

        if haszones:
            for name in files:
                if name[0].isupper():
                    zones.append('/'.join(parts + [name]))

    zones.sort()
    return zones


def settimezone (zone):
    tzfile = os.path.join(TZROOT, *zone.split('/'))

    if os.path.isfile(tzfile):
        if os.path.isfile(TZLINK):
            os.remove(TZLINK)

        os.symlink(tzfile, TZLINK)
        file(TZTEXT, 'w').write(zone + "\n")

        try:
            os.environ['TZ'] = zone
            time.tzset()
        except AttributeError, e:
            warning("Unable to reload new timezone after update: %s"%e)


    else:
        raise NoSuchZone(zone)


def gettimezone ():
    try:
        ### If /etc/timezone exists, read timezone from it.
        zone = file(TZTEXT).read().strip()

    except IOError:
        ### If /etc/localtime is a symbolic link, see where it points
        if os.path.islink(TZLINK):
            abspath = os.readlink(TZLINK)
            zone    = abspath[_TZSKIP:]


        ### Otherwise, compare contents of /etc/localtime with contents
        ### of every file in /usr/share/zoneinfo and return first match
        elif os.path.isfile(TZLINK):
            lthash = hash(file(TZLINK).read())

            for top, folders, files in os.walk(TZROOT):
                for name in files:
                    filename = os.path.join(top, name)
                    contents = file(filename).read()
                    if hash(contents) == lthash:
                        zone = filename[_TZSKIP:]
            else:
                zone = None

        else:
            zone = None

    return zone



#def getcurrentzone ():
#    return "".join([c for c in time.tzname[time.localtime()[-1]] if c.isupper()])

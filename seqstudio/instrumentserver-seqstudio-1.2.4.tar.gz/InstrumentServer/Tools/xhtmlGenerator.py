########################################################################
### FILE:	xhtmlGenerator.py
### PURPOSE:	HTML generator classes
########################################################################

from time     import time

TEXT          = '_text_'

STRICT        = 'strict'
TRANSITIONAL  = 'transitional'
FRAMESET      = 'frameset'


class HTMLError (Exception):
    pass


class HTMLObject:
    ### Text elements, as defined in the XHTML 1.0 DTDs.
    _TEXT         = (TEXT, )

    _special_x    = ('object', 'applet', 'img', 'map', 'iframe')
    _special_b    = ('br', 'span', 'bdo')
    _special      = _special_b + _special_x

    _fontstyle_x  = ('big', 'small', 'font', 'basefont')
    _fontstyle_b  = ('tt', 'i', 'b', 'u', 's', 'strike')
    _fontstyle    = _fontstyle_b + _fontstyle_x

    _phrase_x     = ('sub', 'sup')
    _phrase_b     = ('em', 'strong', 'dfn', 'code', 'q', 'samp', 'kbd',
                     'var', 'cite', 'abbr', 'acronym')
    _phrase       = _phrase_b + _phrase_x


    _inline_forms = ('input', 'select', 'textarea', 'label', 'button')
    _misc_inline  = ('ins', 'del', 'script')
    _misc         = _misc_inline + ('noscript', )
    _inline       = _special + _fontstyle + _phrase + _inline_forms + ('a',)
    _Inline       = _TEXT + _inline + _misc_inline


    _heading      = ('h1', 'h2', 'h3', 'h4', 'h5', 'h6')
    _lists        = ('ul', 'ol', 'dl')
    _blocktext    = ('pre', 'hr', 'blockquote', 'address',
                     'center', 'noframes')

    _block        = _heading + _lists + _blocktext + \
                    ('p', 'div', 'fieldset', 'table')

    _Flow         = _TEXT + _block + _inline + _misc + ('form', )

    _a            = _TEXT + _special + _fontstyle + _phrase + \
                    _inline_forms + _misc_inline

    _pre          = _TEXT + _special_b + _fontstyle_b + _phrase_b + \
                    _inline_forms + _misc_inline + ('a', )

    _form         = _TEXT + _block + _inline + _misc

    _Object       = _form + ('param', 'form')

    _button       = _TEXT + _heading + _lists + _blocktext + \
                    _fontstyle + _phrase + _misc + \
                    ('p', 'div', 'table', 'br', 'span', 'bdo',
                     'object', 'applet', 'img', 'map')
    
    _table        = ('caption', 'col', 'colgroup', 'thead', 'tfoot',
                     'tbody', 'tr')

    _head         = ('title', 'base', 'script', 'style', 'meta',
                     'link', 'object')


    TAGS          = {
        'html'      : { STRICT       : ('head', 'body'),
                        TRANSITIONAL : ('head', 'body'),
                        FRAMESET     : ('head', 'frameset') },
        'head'      : _head,
        'title'     : _TEXT,
        'base'      : None,
        'meta'      : None,
        'link'      : None,
        'style'     : _TEXT,
        'script'    : _TEXT,
        'noscript'  : _Flow,
        'frameset'  : { FRAMESET     : ('frameset', 'frame', 'noframes') },
        'frame'     : { FRAMESET     : None },
        'iframe'    : { TRANSITIONAL : _Flow,
                        FRAMESET     : _Flow },
        'noframes'  : { TRANSITIONAL : _Flow, 
                        FRAMESET     : ('body', ) },
        'body'      : _Flow,
        'div'       : _Flow,
        'p'         : _Inline,
        'h1'        : _Inline,
        'h2'        : _Inline,
        'h3'        : _Inline,
        'h4'        : _Inline,
        'h5'        : _Inline,
        'h6'        : _Inline,
        'ul'        : ('li', ),
        'ol'        : ('li', ),
        'li'        : _Flow,
        'dl'        : ('dt', 'dd'),
        'dt'        : _Inline,
        'dd'        : _Flow,
        'address'   : _Inline,
        'hr'        : None,
        'pre'       : _pre,
        'blockquote': _Flow,
        'center'    : { TRANSITIONAL : _Flow,
                        FRAMESET     : _Flow },
        'ins'       : _Flow,
        'del'       : _Flow,
        'a'         : _a,
        'span'      : _Inline,
        'bdo'       : _Inline,
        'br'        : None,
        'em'        : _Inline,
        'strong'    : _Inline,
        'dfn'       : _Inline,
        'code'      : _Inline,
        'samp'      : _Inline,
        'kbd'       : _Inline,
        'var'       : _Inline,
        'cite'      : _Inline,
        'abbr'      : _Inline,
        'acronym'   : _Inline,
        'q'         : _Inline,
        'sub'       : _Inline,
        'sup'       : _Inline,
        'tt'        : _Inline,
        'i'         : _Inline,
        'b'         : _Inline,
        'big'       : _Inline,
        'small'     : _Inline,
        'u'         : { TRANSITIONAL : _Inline,
                        FRAMESET     : _Inline },
        's'         : { TRANSITIONAL : _Inline,
                        FRAMESET     : _Inline },
        'strike'    : { TRANSITIONAL : _Inline,
                        FRAMESET     : _Inline },
        'basefont'  : { TRANSITIONAL : None,
                        FRAMESET     : None },
        'font'      : { TRANSITIONAL : _Inline,
                        FRAMESET     : _Inline },
        'object'    : _Object,
        'param'     : None,
        'applet'    : { TRANSITIONAL : _Object,
                        FRAMESET     : _Object },
        'img'       : None,
        'map'       : _block + _misc + ('form', 'area'),
        'area'      : None,
        'form'      : _form,
        'label'     : _Inline,
        'input'     : None,
        'select'    : ('optgroup', 'option'),
        'optgroup'  : ('option', ),
        'option'    : _TEXT,
        'textarea'  : _TEXT,
        'fieldset'  : _form + ('legend', 'form'),
        'button'    : _button,
        'table'     : _table,
        'caption'   : _Inline,
        'thead'     : ('tr', ),
        'tfoot'     : ('tr', ),
        'tbody'     : ('tr', ),
        'colgroup'  : ('col', ),
        'col'       : None,
        'tr'        : ('th', 'td'),
        'th'        : _Flow,
        'td'        : _Flow,
        }
        


    def __init__ (self, tag=None, dtd=STRICT, *data, **attr):
        ### Obtain a list of valid sub-tags within this object
        if not tag:
            self._subtags = self.TAGS

        elif tag in self.TAGS:
            subtags = self.TAGS[tag]
            if isinstance(subtags, dict):
                try:
                    subtags = subtags[dtd]
                except KeyError:
                    raise HTMLError, "Invalid XHTML/%s element: <%s>"%(dtd, tag)

            self._subtags = subtags or ()

        else:
            raise HTMLError, "Invalid XHTML element: '%s'"%(dtd, tag)



        ### Define a method for each valid sub-tag
#        for subtag in self._subtags:
#            if not subtag is TEXT:
#                self.define_tag(subtag)

        ### Store arguments
        self._tag     = tag
        self._dtd     = dtd
        self._attr    = attr
        self._data    = []
        for item in data:
            self.add(data)



    def __call__ (self):
        '''Return the XHTML code representation of this data'''

        output = []
        for item in self._data:
            if isinstance(item, HTMLObject):
                output.extend(item())
            else:
                output.append(item)

        if self._tag:
            argstr = ''
            for k, v in self._attr.items():
                argstr += ' %s="%s"'%(k.lower().strip('_').replace('_', '-'),
                                      v)

            if not self._subtags:
                output = [ '<%s%s />\n'%(self._tag, argstr) ]

            elif not output:
                output = [ '<%s%s></%s>\n'%(self._tag, argstr, self._tag) ]

            elif len(output) == 1:
                output = [ '<%s%s>%s</%s>\n'%(self._tag, argstr,
                                              output[0].strip(), self._tag) ]

            else:
                for index, outputline in enumerate(output):
                    output[index] = "  %s"%outputline

                output.insert(0, '<%s%s>\n'%(self._tag, argstr))
                output.append('</%s>\n'%self._tag)

        return output



    def define_tag (self, tag):
        setattr(self, tag,
                lambda *data, **attr: self.add_tag(tag, *data, **attr))


    def add_tag (self, tag, *data, **args):
        assert tag in self._subtags, \
               '<%s> element is not allowed within <%s> elements'%\
               (tag, self._tag)

        element = HTMLObject(tag, self._dtd, *data, **args)
        self.add(element)
        return element
            


    def add (self, item):
        if not self._subtags:
            raise HTMLError, 'No data is allowed in a <%s /> element'%tag

        elif isinstance(item, basestring):
            if TEXT in self._subtags:
                self._data.append(item + "\n")
            else:
                raise HTMLError, \
                      'Text is not allowed in a <%s> eleement'%self._tag
                
        elif isinstance(item, HTMLObject):
            if not item._tag:
                for subitem in item._data:
                    self.add(subitem)

            elif hasattr(self, item._tag):
                self._data.append(item)

            else:
                raise HTMLError, \
                      ('<%s> elements are not allowed within <%s> elements'%
                       (item._tag, self._tag))

        elif isinstance(item, (list, tuple)):
            for subitem in item:
                self.add(subitem)

        elif item is not None:
            raise HTMLError, \
                      'Cannot add %s element to HTML object'%type(item)

        item = None # Help garbage collector



    
def define_tag (cls, tag):
    setattr(cls, tag,
            lambda obj, *data, **attr: obj.add_tag(tag, *data, **attr))


for tag in HTMLObject.TAGS:
    define_tag(HTMLObject, tag)
    
#    setattr(HTMLObject, tag,
#            lambda self, *data, **attr: self.add_tag(tag, *data, **attr))






class HTMLPage (HTMLObject):
    def __init__ (self, dtd=STRICT):
        self.starttime = time()

        attributes = {
            'xmlns'    : 'http://www.w3.org/1999/xhtml',
            'xml:lang' : 'en',
            'lang'     : 'en' }

        HTMLObject.__init__(self, 'html', dtd=dtd, **attributes)
        

    def __call__ (self):
        top = [
            '<?xml version="1.0" encoding="UTF-8"?>\n',
            '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 %s//EN"'
            ' "http://www.w3.org/TR/xhtml1/DTD/xhtml1-%s.dtd">\n'
            %(self._dtd.capitalize(), self._dtd.lower())
            ]

        middle = HTMLObject.__call__(self)

        bottom = [
            '<!-- Page generated in %s seconds -->\n'%(time() - self.starttime)
            ]

        return top + middle + bottom


########################################################################
### FILE:	phyconfig.py
### PURPOSE:	Functions for configuring physical interfaces
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006 Applied Biosystems.  All rights reserved.
########################################################################

from os           import getenv, popen, mkdir, system
from config       import Config
from struct       import pack, unpack
from re           import findall
from subscription import warning

phydevices = ('eth0', 'eth1')
_sysconfig = getenv('SYSCONFIG', 'simulator').lower()


class PhyConfigError (Exception):
    pass

#if _sysconfig == 'simulator' or _sysconfig == 'windows':
if _sysconfig == 'windows':
    _macconfig = Config('ethers.ini')

    def setmac (iface, mac):
        if isValidMac(mac):
            _macconfig.set('mac', phydevices[iface], mac)
        else:
            raise PhyConfigError('Invalid MAC address: "%s"'%mac)

    def getmac (iface):
        return _macconfig.get('mac', phydevices[iface], 'FF:FF:FF:FF:FF:FF')
        
elif _sysconfig.lower() == 'armboard':
    _mtderase  = '/usr/bin/eraseall'
    _mtdnode   = '/dev/mtd2'

    def setmac (iface, mac):
        if not isValidMac(mac):
            raise PhyConfigError('Invalid MAC Address: "%s"'%mac)

        macs = []
        fp   = file(_mtdnode)
        macs.append(fp.read(8))
        macs.append(fp.read(8))
        fp.close()

        macs[iface] = mac2str(mac)

        system('%s %s'%(_mtderase, _mtdnode))

        fp = file(_mtdnode, 'w')
        fp.write(''.join(macs))
        fp.close()


    def getmac (iface):
        macs = []
        fp   = file(_mtdnode)
        macs.append(fp.read(8))
        macs.append(fp.read(8))
        fp.close()

        return str2mac(macs[iface])


    def str2mac (string):
        rawbytes = unpack('8B', string)
        return ':'.join([ "%02X"%rawbytes[b] for b in (3,2,1,0,7,6) ])

    def mac2str (mac):
        macbytes = [ int(n, 16) for n in mac.split(':') ] + [ 0, 0 ]
        rawbytes = [ macbytes[n] for n in (3,2,1,0,7,6,5,4) ]
        return pack('8B', *rawbytes)

else:
    def setmac (iface, mac):
        raise PhyConfigError, 'Unable to set MAC address on hardware'

    def getmac (iface):
        iface = phydevices[iface]
        text = _readpipe('/sbin/ifconfig %s'%iface)
        try:
            mac = findall(r'HWaddr \s*(\S+)', text)[0]
        except IndexError:
            raise PhyConfigError, 'Unable to retrieve MAC address'
        return mac

def _readpipe (command):
    pipe = popen(command)
    text = pipe.read()
    stat = pipe.close()
    if stat:
        raise PhyConfigError, \
              'Command "%s" exited with status %s'%(command, stat)
    return text

def isValidMac (mac):
    try:
        seq = [ int(b, 16) for b in mac.split(':') ]
        return (len(seq) == 6) and (min(seq) >= 0x00) and (max(seq) <= 0xFF)
    except ValueError:
        return False


def getlink (iface):
    ifname = phydevices[iface]
    folder = "/sys/class/net/%s"%ifname

    operstate = "/".join((folder, "operstate"))
    carrier   = "/".join((folder, "carrier"))
    
    path   = "/sys/class/net/%s/carrier"%(ifname,)
    try:
        state = file(operstate).read().strip()
        if state == "down":
            return False
        else:
            return bool(int(file(carrier).read().strip()))

    except (EnvironmentError, ValueError), e:
        warning("Unable to read carrier status for device %r: %s"%(ifname, e))
        return False

########################################################################
### FILE:       data.py
### PURPOSE:    Support for variables, dictionaries, arrays
### HISTORY:
###  2016-05-28 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

class _DynamicDataIterator (object):
    def __init__ (self, data):
        self.keys = data.keys()

    def __iter__ (self):
        return self

    def next (self):
        try:
            return self.keys.pop(0)
        except IndexError:
            raise StopIteration


class DynamicData (dict):
    def __init__ (self, _other=None, **_extras):
        if isinstance(_other, dict):
            self.update(_other)
        elif isinstance(_other, (tuple, list)):
            self.update(dict(_other))

        self.update(_extras)

    def __dictkey__(self, key):
        if isinstance(key, basestring):
            return key.lower()
        else:
            return key

    def __getitem__ (self, key):
        return dict.__getitem__(self, self.__dictkey__(key))[1]

    def __set__ (self, key, value):
        dict.__setitem__(self, self.__dictkey__(key), (key, value))

    def __setitem__ (self, key, value):
        self.__set__(key, value)

    def __delitem__ (self, key):
        dict.__delitem__(self, self.__dictkey__(key))

    def __iter__ (self):
        return _DynamicDataIterator(self)

    def __contains__ (self, key):
        return dict.__contains__(self, self.__dictkey__(key))

    def __repr__ (self):
        items = []
        for key, value in self.items():
            if value == self:
                items.append((str(key), 'self'))
            else:
                items.append((str(key), repr(value)))

        return "%s(%s)"%(self.__class__.__name__,
                         ", ".join(['='.join(item) for item in items]))

    def get (self, key, default=None):
        return dict.get(self, key and self.__dictkey__(key), (None, default))[1]

    def pop (self, key, *default):
        try:
            key, value = dict.pop(self, self.__dictkey__(key))
        except KeyError:
            if default:
                return default[0]
            else:
                raise
        else:
            return value

    def has_key (self, key):
        return dict.has_key(self, self.__dictkey__(key))

    def keys (self):
        return [ k for (k, v) in self.items() ]

    def keys_lower (self):
        return dict.keys(self)

    def values (self):
        return [ v for (k, v) in self.items() ]

    def items (self):
        return dict.values(self)

    def update (self, *others, **extras):
        for other in others:
            try:
                items = other.items()
            except AttributeError:
                items = other

            for k, v in items:
                self.__set__(k, v)

        for k, v in extras.items():
            self.__set__(k, v)

    def discard (self, *keys):
        for key in keys:
            if isinstance(key, (list, set)):
                self.discard(*key)
            else:
                try:
                    del self[key]
                except KeyError:
                    pass


from config        import Config
from logging       import warning
from commandParser import parser, ParseError


class PersistentData (DynamicData):
    autocommit = False
    varsection = "."

    def __init__ (self, filename, autocommit=True, valuetype=None, **extras):
        self.valuetype  = valuetype
        self.container  = self
        self.filename   = filename
        self.load()
        self.dirty      = False
        self.autocommit = autocommit

    def load (self):
        config = Config(self.filename)
        for section in config.sections():
            try:
                data = DynamicData()
                for key, value in config.items(section):
                    text, parts = parser.expandArgs(value)
                    data[key] = [ cooked for (opt, cooked, raw) in parts ]

            except ParseError, e:
                warning("Failed to load data from %r section [%s]: [%s] %s"%
                        (self.filename, section, type(e).__name__, e))

            else:
                if section == self.varsection:
                    self.update(data)
                else:
                    self[section] = data

    def save (self):
        config = Config()
        config.add_section(self.varsection)
        for key, value in self.items():
            if isinstance(value, dict):
                config.add_section(key)
                for k, v in value.items():
                    config.set(key, k, parser.collapsePart(v, tag=None))
            elif isinstance(value, list):
                config.set(self.varsection, key, parser.collapseArgs(value, tag=None))
            else:
                config.set(self.varsection, key, parser.collapsePart(value, tag=None))

        config.save(self.filename)

    def setModified (self):
        self.dirty = True
        if self.autocommit:
            self.commit()

    def setAutoCommit (self, autocommit):
        self.autocommit = autocommit
        if autocommit:
            self.commit()

    def getAutoCommit (self):
        return self.autocommit

    def commit (self):
        if self.dirty:
            self.save()
            self.dirty = False

    def __setitem__ (self, key, value):
        self.__set__(key, value)
        self.setModified()

    def __delitem__ (self, key):
        DynamicData.__delitem__(self, key)
        self.setModified()

    def pop (self, key, *default):
        value = DynamicData.pop(self, key, *default)
        self.setModified()
        return value

    def update (self, *others, **extras):
        DynamicData.update(self, *others, **extras)
        self.setModified()

    def discard (self, *keys):
        DynamicData.discard(self, *keys)
        self.setModified()



class DataProxy (object):
    def __init__ (self, maps):
        self._maps = maps

    def getScopeDataValue (self, scope, identifier=None, defaultScope=None):
        if identifier:
            if scope is not None:
                data = self._maps[scope]
                return scope, data, data[identifier]
            else:
                for index, data in enumerate(self._maps):
                    if data is not None:
                        try:
                            return index, data, data[identifier]
                        except KeyError:
                            pass
                else:
                    raise KeyError(identifier)

        else:
            if scope is None:
                scope = defaultScope or 0
            return (scope, self._maps[scope], None)

    def getValue (self, value, key=None):
        if isinstance(value, str):
            if value:
                value = [value]
            else:
                value = []

        if key is None:
            return value
        elif isinstance(value, list):
            return value[int(key)]
        else:
            return value[key]

    def toString (self, value, delimiter=' '):
        if isinstance(value, (dict, list)):
            value = delimiter.join(value)
        return value


class Container (object):
    def __init__ (self, **kwargs):
        for key, value in kwargs.iteritems():
            setattr(self, key, value)



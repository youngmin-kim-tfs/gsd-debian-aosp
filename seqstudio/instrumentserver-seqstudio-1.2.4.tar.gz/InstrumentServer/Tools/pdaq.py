########################################################################
### FILE:	pdaq.py
### PURPOSE:	Download the data from the PDAQ
### AUTHOR:	Marc Haberstroh
###
### Copyrights (C) 2010 Life Technologies, Inc.  All rights reserved.
########################################################################
import base64
import csv

version = "0.2"

class PDAQ:
    def __init__(self,scpiClient):
        self.scpiClient = scpiClient
        self.bulkTransfer = True
        self.data = []
        self.x1ColumnPosition = -1
        self.x2ColumnPosition = -1
        self.csvHeader = []
        self.calcPSD = False

    def acquire(self, inputSources, sampleCount=1, samplePeriod=1):
        self._setInputSources(inputSources)
        self._setSampleCount(sampleCount)
        self._setSamplePeriod(samplePeriod)
        self._startAcquisition()

    def transferAndGetData(self):
        self._waitForAcquisitionComplete()
        self._transferData()
        return self._getData()


    def transferAndWriteToCSV(self, fileName):
        self._waitForAcquisitionComplete()
        self._transferData()
        self.WriteCSV(fileName, self._getData())

    def getHeader(self):
        self._buildHeaderFromInputSources() 
        return self.csvHeader

    def _buildHeaderFromInputSources(self):
        headerLabels = [ 'Time [ms]' ] 
        inputSources=self._getInputSources()
        #Based on MCB version 2553
        if(inputSources & 0x00000001): headerLabels.append('XPOS')
        if(inputSources & 0x00000002): headerLabels.append('YPOS')
        if(inputSources & 0x00000004): headerLabels.append('ZPOS')
        if(inputSources & 0x00000008): headerLabels.append('FPOS')
        if(inputSources & 0x00000010): headerLabels.append('SPOS')
        if(inputSources & 0x00000020): headerLabels.append('NOT_USED')
        if(inputSources & 0x00000040): headerLabels.append('AF_X1')
        if(inputSources & 0x00000080): headerLabels.append('AF_X2')
        if(inputSources & 0x00000100): headerLabels.append('XENC')
        if(inputSources & 0x00000200): headerLabels.append('YENC')
        if(inputSources & 0x00000400): headerLabels.append('ZENC')    
        if(inputSources & 0x00000800): headerLabels.append('FENC')
        if(inputSources & 0x00001000): headerLabels.append('SENC')
        if(inputSources & 0x00002000): headerLabels.append('NOT_USED')
        if(inputSources & 0x00004000): headerLabels.append('AF_LVD')
        if(inputSources & 0x00008000): headerLabels.append('AF_LVD_RI')
        if(inputSources & 0x00010000): headerLabels.append('XSTAT')
        if(inputSources & 0x00020000): headerLabels.append('YSTAT')
        if(inputSources & 0x00040000): headerLabels.append('ZSTAT')    
        if(inputSources & 0x00080000): headerLabels.append('FSTAT')
        if(inputSources & 0x00100000): headerLabels.append('SSTAT')    
        if(inputSources & 0x00200000): headerLabels.append('NOT_USED')
        if(inputSources & 0x00400000): headerLabels.append('NOT_USED')
        if(inputSources & 0x00800000): headerLabels.append('AF_STAT')
        if(inputSources & 0x01000000): headerLabels.append('X1')
        if(inputSources & 0x02000000): headerLabels.append('X2')
        if(inputSources & 0x04000000): headerLabels.append('LD_V_MON')
        if(inputSources & 0x08000000): headerLabels.append('LD_V_RI_MON')
        if(inputSources & 0x10000000): headerLabels.append('PD_I_MON')
        if(inputSources & 0x20000000): headerLabels.append('TEMPERATURE')
        if(inputSources & 0x40000000): headerLabels.append('A_PD_I')
        if(inputSources & 0x80000000): headerLabels.append('AF_TEMP')
    
        try:
            self.x1ColumnPosition = headerLabels.index('X1')
        except ValueError:
            self.x1ColumnPosition = -1
        try:
            self.x2ColumnPosition = headerLabels.index('X2')
        except ValueError:
            self.x2ColumnPosition = -1

        if((self.x1ColumnPosition != -1) and
           (self.x2ColumnPosition != -1) ):
            headerLabels.append('PSD')
            self.calcPSD = True
        else:
            self.calcPSD = False
        self.csvHeader = headerLabels
 
    def _setInputSources(self,inputSources):
        self.scpiClient.sendReceive("mcb:pdaq:InputSOurces "+str(inputSources))
    
    def _getInputSources(self):
        return int(self.scpiClient.sendReceive("mcb:pdaq:InputSOurces?")[1],0)
 
    def _setSampleCount(self, sampleCount):
        self.scpiClient.sendReceive("mcb:pdaq:SampleCOunt "+str(sampleCount))

    def _getSampleCount(self):
        return int(self.scpiClient.sendReceive("mcb:pdaq:SampleCOunt?")[1],0)

    def _setSamplePeriod(self, samplePeriod):
        self.scpiClient.sendReceive("mcb:pdaq:SamplePERiod "+str(samplePeriod))
    
    def _getSamplePeriod(self):
        return int(self.scpiClient.sendReceive("mcb:pdaq:SamplePERiod?")[1],0)


    def _startAcquisition(self):
        self.scpiClient.sendReceive("mcb:pdaq:CONTrol 0x5")
        while(int(self.scpiClient.sendReceive("mcb:pdaq:CONTrol?")[1],0) & 0x4) != 0: pass


    def _transferData(self):
        if self.bulkTransfer:
            self._initiateTransfer()
            self._waitForTransferComplete()
            self.data = self._binStringToInteger(base64.b64decode(self.scpiClient.sendReceive("llac:dump?")[1]))
            #print "self.data = ",self.data
            #print "_getData(self.data):",self._getData()
        else:
            self.data = []
            for i in xrange(int(self.scpiClient.sendReceive("mcb:pdaq:DataWordsInBuffer?")[1],0)):
                self.scpiClient.sendReceive("mcb:pdaq:BufferINDex %d" % i)
                self.data+=[int(self.scpiClient.sendReceive("mcb:pdaq:BufferVALueINT?")[1],0)]
    
    def _waitForAcquisitionComplete(self):
        while not self.acquisitionHasCompleted():
           pass

    def acquisitionHasCompleted(self):
        return ((int(self.scpiClient.sendReceive("mcb:pdaq:STATus?")[1],0) & 0x8) == 0)

    def _initiateTransfer(self):
        self.scpiClient.sendReceive("mcb:pdaq:BufferDestinationNode 0")
        self.scpiClient.sendReceive("mcb:pdaq:BufferDestinationID 0")
        self.scpiClient.sendReceive("llac:data~")
        self.scpiClient.sendReceive("mcb:pdaq:CONTrol 0x101")
        while(int(self.scpiClient.sendReceive("mcb:pdaq:CONTrol?")[1],0) & 0x100) != 0: pass

    def _waitForTransferComplete(self):
        while not self.transferHasCompleted():
           pass

    def transferHasCompleted(self):
        return ((int(self.scpiClient.sendReceive("mcb:pdaq:STATus?")[1],0) & 0x400) != 0)

    def _getData(self):
        return self._splitChannels(self.data)

    def WriteCSV(self, fileName, data):
        self._buildHeaderFromInputSources()
        f=open(fileName,"wb")
        csvwriter = csv.writer(f)
        csvwriter.writerow(self.csvHeader)
        csvwriter.writerows(self._splitIntoRows(data))
        f.close()

    def _binStringToInteger(self,binString):
        i=0
        byteList = [ord(x) for x in binString]
        data=[]
        while i<len(byteList):
            uint = (((byteList[i+2]<<8) + byteList[i+3]<<8) + byteList[i]<<8) + byteList[i+1]		
            if (uint >> 31 )!=0:
                sint = uint - (1<<32) 
            else:
                sint = uint
            i=i+4
            data = data + [sint]
        return data	

    def _splitChannels(self,integerList):
        channels=self._numberOfInputSources(self._getInputSources())
        result = [];
        for i in xrange(channels):
            result += [[]]

        i = 0;
        for v in integerList:
            result[i] += [v]
            i += 1
            if i>=channels: i = 0

        periodInMS = self._getSamplePeriod() * 0.2 # 0.2 ms per tick
        result = [[i*periodInMS for i in range(len(result[0]))]] + result 

        return result	


    def _splitIntoRows(self,data):
        result = []
        row = 0 
	periodInMS = self._getSamplePeriod() * 0.2 # 0.2 ms per tick
        while row < len(data[0]):
            channel = 0
            rowdata=[]
            while channel < len(data):
                rowdata+=data[channel][row:row+1]
                channel+=1
            if(self.calcPSD):
                 psdValue = self._calcPSD(rowdata) 
                 rowdata+= [psdValue]
            result+=[rowdata]
            row+=1
        return result

    def _calcPSD(self, rowdata):
        denominator = float(rowdata[self.x2ColumnPosition] +
                            rowdata[self.x1ColumnPosition])
        if(denominator == 0):
            return -999999999.0
        else:
            return float((rowdata[self.x2ColumnPosition] -
                          rowdata[self.x1ColumnPosition]) /
                         denominator)
    
    def _numberOfInputSources(self,inputSources):
        result = 0
        i = inputSources
        while i!=0:
            if (i & 0x1) != 0: result+=1
            i = i>>1
        return result

        
                
            

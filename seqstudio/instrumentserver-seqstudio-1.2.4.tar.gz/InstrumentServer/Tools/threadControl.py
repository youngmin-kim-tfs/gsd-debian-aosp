########################################################################
### FILE:	threadcontrol.py
### PURPOSE:	Thread() with methods to abort(), etc.
########################################################################

from sys         import exc_info
from traceback   import extract_tb
from threading   import Thread, Event, currentThread
from weakref     import ref
from logging     import debug, info, warning, error

import os.path

class Aborted (Exception): pass

(IGNORE, ALLOW, DEFER) = range(3)   ### Actions for abort and suspend requests
(INACTIVE, REQUESTED, DEFERRED) = range(3)  ### Abort/Suspend states

class ControllableThread (Thread):
    def __init__ (self, *args, **opts):
        Thread.__init__ (self, *args, **opts)

        self.ref        = ref(self)
        self.parent     = currentThread()

        if isinstance(self.parent, ControllableThread):
            self.parent.subthreads.append(self.ref)

        self.subthreads    = []
        self.abortlist     = []
        self.suspendlist   = []
        self.resumelist    = []

        self.abortstate    = INACTIVE
        self.suspendstate  = INACTIVE
        self.abortaction   = None
        self.suspendaction = None

        self.opEvent       = Event()
        self.error         = None
        self.nextChildID   = 1


    def __del__ (self):
        try:
            self.parent.subthreads.remove(self.ref)
        except AttributeError:
            pass

    def run (self):
        self.opEvent.set()
        self.error = invoke(Thread.run, (self,), {}, 'Thread %r'%(self.name,), warning)


    def setAbortable (self, action):
        self.abortaction = action

        if (self.abortstate == DEFERRED) and (action == ALLOW):
            self.abort()


    def getAbortable (self):
        if self.abortaction != None:
            return self.abortaction
        elif isinstance(self.parent, ControllableThread):
            return self.parent.getAbortable()
        else:
            return ALLOW


    def setSuspendable (self, action):
        self.suspendaction = action

        if (self.suspendstate == DEFERRED) and (action == ALLOW):
            self.suspend()


    def getSuspendable (self):
        if self.suspendaction != None:
            return self.suspendaction
        elif isinstance(self.parent, ControllableThread):
            return self.parent.getSuspendable()
        else:
            return ALLOW


    def check (self):
        if self.abortstate == REQUESTED:
            abortaction = self.getAbortable()
            
            if abortaction == ALLOW:
                self.abortstate = INACTIVE
                debug("Aborting thread %r"%self.name)
                raise Aborted

            elif abortaction == DEFER:
                self.abortstate = DEFERRED
                debug("Deferring abort request on thread %r"%self.name)

            elif abortaction == IGNORE:
                self.abortstate = INACTIVE
                debug("Ignoring abort request on thread %s"%self.name)
            

        if self.suspendstate == REQUESTED:
            suspendaction = self.getSuspendable()
            
            if suspendaction == ALLOW:
                debug("Suspending thread %r"%self.name)
                self.suspendstate = INACTIVE
                self.opEvent.wait()
                debug("Resuming thread %r"%self.name)

            elif suspendaction == DEFER:
                debug("Deferring suspend request on thread %r"%self.name)
                self.suspendstate = DEFERRED

            elif suspendaction == IGNORE:
                debug("Ignoring suspend request on thred %r"%self.name)
                self.suspendstate = INACTIVE


    def suspend (self, recursive=True):
        debug('Requesting suspension on thread %r'%self.name)

        if self.getSuspendable() == ALLOW:
            self.opEvent.clear()

            self.suspendstate = ACTIVE
            self.invokeList(self.suspendlist, "thread %r suspend action"%self.name)
            if recursive:
                self.invokeSub('suspend')


    def resume (self, recursive=True):
        if not self.opEvent.isSet():
            self.invokeList(self.resumelist, "thread %r resume action"%self.name)
            self.opEvent.set()
            if recursive:
                self.invokeSub('resume')


    def abort (self, recursive=True):
        if (self.abortstate != REQUESTED):
            debug('Requesting %s abort on thread %r'%(("non-recursive", "recursive")[recursive], self.name))
            self.abortstate = REQUESTED

            if self.getAbortable() == ALLOW:
                self.invokeList(self.abortlist, "thread %r abort action"%self.name)
                if recursive:
                    self.invokeSub('abort')

    def clearAbort (self):
        self.abortstate = INACTIVE

    @property
    def suspended (self):
        return not self.opEvent.isSet()

    def waitResume (self, timeout=None):
        self.opEvent.wait(timeout)

    def waitStart (self, timeout=None):
        self.opEvent.wait(timeout)

    def addAbortAction (self, callback, *args, **kwargs):
        self.abortlist.append((callback, args, kwargs))

    def delAbortAction (self, callback, *args, **kwargs):
        self.abortlist.remove((callback, args, kwargs))

    def addSuspendAction (self, callback, *args, **kwargs):
        self.suspendlist.append((callback, args, kwargs))

    def delSuspendAction (self, callback, *args, **kwargs):
        self.suspendlist.remove((callback, args, kwargs))

    def addResumeAction (self, callback, *args, **kwargs):
        self.resumelist.append((callback, args, kwargs))

    def delResumeAction (self, callback, *args, **kwargs):
        self.resumelist.remove((callback, args, kwargs))

    def invokeList (self, invocationList, description):
        for callback, args, kwargs in invocationList:
            action = ": ".join((description, invocation(callback, args, kwargs)))
            debug("Invoking "+action)
            safeInvoke(callback, args, kwargs, action)

    def invokeSub (self, method):
        for ref in self.subthreads:
            sub = ref()
            if not sub in (None, self) and isinstance(sub, ControllableThread):
                debug("Thread %r recursively invoking subthread %r method %s()"%
                      (self.name, sub.name, method))
                getattr(sub, method)()


def invocation (method, args, kwargs):
    arglist  = [ "%r"%(arg,) for arg in args ]
    arglist += [ "%s=%r"%item for item in kwargs.items() ]

    return "%s(%s)"%(method.__name__, ", ".join(arglist))
    

def stackTrace (method=None, args=(), kwargs={}, traceback=None):
    msg = []
    if method:
        msg.append("  During invocation %s:\n"%invocation(method, args, kwargs))

    if traceback:
        msg.extend([ "  In %s, method %s(), line %d: %s\n"%(filepath, method, lineno, text)
                     for filepath, lineno, method, text in extract_tb(traceback)])

    return "".join(msg)


def invoke (function, args, kwargs, description=None, log=info):
    try:
        return function(*args, **kwargs)

    except Exception, e:
        e_type, e_name, e_tb = exc_info()
        log("Exception occured in %s:\n%s\n[%s] %s"%
            ((description or 'invocation '+invocation(function, args, kwargs)),
             stackTrace(traceback=e_tb),
             e.__class__.__name__,
             e))
        del e_tb  ## Prevent circular reference, per https://docs.python.org/2/library/sys.html.
        return e

def safeInvoke (function, args, kwargs, description=None, log=info):
    return invoke(function, args, kwargs, description, log) is None

def checkThread ():
    thread = currentThread()
    if isinstance(thread, ControllableThread):
        currentThread().check()



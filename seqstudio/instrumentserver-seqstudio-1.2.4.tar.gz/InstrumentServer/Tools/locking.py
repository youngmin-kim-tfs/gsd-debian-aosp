########################################################################
### FILE:    locking.py
### PURPOSE: Replacements for some locking classes/functions found in
###          python's standard modules: Condition(), Event(), Queue()
###
###          When waiting for items (with wait() or get()) with a
###          timeout, the default Python implementation uses
###          non-blocking locks and incremental sleeps (up to 5ms)
###          between each check.  This causes a delay when waiting for
###          an item to become available; moreover, multiple 
###          pending wait()/get() operations with timeout will impact
###          system performance.
###
###          Here, we use a separate thread to monitor timeouts from
###          a Python list (one for each wait()/get() call with timeout).
###          This thread, in turn, loops every .5 second, meaning that
###          there is a .5 second precision on the timeout argument,
###          rather than a forced wait even after an object is available.
###
### AUTHOR:  Tor Slettnes <tor@slett.net>
###
### Coprights (C) 2005-2007 Applied Biosystems.  All rights reserved.
########################################################################

from thread        import error as ThreadError
from threading     import Lock, currentThread
from schedule      import setalarm, clearalarm
from threadControl import Aborted

import thread
import time

class Empty (Exception):
    pass

class Queue (object):
    """
    More efficient queue support compared to Python's Queue.py.

    When waiting for items using get() with a timeout, the
    default Python implementation uses non-blocking locks and
    incremental sleeps (up to 5ms) between each check.  This
    causes a delay when waiting for an item to become available.

    Here, we use a separate thread to monitor timeouts from
    a Python list (one for each get() call with timeout).
    This thread, in turn, loops every .5 second, meaning that
    there is a .5 second precision on the timeout argument,
    rather than a forced wait even after an object is available.
    """
    
    def __init__ (self, maxsize=None):
        self.queue     = []
        self.maxsize   = maxsize
        self.exception = None
        self._mutex    = Lock()
        self._lock     = Lock()

    def __del__ (self):
        self.cancel()

    def put (self, item):
        with self._mutex:
            if self.maxsize and len(self.queue) > self.maxsize:
                del self.queue[0]
            self.queue.append(item)
            if self._lock.locked():
                self._lock.release()

    def clear (self):
        with self._mutex:
            del self.queue[:]
            self.exception = None

    def cancel (self, exception=Empty):
        with self._mutex:
            del self.queue[:]
            self.exception = exception
            if self._lock.locked():
                self._lock.release()


    def get (self, block=True, timeout=None, suspendable=False, abortable=True, last=False):
        thread = currentThread()

        with self._mutex:
            if abortable:
                thread.check()

            if not self.queue and block and (timeout is None or timeout > 0) and not self.exception:
                self._lock.acquire(False)
                self._mutex.release()

                if abortable:
                    thread.addAbortAction(self.cancel, Aborted)

                if timeout:
                    setalarm(timeout, self._lock, suspendable=suspendable)

                self._lock.acquire(True)

                if timeout:
                    clearalarm(self._lock)

                if abortable:
                    thread.delAbortAction(self.cancel, Aborted)

                self._mutex.acquire()

            if self.exception:
                raise self.exception

            elif ((timeout is None) or (timeout >= 0)) and self.queue:
                return self.queue.pop(-int(last))

            else:
                raise Empty


class Event (object):
    def __init__ (self):
        self._flag    = False
        self._mutex   = Lock()
        self._waiters = []

    def isSet (self):
        return self._flag

    def cancel (self):
        with self._mutex:
            for waiter, cancelable in self._waiters:
                if waiter.locked() and cancelable:
                    waiter.release()
        

    def set (self):
        with self._mutex:
            if not self._flag:
                self._flag = True
                for waiter, cancelable in self._waiters:
                    if waiter.locked():
                        waiter.release()

    def clear (self):
        self._flag = False

    def wait (self, timeout=None, suspendable=False, abortable=True, cancelable=True):
        thread = currentThread()

        with self._mutex:
            if abortable:
                thread.check()
            flag   = self._flag

            if not flag:
                lock = Lock()
                lock.acquire()
                if abortable:
                    thread.addAbortAction(lock.release)
                self._waiters.append((lock, cancelable))

                if timeout is not None:
                    setalarm(timeout, lock, suspendable=suspendable)

                self._mutex.release()
                lock.acquire()
                self._mutex.acquire()
                flag = self._flag

                if timeout is not None:
                    clearalarm(lock)
                
                self._waiters.remove((lock, cancelable))
                if abortable:
                    thread.delAbortAction(lock.release)

        if abortable:
            thread.check()

        return flag

class Condition (object):
    LOCK, NOTIFIED = range(2)

    def __init__ (self, lock=None, verbose=None):
        self._mutex    = Lock()
        self._waiters  = []
        self._lock     = lock or Lock()
        self.acquire   = self._lock.acquire
        self.release   = self._lock.release

    def notify (self):
        with self._mutex:
            if self._waiters:
                self._waiters[0][self.NOTIFIED] = True
                self._waiters[0][self.LOCK].release()

    def notifyAll (self):
        with self._mutex:
            for waiter in self._waiters:
                waiter[self.NOTIFIED] = True
                waiter[self.LOCK].release()

    def wait (self, timeout=None, abortable=True, suspendable=False):
        thread = currentThread()

        if abortable:
            thread.check()

        with self._mutex:
            lock = Lock()
            lock.acquire()
            waiter = [lock, False]

            if abortable:
                thread.addAbortAction(lock.release)

            self._waiters.append(waiter)

            if timeout is not None:
                setalarm(timeout, lock, suspendable=suspendable)

            self.release()
            self._mutex.release()
            lock.acquire()
            self._mutex.acquire()
            self.acquire()

            if timeout is not None:
                clearalarm(lock)

            self._waiters.remove(waiter)
            if abortable:
                thread.delAbortAction(lock.release)

        if abortable:
            thread.check()

        return waiter[self.NOTIFIED]

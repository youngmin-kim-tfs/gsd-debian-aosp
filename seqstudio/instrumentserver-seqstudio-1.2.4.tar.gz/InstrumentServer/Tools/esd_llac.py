#######################################################################
### FILE:	esd_llac.py
### PURPOSE:	ESD data - LLAC packet conversion
### AUTHOR:	Richard D. Morris
###
### Copyrights (C) 2009 Applied Biosystems.  All rights reserved.
########################################################################


import sys
import re
import llac_can_packet



class ESD_CAN_Parse:

    #esd_pat  = re.compile("^\s*(\d+)\s+(\d\d:\d\d:\d\d)\s+(\d+\.\d+)\s+(\d+\.\d+)\s+(\d+)\s+([0123456789ABCDEF]+)\s+(\w)\s+(\d)((\s+[0123456789ABCDEF]{2}){0,8})\s+(\S*)")
    #esd_pat  = re.compile("^\s*(\d+)\s+(\d\d:\d\d:\d\d)\s+([0123456789\.=]+)\s+(\d+\.\d+)\s+(\d+)\s+([0123456789ABCDEF]+)\s+(\w)\s+(\d)((\s+[0123456789ABCDEF]{2}){0,8})\s+(\S*)")
    esd_pat  = re.compile("^\s*(\d+)\s+(\d\d:\d\d:\d\d)\s+(\S+)\s+(\S+)\s+(\d+)\s+([0123456789ABCDEF]+)\s+(\w)\s+(\d)((\s+[0123456789ABCDEF]{2}){0,8})\s+(\S*)")
    data_pat  = re.compile("^\s*(\w*)\s*(\w*)\s*(\\w*)\s*(\\w*)\s*(\\w*)\s*(\\w*)\s*(\\w*)\s*(\\w*)")

    ESD_ID = 6
    ESD_DATA_COUNT = 8
    ESD_DATA = 9

    def __init__(self, l):
        esd_match = re.match(ESD_CAN_Parse.esd_pat, l)
        self.__valid = esd_match != None
        if self.__valid:
            self.__id = int(esd_match.group(ESD_CAN_Parse.ESD_ID), 16)
            len = int(esd_match.group(ESD_CAN_Parse.ESD_DATA_COUNT))

            data_match = re.match(ESD_CAN_Parse.data_pat, esd_match.group(ESD_CAN_Parse.ESD_DATA))

            self.__data = []
            for i in range(0, len):
                self.__data.append(int(data_match.group(i+1), 16))


    def len(self):
        return len(self.__data)

    def valid(self):
        return self.__valid

    def data(self):
	return self.__data

    def id(self):
	return self.__id




def test():
    file = open(sys.argv[1])

    l = file.readline()
    count = 0
    print count, llac_can_packet.LLAC_Packet_ASCII.title()

    while len(l):
        cmsg = ESD_CAN_Parse(l)
        if cmsg.valid():
            count += 1
            llac = llac_can_packet.LLAC_Packet_ASCII(llac_can_packet.LLAC_Packet(llac_can_packet.CAN_Packet(cmsg.id, cmsg.data))).ascii()
            if len(llac):
                print count, llac
            else:
                print "########### len is 0"

        l = file.readline()




if __name__ == '__main__':
    test()

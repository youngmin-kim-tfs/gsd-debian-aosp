#!/usr/bin/python
############################################################################################################
#
# Filename:  ISAccess.py
#
# Author:  Dave Comstock
#
# Revision History:  06/16/2017      0.1   DC   For Ron
#
# Description:  This script includes functions to authenticate with the Instrument Server running on a
#               SeqStudio instrument.
#
############################################################################################################

version = "0.1"

import scpiClient
import scpiauth


class SCPI_IO:
    def __init__(self, scpiClient):
        self.scpiClient = scpiClient

        
    def sendReceive(self, command, timeout=30.0):
        status, output, keywords = self.scpiClient.sendReceive(command, True, True, timeout)

        if None:
            if status != self.scpiClient.OK:
                raise IOError, "SCPI server returned %s response to %s: %s" % (status, command,
                                                                               output, keywords)

        return output

        
    def sendCommand(self, command, deltiff=False, messageTopic='', messageText=''):
        return self.scpiClient.sendCommand(command + " -deltiff=" + str(deltiff) + " -message="
                                           + messageTopic + " \"" + messageText + '"')


    def receiveResponse(self, commandIndex, timeout=30.0):
        return self.scpiClient.receiveResponse(commandIndex, timeout=timeout)


    def subscribe(self, topic, callback):
        self.scpiClient.subscribe(topic, callback)


    def unsubscribe(self, topic, callback, regex=False, ignoreMissing=False):
        self.scpiClient.unsubscribe(topic, callback, regex, ignoreMissing)

        
    def disconnect(self):
        self.scpiClient.disconnect()


def basicUnitTestSetup(self, server, portNumber):
    scpi_connection = scpiClient.SCPIClient((server, portNumber),
                                            authentication=scpiauth.secrets['monarch'],
                                            access=scpiClient.ACCESS_ADMINISTRATOR)

    scpi_io = SCPI_IO(scpi_connection)

    scpi_io.sendReceive("ACCess CONTROLLER")
    isBranches = scpi_io.sendReceive("BRANCH*")

########################################################################
### FILE:	thermoTag.py
### PURPOSE:	Support for Thermo Fisher consumable tags.
### HISTORY:
###  2016-11-14 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from struct   import Struct, error as StructError
from ndefTag  import NdefTag, TagError
from logging  import debug, info, warning
from data     import DynamicData

class ThermoTable (dict):
    '''
    ThermoFisher NFC/RFID Tag structure
    '''

    FieldTypes = (UINT, INT, FLOAT, STRING) = \
                 ("UINT", "INT", "FLOAT", "STRING")

    Packing  = {
        UINT   : {1:Struct('<B'), 2:Struct('<H'), 4:Struct('<I'), 8:Struct('<Q')},
        INT    : {1:Struct('<b'), 2:Struct('<h'), 4:Struct('<i'), 8:Struct('<q')},
        FLOAT  : {4:Struct('<f'), 8:Struct('<d')},
    }

    ValueRanges = {
        UINT   : lambda size: (0, (1<<(8*size)) - 1),
        INT    : lambda size: (-(1<<(8*size-1)), (1<<(8*size-1)) - 1)
    }

    FormatRevision = 0x10
    FieldSizes     = [ 1, 1, 0, 0 ]
    FIELDS = (F_ENTRYTYPE, F_ENTRYSIZE) = range(2)

    def __init__ (self, *args, **kwargs):
        dict.__init__(self, *args, **kwargs)
        self.knownEntryTypes = {}
        self.structures      = DynamicData()

    def addKnownType (self, entryName, entryType, dataType, dataSize):
        if not dataType in self.FieldTypes and not dataType in self.structures:
            raise TagError("Unknown data type %r cannot be used for entry type %r"%(dataType, entryName))

        self.knownEntryTypes[entryType] = (entryName, dataType, dataSize)

    def popKnownType (self, entryName):
        for key, value in self.knownEntryTypes.items():
            name, type, size = value
            if name.lower() == entryName.lower():
                del self.knownEntryTypes[key]
                return name, key, type, size

    def getKnownType (self, entryName, ignoreMissing=False):
        for key, value in self.knownEntryTypes.items():
            name, type, size = value
            if name.lower() == entryName.lower():
                return (name, key, type, size)
        else:
            if not ignoreMissing:
                raise TagError("Unknown entry key: %r"%(entryName,))

    def getKnownTypes (self):
        types = []
        for key in sorted(self.knownEntryTypes):
            name, type, size = self.knownEntryTypes[key]
            types.append((name, key, type, size))
        return types


    def namedItems (self):
        items = []
        for code in sorted(self):
            try:
                _name, _type, _size = self.knownEntryTypes[code]
            except KeyError:
                _name = 'entry-0x%02X'%(code,)

            items.append((_name, self[code]))

        return items


    def packedEntry (self, entry, value):
        try:
            entryname, datatype, datasize = self.knownEntryTypes[entry]
        except KeyError, e:
            if isinstance(value, (str, bytearray)):
                return value
            else:
                raise TagError("Uknown entry type 0x%02X in table"%(entry,))
        else:
            return self.packed(entryname, self.structures.get(datatype, datatype), datasize, value)


    def packed (self, entryname, datatype, datasize, value):
        if not datatype:
            return ""

        elif isinstance(datatype, list):
            strings = [ self.packed(entryname, datatype[i%len(datatype)], None, v) for (i, v) in enumerate(value) ]
            return "".join(strings)

        elif isinstance(datatype, tuple) and isinstance(datatype[0], tuple):
            if len(datatype) != len(value):
                raise TagError("Table entry %s requires %d values, %d given."%(entryname, len(datatype), len(value)))

            return "".join([ self.packed(entryname, t, None, v) for (t, v) in zip(datatype, value) ])

        elif isinstance(datatype, tuple) and len(datatype) == 2:
            return self.packed(entryname, datatype[0], datatype[1], value)

        elif datatype == self.STRING:
            return value

        elif datatype in self.Packing:
            if datasize == None:
                datasize = self._determineSize(value, datatype)

            try:
                packing = self.Packing[datatype][datasize]

            except KeyError, e:
                raise TagError("Invalid data size for entry %r data type %r: %d"%(entryname, datatype, datasize))

            try:
                return packing.pack(value)

            except StructError, e:
                raise TagError("Unable to pack entry %r, datatype %s, datasize %r, formatsize %r, value %r"%
                               (entryname, datatype, datasize, packing.size, value))

        else:
            raise TagError("Unknown data type %r for entry %r, size %r, value %r"%
                           (datatype, entryname, datasize, value))


    def unpackedEntry (self, entry, bytes):
        try:
            entryname, datatype, datasize = self.knownEntryTypes[entry]
        except KeyError:
            warning("ThermoTag: Uknown entry type 0x%02X in tag"%(entry,))
            return str(bytes)
        else:
            return self.unpacked(entryname, self.structures.get(datatype, datatype), datasize, bytes)

    
    def unpacked (self, entryname, datatype, datasize, bytes):
        if not datatype:
            return []
            
        elif isinstance(datatype, list):
            items = []
            index = 0
            while bytes:
                items.append(self.unpacked(entryname, datatype[index%len(datatype)], None, bytes))
                index += 1
            return items

        elif isinstance(datatype, tuple) and isinstance(datatype[0], tuple):
            return tuple([ self.unpacked(entryname, t, None, bytes) for t in datatype ])

        elif isinstance(datatype, tuple) and len(datatype) == 2:
            return self.unpacked(entryname, datatype[0], datatype[1], bytes)

        elif datatype == self.STRING:
            string = str(bytes[:datasize])
            del bytes[:datasize]
            return string

        elif datatype in self.Packing:
            string = str(bytes[:datasize])
            del bytes[:datasize]

            if datasize is not None:
                string = string.ljust(datasize, "\x00")

            try:
                packing = self.Packing[datatype][len(string)]

            except KeyError, e:
                raise TagError("Invalid data size for entry %r data type %r: %r"%(entryname, datatype, datasize))


            try:
                return packing.unpack(string)[0]

            except StructError, e:
                raise TagError("Unable to unpack entry %r, datatype %s, datasize %r, format %r, data %r"%
                               (entryname, datatype, datasize, packing.format, string))

        else:
            raise TagError("Unknown data type %r for entry %r, size %r, value %r"%(datatype, entryname, datasize, value))

            

    def _importEntries (self, bytestream, introStruct):
        entries     = {}
        introLength = introStruct.size

        lastentry   = None

        while len(bytestream)>0:
            try:
                introFields = introStruct.unpack(bytestream[:introLength])
            except StructError:
                raise TagError("Incomplete entry in byte stream: %s"%
                               ([ ",".join(["0x%02X"%b for b in bytestream])]))

            else:
                entryType   = introFields[self.F_ENTRYTYPE]
                entryLength = introFields[self.F_ENTRYSIZE]
                payload = bytestream[introLength:introLength+entryLength]
                del bytestream[:introLength+entryLength]

                if entryType != 0x00:
                    lastentry = entries[entryType] = payload
                elif lastentry != None:
                    lastentry.extend(payload)
                else:
                    raise TagError("Continuation entry type 0x%02X cannot at beginning of tag data"%(entryType,))


        for entryType, payload in entries.items():
            self[entryType] = self.unpackedEntry(entryType, payload)


    def _exportEntry (self, bytestream, entry, introStruct):
        bytes = self.packedEntry(entry, self[entry])

        introFields = [ 0 for size in self.FieldSizes if size ]
        first       = True

        while bytes:
            chunk, bytes = bytes[:255], bytes[255:]

            introFields[self.F_ENTRYTYPE] = (0x00, entry)[first]
            introFields[self.F_ENTRYSIZE] = len(chunk)
            first = False

            try:
                intro = introStruct.pack(*introFields)
            except StructError:
                raise TagError("Unable to pack entry 0x%02X, format %r: %r"%
                               (entry, introStruct.format, introFields))
            else:
                bytestream.extend(intro)
                bytestream.extend(chunk)


    def _determineSize (self, value, datatype):
        if datatype in self.ValueRanges:
            for datasize in (1, 2, 4, 8):
                low, high = self.ValueRanges[datatype](datasize)
                if low <= value <= high:
                    break

        elif datatype == self.STRING:
            datasize = len(value)

        elif datatype in self.FieldTypes:
            datasize = 4

        elif not datatype:
            datasize = 0
            
        elif isinstance(datatype, list):
            datasize = _determineSize(value[0], datatype[0]) * len(value)

        elif isinstance(datatype, tuple) and isinstance(datatype[0], tuple):
            datasize = sum([esize for etype, esize in datatype])

        else:
            raise TagError("Unable to determine size of value %r, data type %r"%(value, datatype))

        return datasize


    def fromBytes (self, data):
        bytestream   = bytearray(data)

        tableformat  = bytestream.pop(0)  # Byte 0 specifies the width of the entry type and entry length fields.
        tableversion = bytestream.pop(0)  # Byte 1 specifies the table revision.

        formatcode = "<"
        for shift in (6, 4, 2, 0):
            fieldsize = (tableformat >> shift) & 0x03
            formatcode += ('', 'B', 'H', 'I')[fieldsize]

        introStruct = Struct(formatcode)
        self._importEntries(bytestream, introStruct)


    def toBytes (self):
        bytestream = bytearray()
        
        formatcode  = "<"
        tableformat = 0x00
        for shift, size in zip((6, 4, 2, 0), self.FieldSizes):
            formatcode  += ('', 'B', 'H', 'I')[size]
            tableformat |= (size & 0x03) << shift

        introStruct = Struct(formatcode)

        bytestream.append(tableformat)
        bytestream.append(self.FormatRevision)
        
        for entry in sorted(self):
            self._exportEntry(bytestream, entry, introStruct)

        return bytestream



class ThermoTag (NdefTag):
    TNF            = NdefTag.TNF_MIME
    RECORDTYPE     = 'application/vnd.thermofisher.consumable'
    TableClass     = ThermoTable

    def __init__ (self, table=None):
        NdefTag.__init__(self)
        self.table   = table or self.TableClass()

    def readTable (self, tagindex, ignoreEmpty=False, ignoreMismatch=False):
        if self.readMessage(tagindex, ignoreEmpty, ignoreMismatch):
            return self.unpackTable(ignoreEmpty, ignoreMismatch)

    def writeTable (self, tagindex):
        self.packTable()
        self.writeMessage(tagindex)

    def unpackTable (self, ignoreEmpty=False, ignoreMismatch=False):
        self.table.clear()

        if (self.tnf, self.recordtype) == (self.TNF, self.RECORDTYPE):
            self.table.fromBytes(self.payload)

        elif self.recordtype is None and not ignoreEmpty:
            raise TagError("Empty Tag")

        elif self.recordtype is not None and not ignoreMismatch:
            raise TagError("Unknown tag type, TNF %d, record type %r"%
                           (self.tnf, self.recordtype))

        return self.table

    def packTable (self):
        self.tnf        = self.TNF
        self.recordtype = self.RECORDTYPE
        self.payload    = self.table.toBytes()
        self.packMessage()

########################################################################
### FILE:	llacSimulator.py
### PURPOSE:	Dummy LLAC Transport for simulation purposes
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################


from struct   import pack, unpack, error as StructError
from random   import sample
from logging  import warning, info, debug
from schedule import schedule
from locking  import Queue, Empty
#from Queue    import Queue, Empty

regsize  = 4       ### Change to 8 for older LLAC simulations
isopen   = False
isblocked = False
regmap   = {}
handlers = {}
queue    = Queue()
msgids   = { }

MessageTypes = ("", "Event", "WriteRequest", "Acknowledge",
                "ReadRequest", "ReadReply", "RegistrationRequest", "Transfer")

(MT_UNUSED, MT_EVENT, MT_WRITE, MT_ACK,
 MT_READ, MT_REPLY, MT_REGREQ, MT_TRANSFER) = range(len(MessageTypes))


mRefs = {
    MT_EVENT    : 'id',
    MT_WRITE    : 'reg',
    MT_ACK      : 'status',
    MT_READ     : 'reg',
    MT_REPLY    : 'status' }


def _packetString (name, mt, dest, source, control, ref, msgid, data, delimiter=","):
    mtname     = MessageTypes[mt]
    datastring = delimiter.join([ '0x%02X'%ord(c) for c in data ])
    refname    = mRefs.get(mt, 'ref')

    return ("%s, name=%s, dest=0x%02X, source=0x%02X, control=0x%02X, %s=%04X, msgid=0x%04X, data=[%s]"
            %(mtname, name or "(unknown)", dest, source, control, refname, ref, msgid, datastring))



def open (node=0x00, mask=0xFF):
    "Open the Dummy LLAC transport driver"
    global isopen
    assert not isopen, 'LLAC transport driver is already open'
    isopen = True


def close ():
    "Close the Dummy LLAC transport driver"
    global isopen
    assert isopen, 'LLAC transport driver is already closed'
    queue.cancel()
    isopen = False


def send (mt, dest, src, control, ref, msgid, data):
    "Send a LLAC packet"

    assert len(data) <= 8, 'Too many data bytes to fit in CAN packet'
    assert isopen, 'LLAC transport driver must be open before you can send'

    if mt in handlers:
        if (dest == 0xFF):
            for node in msgids:
                handlers[mt](mt, node, src, control, ref, msgid, data)
        else:
            msgids.setdefault(dest, 0)
            handlers[mt](mt, dest, src, control, ref, msgid, data)



def receive ():
    """
    Wait for and return one and exactly one LLAC packet.
    Returns a tuple containing:
    - The ID/header
    - The data, up to 8 bytes
    - A boolean, indicating whether this was an extended CAN frame
    """
    global isblocked
    assert isopen, 'LLAC transport driver must be open before you can receive'

    try:
        packet = queue.get(block=False)
        
    except Empty:
        isblocked = True
        try:
            try:
                packet = queue.get()
            except Empty:
                raise EOFError
        finally:
            isblocked = False

    return packet


def waitingForInput ():
    return isblocked


def _getRegister (node, reg):
    if not (node, reg) in regmap:
        regmap[node,reg] = ("%c"*regsize) % tuple(sample(range(256), regsize))

    return regmap[node, reg]


def _handleReadRequest (mt, dest, src, control, reg, msgid, data=""):
    queue.put((MT_REPLY, src, dest, 0, 0, msgid, _getRegister(dest, reg)[-control:]))


def _handleWriteRequest (mt, dest, src, control, reg, msgid, data):
    if (control & 0xC0) == 0xC0:
        ### SIMULATOR USE: If control bits 7 and 6 are set, return
        ### an error response with the return code as indicated in 
        ### the register, and data bytes as in the request.
        item = (MT_ACK, src, dest, 0, reg, msgid, data)
        queue.put(item)

    else:
        if (control & 0x40) == 0x40:
            ### SIMULATOR USE: If control bit 6 is set, generate an
            ### asynchronous event with severity bits as indicated in
            ### control bits 5 and 4, and event ID taken from register
            eventid = reg
            item = (MT_EVENT, src, dest, control & 0x30, eventid, msgids[dest], data)
            queue.put(item)
            msgids[dest] += 1

        else:
            ### Write data to pseudo-register
            regmap[dest, reg] = data.rjust(regsize, '\0')


        ### Acknowledge
        item = (MT_ACK, src, dest, 0, 0, msgid, "")
        queue.put(item)

        ### If synchronization bit was set, generate synchronization response.
        if (control & 0xC0) == 0x80:
            item = (MT_ACK, src, dest, 1, 0, msgid, "")
            #info("Sending SYNC event: %s"%(_packetString(None, *item)))
            queue.put(item)
            msgids[dest] += 1




def _handleDownloadRequest (mt, dest, src, control, reg, msgid, data):
    regmap[dest, reg] = (data + ('\x00'*8))[:8]


def _handleRegistrationRequest (mt, dest, src, control, reg, msgid, data):
    queue.put((MT_EVENT, src, dest, 0x40, msgid, msgids[dest], "\x00\x00\x00\x00"))
    msgids[dest] += 1


handlers = {
    MT_READ    : _handleReadRequest,
    MT_WRITE   : _handleWriteRequest,
    MT_TRANSFER: _handleDownloadRequest,
    MT_REGREQ  : _handleRegistrationRequest,
    }

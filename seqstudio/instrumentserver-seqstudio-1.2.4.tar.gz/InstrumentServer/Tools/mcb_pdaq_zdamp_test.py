#!/usr/bin/python
########################################################################
### FILE:	mcb_pdaq_zdamp_test.py
### PURPOSE:	Download the data from the PDAQ
### AUTHOR:	    Fabio Rojas  
###
### USAGE:      This script is intended to be used to traverse z from a zstart
###             to a zend position and log the results using the PDAQ system.
###
### HELP:	    python mcb_pdaq_zdamp_test.py --help 
###             This will print out the optimal parameters and usage of the script
###            
### EXAMPLE:    python mcb_pdaq_zdamp_test.py --zstart=900000 --zend=901000
###             This will save the PDAQ z target position motion curve and the
###             z encoder position curve.             
###
### REFERENCE:  MCB RegisterMapSpecification section: Performace Data Acquisition 
###
### ISSUES:     The creating of the CSV labels based on the input sources
###             needs to be improved.  Tried using 0x0404 and the script
###             generated an error.  Using the default input sources is
###             the most common use of the this for auto focus testing
###
### Copyrights (C) 2010 Life Technologies, Inc.  All rights reserved.
########################################################################

import re
import sys
import optparse
import scpiClient
import pdaq
import datetime

version = "0.2"

        
def getOptions (version, defaulthost="localhost", defaultport=7000):
    parser = optparse.OptionParser()

    parser.add_option(
        "-s", "--server",
        dest="server", nargs=1, default="localhost",
        help="Host on which the SCPI server is running [%default]")

    parser.add_option(
        "-p", "--port",
        dest="port", nargs=1, default=7000,
        help="TCP port on which the SCPI server is listening [%default]")

    parser.add_option(
        "-v", "--verbose",
        dest="verbose", action='store_true', default=False,
        help='Be verbose')

    parser.add_option(
        "--zstart",
        dest="zstart", nargs=1, default=0,
        help="Starting z position [%default steps]")

    parser.add_option(
        "--zend",
        dest="zend", nargs=1, default=100000,
        help="End z position [%default steps]")
    
    parser.add_option(
        "--zstm",
        dest="zstm", nargs=1, default=5,
        help="z SettleTimeMove [%default ms]")

    parser.add_option(
        "--pdaqis",
        dest="pdaqis", nargs=1, default=0x00000404,
        help="PDAQ Input SOurces [%default]")
    
    parser.add_option(
        "--pdaqsc",
        dest="pdaqsc", nargs=1, default=2000,
        help="PDAQ SampleCOunt [%default counts]")

    parser.add_option(
        "--pdaqsp",
        dest="pdaqsp", nargs=1, default=1,
        help="PDAQ SamplePERiod [%default*(200 us)]")
    
    parser.add_option(
        "--repeats",
        dest="repeats", nargs=1, default=1,
        help="Number of repeats for the motion [%default]")
    
    options, args = parser.parse_args()
    return options, args


class SCPI_IO:
        def __init__(self,scpiClient):
            self.scpiClient = scpiClient

    
        def sendReceive(self, command, timeout=60.0):
            status, text = self.scpiClient.sendReceive(command, timeout=timeout)
            if None:
                if status != self. scpiClient.OK:
                    raise IOError, \
                        "SCPI server returned %s response to %s: %s"%\
                        (status, command, text)
            return text

        def disconnect(self):
            self.scpiClient.disconnect()

def genTimeStampedFileName():
    date = datetime.datetime.today()
    (fyear, fmonth, fday, fhour, fmin, fsec) = date.timetuple()[0:6]
    _filename = "mcb-pdaq-"
    _filename += str(fyear) + "-" + str(fmonth) + "-" + \
                 str(fday)  + "-" + str(fhour) + "-" + \
                 str(fmin)  + "-" + str(fsec) + ".csv"
    return _filename

def execute():
    options, args  = getOptions(version)
    numberRepeats = int(options.repeats)
    
    if (len(args) != 0):
         filename = args[0]
    else:
        filename = genTimeStampedFileName()
    
    scpi_connection = scpiClient.SCPIClient((options.server, int(options.port)))
    scpi_io = SCPI_IO(scpi_connection)
    pdaq_io = pdaq.PDAQ(scpi_connection)
    
    scpi_io.sendReceive("ACCess CONTROLLER")
    # Enable use encoders for the z access
    scpi_io.sendReceive("MCB:MOT:Z:CONF 0x55448001")
	# Set the Z settle time move
    scpi_io.sendReceive("MCB:MOT:Z:STM %s" % options.zstm)
	# Move to the start z position
    scpi_io.sendReceive("MCB:ZMOVe %s" % options.zstart)
	# setup PDAQ settings
    pdaq_io.acquire(options.pdaqis, options.pdaqsc, options.pdaqsp)

    while (numberRepeats > 0):
        numberRepeats -= 1
		# move to the start
        scpi_io.sendReceive("MCB:ZMOVe %s" % options.zstart)
        # move to the end
        scpi_io.sendReceive("MCB:ZMOVe %s" % options.zend)

    pdaq_io.transferAndWriteToCSV(filename);

    scpi_io.disconnect();
    
if __name__ == '__main__':
    execute()

########################################################################
### FILE:	process.py
### PURPOSE:	Launch and control subprocesses
### AUTHOR:	Tor Slettnes <tor.slettnes@lifetech.com>
###
### Copyrights (C) 2015 ThermoFisher Scientific.  All rights reserved.
########################################################################

import logging
import subprocess
import signal
import sys
import os
import errno
import threading
import select


try:
    from signal import SIGTERM, SIGABRT, SIGKILL, SIGSTOP, SIGCONT
    gotPosix = True
except ImportError:
    from signal import SIGTERM, SIGTERM as SIGABRT, SIGTERM as SIGKILL
    gotPosix = False


class ProcessError (EnvironmentError):
    def __init__ (self, errno, strerror=None, filename=None, **attributes):
        self.errno      = errno
        self.strerror   = strerror
        self.filename   = filename
        self.attributes =  attributes
        EnvironmentError.__init__(self, self.errno, self.strerror, self.filename)


class InvocationError (ProcessError):
    def __init__ (self, errno, strerror=None, filename=None, **attributes):
        if strerror is None:
            strerror = (errno and os.strerror(errno)) or "Unknown Error"
        ProcessError.__init__(self, errno, strerror, filename, **attributes)


class ExitStatus (ProcessError):
    pass



sigmap   = {}
signames = {}
for symbol, value in signal.__dict__.iteritems():
    if symbol.startswith("SIG"):
        signames[value] = symbol
        sigmap[symbol[3:]] = value



def launch (argv, shell=False, detached=False,
            input=None, inputFile=None, outputFile=None, errorFile=None,
            cwd="/", chroot=None, proxy=None, renice=0, env=None, log=logging.debug):

    try:
        if input is not None and not detached:
            stdin = subprocess.PIPE
        elif inputFile:
            stdin = inputFile
        else:
            stdin = file(os.devnull)

        if outputFile:
            stdout = outputFile
        elif detached:
            stdout = file(os.devnull, "w")
        else:
            stdout = subprocess.PIPE

        if errorFile:
            stderr = errorFile
        elif detached:
            stderr = file(os.devnull, "w")
        else:
            stderr = subprocess.PIPE

        realargv = list(argv)
        if proxy:
            realargv.insert(0, proxy)

        if gotPosix:
            def preexec():
                if chroot:
                    os.chroot(chroot)

                if renice is not None:
                    os.nice(renice)


            instance = subprocess.Popen(realargv,
                                        bufsize=-1,
                                        stdin=stdin,
                                        stdout=stdout,
                                        stderr=stderr,
                                        shell=shell,
                                        preexec_fn=preexec,
                                        env=env,
                                        cwd=cwd,
                                        close_fds=True)

        else:
            instance = subprocess.Popen(realargv,
                                        bufsize=-1,
                                        stdin=stdin,
                                        stdout=stdout,
                                        stderr=stderr,
                                        env=env,
                                        cwd=cwd)

    except EnvironmentError, e:
        raise InvocationError(e.errno, e.strerror, filename=argv[0],
                              code=errno.errorcode.get(e.errno, "Unknown"),
                              command=argv[0],
                              cwd=cwd,
                              shell=shell,
                              proxy=proxy)

    else:
        if log:
            log('Invoked %s %s command, pid=%s, proxy=%s: %s'%
                (("attached", "detached")[detached],
                 ("external", "shell")[shell],
                 instance.pid,
                 proxy,
                 argv))

        return instance

def formatOutput (message):
    return bytearray("\n  >>").join([''] + message.splitlines())

def readOutput (fp, timeout=None):
    if timeout is not None:
        output = bytearray()
        while True:
            inp, outp, errp = select.select([fp], [], [], timeout)
            if not inp:
                break
            output.append(fp.read(1))
        return str(output)
    else:
        return fp.read()

def readline (instance, timeout=None, stderr=False, log=None):
    out, err = communicate(instance, captureOutput=not stderr, captureError=stderr, terminator='\n', log=log)
    return (out, err)[stderr]

def communicate (instance, input=None, captureOutput=True, captureError=True, timeout=None, terminator=None, maxread=None, log=None):
    thread = threading.currentThread()

    try:
        ### If this thread is a subclass of "ControllableThread()",
        ### honor abort requests
        thread.addAbortAction(instance.send_signal, SIGABRT)
        thread.addSuspendAction(instance.send_signal, SIGSTOP)
        thread.addResumeAction(instance.send_signal, SIGCONT)
    except AttributeError, e:
        pass

    if captureOutput and captureError and not timeout and not terminator:
        out, err = instance.communicate(input)
    else:
        if input and instance.stdin:
            instance.stdin.write(input)
            instance.stdin.close()

        receivers = {}
        out = err = None
        if captureOutput and instance.stdout:
            receivers[instance.stdout.fileno()] = out = bytearray()
        if captureError and instance.stderr:
            receivers[instance.stderr.fileno()] = err = bytearray()

        if receivers:
            chunk = ""
            chunksize = (1, 1024)[timeout is None and not terminator]
            try:
                while not terminator or not (terminator in chunk):
                    recv, send, exc = select.select(receivers, [], [], timeout)
                    if not recv:
                        break

                    fd = recv[0]
                    data = receivers[fd]
                    chunk = os.read(fd, chunksize)
                    if not chunk:
                        break

                    data.extend(chunk)
                    if maxread:
                        remaining = maxread - len(data)
                        if remaining < chunksize:
                            chunksize = remaining
                            if chunksize <= 0:
                                break

            except select.error:
                pass

    try:
        thread.delAbortAction(instance.send_signal, SIGABRT)
        thread.delSuspendAction(instance.send_signal, SIGSTOP)
        thread.delResumeAction(instance.send_signal, SIGCONT)
    except AttributeError, e:
        pass

    if log and out:
        log("Standard output from pid %s: %s"%(instance.pid, formatOutput(out)))

    if log and err:
       log("Standard error from pid %s: %s"%(instance.pid, formatOutput(err)))

    return out, err


def waitInstance (instance, out=None, err=None, ignoreExit=False, log=logging.debug):
    status = instance.wait()

    if instance.stdin is not None:
        instance.stdin.close()

    if status == 0:
        if log:
           log("Process completed normally, pid=%s"%(instance.pid,))

    else:
        if status < 0:
            code    = signames.get(-status)
            text    = "Terminated by signal %s (%s)"%(-status, code or "Unknown")
            message = "Process terminated by signal %s (%s), pid=%s"%(-status, code or "Unknown", instance.pid)

        else:
            code    = errno.errorcode.get(status)
            text    = os.strerror(status) or "Unknown Error"
            message = "Process returned non-zero exit status %d, pid=%s: [%s] %s"%\
                      (status, instance.pid, code, text)

        if log:
            log(message)

        if not ignoreExit:
            raise ExitStatus(status, (err or out or text).strip(), code=code, pid=instance.pid)

    return status


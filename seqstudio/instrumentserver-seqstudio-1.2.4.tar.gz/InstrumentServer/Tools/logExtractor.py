#!/usr/bin/env python
########################################################################
### FILE:	logExtractor.py
### PURPOSE:	Extract tagged key/value pairs from IS log into .CSV file
###
### Copyrights (C) 2011 Life Technologies.  All rights reserved.
########################################################################

import commandParser, optparse, sys, re, gzip, os.path

class LogExtractor (commandParser.CommandParser):

    def __init__ (self, tag, fileNameHeader, fileNameFilter,
                  timeStampHeader="Time",
                  timeStampFilter=r"(?:\d{4}-\d{2}-\d{2} )?\d{2}:\d{2}:\d{2}(?:\.\d{3})",
                  delimiter=","):

        commandParser.CommandParser.__init__(self)
        
        self.tags           = []
        self.records        = []
        self.numitems       = {}
        self.fileNameData   = ""
        self.delimiter      = delimiter

        self.setLogTag(tag)
        self.setFileNameHeader(fileNameHeader)
        self.setFileNameFilter(fileNameFilter)
        self.setTimeStampHeader(timeStampHeader)
        self.setTimeStampFilter(timeStampFilter)


    def setFileNameHeader (self, tag):
        self.fileNameHeader = tag
        if tag:
            self.tags.append(tag)

    def setFileNameFilter (self, tag):
        self.fileNameFilter = re.compile(tag)

    def setTimeStampHeader (self, tag):
        self.timeStampHeader = tag
        self.tags.append(tag)

    def setTimeStampFilter (self, expression):
        self.timeStampFilter = re.compile(expression)
        

    def setLogTag (self, tag):
        self.logTag = re.compile("(%s)"%tag)

    def debug (self, text):
        sys.stdout.write("%s\n"%text)


    def processLogFile (self, path):
        assert self.logTag, "You must invoke setLogTag() before processLogFile()"

        self.debug("Processing log file %r..."%(path,))

        if not path.endswith(".gz") and os.path.exists("%s.gz"%path):
            fp = self.openFile("%s.gz"%path, "r", compressed=True)

        else:
            fp = self.openFile(path, "r", compressed=path.endswith('.gz'))


        matches = self.fileNameFilter.findall(path)
        if matches:
            fileNameData = matches[0]
        else:
            fileNameData = ""

        for line in fp:
            match = self.logTag.search(line)
            if match:
                tsmatch = self.timeStampFilter.findall(line) or ['']
                timestamp = tsmatch[0]

                try:
                    self.processTags(fileNameData, timestamp, line)
                except commandParser.ParseError:
                    pass

        fp.close()


    def processTags (self, fileNameData, timestamp, text):
        raw, parts = self.expandArgs(text)

        record = { self.fileNameHeader : [ fileNameData ],
                   self.timeStampHeader : [ timestamp ] }

        for option, value, raw in parts:
            if option:
                if value:
                    values = value.split(self.delimiter)
                else:
                    values = []
                record[option] = values

                if not option in self.tags:
                    self.tags.append(option)

                if len(values) > self.numitems.get(option, 0):
                    self.numitems[option] = len(values)

        self.records.append(record)


    def writeOutput (self, path):
        self.debug("Writing output file %r..."%(path,))

        fp = self.openFile(path, "wb")

        self.writeHeader(fp)
        for record in self.records:
            self.writeRecord(fp, record)

        fp.close()


    def writeHeader (self, fp):
        fields = []
        for tag in self.tags:
            count = self.numitems.get(tag, 1)
            if count > 1:
                fields.extend([ "%s[%d]"%(tag, i+1) for i in range(count) ])
            else:
                fields.append(tag)

        fp.write(self.delimiter.join(fields) + "\n")


    def writeRecord (self, fp, record):
        values = []
        for key in self.tags:
            fields  = record.get(key, [])
            count   = self.numitems.get(key, 1)
            fields.extend([""] * (count - len(fields)))
            values.extend(fields)

        fp.write(self.delimiter.join(values) + "\n")
        

    def openFile (self, filename, mode, compressed=False):
        try:
            if compressed:
                return gzip.GzipFile(filename, mode)
            else:
                return open(filename, mode)

        except EnvironmentError, e:
            sys.stderr.write("Warning: Unable to open file %s: %s"%(e.filename, e))
            sys.exit(-1)



def extractLogs (outputFile, inputFiles, tag, fileNameHeader=None, fileNameFilter='.*'):
    extract = LogExtractor(tag=tag,
                           fileNameHeader=fileNameHeader,
                           fileNameFilter=fileNameFilter)
    
    try:
        for filename in inputFiles:
            extract.processLogFile(filename)
    finally:
        extract.writeOutput(outputFile)



def getOptions ():
    parser = optparse.OptionParser(usage="%prog [options] -t <tag> -o <output>.csv logfiles ...",
                                   version="1.1")

    parser.add_option("-o", "--output",
                      dest="output", action="store", nargs=1, 
                      help=("Output file; use '-' for standard output.  [%default]"))

    parser.add_option("-n", "--file-name-header",
                      dest="fileHeader", action="store", nargs=1, default="",
                      help=("Include log file name, in part or in whole, in CSV data, "
                            "under the specified header name"))

    parser.add_option("-m", "--file-name-mask",
                      dest="fileFilter", action="store", nargs=1, default='.*',
                      help=("Filter log file name through the specified regular expression "
                            "(Python compatible PCRE); the first match is then included."))

    parser.add_option("-t", "--tag", 
                      dest="tag", action="store", nargs=1,
                      help=("Process log entries matching the specified regular expression "
                            "(Python compatible PRCE)."))

    options, args = parser.parse_args()

    if not options.tag:
        parser.error("No tag specified!")

    elif not options.output:
        parser.error("No output file specified!")

    elif not args:
        parser.error("No log file(s) specified!")

    return options, args



if __name__ == '__main__':
    options, inputFiles = getOptions()

    extractLogs(outputFile = options.output,
                inputFiles = inputFiles,
                tag = options.tag,
                fileNameHeader = options.fileHeader,
                fileNameFilter = options.fileFilter)

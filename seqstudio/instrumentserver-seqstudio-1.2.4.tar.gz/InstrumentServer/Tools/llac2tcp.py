################################################################################
### FILE:       llac2tcp.py
### PURPOSE:    LLAC v10 bindings to COFFEE TCP/IP device. Based on the bindings
###             to the AnaGate CAN uno
### AUTHORS:    Sanket Chitagopkar, Caleb Chow
###
### Copyrights (C) 2018 Thermo Fisher Scientific, Inc.  All rights reserved.
################################################################################

from   struct        import pack, unpack
from   subscription  import debug, info, warning, error, publish, INFO
from   time          import sleep
from   urlparse      import urlparse
import socket
import os
import threading
import inspect
try:
    import _winreg as wreg
except:
    pass


# TODO: Why is this required? Should be resolved?
MESSAGE_TYPES = (MT_EVENT, MT_WRITE, MT_ACK, MT_READ, MT_REPLY, MT_REGREQ,
                 MT_TRANSFER) = range(1,8)

TCP_TIMEOUT = 10
TCP_BUFFER_SIZE = 1024
TCP_HANDSHAKE_DELAY = 1
TCP_HANDSHAKE_HEADER_LEN = 16
TCP_CONNECT_RETRY_DELAY_SEC = 1

__s = None
__llacToTcp = None
__receiveBuffer = []
__reconnectLock = threading.Lock()  


def __readUrl():
    # NT constants
    WREG_SUBKEY_LLAC2TCP = 'Software\\LLAC2TCP'
    WREG_SUBKEY_ADDRESS  = 'Address'

    # Non-NT constants
    ADDRESS_FILE_PATH    = '/var/lib/llac2tcp/address.txt'

    info('LLAC2TCP: Read URL')

    if os.name == 'nt':
        try:
            key = wreg.CreateKey(wreg.HKEY_LOCAL_MACHINE, WREG_SUBKEY_LLAC2TCP)
            address = wreg.QueryValue(key, WREG_SUBKEY_ADDRESS)
            key.Close()
        except:
            error('LLAC2TCP: Device address not found at ' + WREG_SUBKEY_LLAC2TCP + ', ' + WREG_SUBKEY_ADDRESS)
            raise
    else:
        address = file(ADDRESS_FILE_PATH).read().strip()

    if address == '':
        error('LLAC2TCP: Device address empty')
        raise ValueError('LLAC2TCP: Device address empty')

    # Parse address formatted as: scheme://hostname:port
    # example: can://10.192.255.238:55555
    parsed_url = urlparse(address)

    info('LLAC2TCP: Read URL ' + address + ' (' + parsed_url.hostname + ':' + str(parsed_url.port) + ')')

    return parsed_url


def open(node=0x00, mask=0xFF):
    "Open connection to TCP/IP device"
    global __s
    global __llacToTcp

    info('LLAC2TCP: Open')

    while True: # Wait for valid handshake
        while True: # Wait for socket connection
            try:
                info('LLAC2TCP: Connect')
                parsed_url = __readUrl()

                info('LLAC2TCP: Connecting')
                __s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                __s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 0) # Explicitly set
                __s.settimeout(TCP_TIMEOUT)
                __s.connect((parsed_url.hostname, parsed_url.port))

                info('LLAC2TCP: Connected')
                break
            except Exception, msg:
                info('LLAC2TCP: Connect error: ' + str(msg))
                sleep(TCP_CONNECT_RETRY_DELAY_SEC)

        # Perform handshake
        try:
            info('LLAC2TCP: Performing handshake')

            # Receive header information
            buffer = ''
            while len(buffer) < TCP_HANDSHAKE_HEADER_LEN:
                buffer = buffer + __s.recv(TCP_BUFFER_SIZE)

            # Parse header and read any additional data
            header = buffer[0:12]
            extendedLen = unpack('<I', buffer[12:16])[0]
            while len(buffer) < (TCP_HANDSHAKE_HEADER_LEN + extendedLen):
                buffer = buffer + __s.recv(TCP_BUFFER_SIZE)

            # Display header
            if len(buffer):
                info('LLAC2TCP: Received header = ' + ' '.join('0x%02X' % ord(c) for c in buffer))

            # Check if protocol supported
            if cmp(header, LLAC_to_TCP_V0.HEADER_STRING) == 0:
                info('LLAC2TCP: Protocol supported')
                
                # Echo supported protocol
                __s.sendall(buffer)

                info('LLAC2TCP: Performed handshake')

                __llacToTcp = LLAC_to_TCP_V0()
                break
            else:
                # Protocol not supported. Close connection.
                info('LLAC2TCP: Protocol not supported')
                close();
        except socket.timeout:
            info('LLAC2TCP: Handshake timeout')
            close()
            sleep(TCP_CONNECT_RETRY_DELAY_SEC)
        except socket.error, msg:
            info('LLAC2TCP: Handshake error: ' + str(msg))
            close()
            sleep(TCP_CONNECT_RETRY_DELAY_SEC)

    info('LLAC2TCP: Opened')


def close():
    "Close connection to TCP/IP device"
    global __s
    global __receiveBuffer

    info('LLAC2TCP: Close')

    __s.close()
    __receiveBuffer = []

    info('LLAC2TCP: Closed')


def __reconnect():
    "Reconnect to TCP/IP device"
    global __reconnectLock
    
    info('LLAC2TCP: Reconnect')

    acquired = __reconnectLock.acquire(False) # Non-blocking acquire
    if acquired:
        info('LLAC2TCP: Reconnecting')
        
        close()
        open()

        __reconnectLock.release()

        info('LLAC2TCP: Reconnected')
    else:
        info('LLAC2TCP: Reconnection already in progress')


def __socketSend(data):
    "Send array of bytes to TCP/IP device"
    global __s

    try:
        data_string = ''.join(chr(b) for b in data)
        __s.sendall(data_string)

        # Debugging: log sent data
        #if len(data):
        #    info('LLAC2TCP: Send: ' + ' '.join('0x%02X' % b for b in data))

        return True
    except socket.error, msg:
        info('LLAC2TCP: Send error: ' + str(msg))
        __reconnect()
        return False


def __socketReceive():
    "Receive array of bytes from TCP/IP device"
    global __s

    try:
        data_string = __s.recv(TCP_BUFFER_SIZE)
        data = [ord(c) for c in data_string]

        if len(data) == 0:
            raise socket.error('LLAC2TCP: Socket closed, received 0 bytes')

        # Debugging: log received data
        #if len(data_string):
        #    info('LLAC2TCP: Recv: ' + ' '.join('0x%02X' % b for b in data))
        
        return data
    except socket.timeout:
        return []
    except socket.error, msg:
        info('LLAC2TCP: Recv error: ' + str(msg))
        __reconnect()
        return []


def send(mt, dest, src, control, ref, msgid, data):
    "Send LLAC packet to TCP/IP device"
    global __llacToTcp

    data = __llacToTcp.encode(mt, dest, src, control, ref, msgid, data)
    __socketSend(data)


def receive():
    "Receive LLAC packets from TCP/IP device"
    global __llacToTcp
    global __receiveBuffer

    while True:
        # Read data into receive buffer if not enough data for a frame
        while len(__receiveBuffer) < __llacToTcp.frame_length(__receiveBuffer):
            data = __socketReceive()
            __receiveBuffer.extend(data)

        # Decode frame from receive buffer
        frame = __llacToTcp.decode(__receiveBuffer)
        if frame == None:
            error('LLAC2TCP: Received invalid frame, resynchronizing buffer: ' + ' '.join('0x%02X' % b for b in __receiveBuffer))
            __llacToTcp.resync(__receiveBuffer)
            error('LLAC2TCP: Resynchronized buffer: ' + ' '.join('0x%02X' % b for b in __receiveBuffer))
        else:
            break

    return frame


def transfer(nodeAddr, node, sequence, data, increment=1, delay=0):
    "Transfer data to TCP/IP device"
    global __llacToTcp

    sendData = []
    for index in xrange(0, len(data), 8):
        bytes = data[index:index+8]
        encodedData = __llacToTcp.encode(MT_TRANSFER, node, nodeAddr, 0x00, sequence, 0x0000, bytes)
        sendData.extend(encodedData)
        sequence += increment

        #if delay:
        #    sleep(delay)

    __socketSend(sendData)

    return sequence


class LLAC_Protocol_V14_5:

    MESSAGE_TYPES = (MT_EVENT, MT_WRITE, MT_ACK, MT_READ, MT_REPLY, MT_REGREQ,
                     MT_TRANSFER) = range(1,8)
    DATA_LEN_MAX = (-1, 4, 4, 0, 0, 4, 0, 8)


class LLAC_to_TCP_V0:
    # CAN Frame Format
    # Start: 4 bytes: 0xFA 0xCE 0xFE 0xED (LSB .. MSB)
    # ID: 4 bytes <little endian> ; 29 bit (bits 28:0) ; 11 bit (bits 28:18)
    # Ide: 1 byte
    # Rtr: 1 byte
    # Length: 1 byte
    # Reserved: 1 byte
    # Data: 8 bytes ; of which only Length bytes are valid, rest 0 padded

    LLAC_PROTOCOL = LLAC_Protocol_V14_5()

    HEADER = [ 0x49, 0x53, 0x4F, 0x31, 0x31, 0x38, 0x39, 0x38, # ISO11898
               0x00, 0x00, 0x00, 0x00 ] # Version (LSB, ..., MSB)
    HEADER_STRING = ''.join(chr(B) for B in HEADER)

    START = [ 0xFA, 0xCE, 0xFE, 0xED ]
    IDE = 0x01
    RTR = 0x00
    RESERVED = 0x00
    PAD = 0x00
    DATA_LEN_MAX = 8


    def frame_length(self, data):
        # Frames have fixed length. No need to look through data to calculate.
        return 20


    def resync(self, buffer):
        while len(buffer) >= len(self.START): # Resync while has enough bytes for START
            for index, value in enumerate(self.START): # Iterate through START
                if buffer[index] != value: # Look for mismatch
                    del buffer[:index] # Delete up to mismatch
                    pass # Start over
            break # Synced


    def encode(self, mt, dest, src, control, ref, msgid, data):
        if mt not in self.LLAC_PROTOCOL.MESSAGE_TYPES:
            error('LLAC_to_TCP_V0: Encode invalid LLAC message type: ' + str(mt))
            return []

        if len(data) > self.LLAC_PROTOCOL.DATA_LEN_MAX[mt]:
            error('LLAC_to_TCP_V0: Encode too many data bytes to fit in packet: ' + str(len(data)))
            return []

        # Pack LLAC fields into CAN frame
        d = [ord(A) for A in data]
        if mt == MT_TRANSFER:
            can_id = (mt << 26) | (dest << 18) | ref
        else:
            can_id = (mt << 26) | (dest << 18) | (src << 8) | control
            d = [ref >> 8, ref & 0xFF, msgid >> 8, msgid & 0xFF] + d

        # Pack CAN frame into packet
        packet = []
        packet.extend(self.START)
        packet.extend([k for k in unpack('BBBB',pack('<I',can_id))])
        packet.append(self.IDE)
        packet.append(self.RTR)
        packet.append(len(d))
        packet.append(self.RESERVED)
        packet.extend(d)
        packet.extend([self.PAD] * (self.DATA_LEN_MAX - len(d)))

        return packet


    def decode(self, buffer):
        # Extract CAN frame from buffer
        start         = (buffer[0:4]    )
        id            = (buffer[4]      ) | (buffer[5] <<  8) | \
                        (buffer[6] << 16) | (buffer[7] << 24)
        ide           = (buffer[8]      )
        rtr           = (buffer[9]      )
        length        = (buffer[10]     )
        reserved      = (buffer[11]     )
        data          = (buffer[12:12+length])

        # Debugging: log fields
        #print "buffer:", buffer
        #print "id:", id
        #print "ide:", ide
        #print "rtr:", rtr
        #print "length:", length
        #print "reserved:", reserved
        #print "data:", data

        if cmp(start, self.START) != 0:
            error('LLAC_to_TCP_V0: Decode received unexpected start bytes in buffer: ' + ' '.join('0x%02X' % b for b in start))
            return None

        if length > self.DATA_LEN_MAX:
            error('LLAC_to_TCP_V0: Decode expected too many data bytes from packet: ' + str(length))
            return None

        # Remove frame from buffer
        del buffer[:self.frame_length(buffer)]

        # Extract LLAC fields from CAN frame
        mt = (id >> 26) & 0x7
        if mt == MT_TRANSFER:
            dest    = (id >> 18) & 0xFF
            src     = 0x00
            control = 0x00
            ref     = (id >> 0) & 0xFFFF
            msgid   = 0x0000
            d = ''.join(chr(A) for A in data)
        elif (length >= 4) and (length == len(data)):
            dest    =  (id      >> 18) & (0xFF   )
            src     =  (id      >>  8) & (0xFF   )
            control =  (id           ) & (0xFF   )
            ref     =  (data[0] <<  8) | (data[1])
            msgid   =  (data[2] <<  8) | (data[3])
            d = ''.join(chr(A) for A in data[4:])
        else:
            # Invalid data length or not enough data in buffer
            error('LLAC_to_TCP_V0: Decode received invalid packet: length = ' + str(length) + ', data length = ' + str(len(data)))
            return None

        return (mt,dest,src,control,ref,msgid,d)

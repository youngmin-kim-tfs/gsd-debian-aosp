#######################################################################
### FILE:	CameraController.py
### PURPOSE:	Camera Controller (Direct interface to camera subsystem)
### AUTHOR:	Terence Soh
###  2008-2010	Terence Soh
###		Created
###  2010-11-05 Tor Slettnes  
### 		Removed IS/SCPI dependencies
###
### Copyrights (C) 2008-2010 Applied Biosystems.  All rights reserved
########################################################################

from threading     import Lock
from time          import time


class CameraController (object):
    _mutex = Lock()

    def __init__ (self, modulename):
        self.isopen     = False
        self.lutcontrol = False
        self.lut        = [0, 0]
        self.modulename = modulename
        self.camera     = self.cameraDevice(modulename)

    def cameraDevice (self, modulename):
        if modulename == 'GigEBasler':
            import sys, dl
            dlstatus = sys.getdlopenflags()
            sys.setdlopenflags(dl.RTLD_NOW|dl.RTLD_GLOBAL)
            device = __import__(modulename)
            sys.setdlopenflags(dlstatus)
        else:
            device = __import__(modulename)

        return device


    def open (self):
        try:
            self._mutex.acquire()
            if not self.isopen:
                self.camera.open()
                self.isopen = True
        finally:
            self._mutex.release()

    def close (self):
        try:
            self._mutex.acquire()
            if self.isopen:
                self.camera.close()
                self.isopen = False
        finally:
            self._mutex.release()

    def _op (self, method, *args, **kwargs):
        try:
            self._mutex.acquire()
            return method(*args, **kwargs)
        finally:
            self._mutex.release()

    def setExposureTime (self, time):
        self._op(self.camera.setexposuretime, time)

    def getExposureTime (self):
        return self._op(self.camera.getexposuretime)

    def setBias (self, bias):
        self._op(self.camera.setbias, bias)

    def getBias (self):
        return self._op(self.camera.getbias)

    def getTemperature (self):
        return self._op(self.camera.gettemperature)

    def setTemperature (self, temperature):
        return self._op(self.camera.settemperature, temperature)

    def setGain (self, gain):
        return self._op(self.camera.setgain, gain)

    def getGain (self):
        return self._op(self.camera.getgain)

    def setLUTControl (self, enable):
        self.lutcontrol = enable
    
    def getLUTControl (self):
        return self.lutcontrol
    
    def setLUT (self, *table):
        try:
            self._mutex.acquire()
            for input in table:
                try:
                    index, value = input.split(',')
                    index = int(index)
                    value = int(value)
                except ValueError:
                    raise InputOutOfRange()
                lut.append('%s,%s'%(index, value))
            self.lut = lut
            # TBC Set LUT to camera
        finally:
            self._mutex.release()

    def getLUT (self):
        return self.lut


    def setDimensions (self, xsize, ysize):
        return self._op(self.camera.setsize, xsize, ysize)

    def getDimensions (self):
        return self._op(self.camera.getsize)

    # To be deprecated once no longer needed, replaced by setImageArea
    def setImagearea (self, x1, y1, x2, y2):
        return self._op(self.camera.setimagearea, x1, y1, x2, y2)

    # Variant of setImagearea for more consistent capitalization
    def setImageArea (self, x1, y1, x2, y2):
        return self._op(self.camera.setimagearea, x1, y1, x2, y2)

    def getImageArea (self):
        return self._op(self.camera.getimagearea)

    def getMaxImageArea (self):
        return self._op(self.camera.getmaximagearea)

    def getImageVisibleArea (self):
        x1, y1, x2, y2 = area = self._op(self.camera.getvisiblearea)
        return area

    def setvbin (self, bin):
        self._op(self.camera.setvbin, bin)

    def getvbin (self):
        return self._op(self.camera.getvbin)

    def sethbin (self, bin):
        self._op(self.camera.sethbin, bin)

    def gethbin (self):
        return self._op(self.camera.gethbin)

    def setOffset (self, xoffset, yoffset):
        self._op(self.camera.setoffset, xoffset, yoffset)

    def getOffset (self):
        return self._op(self.camera.getoffset)

    def setNFlushes (self, flushes):
        self._op(self.camera.setnflushes, flushes)

    def setdebug (self, state):
        dbg = (self.camera.DBG_OFF, self.camera.DBG_ALL)[state]
        self._op(self.camera.setdebug, dbg)

    def getSerial (self, ignoreErrors=False):
        try:
            return self._op(self.camera.getserial)
        except Exception, e:
            if not ignoreErrors:
                raise

    def getHardwareVersion (self, ignoreErrors=False):
        try:
            return self._op(self.camera.gethardwareversion)
        except Exception, e:
            if not ignoreErrors:
                raise


    def getLibraryVersion (self, ignoreErrors=False):
        try:
            return self._op(self.camera.getlibraryversion)
        except Exception, e:
            if not ignoreErrors:
                raise

    def getDriverVersion (self, ignoreErrors=False):
        try:
            return self._op(self.camera.getdriverversion)
        except Exception, e:
            if not ignoreErrors:
                raise


#    def getVersion (self, ignoreErrors=False):
#        return self._op(self.camera.getfirmwareversion, ignoreErrors)

#    def getModel (self, ignoreErrors=False):
#        return self._op(self.camera.getmodel, ignoreErrors)

    def frameTypes (self):
        return {"FT_DARK"  : self.camera.FT_DARK,
                "FT_NORMAL": self.camera.FT_NORMAL }

    def setFrame (self, frametype):
        self._op(self.camera.setframetype, frametype)

    def getFrameType (self):
        return self._op(self.camera.getframetype)

    def getPixelSize (self):
        return self._op(self.camera.getpixelsize)

    def openShutter (self):
        self._op(self.camera.openshutter)

    def closeShutter (self):
        self._op(self.camera.closeshutter)

    def acquireImage (self):
        return self._op(self.camera.acquire)

    def updateFirmware (self, filename):
        self._op(self.camera.updatefirmware, filename)

    def getRegister (self, reg_id):
        return self._op(self.camera.getregister, reg_id)

    def setRegister (self, reg_id, reg_value):
        self._op(self.camera.setregister, reg_id, reg_value)


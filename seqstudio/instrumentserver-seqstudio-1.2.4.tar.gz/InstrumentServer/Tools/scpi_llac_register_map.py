#!/usr/bin/python
########################################################################
### FILE:	scpi_llac_register_map.py
### PURPOSE:	Build register map to SCPI command map
### AUTHOR:	Richard D. Morris
###
### CHANGE LOG:
###		REB	061617	Updated to Run Monarch Instrument Server.
###		            Added Authentication.
###		            Fixed Un Replied Message List. (added line id)
###                 Usage Help with Versioning.  0.3
###
### Copyrights (C) 2009 Applied Biosystems.  All rights reserved.
########################################################################

import re
import sys
import optparse
import scpiClient
import esd_llac
import llac_can_packet
import scpiauth


version = "%prog: 0.3"

        
def getOptions (version, defaulthost="localhost", defaultport=7000):
    usage = "usage: %prog infile [options]"
    parser = optparse.OptionParser(usage=usage, version=version)

    parser.add_option(
        "-s", "--server",
        dest="server", nargs=1, default="localhost",
        help="Host on which the SCPI server is running [%default]")

    parser.add_option(
        "-p", "--port",
        dest="port", nargs=1, default=7000,
        help="TCP port on which the SCPI server is listening [%default]")

    parser.add_option(
        "-b", "--branch",
        dest="branch", nargs=1, default="",
        help="List command only within a given branch/scope.")

    parser.add_option(
        "-v", "--verbose",
        dest="verbose", action='store_true', default=False,
        help='Be verbose')

    options, args = parser.parse_args()
    return options, args



def _getServerInfo(scpi, branch, item, default=None):
    status, reply = scpi.sendReceive("%s:%s"%(branch, item))
    return (default, reply)[status == scpiClient.OK]


def getServerInfo(scpi, branch):
    product = _getServerInfo(scpi, branch, 'PRODuct?')
    version = _getServerInfo(scpi, branch, 'VERSion?')
    return ' version '.join([ item for item in (product, version) if item ])


def sendReceive(scpi, command, timeout=60.0):
    status, text = scpi.sendReceive(command, timeout=timeout)
    if None:
        if status != scpiClient.OK:
            raise IOError, \
                "SCPI server returned %s response to %s: %s"%\
                (status, command, text)
    return text



class Register_Leaf:

    register_x  = re.compile(r'(?:\s*-sync=(\d+.?\d*))?(?:\s*-node=(0x\w+))?(?:\s*-base=(0x\w+))?(?:\s*-offset=(\d+))?(?:\s*-register=(0x\w+))?\s*-size=(\d+)\s+-type=(\w+)')
    ids = (M_ALL, M_SYNC, M_NODE, M_BASE, M_OFFSET, M_REGISTER, M_SIZE, M_TYPE) = range(8)


    def __init__(self, scpi_reply):
        try:
            m = re.search(Register_Leaf.register_x, scpi_reply)
            self.valid = m != None
            if self.valid:
                self.sync = m.group(Register_Leaf.M_SYNC)
                if self.sync:
                    self.sync = float(self.sync)

                self.node = m.group(Register_Leaf.M_NODE)
                if self.node:
                    self.node = int(self.node, 16)

                self.base = m.group(Register_Leaf.M_BASE)
                if self.base:
                    self.base = int(self.base, 16)
                
                self.offset = m.group(Register_Leaf.M_OFFSET)
                if self.offset:
                    self.offset = int(self.offset)

                self.reg = m.group(Register_Leaf.M_REGISTER)
                if self.reg:
                    self.reg = int(self.reg, 16)

                self.size = int(m.group(Register_Leaf.M_SIZE))
                self.type = m.group(Register_Leaf.M_TYPE)

        except Exception, e:
            sys.stderr.write('Register_Leaf.__init__(%s): %s %s\n### %s\n'%
                         (scpi_reply, m.groups(), self.__dict__, e))



class SCPI_Register_Map:

    def __init__(self, scpi, verbose):
        self.scpi = scpi
        self.verbose = verbose
        self.map = None
        

    def ident(self, sync, node, reg):
        return (int(bool(sync)) << 24) | (node << 16) | reg


    def generate(self, branch):

        subbranches, reg_map = self.command_list(branch)

        for subbranch in subbranches:
            try:
                reg_map.update(self.generate(
                                             "%s%s%s"%(branch, branch and ":", subbranch),
                                            )
                              )
            except Exception, e:
                sys.stderr.write('While documenting %s:%s:\n### %s\n'%
                                 (branch, subbranch, e))

        self.map = reg_map
        return self.map



    def command_list(self, branch):
        reg_map = {}

        if branch:
            branch += ':'

        command    = branch + 'HELP? -all'
        sys.stdout.write('%s\n'%command)
        text       = sendReceive(self.scpi, command)

        branches   = []

        for line in text.strip().splitlines():
            try:
                if (line != "<quote.reply>" and line != "</quote.reply>"):
                    element, kind = [w.strip() for w in line.split(':', 1)]
                else:
                    continue

            except ValueError:
                raise IOError, \
                  'Garbled line in response from SCPI server: %s'%repr(line)

            if self.verbose:
                sys.stdout.write('Processing %s %s%s \n'%(kind, branch, element))


            if (('branch' in kind) or ('dynamic full branch' in kind) or ('dynamic command' in kind)) and not ('linked' in kind):
                branches.append(element)

            if (kind == "LLAC register") or (kind == "leaf"):
                ### Retreive HELP? or XMLHelp? text from instrument
                try:
                    reg_text = sendReceive(self.scpi, "%s%s %s"%(branch, "REGister?", element))
                    if self.verbose:
                        sys.stdout.write('Generating description: %s%s %s\n' % (branch, element, kind))
                        sys.stdout.write('REGister? %s\n' % (reg_text,))
                    rl = Register_Leaf(reg_text)
                    if rl.valid:
                        # Strip the ?.  It will be added later for reads
                        reg_map[self.ident(rl.sync, rl.node, rl.reg)] = rl, branch+element.rstrip('?')

                except:
                    # Not all leaves are registers so just continue
                    pass


        return branches, reg_map



class SCPI_Decode:

    OK = "OK"
    NEXT = "NEXT"
    ERROR = "ERRor"
    EVENT = "EVENT"

    map_types = {
                 'BOOL' : llac_can_packet.LLAC_Packet_ASCII.bool32,
                 'INT'  : llac_can_packet.LLAC_Packet_ASCII.int32,
                 'UINT' : llac_can_packet.LLAC_Packet_ASCII.uint32,
                 'HEX'  : llac_can_packet.LLAC_Packet_ASCII.hex32,
                 'REAL' : llac_can_packet.LLAC_Packet_ASCII.float32,
                 'TEXT' : llac_can_packet.LLAC_Packet_ASCII.text32
                }

    def unused(self):
        return "Message Type: Unused\n"


    def event(self):
        result = SCPI_Decode.EVENT + " source=" + self.llac_ascii.src() +\
                                   " target=" +  self.llac_ascii.dest() +\
                                   " control=" + self.llac_ascii.control() +\
                                   " id=" + self.llac_ascii.ref() +\
                                   " data=" + self.llac_ascii.data()
        return result


    def write(self):
        reg_element = self.reg_map.map[self.reg_map.ident(self.llac_pkt.sync, self.llac_pkt.dest, self.llac_pkt.ref)]
        result = reg_element[1] + " " + SCPI_Decode.map_types[reg_element[0].type](self.llac_ascii)
        if self.llac_pkt.msgid in self.reply_map:
            self.non_reply_map[self.llac_pkt.msgid] = self.reply_map[self.llac_pkt.msgid]
        self.reply_map[self.llac_pkt.msgid] = result, self.llac_pkt.sync, self.id
        return result


    def read(self):
        reg_element = self.reg_map.map[self.reg_map.ident(self.llac_pkt.sync, self.llac_pkt.dest, self.llac_pkt.ref)]
        result = reg_element[1] + "?"
        if self.llac_pkt.msgid in self.reply_map:
            self.non_reply_map[self.llac_pkt.msgid] = self.reply_map[self.llac_pkt.msgid]
        self.reply_map[self.llac_pkt.msgid] = result, self.llac_pkt.sync, reg_element[0].type, self.id
        return result


    def ack(self):
        reply_map = self.reply_map[self.llac_pkt.msgid]

        error = ""

        if self.llac_pkt.ref: # an error has occurred
            status = SCPI_Decode.ERROR
            error = " Status Code: " + self.llac_ascii.ref()
            del self.reply_map[self.llac_pkt.msgid]

        elif self.llac_pkt.sync == reply_map[1]:
            status = SCPI_Decode.OK
            del self.reply_map[self.llac_pkt.msgid]
        else:
            status = SCPI_Decode.NEXT

        return status + " " + reply_map[0] + error


    def reply(self):
        # try:
            reply_map = self.reply_map[self.llac_pkt.msgid]

            error = ""

            if self.llac_pkt.ref: # an error has occurred
                status = SCPI_Decode.ERROR
                error = " Status Code: " + self.llac_ascii.ref()
                del self.reply_map[self.llac_pkt.msgid]
            elif self.llac_pkt.sync == reply_map[1]:
                status = SCPI_Decode.OK
                del self.reply_map[self.llac_pkt.msgid]
            else:
                status = SCPI_Decode.NEXT

            return status + " " + reply_map[0] + " " + SCPI_Decode.map_types[reply_map[2]](self.llac_ascii) + " " + error
        # except:
        #     print "reply map error"




    def reg_request(self):
        pass


    def transfer(self):
        pass


    def __init__(self, reg_map):
        self.reg_map = reg_map
        self.cmd_list = {}
        self.count = 0
        self.id = 0
        self.reply_map = {}
        self.non_reply_map = {}

        self.handle_packet = {
                               llac_can_packet.MT_UNUSED   : self.unused,
                               llac_can_packet.MT_EVENT    : self.event,
                               llac_can_packet.MT_WRITE    : self.write,
                               llac_can_packet.MT_ACK      : self.ack,
                               llac_can_packet.MT_READ     : self.read,
                               llac_can_packet.MT_REPLY    : self.reply,
                               llac_can_packet.MT_REGREQ   : self.reg_request,
                               llac_can_packet.MT_TRANSFER : self.transfer
                             }


    def ascii(self, l, c):
        self.cmsg = esd_llac.ESD_CAN_Parse(l)
        if self.cmsg.valid():
            self.count += 1
            self.id = c
            self.can_pkt = llac_can_packet.CAN_Packet(self.cmsg.id(), self.cmsg.data())
            self.llac_pkt = llac_can_packet.LLAC_Packet(self.can_pkt)
            self.llac_ascii = llac_can_packet.LLAC_Packet_ASCII(self.llac_pkt)
            return self.llac_pkt.msgid, self.handle_packet[self.llac_pkt.mt]()
        else:
            return None, None


def execute():
    options, args  = getOptions(version)
    if len(args) == 0:
        sys.stderr.write('Error: Missing Input File Name!\n');
        sys.stderr.write('     Use -h option for help!\n\n')
        exit()
    if len(args) != 1:
        sys.stderr.write('Error: Two many arguments!\n');
        sys.stderr.write('     Use -h option for help!\n\n')
        exit()

    file = open(args[0])

    connection     = scpiClient.SCPIClient((options.server, int(options.port)),
						authentication=scpiauth.secrets['gsd'],
						access=scpiClient.ACCESS_ADMINISTRATOR)
    sendReceive(connection, "ACC CONTROLLER")
    
    reg_map = SCPI_Register_Map(connection, options.verbose)
    reg_map.generate("")

    scpi_decode = SCPI_Decode(reg_map)


    count = 0
    print count, llac_can_packet.LLAC_Packet_ASCII.title()
    
    line_x  = re.compile(r'\s*(\d+)\s*(\d+:\d+:\d+)\s*(\d+.\d+)\s*(\d+.\d+)')

    l = file.readline()
    while len(l):

        # Retrieve the line number
        m = re.search(line_x, l)
        if m != None:
            l_num = m.group(1) + " " + m.group(2) + "." + m.group(3) + " " + m.group(4)
        else:
            lnum = ''

        try:
            msgid, scpi = scpi_decode.ascii(l, count+1)
            if scpi and msgid:
                count += 1
                print l_num, count, msgid, scpi
        except:
            count += 1
            print l_num, count, "CAN:", l

        l = file.readline()
   
    if len(scpi_decode.reply_map):
        print "Unreplied messages:\n"
        # print scpi_decode.reply_map
        for keys,values in scpi_decode.non_reply_map.items():
            print keys, ': ',  values
        for keys,values in scpi_decode.reply_map.items():
            print keys, ': ',  values

if __name__ == '__main__':
    execute()

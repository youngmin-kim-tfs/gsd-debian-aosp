"""SCPIClient class and associated symbol definitions.

This module provides client support for communicating with the
instrument server.


========================
CONNECTING TO THE SERVER
========================

A typical connection scenario would be:

    from scpiClient import SCPIClient, ACCESS_OBSERVER,

    scpi = SCPIClient()

    scpi.connect(("localhost", 7000),
                 timeout=15,
                 access=ACCESS_OBSERVER,
                 role="My Application Name")

By default, a new receiver thread is launched on connect() to handle
input from the server, and from there to dispatch appropriate response
actions or invoke callbacks.  To prevent this, use "threaded=False".
You then have two options:

 * You can spawn your own receiver thread, and from there invoke
   "receiveLoop()" directly.  This has the same effect as letting the
   conect() method spawn one, but may be useful if you are using a
   different threading model in your application (e.g. from the
   "multiprocessing" module, or if you are using PyQt).

   In this case, 'receiveLoop()' must be invoked AFTER 'connect()'.


 * You can omit threading altogether, in which input from the server
   will only be processed when you invoke the "receiveResponse()"
   method (directly, or indirectly via "sendReceive()"); see below.
   This means that responses to asynchronous commands as well as
   message publications will only be processed during those times.



================
SENDING COMMANDS
================

To send a single command to the server, use:

    index = scpi.sendCommand(<command>)

where <command> is either
  - a single string, with argument values quoted as needed, or
  - separated into a list/tuple of individual arguments, with each
    argument comprised either of a string or a 2+-element tuple
    representing an option name and option value.

The following are equivalent:

    - "COMMAND -option='some value' \"argument one\" <<<argument\ntwo>>>"
    - ("COMMAND", "-option='some value'", "argument one", "argument\ntwo")
    - [ "COMMAND", ('option', 'some value'), 'argument one', 'argument\ntwo' ]



The return value is an index, which will then be supplied as argument
to the "receiveResponse()" method, below.


===================
RECEIVING RESPONSES
===================

To receive the server response to a previously-sent command, you can choose
one of the following invocations of "receiveResponse()":

    rawresponse = scpi.receiveResponse(index, splitResponse=False)

    status, reply = scpi.receiveResponse(index, splitResponse=True)

    status, parts = scpi.receiveResponse(index, splitParts=True)

    status, outputs, keywords = scpi.receiveResponse(index, decompose=True)

where:

    rawresponse is the raw text received from the server, including
                the command index (or text) from the original command

    status      is "OK" or "NEXT", with the latter indicating that the
                command is now running asynchronously (in the background)
                (use "receiveResponse(...ignoreNext=True)" or else invoke
                "receiveResponse()" again to wait for final completion)

    reply       is the reply portion of the server response, as a single
                unparsed string

    parts       is a list of 3-element tuples corresponding to outputs
                returned by the server, each made up of
                  - An option name (or None if it is an unnamed output)
                  - An option value, with substitutions performed
                  - A "raw" string containing the original unparsed argument

    outputs     is a list of unnamed (positional) response words returned
                from the server

    keywords    is a dictionary containing any named response words from
                the server.


A convenience method, "sendReceive()", combines "sendCommand()" and
"receiveResponse()" into a single call:

   status, outputs, keywords = sendReceive(command, **options)


EXAMPLES:

   scpi.sendReceive("VERSion?", splitResponse=False)
   --> "OK 1 -InstrumentServer:Build=42 -InstrumentServer:Version=0.0.5 -ASCB=8812"

   scpi.sendReceive("VERSion?", splitResponse=True)
   --> ("OK",
        "-InstrumentServer:Build=42 -InstrumentServer:Version=0.0.5 -ASCB=8812")

   scpi.sendReceive("VERSion?", splitParts=True)
   --> ("OK",
        [ ("InstrumentServer:Build", "42", "-InstrumentServer:Build=42 "),
          ("InstrumentServer:Version", "0.0.5", "-InstrumentServer:Version=0.0.5 "),
          ("ASCB", "8812", "-ASCB=8812") ])


   scpi.sendReceive("VERSion?", decompose=True)
   --> ("OK",
        [],
        {"InstrumentServer:Version": "0.0.5", "InstrumentServer:Build": "42", "ASCB": "8812" })



=======================
SUBSCRIBING TO MESSAGES
=======================

Asynchronous events are published by the Instrument Server as
messages, organized by "Topic".  For instance, many qPCR instruments
publish various temperatures on the "Temperature" topic once per
second, and progress during a run on the "Run" topic.

To subscribe to such messages, use:
     scpi.subscribe(topic, callback, ...)

The topic may also contain wildcard characters ("?" to match any
single character and "*" to match anything):

    scpi.subscribe(r"Session-*", callback, ...)

Depending on the IS version you are connecting to and whether the
specified topic contains any wildcard characters, the subscription
only takes effect on topics that exist at the time of subscription.
To ensure that the subscribe applies to any matching topic that may
be created in the future, you can try the "future" option:

   scpi.subscribe("*", callback, future=True, ...)

However, note that older IS versions may not support this option,
and return an error in this case.

Once a message is received from the server, the corresponding callback
is invoked -- by default, as follows:

    callback(<topic>, <text>)

where <topic> is the messsage topic supplied by the server (which may
differ from what was subscribed to in case wildcards were used, and
also by uppercase/lowercase letters).

However, several options exist to control what arguments are supplied
in the callback:

   - Use "withTimestamp=True" to include a timestamp (seconds since epoch,
     with millisecond precision):

         callback(<topic>, <message>, <timestamp>)

   - Use "cbargs=(ARG_TOPIC, ARG_TIMESTAMP, ARG_LEVEL, ARG_PARTS,
     ARG_TEXT, ARG_MESSAGE)" and "staticargs=(value1, value2, ...)"
     to get more detailed control of what arguments are included in
     the callback, and in what order.  Those specified in "cbargs"
     appear before those in "staticargs":

         subscribe(mytopic, callback, cbargs=(ARG_LEVEL, ARG_MESSAGE), staticargs=(reference,))
         --> callback(level, message, reference)

   - Use any keyword arguments to "subscribe()" to have those same
     arguments included in the callback:
         subscribe(mytopic, callback, fruit="banana")
         --> callback(mytopic, message, fruit="banana")

   - Use "decompose=True" to decompose the published message in a
     manner similar to response parsing, above; unnamed
     arguments/words from the message are appended as additional
     arguments, and named options/values are included as keyword
     arguments:
         subscribe(mytopic, callback, timestamp=True, decompose=True)
         --> callback(mytopic, timestamp, arg1, arg2, option1=value1, option2=value2...)



=======
SENSORS
=======

Specialized support is provided to keep track of periodically
published sensor values, and to cache these for later retrieval.  For
instance, to keep a rolling record of the last 256 sample and block
temperatures published by the server, use this:

   scpi.addSensor("Temperature", ("sample", "block"), historySize=256)

Then, to retrieve the current value of such a sensor:
   value = scpi.getSensorValue("Temperature", "sample")

And the recorded history:
   history = scpi.getSensorHistory("Temperature", "sample")



======
STATES
======

A "State" is anInstrument Server construct which represents a
binary (True/False) condition or switch in the system.
Examples would include:
 - Whether a particular firmware component is available and initialized
 - The current state of a door or interlock
 - Whether the instrument is ready to operate
 - Whether the instrument is currently performing a run
 - Whether removable media is inserted, readable, writable, etc.
 - Whether the instrument has a valid network connection
 - Etc.


To enumerate the states that the server currently keeps track of, use:
   names = scpi.getStateNames()

To get the current value (True or False) of a state, use:
   enabled = scpi.getStateValue(name)

To listen to state changes in the instrument, use:
   scpi.addStateListener(callback)

Then, once a state changes, the callback is invoked as follows:
   -> callback(name, value)

The value is normally True or False; however the Instrument Server
also uses a third possible value, "Error", to represent that something
went wrong while executing a state trigger.  In the callback, such
an error value is represented as a reference to the Python Exception
class.

States are interdependent, so one state change it will often
cascade to others.

"""




from threading     import Thread, Lock, RLock, Event
from Queue         import Queue, Empty
from socket        import socket, AF_INET, SOCK_STREAM, SHUT_RDWR, error as SocketError
from commandParser import CommandParser, ParseError, QUOTE_ATTRIBUTES


try:
    from hashlib import md5
except ImportError:
    import md5

import hmac
import fnmatch
import re
import time
import sys
import select
import traceback
import logging


### Access Levels
ACCESS_LEVELS = \
    (ACCESS_GUEST, ACCESS_OBSERVER, ACCESS_CONTROLLER, ACCESS_ADMINISTRATOR) = \
    ("Guest", "Observer", "Controller", "Administrator")

### Response and input types from the SCPI server
RESPONSE_TYPES = \
    (OK, NEXT, ERROR, MESSAGE, READY) = \
    ("OK", "NEXT", "ERRor", "MESSage", "READy")

### Response formats
RESPONSE_FORMATS = \
    (RAW, STRING, PARTS, VALUES) = \
    range(4)

### Subscription levels
SUBSCRIPTION_LEVELS = ("trace", "debug", "info", "notice", "warning", "error")
LOGGING_LEVELS =  (0, logging.DEBUG, logging.INFO, logging.INFO, logging.WARNING, logging.ERROR)
(LEVEL_TRACE, LEVEL_DEBUG, LEVEL_INFO, LEVEL_NOTICE, LEVEL_WARNING, LEVEL_ERROR) = \
    range(len(SUBSCRIPTION_LEVELS))


DEFAULT_SERVER = ("127.0.0.1", 7000)


class Message (CommandParser):
    def __init__ (self, topic, parts, timestamp=None, level=LEVEL_DEBUG, quoting=QUOTE_ATTRIBUTES):
        self.topic     = topic or ''
        self.timestamp = timestamp
        self.level     = level
        self.quoting   = quoting
        self.parts     = parts

    @property
    def text (self):
        try:
            return self._text
        except AttributeError:
            self._text = ' '.join(filter(None, self.args))
            return self._text

    @property
    def message (self):
        try:
            return self._message
        except AttributeError:
            self._message = self.collapseArgs(self.parts, tag='message', quoting=self.quoting)
            return self._message

    @property
    def args (self):
        try:
            return self._args
        except AttributeError:
            self._args = [ part[1] for part in self.parts if not part[0] ]
            return self._args

    @property
    def kwargs (self):
        try:
            return self._kwargs
        except AttributeError:
            self._kwargs = dict([part[:2] for part in self.parts if part[0]])
            return self._kwargs

    @property
    def raw (self):
        try:
            return self._raw
        except AttributeError:
            parts = [str(value)
                     for value in (MESSAGE, self.topic, self.timestamp, self.level)
                     if value]
            parts.extend(self.parts)
            self._raw = self.collapseArgs(parts, tag='message', quoting=self.quoting)
            return self._raw


### Available arguments in decomposed message callback
MESSAGE_ARGS = \
    (ARG_TOPIC, ARG_TIMESTAMP, ARG_LEVEL, ARG_PARTS, ARG_KWARGS, ARG_TEXT, ARG_MESSAGE, ARG_RAW) = \
    ("topic", "timestamp", "level", "parts", "kwargs", "text", "message", "raw")





class SCPIError (Exception):

    def __init__ (self, message, *args, **kwargs):
        Exception.__init__(self, message)
        self.message     = message
        self.args        = args
        self.attributes  = kwargs

    def __str__ (self):
        return str(self.message)

    def __repr__ (self):
        return str(self.message)



class SCPICommunicationError (SCPIError):
    pass

class SCPITimeout (SCPIError):
    pass

class SCPISubscribeError (SCPIError):
    pass

class SCPIInvocationError (SCPIError):
    pass

class SCPIAlreadyConnected (SCPIError):
    pass

class SCPIDisconnected (SCPIError):
    pass



class SCPIErrorResponse (SCPIError):
    _errorCodeX = re.compile(r"^\[([\w\.]+)\]$")

    def __init__ (self, text, parts):
        SCPIError.__init__(self, text)

        attributes = {}
        code       = None
        message    = None

        for option, value, raw in parts:
            if raw.startswith("-->"):
                message = []

            elif message is not None:
                message.append(raw)

            elif option:
                attributes[option] = value

            elif self._errorCodeX.match(value):
                code = value[1:-1]

            else:
                message = [ raw ]

        self.raw = text
        self.code = code
        self.attributes = attributes
        self.message = "".join(message)


    def __repr__(self):
        return self.raw.strip()


class SCPIUnknownResponse (SCPIError):
    pass






####################################################################
### SCPI Client class.
### Method names starting with a single underscore ('_') are for
### internal use, and run in a separate thread ('receiveThread').

class SCPIClient (CommandParser):
    multiLineX      = re.compile(r'<(\w+(?:\.[^>]*)?)>')
    authentication  = None
    accesslevel     = None
    serveraddr      = None

    (LOG_SEND, LOG_RECEIVE, LOG_CONNECT, LOG_HANDSHAKE, LOG_PROTOCOL, LOG_MESSAGE, LOG_CB, LOG_CB_EXC) = \
        (LEVEL_TRACE, LEVEL_TRACE, LEVEL_INFO, LEVEL_INFO, LEVEL_NOTICE, LEVEL_TRACE, LEVEL_TRACE, LEVEL_WARNING)


    def __init__(self,
                 serveraddr=None,
                 commandIndex=True,       # <index> COMMand Args...
                 checkPartialReply=False, # ERRor <partial-command> <-- ...
                 autoconnect=True,        # Automatically (re)connect to server on demand
                 authentication=None,     # Perform Challenge/Response authentication using the supplied secret
                 access=None,             # Access level requested ("OBSERVER", "CONTROLLER", etc)
                 exclusive=False,         # Request exclusive access
                 stealth=False,           # Request stealth access
                 role=None,               # Description of this session.
                 logger=None):            # Callback method for logging: callback(level, message)

        if serveraddr:
            self.serveraddr  = serveraddr
        self.autoconnect     = autoconnect
        self.commands        = {}

        self.authentication  = authentication
        self.accessLevel     = self.accessLevelIndex(access)
        self.exclusive       = exclusive
        self.stealth         = stealth
        self.serverinfo      = {}
        self.role            = role
        self.log             = logger or self.defaultLogger

        logLevels = {
            "send" : LEVEL_DEBUG,
            "receive" : LEVEL_DEBUG,
            "connect" : LEVEL_INFO,
            "auth"    : LEVEL_DEBUG,
        }


        self.pendingInput    = ""
        self.receiveThread   = None
        self.isReceiving     = False
        self.isConnected     = False
        self.isReady         = Event()
        self.connectionError = None
        self.socket          = None

        self.callbackThread  = None
        self.callbackQueue   = None

        self.commandLock     = RLock()
        self.commandIndex    = 0
        self.useIndex        = commandIndex
        self.partialReply    = checkPartialReply

        ### Subscription support
        self.subscriptions   = {}
        self.sensors         = {}
        self.states          = None
        self.stateListeners  = {}
        self.logMask         = None
        self.logHistory      = []
        self.connecthooks    = []
        self.disconnecthooks = []

    def __del__ (self):
        self.disconnect()


    def connect (self, serveraddr=None,
                 timeout=None,             # Timeout for initial connect
                 threaded=True,            # Use dedicated thread for receiving from server
                 authentication=None,      # Authentication secret (not always needed)
                 access=None,              # Initial access level (default is Guest)
                 role=None,                # Description of your application/session
                 ignoreFailure=False):     # Do not raise error if connection fails (just return boolean)


        if self.isConnected and self.socket:
            if not ignoreFailure:
                raise self.SCPIAlreadyConnected("Already connected to server %s"%(self.socket.getpeername(),))

            return False

        if serveraddr:
            self.serveraddr = serveraddr
        elif not self.serveraddr:
            self.serveraddr = DEFAULT_SERVER

        self.log(self.LOG_CONNECT, 'Connecting to %s:%s, timeout=%s'%(self.serveraddr + (timeout, )))

        ### Communication
        self.socket = socket(AF_INET, SOCK_STREAM)
        self.fileno = self.socket.fileno
        self.rfile  = self.socket.makefile('rb', -1)
        self.connectionError = None

        self.socket.settimeout(timeout)
        try:
            self.socket.connect(self.serveraddr)

        except SocketError, e:
            self._onDisconnect()
            self.connectionError = e
            if not ignoreFailure:
                raise SCPICommunicationError(e.args[-1])

            return False

        self.socket.settimeout(None)
        self.isConnected = True

        self.log(self.LOG_CONNECT, 'Connected to %s:%s'%self.serveraddr)

        if threaded and not self.isReceiving:
            self.receiveThread = Thread(None, self.receiveLoop, "receiveThread")
            self.receiveThread.setDaemon(True)
            self.receiveThread.start()

        return self.handshake(authentication, access, role)


    def handshake (self, authentication=None, access=None, role=None, exclusive=False, stealth=False, ignoreFailure=False):
        try:
            if authentication is None:
                authentication = self.authentication
            if authentication is not None:
                self.authenticate(authentication)
                self.authentication = authentication

            if access is not None:
                access = self.accessLevelIndex(access)
            else:
                access, stealth, exclusive = self.accessLevel, self.stealth, self.exclusive

            if access is not None:
                self.setAccess(ACCESS_LEVELS[access], exclusive, stealth)
                self.accessLevel, self.stealth, self.exclusive = access, stealth, exclusive

            if role is None:
                role = self.role
            if role is not None:
                self.announce(role)
                self.role = role


        except SCPIError, e:
            self.connectionError = e
            if not ignoreFailure:
                raise

            return False

        else:
            self._onConnect()
            return True


    def disconnect (self):
        gotThread = self.isReceiving

        if self.isConnected:
            if self.serveraddr:
                self.log(self.LOG_CONNECT, 'Disconnecting from %s:%s'%self.serveraddr)
            self.isConnected = False
            self.socket.shutdown(SHUT_RDWR)

        elif not gotThread:
            self._onDisconnect()


    def _onConnect (self):
        self.runHooks(self.connecthooks)

    def _onDisconnect (self):
        if self.socket:
            self.socket.close()
            self.socket = None
            self.states = None
            self.subscriptions = {}
            self.sensors = {}
            self.logMask = None
            del self.logHistory[:]

        self.isConnected = False
        exception = SCPIDisconnected("Lost Connection to Server")

        for command, responseQueue in self.commands.itervalues():
            responseQueue.put((exception, None, None))

        if self.callbackQueue is not None:
            self.callbackQueue.put(None)

        self.runHooks(self.disconnecthooks)

    def addConnectHook (self, callback, *args, **kwargs):
        self.connecthooks.append((callback, args, kwargs))

    def addDisconnectHook (self, callback, *args, **kwargs):
        self.disconnecthooks.append((callback, args, kwargs))

    def runHooks (self, hooks):
        for callback, args, kwargs in hooks:
            self.safeInvoke(callback, args, kwargs)

    def waitReady (self, timeout=None):
        self.isReady.wait(timeout)

    def authenticate (self, secret):
        self.log(self.LOG_HANDSHAKE, "Authenticating to server")
        status, challenge = self.sendReceive("CHALlenge?")
        response  = hmac.new(secret, challenge, md5).hexdigest()
        self.sendReceive(("AUTHentication", response))

    def setAccess (self, level, exclusive=False, stealth=False):
        command = ["ACCess"]
        if exclusive:
            command.append(("exclusive", None))
        if stealth:
            command.append(("stealth", None))
        command.append(level)
        self.sendReceive(command)

    def announce (self, role):
        self.sendReceive(("SESSion:ROLe=", role))

    def defaultLogger (self, level, message):
        logging.log(LOGGING_LEVELS[level], message)




    ####################################################################
    ### The following methods receive input from the instrument in a
    ### separate thread

    def receiveLoop (self):
        "Runs in a separate thread to receive input from the instrument"

        assert self.isConnected, "You must connect() before you can invoke receiveLoop()"

        self.log(self.LOG_HANDSHAKE, 'Starting SCPI client receive thread')
        self.isReceiving = True

        while self._receive():
            self.isReady.set()

        self.isReceiving = False
        self.receiveThread = None
        self.log(self.LOG_HANDSHAKE, 'Ending SCPI client receive thread')


    def readLine (self, instream):
        text = CommandParser.readLine(self, instream)
        self.log(self.LOG_RECEIVE, "RECV: "+text.rstrip())
        return text


    def _receive (self):
        try:
            text, parts = self.expandArgs(self.rfile)

        except ParseError, e:
            self._processParseError(e)
            return True

        except EOFError, e:
            self._onDisconnect()
            return False

        else:
            if parts:
                self._processParts(text, parts)
            return True



    def _processParts (self, text, parts):
        "Handle input received from instrument"

        option, status, raw = parts.pop(0)

        if status in (OK, NEXT, ERROR):
            return self._processResponse(status, text, parts)

        elif status == MESSAGE:
            return self._processMessage(text, parts)

        elif status == READY:
            return self._processReady(text, parts)

        else:
            self.log(self.LOG_PROTOCOL,
                     'Invalid status word "%s" received from SCPI server: "%s"'%
                     (status, text.strip()))


    def _processParseError (self, e):
        self.log(self.LOG_PROTOCOL, "Failed to parse server output: %s"%(e,))

    def _processReady (self, text, parts):
        "Handle initial READy prompt from IS"

        for option, value, raw in parts:
            self.serverinfo[option] = value


    def _processResponse (self, status, text, parts):
        "Handle a response to a prior command, add to response queue"

        try:
            option, idx, header    = parts.pop(0)
            idx                    = int(idx)
            command, responseQueue = self.commands[idx]


        except KeyError:
            self.log(self.LOG_PROTOCOL, "Received %s response to unknown command index %d: %s"%(status, idx, text.strip()))
            responseQueue = None


        except IndexError:
            self.log(self.LOG_PROTOCOL, 'Command index missing in response from SCPI server: "%s"'%(text.strip()))
            responseQueue = None


        except ValueError:
            for (command, responseQueue) in self.commands.values():
                echo  = header
                part  = 0
                while part < len(parts) and (command.strip()+' ').startswith(echo.strip()+' '):
                    option, value, raw = parts[part]
                    echo += raw
                    part += 1

                if (echo.strip()+' ').startswith(command.strip()+' '):
                    del parts[:part-1]
                    break

                elif command.startswith(header) and self.partialReply:
                    break

            else:
                self.log(self.LOG_PROTOCOL, 'Received response to unknown command: "%s"'%(text.strip()))
                responseQueue = None

        if responseQueue:
            response = (status, text, parts)
            responseQueue.put(response)
            return response



    _timeStampX = re.compile(r'^\d+\.\d+$')

    def _processMessage (self, text, parts):
        "Handle a message publication; invoke any subscriber callback methods"

        try:
            matches   = 0
            callbacks = 0

            option, topic, raw = parts.pop(0)

            for rx, hasformat, records in self.subscriptions.itervalues():
                if rx.match(topic):
                    matches += 1

                    # NOTE: message must be parsed following format as subscribed to in
                    #       subscribe(). Takes format:
                    #           <topic> <timestamp> <optional level> <message>
                    #       Level is expected when hasFormat==True.
                    option, word, raw = parts[0]
                    if self._timeStampX.match(word):
                        timestamp = float(word)
                        parts.pop(0)
                    else:
                        timestamp = None

                    if hasformat:
                        option, level, raw = parts[0]
                        level = SUBSCRIPTION_LEVELS.index(level.lower())
                        parts.pop(0)
                    else:
                        level = None

                    message = Message(topic, parts, timestamp, level)

                    for record in records:
                        callbacks += 1
                        callback, cbargs, staticargs, staticopts, decompose = record

                        args = list(staticargs) + [getattr(message, a) for a in cbargs]
                        opts = dict(staticopts)

                        if decompose:
                            args.extend(message.args)
                            opts.update(message.kwargs)

                        self.log(self.LOG_CB, self.invocation(callback, args, opts))
                        self._callback((callback, args, opts))

            if matches or callbacks:
                self.log(self.LOG_CB,
                         "Found %d subscriber matches and dispatched %d callbacks for message topic %r"%
                         (matches, callbacks, message.topic))

        except IndexError:
            self.log(self.LOG_PROTOCOL, "Missing elements in published message: %r, parts=%s"%(text.strip(), parts))
        except ValueError, e:
            self.log(self.LOG_PROTOCOL, "Invalid level element in published message: %r, parts=%s"%(text.strip(), parts))


    def _callback (self, record):
        if self.callbackThread is None:
            self.callbackQueue  = Queue()
            self.callbackThread = Thread(None, self._callbackLoop, "callbackThread")
            self.callbackThread.setDaemon(True)
            self.callbackThread.start()

        self.callbackQueue.put(record)


    def _callbackLoop (self):
        while self.isConnected:
            record = self.callbackQueue.get()
            if record:
                self.safeInvoke(*record)

        self.callbackThread = None
        self.callbackQueue  = None


    def safeInvoke (self, function, args=(), kwargs={}):
        try:
            if function:
                function(*args, **kwargs)
                return True

        except Exception, e:
            e_type, e_name, e_tb = sys.exc_info()

            tb = [ "    In %s, method %s(), line %s: %s"%(filename, method, lineno, text)
                   for filename, lineno, method, text in traceback.extract_tb(e_tb) ]

            del e_type, e_name, e_tb

            self.log(self.LOG_CB_EXC,
                     "Exception occured in callback %s:\n%s\n    [%s] %s"%
                     (self.invocation(function.__name__, args, kwargs),
                      "\n".join(tb),
                      e.__class__.__name__,
                      e))

            return False


    def invocation (self, function, args, kwargs):
        arglist  = [ "%r"%(arg,) for arg in args ]
        arglist += [ "%s=%r"%item for item in kwargs.items() ]
        return "%s(%s)"%(function.__name__, ", ".join(arglist))


    def _indent (self, text, prefix="    ", infix=None):
        infix = "\n" + (prefix, infix)[infix is not None]
        return prefix + infix.join(text.splitlines())


    ####################################################################
    ### The following methods can be invoked to send commands to and
    ### receive responses or other input from the instrument.

    def sendCommand (self, command):
        "Send a command to the SCPI server"

        if isinstance(command, (list, tuple)):
            command = self.collapseArgs(command)

        elif isinstance(command, basestring):
            command = command.rstrip('\r\n ')

        else:
            raise TypeError("Invalid command, must be a string, a list of strings, "
                            "or a list of 2-3 string tuples: %r"%(command,))

        with self.commandLock:
            if self.socket == None:
                if self.autoconnect:
                    self.connect()
                else:
                    raise SCPIDisconnected("Not connected to server")


            self.commandIndex += 1
            self.commands[self.commandIndex] = (command, Queue())

            if self.useIndex:
                command = "%s %s"%(self.commandIndex, command)

            try:
                self.log(self.LOG_SEND, self._indent(command, "SEND: ", "send: "))
                self.socket.send(command+"\n")
            except SocketError, e:
                self._onDisconnect()
                raise SCPICommunicationError(str(e), *e.args)

            return self.commandIndex


    def _getResponse (self, commandIndex, timeout=None, ignoreNext=False):
        (command, responseQueue) = self.commands[commandIndex]

        start = time.time()
        self.log(self.LOG_RECEIVE, "WAIT: %s -timeout=%s -ignoreNext=%s"%(commandIndex, timeout, ignoreNext))
        while timeout is None or time.time() < start+timeout:
            while not self.isReceiving and responseQueue.empty():
                if not self._receive():
                    return

            try:
                status, text, parts = responseQueue.get(True, timeout)

            except Empty:
                pass

            else:
                if isinstance(status, Exception):
                    raise status

                if status != NEXT:
                    del self.commands[commandIndex]

                if status != NEXT or not ignoreNext:
                    return status, text, parts

        else:
            del self.commands[commandIndex]
            raise SCPITimeout("Timeout waiting for SCPI response after %.1fs"%(time.time()-start))



    def receiveResponse (self, commandIndex,
                         splitResponse=True,
                         splitParts=False,
                         decompose=False,
                         ignoreNext=False,
                         ignoreError=False,
                         timeout=None):
        "Wait for a response to a previously sent command"

        status, text, parts = self._getResponse(commandIndex, timeout, ignoreNext)

        if status[:3] == "ERR" and not ignoreError:
            raise SCPIErrorResponse(text, parts)

        elif splitParts:
            return status, parts

        elif decompose:
            args, opts, string = self.decomposeParts(parts)
            return status, args, opts

        elif splitResponse:
            return status, "".join([ raw for opt, arg, raw in parts ]).strip()

        else:
            return text


    def sendReceive (self, command,
                     splitResponse=True,
                     splitParts=False,
                     decompose=False,
                     ignoreNext=False,
                     ignoreError=False,
                     timeout=None):

        idx = self.sendCommand(command)
        return self.receiveResponse(idx, splitResponse, splitParts, decompose, ignoreNext, ignoreError, timeout)



    def profile (self, command, count=1, ignoreNext=False, timeout=None):
        start = time.time()
        for n in xrange(count):
            self.sendReceive(command, True, ignoreNext, timeout)
        return (time.time() - start) / count



    ####################################################################
    ### The following methods provide subscription/callback

    _formatWithLevel = "$topic$ $timestamp$ $level$ $message$"


    def subscribe (self, topic, callback, sendSubscribeCommand=True,
                   regex=False, future=None, level=None, cbargs=None,
                   withTimestamp=False, withLevel=False, withFormat=None,
                   splitParts=False, decompose=False,
                   staticargs=(), first=False, **staticopts):

        """Subscribe to a topic, and register a callback method"""
        assert callable(callback), \
               'The supplied callback handler is not callable'

        if not cbargs:
            cbargs = (ARG_TOPIC,)

            if splitParts:
                cbargs += (ARG_PARTS,)

            elif not decompose:
                cbargs += (ARG_MESSAGE,)

            if withTimestamp:
                cbargs += (ARG_TIMESTAMP,)

            if withLevel:
                cbargs += (ARG_LEVEL,)
                if withFormat is None:
                    withFormat = True

        else:
            for a in cbargs:
                if not a in MESSAGE_ARGS:
                    raise SCPIInvocationError("Invalid callback argument %r in "
                                              "message subscription on topic %r, callback %s()"%
                                              (a, topic, callback.__name__))

        if regex:
            rx = re.compile(topic, re.I)
        else:
            rx = re.compile(fnmatch.translate(topic), re.I)

        record = (callback, cbargs, staticargs, staticopts, decompose)

        try:
            rx, hasFormat, records = self.subscriptions[topic.lower()]

            if hasFormat or not withFormat:
                sendSubscribeCommand = False
                withFormat = hasFormat

            if first:
                records.insert(0, record)
            else:
                records.append(record)

        except KeyError:
            records = [record]

        self.subscriptions[topic.lower()] = rx, withFormat, records

        if sendSubscribeCommand:
            # NOTE: message format generated must be supported by parser in
            #       _processMessage(). Generates format:
            #           <topic> <timestamp> <optional level> <message>
            #       Level is included when withFormat==True.
            parts     = ["SUBScribe"]
            if future is not None:
                parts.append(('future', future))
            if level is not None:
                parts.append(('level', SUBSCRIPTION_LEVELS[level]))
            if regex:
                parts.append(('regex', True))

            if withFormat:
                parts.append(('format', self._formatWithLevel))
            else:
                parts.append(('timestamp', True))

            parts.append(topic)
            self.sendReceive(parts)


    def unsubscribe (self, topic, callback, ignoreMissing=False, sendUnsubscribeCommand=True):
        """Subscribe to a topic, and register a callback method"""

        foundTopic    = False
        callbacks     = 0

        ### First, look through our own subscription records, and remove
        ### any matching references to callback

        for (candidate, subscription) in self.subscriptions.items():
            if candidate == topic.lower():
                rx, hasFormat, records = subscription
                for record in records[::-1]:
                    cb = record[0]
                    if cb == callback:
                        records.remove(record)
                        callbacks += 1

                if records:
                    foundTopic = True

                elif self.isConnected and sendUnsubscribeCommand:
                    self.sendReceive(("UNSubscribe", "-ignoreMissing", topic))
                    del self.subscriptions[candidate]


        ### If no matches were found, try unsubscribing anyway; we may have
        ### been subscribed to a "wildcard" topic (e.g. "Session-*") and now
        ### are unsubscribing from a more specific one (e.g. "Session-1")

        if sendUnsubscribeCommand and callbacks == 0:
            if foundTopic:
                if not ignoreMissing:
                    raise SCPISubscribeError("Callback %r not is not registered for topic subscription %r"%
                                             (callback.__name__, topic))
            else:
                try:
                    self.sendReceive(("UNSubscribe", topic))
                except SCPIErrorResponse:
                    if not ignoreMissing:
                        raise

        return callbacks


    def publish (self, topic, message, raw=True):
        topic = self.protectString(topic)

        if isinstance(message, list):
            message = self.collapseArgs(message)

        elif isinstance(message, dict):
            message = self.collapseArgs(message.items())

        elif isinstance(message, basestring):
            message = self.protectString(message)

        return self.sendReceive('PUBLish %s %s'%(topic, message))


    def getSubscriptions (self, callback, *args, **kwargs):
        subscriptions = []
        for rx, hasformat, records in self.subscriptions.itervalues():
            for record in records:
                cb, cbargs, staticargs, staticopts, decompose = record
                if ((cb == callback) and
                    (not args or args==staticargs) and
                    (not kwargs or kwargs==staticopts)):
                    subscriptions.append(rx.pattern)
        return subscriptions


    ########################################################################
    ### The following are convenience methods for caching published
    ### messages

    def startMessageLog (self, mask="*", historySize=256):
        self.stopMessageLog()

        self.logMask = mask
        self.logHistorySize = historySize
        del self.logHistory[:]

        self.subscribe(mask, self._logMessage, first=True, withFormat=True,
                       cbargs=(ARG_TOPIC, ARG_MESSAGE, ARG_TIMESTAMP, ARG_LEVEL))


    def stopMessageLog (self):
        if self.logMask:
            self.unsubscribe(self.logMask, self._logMessage)
            self.logMask = None


    def _logMessage (self, topic, message, timestamp, level):
        while len(self.logHistory) >= self.logHistorySize > None:
            del self.logHistory[0]

        self.logHistory.append((topic, message, timestamp, level))

    def getMessageLog (self, mask=None):
        if mask is None:
            return self.logHistory
        else:
            mask = mask.lower()
            return [ record for record in self.logHistory
                     if fnmatch.fnmatchcase(record[0].lower(), mask) ]

    def getLastMessage (self, mask=None):
        log = self.getMesssageLog(mask)
        try:
            return log[-1]
        except IndexError:
            return None



    ####################################################################
    ### The following are convenience methods to handle subscriptions
    ### to sensor values.

    def addSensors (self, topic, sensornames=(), historySize=256):
        if not topic in self.sensors:
            self.sensors[topic] = (historySize, sensornames, {})
            self.subscribe(topic, self._processSensor, withTimestamp=True, decompose=True)


    def _processSensor (self, topic, timestamp, **valuemap):
        histsize, sensors, history = self.sensors[topic]

        for key, value in valuemap.items():
            if key in sensors:
                try:
                    values = [ eval(v) for v in valuestring.split(',') ]
                except:
                    self.log(self.LOG_PROTOCOL, 'Invalid value for topic "%s", sensor "%s": "%s"'%
                            (name, key, valuestring))
                    return

                records = history.setdefault(key, [])
                if len(records) >= histsize:
                    del records[0]
                records.append((timestamp, values))



    def getSensorHistory (self, topic, key=None):
        (histSize, sensors, history) = self.sensors.get(topic, (0, {}))

        if key is None:
            return history
        else:
            return history.get(key, [])


    def getSensorValue (self, topic, key, index=None):
        history = self.getSensorHistory(topic, key)
        values  = history[-1]
        if index is not None:
            return values[index]
        else:
            return values


    ####################################################################
    ### Instrument Server States

    StateStrings  = ("False", "True", "Failed", "Pending")
    StateValues   = (OFF, ON, FAILED, PENDING) = range(len(StateStrings))

    def _initStateNames (self):
        if not self.states:
            self.states = {}
            self.subscribe("State", self._processState, withTimestamp=True, decompose=True)
            status, states, opts = self.sendReceive('State*', decompose=True)
            for name in states:
                self.states[name.lower()] = (name, None)


    def _initStateValues (self, states=None):
        missing = []
        for name in states or self.getStateNames():
            try:
                name, value = self.states[name.lower()]
            except KeyError:
                missing.append(name)
            else:
                pass

        if missing:
            command = [ "State?", ("named", True) ] + missing
            status, outputs, states = self.sendReceive(command, decompose=True)
            self._processState(None, None, **states)



    def _processState (self, topic, timestamp, **states):
        for name, value in states.iteritems():
            try:
                value = self.StateStrings.index(value)
            except ValueError:
                self.log(self.LOG_PROTOCOL, "Invalid state value received on topic %r: -%s=%r"%(topic, name, value))
            else:
                self.states[name.lower()] = (name, value)

                if topic is not None:
                    for listenerkey in (None, name):
                        for listener, withTimestamp in self.stateListeners.get(listenerkey, []):
                            args = [name, value]
                            if withTimestamp:
                                if timestamp is None:
                                    timestamp = time.time()
                                args.append(timestamp)
                            self.safeInvoke(listener, args)


    def getStateNames (self):
        self._initStateNames()
        return [ name for (name, value) in self.states.values() ]


    def getStateValues (self, *states):
        self._initStateNames()
        self._initStateValues(states)

        if not states:
            values = self.states.values()
        else:
            values = [ self.states[name.lower()] for name in states ]

        return dict(values)


    def getStateValue (self, name, ignoreMissing=False):
        self._initStateNames()
        self._initStateValues((name,))
        name, value = self.states[name.lower()]
        return value


    def addStateListener (self, callback, states=None, withTimestamp=False):
        if self.states is None:
            self._initStateNames()

        if not isinstance(states, (tuple, list)):
            states = [states]

        for state in states:
            self.stateListeners.setdefault(state, []).append((callback, withTimestamp))


    def removeStateListener (self, callback):
        found = False


        for state, callbacks in self.stateListeners.items():
            try:
                callbacks.remove(callback)
            except ValueError:
                pass
            else:
                found = True
                if not callbacks:
                    del self.stateListeners[state]

        return found


    def decomposeParts (self, parts):
        args, opts, strings = [], {}, []

        for opt, value, raw in parts:
            if opt:
                opts[opt] = value
            else:
                args.append(value)

            strings.append(raw)

        return args, opts, "".join(strings).strip()

    def accessLevelIndex (self, accessLevel):
        if not accessLevel:
            return None
        elif isinstance(accessLevel, int):
            if 0 <= accessLevel < len(ACCESS_LEVELS):
                return accessLevel
            else:
                raise ValueError(accessLevel, "not in range")
        elif isinstance(accessLevel, str):
            return ACCESS_LEVELS.index(accessLevel.capitalize())
        else:
            raise TypeError(accessLevel, "int or string required")

#!/usr/bin/python
########################################################################
### FILE:	pdaq_download.py
### PURPOSE:	Download the data from the PDAQ
### AUTHOR:	Richard D. Morris
###
### Copyrights (C) 2010 Life Technologies, Inc.  All rights reserved.
########################################################################

import re
import sys
import optparse
import scpiClient
import pdaq


version = "0.1"

        
def getOptions (version, defaulthost="localhost", defaultport=7000):
    parser = optparse.OptionParser()

    parser.add_option(
        "-s", "--server",
        dest="server", nargs=1, default="localhost",
        help="Host on which the SCPI server is running [%default]")

    parser.add_option(
        "-p", "--port",
        dest="port", nargs=1, default=7000,
        help="TCP port on which the SCPI server is listening [%default]")

    parser.add_option(
        "-v", "--verbose",
        dest="verbose", action='store_true', default=False,

        help='Be verbose')

    options, args = parser.parse_args()
    return options, args


class SCPI_IO:
        def __init__(self,scpiClient):
            self.scpiClient = scpiClient

    
        def sendReceive(self, command, timeout=60.0):
            status, text = self.scpiClient.sendReceive(command, timeout=timeout)
            if None:
                if status != self. scpiClient.OK:
                    raise IOError, \
                        "SCPI server returned %s response to %s: %s"%\
                        (status, command, text)
            return text




def execute():
    options, args  = getOptions(version)

    scpi_connection = scpiClient.SCPIClient((options.server, int(options.port)))
    scpi_io = SCPI_IO(scpi_connection)
    pdaq_io = pdaq.PDAQ(scpi_connection)
    
    scpi_io.sendReceive("ACCess CONTROLLER")
    #scpi_io.sendReceive("MCB:ZMove 0");

    #pdaq_io.acquire(0x404, 40000)
    #scpi_io.sendReceive("MCB:ZMove 700000");
    pdaq_io.transferAndWriteToCSV(args[0]);



if __name__ == '__main__':
    execute()

########################################################################
### FILE:	xmlGenerator.py
### PURPOSE:	Generic XML generator classes
### HISTORY:
###  2016-11-12 Tor Slettnes
###             Created.
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

class XMLGeneratorError (Exception):
    pass

class XMLObject (object):

    def __init__ (self, tag=None, *data, **attr):
        self._tag   = tag
        self._attr  = attr
        self._data  = []
        for item in data:
            self.add(data)


    def __call__ (self):
        '''Return the XML code representation of this data'''

        output = []
        for item in self._data:
            if isinstance(item, XMLObject):
                output.extend(item())
            else:
                output.append(item)

        if self._tag:
            argstr = ''
            for k, v in self._attr.items():
                argstr += ' %s="%s"'%(k.lower().strip('_').replace('_', '-'), v)

            if not output:
                output = [ '<%s%s />\n'%(self._tag, argstr) ]

            elif len(output) == 1:
                output = [ '<%s%s>%s</%s>\n'%(self._tag, argstr,
                                              output[0].strip(), self._tag) ]

            else:
                for index, outputline in enumerate(output):
                    output[index] = "  %s"%outputline

                output.insert(0, '<%s%s>\n'%(self._tag, argstr))
                output.append('</%s>\n'%self._tag)

        return output

    def __getattr__ (self, attr):
        try:
            return object.__getattr__(self, attr)
        except AttributeError:
            tag = attr.replace('_', '-')
            return lambda *data, **opts: self.add_tag(tag, *data, **opts)

    def add_tag (self, tag, *data, **args):
        element = XMLObject(tag, *data, **args)
        self.add(element)
        return element


    def add (self, item):
        if isinstance(item, basestring):
            self._data.append(item + "\n")
                
        elif isinstance(item, XMLObject):
            if not item._tag:
                for subitem in item._data:
                    self.add(subitem)

            else:
                self._data.append(item)

        elif isinstance(item, (list, tuple)):
            for subitem in item:
                self.add(subitem)

        elif item is not None:
            raise XMLGeneratorError, \
                      'Cannot add %s element to XML object'%type(item)


class XMLDocument (XMLObject):
    def __init__ (self, doctype, version="1.0", public=None, system=None, standalone=None, encoding="utf-8", **attributes):

        fields = [ ]
        if version:
            fields.append('version="%s"'%(version,))
        if standalone is not None:
            standalone = ("no", "yes")[bool(standalone)]
            fields.append('standalone="%s"'%(standalone,))
        if encoding is not None:
            fields.append('encoding="%s"'%(encoding,))
        self.xmlspec = ' '.join(fields)


        fields = [ doctype ]
        if public:
            fields.extend(["PUBLIC", '"%s"'%(public,)])
        if system:
            fields.extend(["SYSTEM", '"%s"'%(system,)])
        self.doctype    = ' '.join(fields)

        XMLObject.__init__(self, doctype, **attributes)
        

    def __call__ (self):
        lines = [ '<?xml %s?>\n'%(self.xmlspec,),
                  '<!DOCTYPE %s>\n'%(self.doctype,)  ]

        lines.extend(XMLObject.__call__(self))
        return lines



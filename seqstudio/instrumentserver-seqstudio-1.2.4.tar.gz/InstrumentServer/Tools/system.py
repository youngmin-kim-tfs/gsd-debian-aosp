########################################################################
### FILE:	system.py
### Purpose:	OS/System interface
########################################################################


import time

try:
    from os   import uname

except ImportError:
    # Non-POSIX
    from os import environ
    from sys import getwindowsversion
    _posix = False
    
    def getos ():
        major, minor, build, platform, text = getwindowsversion()
        return "%s %s (build %d, major %d, minor %d, platform %d)"%\
               (environ.get('OS', 'Windows'),
                text, build, major, minor, platform)

    def gettimezone ():
        return "UTC"

    def settimezone (zone):
        pass

else:

    def getos ():
        sysname, nodename, release, version, machine = uname()
        return '%s/%s %s (build %s on %r)'%\
               (sysname, machine, release, version, nodename)

    def gettimezone ():
        return time.tzname[time.localtime()[-1]]

    def settimezone (zone):
        pass


    
try:
    from pytz import common_timezones
except ImportError:
    common_timezones = [ "UTC" ]


def gettimezones ():
    return common_timezones

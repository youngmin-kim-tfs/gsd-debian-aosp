#!/usr/bin/python
########################################################################
### FILE:	mcb_af_pdaq_noise_test.py
### PURPOSE:	Download the data from the PDAQ
### AUTHOR:	Richard D. Morris,
###             Fabio Rojas
###
### USAGE:      This script is intended to be used to tranverse a zstart
###             and zend position that is near the z best focus position.
###             First find your z best focus position using the Imager
###             (Robin) application, then use a zstart and zend that is a
###             few microns within that position (e.g. within 40 microns).
###
###             If you're planning on looking at the laser settling time
###             then move the SCPI command that turns on the laser to the
###             statement after the PDAQ is started.  By default, the laser
###             is turned on before the PDAQ is started.
###
###  NOTE:      Per Matt Chan's request, when the PSD value in the .csv
###             is reported as -999999999 it is because the calculated
###             denominator (X2+X1) readings result was 0.
###
###  ISSUES:    The creating of the CSV labels based on the input sources
###             needs to be improved.  Tried using 0x0404 and the script
###             generated an error.  Using the default input sources is
###             the most common use of the this for auto focus testing
###
### Copyrights (C) 2010 Life Technologies, Inc.  All rights reserved.
########################################################################

import re
import sys
import optparse
import scpiClient
import pdaq
import datetime

version = "0.2"

        
def getOptions (version, defaulthost="localhost", defaultport=2323):
    parser = optparse.OptionParser()

    parser.add_option(
        "-s", "--server",
        dest="server", nargs=1, default="localhost",
        help="Host on which the SCPI server is running [%default]")

    parser.add_option(
        "-p", "--port",
        dest="port", nargs=1, default=7000,
        help="TCP port on which the SCPI server is listening [%default]")

    parser.add_option(
        "-v", "--verbose",
        dest="verbose", action='store_true', default=False,
        help='Be verbose')

    parser.add_option(
        "--zstart",
        dest="zstart", nargs=1, default=0,
        help="Starting z position [%default steps]")

    parser.add_option(
        "--zend",
        dest="zend", nargs=1, default=100000,
        help="End z position [%default steps]")
    
    parser.add_option(
        "--zstm",
        dest="zstm", nargs=1, default=100,
        help="z SettleTimeMove [%default ms]")

    parser.add_option(
        "--pdaqis",
        dest="pdaqis", nargs=1, default=0x3F000404,
        help="PDAQ Input SOurces [%default]")
    
    parser.add_option(
        "--pdaqsc",
        dest="pdaqsc", nargs=1, default=4000,
        help="PDAQ SampleCOunt [%default counts]")

    parser.add_option(
        "--pdaqsp",
        dest="pdaqsp", nargs=1, default=1,
        help="PDAQ SamplePERiod [%default*(200 us)]")

    parser.add_option(
        "--foclst",
        dest="foclst", nargs=1, default=1000,
        help="MCB:FOC:LasterStabilizeTime [%default us]")
    
    parser.add_option(
        "--focsc",
        dest="focsc", nargs=1, default=8,
        help="MCB:FOC:SAMPle count [%default]")
    
    parser.add_option(
        "--repeats",
        dest="repeats", nargs=1, default=1,
        help="Number of repeats for the motion [%default]")
    
    #was trying to figure out how to print as hex value
    #print hex(parser.__dict__['defaults']['pdaqis'])
    options, args = parser.parse_args()
    return options, args


class SCPI_IO:
        def __init__(self,scpiClient):
            self.scpiClient = scpiClient

    
        def sendReceive(self, command, timeout=60.0):
            status, text = self.scpiClient.sendReceive(command, timeout=timeout)
            if None:
                if status != self. scpiClient.OK:
                    raise IOError, \
                        "SCPI server returned %s response to %s: %s"%\
                        (status, command, text)
            return text

        def disconnect(self):
            self.scpiClient.disconnect()

def genTimeStampedFileName():
    date = datetime.datetime.today()
    (fyear, fmonth, fday, fhour, fmin, fsec) = date.timetuple()[0:6]
    _filename = "mcb-pdaq-"
    _filename += str(fyear) + "-" + str(fmonth) + "-" + \
                 str(fday)  + "-" + str(fhour) + "-" + \
                 str(fmin)  + "-" + str(fsec) + ".csv"
    return _filename

def execute():
    options, args  = getOptions(version)
    numberRepeats = int(options.repeats)
    
    if (len(args) != 0):
         filename = args[0]
    else:
        filename = genTimeStampedFileName()
    
    scpi_connection = scpiClient.SCPIClient((options.server, int(options.port)))
    scpi_io = SCPI_IO(scpi_connection)
    pdaq_io = pdaq.PDAQ(scpi_connection)
    
    scpi_io.sendReceive("ACCess CONTROLLER")
    scpi_io.sendReceive("STAGE:POS -F=3")
    scpi_io.sendReceive("MCB:MOT:Z:CONF 0x55448003")
    scpi_io.sendReceive("MCB:MOT:Z:STM %s" % options.zstm)

    scpi_io.sendReceive("MCB:FOC:CONF 0x0010113F")
    scpi_io.sendReceive("MCB:FOC:LST %s" % options.foclst)
    scpi_io.sendReceive("MCB:DRIV:FLAS:CONT 1")
    scpi_io.sendReceive("MCB:FOC:SAMP %s" % options.focsc)
    scpi_io.sendReceive("MCB:FOC:SYC 2")
                        
    scpi_io.sendReceive("MCB:ZMOVe %s" % options.zstart)

    pdaq_io.acquire(options.pdaqis, options.pdaqsc, options.pdaqsp)

    while (numberRepeats > 0):
        numberRepeats -= 1
        scpi_io.sendReceive("MCB:ZMOVe %s" % options.zstart)
        #Running the single focus command is not the typical use
        #of this script, so I'll comment out this command
        #scpi_io.sendReceive("MCB:FOC:SYC 5")    
        scpi_io.sendReceive("MCB:ZMOVe %s" % options.zend)

    pdaq_io.transferAndWriteToCSV(filename);

    scpi_io.sendReceive("MCB:DRIV:FLAS:CONT 0")
    scpi_io.disconnect();
    
if __name__ == '__main__':
    execute()

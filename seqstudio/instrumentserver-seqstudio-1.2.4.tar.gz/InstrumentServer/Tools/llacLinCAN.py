########################################################################
### FILE:	llacLinCan.py
### PURPOSE:	LLAC bindings to the LinCAN driver
### AUTHOR:	Tor Slettnes <tor@slett.net>
########################################################################

import os, struct


INPUTDEVICE, OUTPUTDEVICE = "/dev/can0", "/dev/can1"
EXTENDED    = 1 << 2

fdin, fdout = None, None
isopen      = False

msgformat   = 'IILLLH8sH'
msgsize     = struct.calcsize(msgformat)


def open ():
    global isopen, fdin, fdout
    if not isopen:
        fdin  = os.open(INPUTDEVICE, os.O_RDONLY)
        try:
            fdout = os.open(OUTPUTDEVICE, os.O_WRONLY)
        except:
            os.close(fdin)
            raise

        isopen = True


def close ():
    global isopen, fdin, fdout
    if isopen:
        os.close(fdin)
        os.close(fdout)
        fdin, fdout = None, None
        isopen      = False



def send (mt, node, ref, data=""):
    assert fdout is not None, \
           'CAN driver should be open()ed before send()'

    assert len(data) <= 8, \
           'Data length should be at most 8 bytes'

    msg  = struct.pack(msgformat, EXTENDED, 0,
                      (node << 21) | (mt << 18) | ref, 0, 0,
                      len(data), data, 0)
    size = os.write(fdout, msg)
    

def receive ():
    assert fdin is not None, \
           'CAN driver should be open()ed before receive()'

    msg    = os.read(fdin, msgsize)
    flags, cob, ident, sec, nsec, length, data, dummy = \
           struct.unpack(msgformat, msg)

    node, mt, ref = int((ident>>21) & 0xFF), \
                    int((ident>>18) & 0x7), \
                    int(ident & 0xFFFF)
    return mt, node, ref, data[:length]

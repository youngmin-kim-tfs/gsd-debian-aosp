#!/usr/bin/python
########################################################################
### FILE:	pdaq_download.py
### PURPOSE:	Download the data from the PDAQ
### AUTHOR:	Richard D. Morris
###         Fabio Rojas, Mamood Habibi
###
### Copyrights (C) 2010 Life Technologies, Inc.  All rights reserved.
########################################################################

import re
import sys
import optparse
import scpiClient
import pdaq
import Gnuplot
import time
import datetime
import pdb


version = "0.1"
 
def genTimeStampedFileName(instrumentNumber, compensatorGain):
	date = datetime.datetime.today()
	(fyear, fmonth, fday, fhour, fmin, fsec) = date.timetuple()[0:6]
	_filename = "mcb-pdaq-" + ("InstrNum-%s-" % instrumentNumber) + \
	             ("CompGain-%9.8f-" % float(compensatorGain)) 
	_filename += str(fyear) + "-" + str(fmonth) + "-" + \
				 str(fday)  + "-" + str(fhour) + "-" + \
				 str(fmin)  + "-" + str(fsec) + ".csv"
	return _filename
 
def getOptions (version, defaulthost="localhost", defaultport=7000):
    parser = optparse.OptionParser()

    parser.add_option(
        "-s", "--server",
        dest="server", nargs=1, default="localhost",
        help="Host on which the SCPI server is running [%default]")

    parser.add_option(
        "-p", "--port",
        dest="port", nargs=1, default=7000,
        help="TCP port on which the SCPI server is listening [%default]")

    parser.add_option(
        "-v", "--verbose",
        dest="verbose", action='store_true', default=False,
        help='Be verbose')

    parser.add_option(
        "--zstart",
        dest="zstart", nargs=1, default=500000,
        help="Starting z position [%default steps]")
 
    parser.add_option(
        "--compgain",
        dest="compgain", nargs=1, default=0.0,
        help="Starting z Compensator GAin [%default steps]")
		
    parser.add_option(
        "--instrnum",
        dest="instrnum", nargs=1, default=0,
        help="Instrument Number [%default]")
		
    options, args = parser.parse_args()
    return options, args

class SCPI_IO:
        def __init__(self,scpiClient):
            self.scpiClient = scpiClient

    
        def sendReceive(self, command, timeout=60.0):
            status, text = self.scpiClient.sendReceive(command, timeout=timeout)
            if None:
                if status != self. scpiClient.OK:
                    raise IOError, \
                        "SCPI server returned %s response to %s: %s"%\
                        (status, command, text)
            return text


def waitForNewData(scpi_io):
   while ( (int(scpi_io.sendReceive("mcb:pdaq:stat?"),0) & 0x00000404) != 0x000000004):
	time.sleep(0.2)


def plotData(g, pdaq_io):
    header=pdaq_io.getHeader()
    data=pdaq_io.transferAndGetData()
    plots=[]
    for i in range(1,len(header)):
	plots+=[Gnuplot.Data(data[0],data[i],title=header[i],with_='lines')]
    g.xlabel(header[0])
    g.plot(*plots)

def printData(pdaq_io):
    print "Header: \n"
    print pdaq_io.getHeader()      
 #   pdg.set_trace()
    print "Data: \n"
    print pdaq_io.transferAndGetData()
    print  
 

def printData_to_file(pdaq_io, fileobj, index):
    data=pdaq_io.transferAndGetData()
    print >> fileobj, str(index)
    print >> fileobj, data[0]   # time ms
    print >> fileobj, data[1]   # trajectory
    print >> fileobj, data[2]   # encoder
	
def execute():
	options, args  = getOptions(version)
	
	scpi_connection = scpiClient.SCPIClient((options.server, int(options.port)))
	scpi_io = SCPI_IO(scpi_connection)
	pdaq_io = pdaq.PDAQ(scpi_connection)
	g = Gnuplot.Gnuplot(debug=1)

	fname = 'c:\\pdaqdata\\' + genTimeStampedFileName(options.instrnum, options.compgain)
	dataFile = open(fname, 'w')
	
	i = 0
	stepDelta = 50
	zMoveDistance = 250
	scpi_io.sendReceive("ACCess CONTROLLER")
	scpi_io.sendReceive("MCB:MIN")
	# get z pos and z enc
	scpi_io.sendReceive("MCB:PDAQ:InputSOurces 0x00000404")
	scpi_io.sendReceive("MCB:MOT:Z:CLIM 250")
	scpi_io.sendReceive("MCB:MOT:Z:CGA %s" % options.compgain)
	while (i < 5):	
		zstart = int(options.zstart) + i*stepDelta
		zend = zstart + zMoveDistance
		scpi_io.sendReceive("MCB:PDAQ:CONTrol 0x00000000")
		scpi_io.sendReceive("MCB:ZMOVe %s" % zstart)        	
		scpi_io.sendReceive("MCB:MOT:Z:POS %s" %  zstart)
		scpi_io.sendReceive("MCB:MOT:Z:EPOS %s" %  zstart)
		scpi_io.sendReceive("MCB:PDAQ:CONTrol 0x00000005")
		scpi_io.sendReceive("MCB:PDAQ:SampleCOunt 400")
		scpi_io.sendReceive("MCB:ZMOV %s" % zend)
		#waitForNewData(scpi_io)
		printData(pdaq_io)
		printData_to_file(pdaq_io, dataFile, i)
		plotData(g,pdaq_io)
		i += 1
	dataFile.close()

if __name__ == '__main__':
    execute()

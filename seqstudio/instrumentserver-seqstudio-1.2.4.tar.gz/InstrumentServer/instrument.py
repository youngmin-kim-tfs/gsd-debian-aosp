#!/usr/bin/python 
########################################################################
### FILE:	instrument.py
### PURPOSE:	Instrument Server Startup
### AUTHOR:     Tor Slettnes <tor.slettnes@thermofisher.com>
###
### Copyrights (C) 2005-2019 ThermoFisher Scientific.  All rights reserved.
########################################################################

import sys, os, os.path, re

### Product name, used to set up search paths below.
product       = "Monarch"

### Instrument Flavor, used to initialize behavior.
### Don't edit this script; instead set environment variables
##  in "/etc/default/instrumentserver".
flavor        = os.getenv("FLAVOR", "Simulator")
#flavor        = os.getenv("FLAVOR", "EP1")
#flavor        = os.getenv("FLAVOR", "EP2")

### Transport to use for Low Level Auxiliary Control 
llactransport = os.getenv("LLACTRANSPORT", "llacSimulator")
#llactransport = os.getenv("LLACTRANSPORT", "llac2ixxat")

### Data Acquisition module
acquisition   = os.getenv("ACQUISITION", "replaySpectrometer")
#acquisition   = os.getenv("ACQUISITION", "horibaSpectrometer")

### Laser module
laser         = os.getenv("LASER","dummylaser")

### Search path for local (instrument-specific) configuration files
configpath    = os.getenv("CONFIGPATH",
                          [ "/etc/opt/%s/IS"%(product,),
                            "/opt/%s/ServiceModules"%(product,) ])

### Search path for local (instrument-specific) SCPI modules
modulepath    = os.getenv("MODULEPATH",
                          [ "/etc/opt/%s/IS"%(product,),
                            "/opt/%s/ServiceModules"%(product,) ])

### RFID Tag type: CoffeeTag or FileTag
rfidtag       = os.getenv("RFID", "FileTag")

### The Instrument Server source is distributed across multiple source repositories:
###  - "Framework" contains code that is included on all supported instrument platforms
###  - "Library" contains generic but optional modules that may or may not be included (e.g. LLAC)
###  - A project specific repository
### The following is used to set up search paths for modules, configuration files etc,
### given specific module locations relative to current working directory.
baseFolders   = [ ".", "../../Library/InstrumentServer", "../../Framework/InstrumentServer" ]

### SCPI modules to load at startup, before accepting client connections.
preload       = [ "init", "instrument", "listeners" ]

### SCPI modules to load at startup, once server is running.
postload      = [ "start" ]

### SCPI modules to load before shutdown.
exitmodules   = [ "stop" ]


### The Instrument Server source is normally distributed across multiple source repositories:
###  - "instrumentserver-framework" contains core components that are included on all supported instrument platforms
###  - "instrumentserver-library" contains optional modules that may or may not be included in a particular device (e.g. LLAC)
###  - "instrumentserver-<project>" contains components specific to <project>.  
###
### The following is used to set up search paths for modules, configuration files etc,
### given specific module locations relative to current working directory.

topfolder=os.path.dirname(sys.argv[0]) or "."

try:
    folderspec  = open(os.path.join(topfolder, ".folders")).read()
    missingtext = "\tPlease obtain it from the corresponding source repository,\n" \
                  "\tor edit your '.folders' file to reflect the correct path."

except EnvironmentError:
    try:
        folderspec = open(os.path.join(topfolder, ".folders.default")).read()
        missingtext = "\tPlease obtain it from the corresponding source repository, or\n" \
                      "\tcreate your custom '.folders' file to reflect the correct path\n" \
                      "\tusing '.folders.default' as template."

    except EnvironmentError:
        folderspec = None


if folderspec:
    baseFolders = filter(None, re.split(r"\s*(?:\#[^\n]*)?\n", folderspec))

    for folder in baseFolders:
        realpath = os.path.realpath(os.path.join(topfolder, folder))
        
        if os.path.isdir(realpath):
            sys.path.append(realpath)
        else:
            sys.stderr.write("\n\tMissing directory: %r.\n\n%s\n\n"%(realpath, missingtext))
            sys.exit(1)
else:
    baseFolders = ["."]


### Import the main server
import instrumentServer


### Add any instrument-specific options here, e.g. support for specific hardware.
instrumentServer.addOption(
    "--llac", "--llac-transport",
    dest="llactransport",
    default=llactransport,
    nargs=1,
    help="Transport module for communication with low level auxiliary control devices [%default]")


instrumentServer.addOption(
    "--acquisition", "--data-acquisition",
    dest="acquisition",
    default=acquisition,
    nargs=1,
    help="Data acquisition/Spectrometer module [%default]")


instrumentServer.addOption(
    "--laser", "--laser-module",
    dest="lasermodule",
    default=laser,
    nargs=1,
    help="Laser device [%default]")


instrumentServer.addOption(
    "--rfid", "--rfid-tag",
    dest="rfidtag",
    default=rfidtag,
    nargs=1,
    help="RFID tag type [%default]")


### Initialize the server instance, with default startup options provided.
### These can be overridden with the corresponding command line switch, 
### which are defined in the "instrumentServer.py" module as well as in the
### "initParser()" method in "<framework>/InstrumetnServer/SCPIServer/scpiServer.py".
### Search paths for modules and configuration files are also initialized here.

instrumentServer.initialize(flavor=flavor,
                            baseFolders=baseFolders,
                            configpath=configpath,
                            modulepath=modulepath,
                            preload=preload,
                            postload=postload,
                            exitmodules=exitmodules)


### Now that paths are set and options configured, set up the SCPI
### command tree. 

import monarchServer
instrumentServer.runServer(monarchServer.Top)


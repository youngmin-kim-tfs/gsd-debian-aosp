"""
SCPIClient class and associated symbol definitions.

This module provides client support for communicating with the
instrument server.


========================
CONNECTING TO THE SERVER
========================

A typical connection scenario would be:

    from scpiClient import SCPIClient, ACCESS_OBSERVER,

    scpi = SCPIClient()

    scpi.connect(("localhost", 7000),
                 timeout=15,
                 access=ACCESS_OBSERVER,
                 greeting="My Application Name")

By default, a new receiver thread is launched on connect() to handle
input from the server, and from there to dispatch appropriate response
actions or invoke callbacks.  To prevent this, use "threaded=False".
You then have two options:

 * You can spawn your own receiver thread, and from there invoke
   "receiveLoop()" directly.  This has the same effect as letting the
   conect() method spawn one, but may be useful if you are using a
   different threading model in your application (e.g. from the
   "multiprocessing" module, or if you are using PyQt).

   In this case, 'receiveLoop()' must be invoked AFTER 'connect()'.
      

 * You can omit threading altogether, in which input from the server
   will only be processed when you invoke the "receiveResponse()"
   method (directly, or indirectly via "sendReceive()"); see below.
   This means that responses to asynchronous commands as well as
   message publications will only be processed during those times.



================
SENDING COMMANDS
================

To send a single command to the server, use:

    index = scpi.sendCommand(<command>)

where <command> is either
  - a single string, with argument values quoted as needed, or
  - separated into a list/tuple of individual arguments, with each
    argument comprised either of a string or a 2+-element tuple
    representing an option name and option value.

The following are equivalent:

    - "COMMAND -option='some value' \"argument one\" <<<argument\ntwo>>>"
    - ("COMMAND", "-option='some value'", "argument one", "argument\ntwo")
    - [ "COMMAND", ('option', 'some value'), 'argument one', 'argument\ntwo' ]



The return value is an index, which will then be supplied as argument
to the "receiveResponse()" method, below.


===================
RECEIVING RESPONSES
===================

To receive the server response to a previously-sent command, you can choose
one of the following invocations of "receiveResponse()":

    rawresponse = scpi.receiveResponse(index, splitResponse=False)

    status, reply = scpi.receiveResponse(index, splitResponse=True)

    status, parts = scpi.receiveResponse(index, splitParts=True)    

    status, outputs, keywords = scpi.receiveResponse(index, decompose=True)

where:

    rawresponse is the raw text received from the server, including
                the command index (or text) from the original command

    status      is "OK" or "NEXT", with the latter indicating that the
                command is now running asynchronously (in the background)
                (use "receiveResponse(...ignoreNext=True)" or else invoke
                "receiveResponse()" again to wait for final completion)

    reply       is the reply portion of the server response, as a single
                unparsed string

    parts       is a list of 3-element tuples corresponding to outputs
                returned by the server, each made up of
                  - An option name (or None if it is an unnamed output)
                  - An option value, with substitutions performed
                  - A "raw" string containing the original unparsed argument

    outputs     is a list of unnamed (positional) response words returned
                from the server

    keywords    is a dictionary containing any named response words from
                the server.


A convenience method, "sendReceive()", combines "sendCommand()" and
"receiveResponse()" into a single call:

   status, outputs, keywords = sendReceive(command, **options)


EXAMPLES:

   scpi.sendReceive("VERSion?", splitResponse=False)
   --> "OK 1 -InstrumentServer:Build=42 -InstrumentServer:Version=0.0.5 -ASCB=8812"

   scpi.sendReceive("VERSion?", splitResponse=True)
   --> ("OK",
        "-InstrumentServer:Build=42 -InstrumentServer:Version=0.0.5 -ASCB=8812")

   scpi.sendReceive("VERSion?", splitParts=True)
   --> ("OK",
        [ ("InstrumentServer:Build", "42", "-InstrumentServer:Build=42 "),
          ("InstrumentServer:Version", "0.0.5", "-InstrumentServer:Version=0.0.5 "),
          ("ASCB", "8812", "-ASCB=8812") ])


   scpi.sendReceive("VERSion?", decompose=True)
   --> ("OK",
        [],
        {"InstrumentServer:Version": "0.0.5", "InstrumentServer:Build": "42", "ASCB": "8812" })



=======================
SUBSCRIBING TO MESSAGES
=======================

Asynchronous events are published by the Instrument Server as
messages, organized by "Topic".  For instance, many qPCR instruments
publish various temperatures on the "Temperature" topic once per
second, and progress during a run on the "Run" topic.

To subscribe to such messages, use:
     scpi.subscribe(topic, callback, ...)

The topic may also contain wildcard characters ("?" to match any
single character and "*" to match anything):

    scpi.subscribe(r"Session-*", callback, ...)

By default, the subscription only takes effect on topics that exist at
the time of subscription; if there are no matches, an error is
returned by the server.  However, to subscribe to any matching topics
that may be created in the future as well, use the "future" option:

   scpi.subscribe("*", callback, future=True, ...)
   

Once a message is received from the server, the corresponding callback
is invoked -- by default, as follows:

    callback(<topic>, <text>)

where <topic> is the messsage topic supplied by the server (which may
differ from what was subscribed to in case wildcards were used, and
also by uppercase/lowercase letters).

However, several options exist to control what arguments are supplied
in the callback:

   - Use "timestamp=True" to include a timestamp (seconds since epoch,
     with millisecond precision):

         callback(<topic>, <message>, <timestamp>)
   
   - Use "cbargs=(ARG_TOPIC, ARG_TIMESTAMP, ARG_LEVEL, ARG_MESSAGE)"
     and "staticargs=(value1, value2, ...)"
     to get more detailed control of what arguments are included in
     the callback, and in what order.  Those specified in "cbargs"
     appear before those in "staticargs":
         subscribe(mytopic, callback, cbargs=(ARG_LEVEL, ARG_MESSAGE), staticargs=(reference,))
         --> callback(level, message, reference)

   - Use any keyword arguments to "subscribe()" to have those same
     arguments included in the callback:
         subscribe(mytopic, callback, fruit="banana")
         --> callback(mytopic, message, fruit="banana")

   - Use "decompose=True" to decompose the published message in a
     manner similar to response parsing, above; unnamed
     arguments/words from the message are appended as additional
     arguments, and named options/values are included as keyword
     arguments:
         subscribe(mytopic, callback, timestamp=True, decompose=True)
         --> callback(mytopic, timestamp, arg1, arg2, option1=value1, option2=value2...)



=======
SENSORS
=======

Specialized support is provided to keep track of periodically
published sensor values, and to cache these for later retrieval.  For
instance, to keep a rolling record of the last 256 sample and block
temperatures published by the server, use this:

   scpi.addSensor("Temperature", ("sample", "block"), historySize=256)

Then, to retrieve the current value of such a sensor:
   value = scpi.getSensorValue("Temperature", "sample")
   
And the recorded history:
   history = scpi.getSensorHistory("Temperature", "sample")

   

======
STATES
======

A "State" is anInstrument Server construct which represents a
binary (True/False) condition or switch in the system.
Examples would include:
 - Whether a particular firmware component is available and initialized
 - The current state of a door or interlock
 - Whether the instrument is ready to operate
 - Whether the instrument is currently performing a run
 - Whether removable media is inserted, readable, writable, etc.
 - Whether the instrument has a valid network connection
 - Etc.


To enumerate the states that the server currently keeps track of, use:
   names = scpi.getStateNames()

To get the current value (True or False) of a state, use:
   enabled = scpi.getStateValue(name)

To listen to state changes in the instrument, use:
   scpi.addStateListener(callback)

Then, once a state changes, the callback is invoked as follows:
   -> callback(name, value)

The value is normally True or False; however the Instrument Server
also uses a third possible value, "Error", to represent that something
went wrong while executing a state trigger.  In the callback, such
an error value is represented as a reference to the Python Exception
class.

States are interdependent, so one state change it will often
cascade to others.  
"""




from threading     import Thread, Lock, RLock
from Queue         import Queue, Empty
from socket        import socket, AF_INET, SOCK_STREAM, SHUT_RDWR, error as SocketError
from logging       import debug, info, warning
from commandParser import CommandParser


try:
    from hashlib import md5
except ImportError:
    import md5

import hmac
import fnmatch
import re
import time
import sys
import traceback




### Access Levels
ACCESS_LEVELS = \
    (ACCESS_GUEST, ACCESS_OBSERVER, ACCESS_CONTROLLER, ACCESS_ADMINISTRATOR) = \
    ("Guest", "Observer", "Controller", "Administrator")

### Response and input types from the SCPI server
RESPONSE_TYPES = \
    (OK, NEXT, ERROR, MESSAGE, READY) = \
    ("OK", "NEXT", "ERRor", "MESSage", "READy")

### Response formats
RESPONSE_FORMATS = \
    (RAW, STRING, PARTS, VALUES) = \
    range(4)

### Subscription levels
SUBSCRIPTION_LEVELS = ("Debug", "Info", "Notice", "Warning", "Error")
(LEVEL_DEBUG, LEVEL_INFO, LEVEL_NOTICE, LEVEL_WARNING, LEVEL_ERROR) = \
    range(len(SUBSCRIPTION_LEVELS))
    

### Available arguments in decomposed message callback
MESSAGE_ARGS = \
    (ARG_TOPIC, ARG_TIMESTAMP, ARG_LEVEL, ARG_MESSAGE) = \
    ("topic", "timestamp", "level", "message")



DEFAULT_SERVER = ("127.0.0.1", 7000)



class SCPIError (Exception):

    def __init__ (self, message, *args, **kwargs):
        Exception.__init__(self, message)
        self.message     = message
        self.args        = args
        self.attributes  = kwargs

    def __str__ (self):
        return str(self.message)

    def __repr__ (self):
        return str(self.message)



class SCPICommunicationError (SCPIError):
    pass

class SCPITimeout (SCPIError):
    pass

class SCPISubscribeError (SCPIError):
    pass


class SCPIInvocationError (SCPIError):
    pass

class SCPIAlreadyConnected (SCPIError):
    pass

class SCPIDisconnected (SCPIError):
    pass

class SCPIErrorResponse (SCPIError):
    _errorCodeX = re.compile(r"^\[([\w\.]+)\]$")

    def __init__ (self, text, parts):
        SCPIError.__init__(self, text)
        
        attributes = {}
        code       = None
        message    = None

        for option, value, raw in parts:
            if raw.startswith("-->"):
                message = []

            elif message is not None:
                message.append(raw)

            elif option:
                attributes[option] = value

            elif self._errorCodeX.match(value):
                code = value[1:-1]
                    
            else:
                message = [ raw ]

        self.raw = text
        self.code = code
        self.attributes = attributes
        self.message = "".join(message)


    def __repr__(self):
        return self.raw.strip()
    

class SCPIUnknownResponse (SCPIError):
    pass






def safeInvoke (function, args=(), kwargs={}, log=warning):
    try:
        if function:
            function(*args, **kwargs)
        return bool(function)

    except Exception, e:
        e_type, e_name, e_tb = sys.exc_info()

        arglist  = [ "%r"%(arg,) for arg in args ]
        arglist += [ "%s=%r"%item for item in kwargs.items() ]

        tb = [ "    In %s, method %s(), line %d: %s"%(filename, method, lineno, text)
               for filename, lineno, method, text in traceback.extract_tb(e_tb) ]

        log("Exception occured in callback %s(%s):\n%s\n    [%s] %s"%
            (function.__name__,
             ", ".join(arglist),
             "\n".join(tb),
             e.__class__.__name__,
             e))

        return False




####################################################################
### SCPI Client class.
### Method names starting with a single underscore ('_') are for
### internal use, and run in a separate thread ('receiveThread').

class SCPIClient (CommandParser):
    multiLineX      = re.compile(r'<(\w+(?:\.[^>]*)?)>')
    authentication  = None
    accesslevel     = None
    serveraddr      = None

    def __init__(self,
                 serveraddr=None,
                 commandIndex=True,       # <index> COMMand Args...
                 checkPartialReply=False, # ERRor <partial-command> <-- ...
                 authentication=None,     # Perform Challenge/Response authentication using the supplied secret
                 access=None,             # Access level requested ("OBSERVER", "CONTROLLER", etc)
                 greeting=None):          # Description of this session.

        CommandParser.__init__(self)

        if serveraddr:
            self.serveraddr  = serveraddr 
        self.autoConnect     = True
        self.commands        = {}

        self.authentication  = authentication
        self.accesslevel     = access
        self.serverinfo      = {}
        self.greeting        = greeting

        self.pendingInput    = ""
        self.receiveThread   = None
        self.isReceiving     = False
        self.isConnected     = False
        self.connectionError = None
        self.socket          = None

        self.callbackThread  = None
        self.callbackQueue   = None

        self.commandLock     = RLock()
        self.commandIndex    = 0
        self.useIndex        = commandIndex
        self.partialReply    = checkPartialReply

        ### Subscription support
        self.sessionTopic    = None
        self.subscriptions   = {}
        self.sensors         = {}
        self.states          = None
        self.stateListeners  = {}
        self.logMask         = None
        self.logHistory      = []
        self.connecthooks    = []
        self.disconnecthooks = []



    def connect (self, serveraddr=None,
                 timeout=None,             # Timeout for initial connect
                 threaded=True,            # Use dedicated thread for receiving from server
                 authentication=None,      # Authentication secret (not always needed)
                 access=None,              # Initial access level (default is Guest)
                 greeting=None,            # Description of your application/session
                 ignoreFailure=False):     # Do not raise error if connection fails (just return boolean)

        if not serveraddr:
            serveraddr = self.serveraddr or DEFAULT_SERVER


        if self.isConnected and self.socket:
            if not ignoreFailure:
                raise self.SCPIAlreadyConnected("Already connected to server %s"%(self.socket.getpeername(),))

            return False

        info('Connecting to %s:%s, timeout=%s'%(serveraddr + (timeout, )))

        ### Communication
        self.socket = socket(AF_INET, SOCK_STREAM)
        self.fileno = self.socket.fileno
        self.rfile  = self.socket.makefile('rb', -1)
        self.connectionError = None

        self.socket.settimeout(timeout)
        try:
            self.socket.connect(serveraddr)

        except SocketError, e:
            self._onDisconnect()
            self.connectionError = e
            if not ignoreFailure:
                raise SCPICommunicationError(e.args[-1])

            return False


        self.socket.settimeout(None)
        self.isConnected = True

        if threaded and not self.isReceiving:
            self.receiveThread = Thread(None, self.receiveLoop, "receiveThread")
            self.receiveThread.setDaemon(True)
            self.receiveThread.start()

        try:
            if authentication or self.authentication:
                self.authenticate(authentication or self.authentication)
                
            if access or self.accesslevel:
                self.setAccess(access or self.accesslevel)

            if greeting or self.greeting:
                self.greet(greeting or self.greeting)

        except SCPIError, e:
            self.connectionError = e
            if not ignoreFailure:
                raise

            return False

        else:
            self._onConnect()
            return True
                
        

    def disconnect (self):
        if self.serveraddr:
            info('Disconnecting from %s:%s'%(self.serveraddr))

        gotThread = self.isReceiving

        if self.isConnected:
            self.isConnected = False
            self.socket.shutdown(SHUT_RDWR)

        elif not gotThread:
            self._onDisconnect()


    def _onConnect (self):
        for callback, args, kwargs in self.connecthooks:
            safeInvoke(callback, args, kwargs)
        

    def _onDisconnect (self):
        if self.socket:
            self.socket.close()
            self.socket = None
            self.states = None
            self.subscriptions = {}
            self.sensors = {}
            self.logMask = None
            del self.logHistory[:]
            self.sessionTopic = None

        self.isConnected = False

        exception = SCPIDisconnected("Lost Connection to Server")

        for command, responseQueue in self.commands.itervalues():
            responseQueue.put((exception, None, None))

        if self.callbackQueue is not None:
            self.callbackQueue.put(None)

        for callback, args, kwargs in self.disconnecthooks:
            safeInvoke(callback, args, kwargs)


    def addConnectHook (self, callback, *args, **kwargs):
        self.connecthooks.append((callback, args, kwargs))

    def addDisconnectHook (self, callback, *args, **kwargs):
        self.disconnecthooks.append((callback, args, kwargs))


    def authenticate (self, secret):
        debug("Authenticating to server")
        status, challenge = self.sendReceive("CHALlenge?")
        response  = hmac.new(secret, challenge, md5).hexdigest()
        self.sendReceive(("AUTHentication", response))

    def setAccess (self, level):
        self.sendReceive(("ACCess", level))

    def greet (self, greeting):
        self.sendReceive(("SESSion:DESCription=", greeting))



    ####################################################################
    ### The following methods receive input from the instrument in a
    ### separate thread

    def receiveLoop (self):
        "Runs in a separate thread to receive input from the instrument"

        assert self.isConnected, "You must connect() before you can invoke receiveLoop()"

        debug('Starting SCPI client receive thread')
        self.isReceiving = True

        try:
            while True:
                response = self._receive()

        except EOFError, e:
            self.isReceiving   = False
            self.receiveThread = None
            debug('Ending SCPI client receive thread')


    def _receive (self):
        try:
            text, parts = self.expandArgs(self.rfile)
        except EOFError, e:
            self._onDisconnect()
            raise
        else:
            return self._processParts(text, parts)


    def _processParts (self, text, parts):
        "Handle input received from instrument"

        option, status, raw = parts.pop(0)

        if status in (OK, NEXT, ERROR):
            return self._processResponse(status, text, parts)

        elif status == MESSAGE:
            return self._processMessage(text, parts)

        elif status == READY:
            return self._processReady(text, parts)

        else:
            warning('Invalid status word "%s" received from SCPI server: "%s"'%
                    (status, text.strip()))



    def _processReady (self, text, parts):
        "Handle initial READy prompt from IS"

        for option, value, raw in parts:
            self.serverinfo[option] = value

        self.sessionTopic = "Session-%s"%(self.serverinfo.get('session', 0))

        

    def _processResponse (self, status, text, parts):
        "Handle a response to a prior command, add to response queue"

        try:
            option, idx, header    = parts.pop(0)
            idx                    = int(idx)
            command, responseQueue = self.commands[idx] 


        except KeyError:
            warning("Received response to unknown command index %d: %s"%
                    (idx, text.strip()))
            responseQueue = None


        except IndexError:
            warning('Command index missing in %s response from SCPI server: "%s"'%
                    (status, text.strip()))
            responseQueue = None


        except ValueError:
            for (command, responseQueue) in self.commands.values():
                echo  = header
                part  = 0
                while part < len(parts) and (command.strip()+' ').startswith(echo.strip()+' '):
                    option, value, raw = parts[part]
                    echo += raw
                    part += 1

                if (echo.strip()+' ').startswith(command.strip()+' '):
                    del parts[:part-1]
                    break

                elif command.startswith(header) and self.partialReply:
                    break

            else:
                warning('Received response to unknown command: "%s"'%(text.strip()))
                responseQueue = None

        if responseQueue:
            response = (status, text, parts)
            responseQueue.put(response)
            return response



    _messageFormat = "${topic} ${timestamp} ${level#} ${message}"

    def _processMessage (self, text, parts):
        "Handle a message publication; invoke any subscriber callback methods"

        try:
            option, topic, raw = parts.pop(0)
            option, timestamp, raw = parts.pop(0)
            option, level, raw = parts.pop(0)
            
            time = float(timestamp)
            level = int(level)

        except IndexError:
            warning("Missing elements in published message: %r"%(text.strip()))

        except ValueError, e:
            warning("Malformed value in published message %r: %s"%(text.strip(), e))

        else:
            messageArgs, messageOpts, message = self.decomposeParts(parts)

            cbmap = {
                ARG_TOPIC     : topic,
                ARG_TIMESTAMP : time,
                ARG_LEVEL     : level,
                ARG_MESSAGE   : "".join(message).strip() }

            matches   = 0
            callbacks = 0

            for ro, records in self.subscriptions.iteritems():
                if ro.match(topic):
                    matches += 1

                    for record in records:
                        callbacks += 1
                        callback, cbargs, staticargs, staticopts, decompose = record

                        args = [cbmap[a] for a in cbargs]
                        args.extend(staticargs)

                        opts = dict(staticopts)
                            
                        if decompose:
                            args.extend(messageArgs)
                            opts.update(messageOpts)

                        self._processCallback((callback, args, opts))


    

    def _processCallback (self, record):
        if self.callbackThread is None:
            self.callbackQueue  = Queue()
            self.callbackThread = Thread(None, self._callbackLoop, "callbackThread")
            self.callbackThread.setDaemon(True)
            self.callbackThread.start()

        self.callbackQueue.put(record)


    def _callbackLoop (self):
        while self.isConnected:
            record = self.callbackQueue.get()
            if record:
                safeInvoke(*record)

        self.callbackThread = None
        self.callbackQueue  = None


    ####################################################################
    ### The following methods can be invoked to send commands to and 
    ### receive responses or other input from the instrument.

    def sendCommand (self, command):
        "Send a command to the SCPI server"

        if isinstance(command, (list, tuple)):
            command = self.collapseArgs(command)

        elif isinstance(command, basestring):
            command = command.rstrip('\n').rstrip('\r')

        else:
            raise TypeError("Invalid command, must be a string, a list of strings, "
                            "or a list of 2-3 string tuples: %r"%(command,))

        try:
            self.commandLock.acquire()

            if self.socket == None:
                if self.autoConnect:
                    self.connect()
                else:
                    raise SCPIDisconnected("Not connected to server")


            self.commandIndex += 1
            self.commands[self.commandIndex] = (command, Queue())
            try:
                if self.useIndex:
                    self.socket.send("%s %s\n"%(self.commandIndex, command))
                else:
                    self.socket.send("%s\n"%command)
            except SocketError, e:
                self._onDisconnect()
                raise SCPICommunicationError(str(e), *e.args)

            return self.commandIndex

        finally:
            self.commandLock.release()


    def _getResponse (self, commandIndex, timeout=None, ignoreNext=False):
        (command, responseQueue) = self.commands[commandIndex]

        start = time.time()
        while timeout is None or time.time() < start+timeout:
            while not self.isReceiving and responseQueue.empty():
                self._receive()
                    
            try:
                status, text, parts = responseQueue.get(True, timeout)

            except Empty:
                pass

            else:
                if isinstance(status, Exception):
                    raise status

                if status != NEXT:
                    del self.commands[commandIndex]

                if status != NEXT or not ignoreNext:
                    return status, text, parts

        else:
            del self.commands[commandIndex]
            raise SCPITimeout("Timeout waiting for SCPI response after %.1fs"%(time.time()-start))



    def receiveResponse (self, commandIndex,
                         splitResponse=True,
                         splitParts=False,
                         decompose=False,
                         ignoreNext=False,
                         ignoreError=False,
                         timeout=None):
        "Wait for a response to a previously sent command"

        status, text, parts = self._getResponse(commandIndex, timeout, ignoreNext)

        if status[:3] == "ERR" and not ignoreError:
            raise SCPIErrorResponse(text, parts)

        elif decompose:
            args, opts, string = self.decomposeParts(parts)
            return status, args, opts

        elif splitParts:
            return status, parts

        elif splitResponse:
            return status, "".join([ raw for opt, arg, raw in parts ]).strip()

        else:
            return text


    def sendReceive (self, command, 
                     splitResponse=True,
                     splitParts=False, 
                     decompose=False,
                     ignoreNext=False,
                     ignoreError=False,
                     timeout=None):

        idx = self.sendCommand(command)
        return self.receiveResponse(idx, splitResponse, splitParts, decompose, ignoreNext, ignoreError, timeout)



    def profile (self, command, count=1, ignoreNext=False, timeout=None):
        start = time.time()
        for n in xrange(count):
            self.sendReceive(command, True, ignoreNext, timeout)
        return (time.time() - start) / count



    ####################################################################
    ### The following methods provide subscription/callback


    def subscribe (self, topic, callback, regex=False, future=True, level=LEVEL_DEBUG,
                   cbargs=None, withTimestamp=False, withLevel=False, decompose=False,
                   staticargs=(), first=False, **staticopts):

        """Subscribe to a topic, and register a callback method"""
        assert callable(callback), \
               'The supplied callback handler is not callable'


        if not cbargs:
            cbargs = (ARG_TOPIC,)

            if not decompose:
                cbargs += (ARG_MESSAGE,)

            if withTimestamp:
                cbargs += (ARG_TIMESTAMP,)

            if withLevel:
                cbargs += (ARG_LEVEL,)

        else:
            for a in cbargs:
                if not a in MESSAGE_ARGS:
                    raise SCPIInvocationError("Invalid callback argument %r in "
                                              "message subscription on topic %r, callback %s()"%
                                              (a, topic, callback.__name__))

        record = (callback, cbargs, staticargs, staticopts, decompose)
        rx     = (fnmatch.translate(topic), topic)[bool(regex)]
        rxobj  = re.compile(rx, re.I)

        try:
            if first:
                self.subscriptions[rxobj].insert(0, record)
            else:
                self.subscriptions[rxobj].append(record)

        except KeyError:
            self.subscriptions[rxobj] = [record]
            self.sendReceive(("SUBScribe",
                              ('future', future),
                              ('level', SUBSCRIPTION_LEVELS[level]),
                              ('regex', bool(regex)),
                              ('format', self._messageFormat),
                              topic))


    def unsubscribe (self, topic, callback, regex=False, ignoreMissing=False):
        """Subscribe to a topic, and register a callback method"""

        rx = (fnmatch.translate(topic.lower()), topic.lower())[bool(regex)]
        foundCallback = False
        foundTopic    = False

        ### First, look through our own subscription records, and remove
        ### any matching references to callback

        for (ro, records) in self.subscriptions.items():
            if ro.pattern == rx:
                for record in records[::-1]:
                    if record[0] == callback:
                        records.remove(record)
                        foundCallback = True

                if records:
                    foundTopic = True

                else:
                    self.sendReceive(("UNSubscribe",  topic))
                    del self.subscriptions[ro]


        ### If no matches were found, try unsubscribing anyway; we may have
        ### been subscribed to a "wildcard" topic (e.g. "Session-*") and now
        ### are unsubscribing from a more specific one (e.g. "Session-1")

        if not foundCallback:
            if foundTopic:
                raise SCPISubscribeError("Callback %r not is not registered for topic subscription %r"%
                                         (callback.__name__, topic))
            else:
                try:
                    self.sendReceive(("UNSubscribe", topic))
                except SCPIErrorResponse:
                    if not ignoreMissing:
                        raise


    def publish (self, topic, message):
        if isinstance(message, list):
            message = self.collapseArgs(message)

        elif isinstance(message, dict):
            message = self.collapseArgs(message.items())

        elif isinstance(message, basestring):
            message = message.rstrip('\n').rstrip('\r')
            
        return self.sendReceive('PUBLish %r %s'%(topic, message))



    ########################################################################
    ### The following are convenience methods for caching published
    ### messages

    def startMessageLog (self, mask="*", historySize=256):
        self.stopMessageLog()

        self.logMask = mask
        self.logHistorySize = historySize
        del self.logHistory[:]

        self.subscribe(mask, self._logMessage, first=True,
                       cbargs=(ARG_TOPIC, ARG_MESSAGE, ARG_TIMESTAMP, ARG_LEVEL))
        

    def stopMessageLog (self):
        if self.logMask:
            self.unsubscribe(self.logMask, self._logMessage)
            self.logMask = None


    def _logMessage (self, topic, message, timestamp, level):
        while len(self.logHistory) >= self.logHistorySize > None:
            del self.logHistory[0]

        self.logHistory.append((topic, message, timestamp, level))

    def getMessageLog (self, mask=None):
        if mask is None:
            return self.logHistory
        else:
            mask = mask.lower()
            return [ record for record in self.logHistory
                     if fnmatch.fnmatchcase(record[0].lower(), mask) ]

    def getLastMessage (self, mask=None):
        log = self.getMesssageLog(mask)
        try:
            return log[-1]
        except IndexError:
            return None



    ####################################################################
    ### The following are convenience methods to handle subscriptions
    ### to sensor values.

    def addSensors (self, topic, sensornames=(), historySize=256):
        if not topic in self.sensors:
            self.sensors[topic] = (historySize, sensornames, {})
            self.subscribe(topic, self._processSensor, withTimestamp=True, decompose=True)


    def _processSensor (self, topic, timestamp, **valuemap):
        histsize, sensors, history = self.sensors[topic]

        for key, value in valuemap.items():
            if key in sensors:
                try:
                    values = [ eval(v) for v in valuestring.split(',') ]
                except:
                    warning('Invalid value for topic "%s", sensor "%s": "%s"'%
                            (name, key, valuestring))
                    return

                records = history.setdefault(key, [])
                if len(records) >= histsize:
                    del records[0]
                records.append((timestamp, values))

                    

    def getSensorHistory (self, topic, key=None):
        (histSize, sensors, history) = self.sensors.get(topic, (0, {}))

        if key is None:
            return history
        else:
            return history.get(key, [])


    def getSensorValue (self, topic, key, index=None):
        history = self.getSensorHistory(topic, key)
        values  = history[-1]
        if index is not None:
            return values[index]
        else:
            return values


    def _initStateNames (self):
        if not self.states:
            self.states = {}
            self.subscribe("State", self._processState, withTimestamp=True, decompose=True)
            status, states, opts = self.sendReceive('STATe*', decompose=True)
            for name in states:
                self.states[name.lower()] = (name, None)
            

    def _initStateValues (self, states=None):
        missing = []
        for name in states or self.getStateNames():
            name, value = self.states.get(name.lower(), (name, None))
            if value is None:
                missing.append(name)

        if missing:
            command = [ "STATe?", ("named", True) ] + missing
            status, outputs, states = self.sendReceive(command, decompose=True)
            self._processState(None, None, **states)



    def _processState (self, topic, timestamp, **states):
        for name, value in states.iteritems():
            if value in ("True", "False", "Error"):
                Error = Exception
                value = eval(value)
                self.states[name.lower()] = (name, value)

                if topic is not None:
                    for listenerkey in (None, name):
                        for listener, withTimestamp in self.stateListeners.get(listenerkey, []):
                            args = [name, value]
                            if withTimestamp:
                                if timestamp is None:
                                    timestamp = time.time()
                                args.append(timestamp)
                            safeInvoke(listener, args)
            else:
                warning("Invalid state value received on topic %r: -%s=%r"%(topic, name, value))
                            

    def getStateNames (self):
        self._initStateNames()
        return [ name for (name, value) in self.states.values() ]


    def getStateValues (self, *states):
        self._initStateNames()
        self._initStateValues(states)

        if not states:
            values = self.states.values()
        else:
            values = [ self.states[name.lower()] for name in states ]

        return dict(values)


    def getStateValue (self, name, ignoreMissing=False):
        self._initStateNames()
        self._initStateValues((name,))
        name, value = self.states[name.lower()]
        return value
        

    def addStateListener (self, callback, states=None, withTimestamp=False):
        if self.states is None:
            self._initStateNames()

        if not isinstance(states, (tuple, list)):
            states = [states]

        for state in states:
            self.stateListeners.setdefault(state, []).append((callback, withTimestamp))


    def removeStateListener (self, callback):
        found = False


        for state, callbacks in self.stateListeners.items():
            try:
                callbacks.remove(callback)
            except ValueError:
                pass
            else:
                found = True
                if not callbacks:
                    del self.stateListeners[state]

        return found


    def decomposeParts (self, parts):
        args, opts, strings = [], {}, []

        for opt, value, raw in parts:
            if opt:
                opts[opt] = value
            else:
                args.append(value)

            strings.append(raw)

        return args, opts, "".join(strings).strip()





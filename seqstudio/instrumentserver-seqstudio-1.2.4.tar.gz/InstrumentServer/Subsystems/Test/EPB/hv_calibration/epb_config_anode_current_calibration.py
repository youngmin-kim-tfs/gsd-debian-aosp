# -*- coding: utf-8 -*-
"""
Created on Sat Aug 27 15:41:28 2016

@author: habersmn
"""
import epb_config_fixture as cfg

CALIBRATION_REPORT_PATH = r'S:\hv_calibration_reports_SVT\\'
CALIBRATION_REPORT_NAME_SUFFIX = 'EPB_anode_current_calibration.txt'
CALIBRATION_LOG = r'S:\hv_calibration_reports_SVT\logs\EPB_anode_current_calibration_log.csv'

SLOPE_TOLERANCE_PERCENT = 1.0
SLOPE_MIN_LIMIT = 1.0 - SLOPE_TOLERANCE_PERCENT / 100.0 
SLOPE_MAX_LIMIT = 1.0 + SLOPE_TOLERANCE_PERCENT / 100.0 

OFFSET_MIN_LIMIT_MICROAMP = -0.2 
OFFSET_MAX_LIMIT_MICROAMP = 0.2

TOLERANCE_SPEC_PERCENT = 1.0
TOLERANCE_SPEC_MICROAMP = 0.2

AVERAGING = 10
CALIBRATION_POINTS = [ 
                       [ 0.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ], # target voltage [V], test load conductance [S]
                       [ 1000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 2000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 3000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 4000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 5000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 6000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 7000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 8000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 9000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 10000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 11000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 12000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ],
                       [ 13000.0, cfg.TEST_LOAD_CONDUCTANCE_SIEMENS ]
                      ]

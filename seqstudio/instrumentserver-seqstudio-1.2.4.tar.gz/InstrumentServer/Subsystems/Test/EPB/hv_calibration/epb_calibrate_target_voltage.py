# -*- coding: utf-8 -*-
"""
Created on Tue Aug  9 09:33:13 2016

@author: habersmn
"""

import time
import csv
import os.path
import numpy as np

import epb_config_target_voltage_calibration as cfg
import epb_fixture

class ToleranceLimit(object):
    def __init__(self, low_voltage_range_max_voltage, 
                       low_voltage_range_spec_limit,
                       high_voltage_range_spec_limit):
        self.low_voltage_range_max_voltage = low_voltage_range_max_voltage
        self.low_voltage_range_spec_limit = low_voltage_range_spec_limit
        self.high_voltage_range_spec_limit = high_voltage_range_spec_limit
        
    def minimum(self, standard):
        if standard <= self.low_voltage_range_max_voltage:
            limit = self.low_voltage_range_spec_limit
        else:
            limit = self.high_voltage_range_spec_limit
        return standard - limit
        
    def maximum(self, standard):
        if standard <= self.low_voltage_range_max_voltage:
            limit = self.low_voltage_range_spec_limit
        else:
            limit = self.high_voltage_range_spec_limit
        return standard + limit
        
    def test_within_limits(self, value, standard):
        return (value >= self.minimum(standard)) and (value <= self.maximum(standard))

    def error(self, value, standard):
        return value - standard
        
class CalibrationPoint(object):
    def __init__(self, uut_target_voltage, limit):
        self.test_condition = uut_target_voltage
        self.standard_measurement = None
        self.limit = limit     
        
    def measure(self, fixture):
        fixture.set_target_voltage(self.test_condition)
        fixture.turn_on_hv()
        standard_voltage = []
        for i in xrange(cfg.AVERAGING):
            standard_voltage.append(fixture.get_standard_voltage())
        self.standard_measurement = sum(standard_voltage) / cfg.AVERAGING
        fixture.turn_off_hv()

    def uut_calibrated_target(self, calibration_coefficients ):
        poly = np.polynomial.Polynomial(calibration_coefficients.coefficients) - np.polynomial.Polynomial([self.test_condition])
        roots = poly.roots()
        roots = roots.real[np.abs(roots.imag) < 1e-10] # filter complex roots 
        if len(roots) >= 1:
            return roots[ np.argmin(np.abs(roots-self.test_condition)) ] # choose root closest to expected 
        else:
            return float('nan')
                
    def test_within_limits(self, calibration_coefficients ):
        return self.limit.test_within_limits(self.uut_calibrated_target(calibration_coefficients), self.standard_measurement)
                
    def error(self, calibration_coefficients):
        return self.limit.error(self.uut_calibrated_target(calibration_coefficients), self.standard_measurement)

    def csv_header(self):
        return ['target [V]',
                'calibrated target [V]',
                'standard voltage [V]', 
                'error [V]',
                'lower limit [V]',
                'upper limit [V]', 
                'result']

    def csv_data(self, calibration_coefficients):
        uut_calibrated_target = self.uut_calibrated_target(calibration_coefficients)       
        err = self.limit.error(uut_calibrated_target, self.standard_measurement )
        return [ self.test_condition, # target [V]
                 uut_calibrated_target, # calibrated target [V]
                 self.standard_measurement, # standard voltage [V]
                 err, # error [V]
                 self.limit.minimum(self.standard_measurement), # lower limit [V]
                 self.limit.maximum(self.standard_measurement), # upper limit [V] 
                 self.limit.test_within_limits(uut_calibrated_target, self.standard_measurement) and "pass" or "fail" # result 
               ]    
    def report_measurement_header(self):    
        return " target | standard voltage"

    def report_measurement(self):
        return "%5.0f V |%6.0f V"%(self.test_condition, self.standard_measurement)
    
    def report_result_header(self):    
        return " target | calibrated target | standard voltage |   error | lower limit | upper limit | result"
    
    def report_result(self, calibration_coefficients):
        uut_calibrated_target = self.uut_calibrated_target(calibration_coefficients)       
        err = self.limit.error(uut_calibrated_target, self.standard_measurement )
        return "%5.0f V |%16.0f V |%15.0f V |%6.0f V |%10.0f V | %9.0f V | %6s"%(
            self.test_condition,            
            uut_calibrated_target,            
            self.standard_measurement,
            err,
            self.limit.minimum(self.standard_measurement),
            self.limit.maximum(self.standard_measurement),
            self.limit.test_within_limits(uut_calibrated_target, self.standard_measurement) and "pass" or "fail")  

class CalibrationCoefficients(object):
    def __init__(self, calibration_points = None):
        if calibration_points:
            self.fit_calibration_points(calibration_points)    
        else: self.coefficients = [0.0, 1.0, 0.0, 0.0] 
        
    def fit_calibration_points(self, calibration_points):
        y = [cp.test_condition for cp in calibration_points]
        x = [cp.standard_measurement for cp in calibration_points]
        self.coefficients = np.polynomial.Polynomial.fit(x,y, deg=3, domain=[]).coef
        
    def margin_to_limit(self):
        v_correction_poly = np.polynomial.Polynomial(self.coefficients) - np.polynomial.polynomial.polyx
        v_target = np.linspace(cfg.MIN_VOLTAGE, cfg.MAX_VOLTAGE, num=1000)
        v_margin = cfg.CALIBRATION_POLYNOMIAL_LIMIT_ABSOLUTE + v_target * cfg.CALIBRATION_POLYNOMIAL_LIMIT_PERCENT * 0.01 - np.abs(v_correction_poly(v_target))
        lowest_margin = v_margin.argmin()
        return v_margin[lowest_margin], v_target[lowest_margin]

    def is_within_limits(self):
       return self.margin_to_limit()[0] >= 0.0

    def csv_header(self):
        return ['A0', 'A1', 'A2', 'A3', 'margin [V]', '@voltage', 'limit absolute', 'limit percent', 'result' ]

    def csv_data(self):
        return ( list(self.coefficients)
                 + list(self.margin_to_limit())
                 + [ cfg.CALIBRATION_POLYNOMIAL_LIMIT_ABSOLUTE, 
                     cfg.CALIBRATION_POLYNOMIAL_LIMIT_PERCENT ]
                 + [ self.is_within_limits() and 'passed' or 'failed' ] )

    def print_report(self, file=None):
        print >> file, "Calibration coefficients:"
        print >> file, "   [A0, A1, A2, A3] = [%r, %r, %r, %r]"%tuple(self.coefficients)     
        print >> file, "Test Limits:"
        print >> file, "   Deviation from nominal voltage less than %0.1f%% of target voltage + %.1fV"%(cfg.CALIBRATION_POLYNOMIAL_LIMIT_PERCENT, cfg.CALIBRATION_POLYNOMIAL_LIMIT_ABSOLUTE)
        print >> file, "Margin to test limit: %.1fV at %.1fV"%self.margin_to_limit()
        if self.is_within_limits():
            print >> file, 'Passed. Calibration coefficients meet test limits.'
        else:
            print >> file, 'Failed. Calibration coefficients do NOT meet test limits.'
        
    def __str__(self):
        return "[A0, A1, A2, A3] = [%r, %r, %r, %r]"%tuple(self.coefficients)

class Calibration(object):
    def __init__(self, fixture):
        self.fixture = fixture
        self.limit = ToleranceLimit(cfg.LOW_VOLTAGE_RANGE_MAX_VOLT,
                                    cfg.TOLERANCE_SPEC_LOW_VOLTAGE_RANGE_VOLT,
                                    cfg.TOLERANCE_SPEC_HIGH_VOLTAGE_RANGE_VOLT)
        self.calibration_points = [CalibrationPoint(V, self.limit) for V in cfg.CALIBRATION_POINTS]
        self.calibration_coefficients = CalibrationCoefficients()    
        
        self.calibration_coefficients_committed = False        
        
        self.execute()

    def execute(self):
            print "--- EPB Target Voltage Calibation ---"
            self.update_metadata()
            if self.serial_number:
                self.print_metadata()
                self.fixture.get_standard_voltage() # dummy read to configure for current measurements
                self.measure()
                self.fit_calibration_coefficients()
                self.print_calibration_coefficients()
                self.print_calibrated_data()
                self.print_pass_fail()
                self.commit_calibration_coefficients()
                self.write_calibration_report()
                self.append_csv_log()
            else:
                print                
                print 'Serial number of EPB not set. Please set serial number before calibrating.'

    def measure(self):
        print    
        print "Collecting calibration data:"
        print self.calibration_points[0].report_measurement_header()
        for calibration_point in self.calibration_points:
            calibration_point.measure(self.fixture)
            print calibration_point.report_measurement()

    def fit_calibration_coefficients(self):
        self.calibration_coefficients.fit_calibration_points(self.calibration_points)

    def print_calibration_coefficients(self, file=None):
        print >> file
        print >> file, "Fitted calibration coefficients:"
        self.calibration_coefficients.print_report(file)

    def print_calibrated_data(self, file=None):
        print >> file 
        print >> file, "Calibrated data:"
        print >> file, self.calibration_points[0].report_result_header()
        for calibration_point in self.calibration_points:
            print >> file, calibration_point.report_result(self.calibration_coefficients)

    def has_passed(self):
            passed = True
            passed = passed and all([ cp.test_within_limits(self.calibration_coefficients) for cp in self.calibration_points])
            passed = passed and self.calibration_coefficients.is_within_limits()
            return passed 
        
    def print_pass_fail(self, file=None):
        print >> file 
        if self.has_passed():
            print >> file, "Calibration PASSED."
        else:
            print >> file, "Calibration FAILED."
             
    def commit_calibration_coefficients(self):
        print
        answer = None
        while not answer in ['y', 'n']:
            answer = raw_input('> Accept calibration? [y/n] ').lower()
        print 
        if answer == 'y':
            print "Committing calibration coefficients ..."
            self.fixture.commit_target_voltage_calibration_coefficients(self.calibration_coefficients.coefficients)
            print "Calibration coefficients committed to EPB."
            self.calibration_coefficients_committed = True
        else:
            print "Calibration coefficients discarded."
            self.calibration_coefficients_committed = False
     
    def update_metadata(self, file=None):
        self.hv_type = self.fixture.get_hv_type()
        self.firmware_version = self.fixture.get_firmware_version()
        self.bootloader_version = self.fixture.get_bootloader_version()
        self.hardware_version = self.fixture.get_hardware_version()
        self.serial_number = self.fixture.get_serial_number()
        self.calibration_date = time.localtime()

    def print_metadata(self, file=None):
        print >> file
        print >> file, 'EPB serial number:   %d'%self.serial_number
        print >> file, 'Firmware version:    0x%x'%self.firmware_version
        print >> file, 'Bootloader version:  0x%x'%self.bootloader_version
        print >> file, 'Hardware version:    0x%x'%self.hardware_version
        print >> file, 'High voltage supply: %s (%d)'%(self.hv_type[1], self.hv_type[0])
        print >> file, 'Calibration date:    %s'%time.strftime('%d %B %Y, %I:%M:%S %p',self.calibration_date)
        print >> file, 'Averaging:           %d readings'%cfg.AVERAGING
    
    def write_calibration_report(self):
        filename = time.strftime('%Y-%m-%d-%H-%M-%S',self.calibration_date) + '-SN%d'%self.serial_number + '-' + cfg.CALIBRATION_REPORT_NAME_SUFFIX 
        with open(cfg.CALIBRATION_REPORT_PATH+filename, 'w') as f:
            print >> f, 'EPB Target Voltage Calibration Report'
            print >> f, '=============================================='
            self.print_pass_fail(f)
            self.print_metadata(f)
            self.print_calibration_coefficients(f)
            print >> f
            if self.calibration_coefficients_committed:
                print >> f, 'Calibration coefficients committed to NVRAM.'
            else:            
                print >> f, 'Calibration coefficients not committed to NVRAM.'            
            self.print_calibrated_data(f)  
        print 
        print 'Calibration report written: %s'%(cfg.CALIBRATION_REPORT_PATH+filename)            

    def append_csv_log(self):
        header = [ 'Calibration Date', 
                   'Result',
                   'Serial Number', 
                   'FW Version', 
                   'Bootloader Version', 
                   'Hardware Version', 
                   'High Voltage Supply Type', 
                   'High Voltage Supply Model' ]
        header += self.calibration_coefficients.csv_header()
        header += [ 'Committed to NVRAM',
                    'Averaging']
                    
        data = [time.strftime('%Y-%m-%d %H:%M:%S',self.calibration_date),
                self.has_passed() and 'passed' or 'failed',
                self.serial_number,
                self.firmware_version,
                self.bootloader_version,
                self.hardware_version,
                self.hv_type[0],
                self.hv_type[1] ]
        data += self.calibration_coefficients.csv_data()
        data += [ self.calibration_coefficients_committed and 'yes' or 'no',
                  cfg.AVERAGING]
                
        for cp in self.calibration_points:
            header.append('-->')
            data.append('-->')            
            header += cp.csv_header()
            data += cp.csv_data(self.calibration_coefficients)

        exists = os.path.exists(cfg.CALIBRATION_LOG)
        with open(cfg.CALIBRATION_LOG, 'ab') as csvfile:
            writer = csv.writer(csvfile)
            if not exists:
                writer.writerow(header)
            writer.writerow(data)
            
        if exists:
            print 'Calibration log appended: %s'%cfg.CALIBRATION_LOG
        else:
            print 'Calibration log created: %s'%cfg.CALIBRATION_LOG
                     
if __name__ == '__main__':
    Calibration(epb_fixture.fixture_init()) 

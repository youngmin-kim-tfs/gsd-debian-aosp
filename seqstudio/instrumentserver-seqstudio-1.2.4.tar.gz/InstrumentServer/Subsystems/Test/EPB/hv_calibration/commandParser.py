########################################################################
### FILE:	commandParser.py
### PURPOSE:	Superclass for input parsers
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

import re, math, sys, time
from socket import error as SocketError

########################################################################
### ParseError exception class
### Raised if there was a problem parsing the text.
########################################################################


class ParseError (Exception):
    def __init__ (self, expression, pos, explanation, error=None):
        self.expression  = expression
        self.pos         = pos
        self.explanation = explanation
        self.error       = error

    def __str__ (self):
        return '%s <-- %s'%(self.expression[:self.pos].rstrip(), self.explanation)






########################################################################
### CommandParser class
### Used to parse command line input.
########################################################################

TOKENS = (SPACE, BACKSLASH, SUBEXPRESSION, SUB_END, HIDDEN, HIDDEN_END,
          ARGUMENT, OPTION, EQUALSIGN, SINGLEQUOTE, DOUBLEQUOTE,
          
          LITERAL, LITERALXML) = \
         ('space', 'backslash', 'subexpression', 'sub_end', 'hidden', 'hidden_end',
          'argument', 'option', 'equalsign', 'singlequote', 'doublequote',
          
          'literal', 'literalxml')


_unescaped  = r'(?<!\\)(?:\\\\)*'

_tokens     = {
    SPACE         : r'(?:^|\s+)\#.*|\s+',
    BACKSLASH     : r'\\',
    SUBEXPRESSION : r'\$?[\{\[\(]',
    SUB_END       : r'[\}\]\)]',
    HIDDEN        : r'\$\<',
    HIDDEN_END    : r'\>',
    ARGUMENT      : r'\$(\d+|[@,/])',
#    OPTION        : r'(?<=\s)\-(?=[a-zA-Z\-\.\:\_\$])',  ### "$" excluded to allow "-${value}" 
    OPTION        : r'(?<=\s)\-+(?=[a-zA-Z\.\:\_])',
    EQUALSIGN     : r'\=',
    SINGLEQUOTE   : r"\'",
    DOUBLEQUOTE   : r'\"',
    LITERAL       : r'\<\<\<|\>\>\>',
    LITERALXML    : r'\</?\w[\w\.]*[^\<\/\>]*\>' }


_endTokens = {
    '${' : '}',
    '$[' : ']',
    '$(' : ')',
    '{'  : '}',
    '['  : ']',
    '('  : ')' }


_literalXmlX  = re.compile(r'\<(/?)\s*(\w[\w\.]*)[^\/\>]*\>')
_literalX     = re.compile(r'(\<|\>)\1\1()')
_eolX         = re.compile(r'\s*(?:\n|$)')

#_protectTags  = re.compile(r'(?P<binary>[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F])|'
#                           r'(?P<quote>(\n(?=.)))')

_protectTags  = re.compile(r'(?P<binary>[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F])|'
                           r'(?P<quote>(\n))')



#                           r'(?P<quote>([\r\n]|\<[^\>]*\>))')
#                           r'(?P<quote>(\n|\<[^\>]*\>|\$[\[\(\{].*))')
#                           r'(?P<space>^[^"\x27].*\s.*[^"\x27]$)')


#_protectEscapes = re.compile(r'[\x00-\x20\x7F-\xA0\$\(\)\<\>\[\]\{\}\'\"\\]|^$')
_protectEscapes = re.compile(r'[\x00-\x20\x7F-\xA0\$\(\)\<\>\'\"\\]|^$')

#_protectSpace = re.compile(r'[\s\'\"\\]')
#_quoteX = re.compile(r'[\x00-\x09\x0B-\x20\x7F-\xA0\'\"\\]|\n(?=.)'
#_protectSpace = re.compile(r'[^\'\"]*\s[^\'\"]$')


PartFields = (OptionName, CookedValue, RawValue) = range(3)


def _tokenSearch (*tokens):
    groups = [r'(?P<%s>%s)'%(t, _tokens[t]) for t in tokens]
    return re.compile("|".join(groups))
#    return re.compile("%s%s"%(_unescaped, '|'.join(groups)))


class CommandParser (object):

    class Option (Exception): pass      # Raised if the argument is "named"

    def __init__ (self):
        self.expansions = {
            '$()' : self._getCommandOutput,
            '${}' : self._getVariable,
            '$[]' : self._getEvaluationResult,
            }



    #######################################################################
    ### "Public" methods


    def expandArgs (self, input, **argmap):
        '''
        Parse the supplied text into a tuple of individual arguments.
        Various substitutions are performed.  ### FIXME: DOC TBD. ###
        '''

        if isinstance(input, basestring):
            text, instream = input, None
        elif input:
            text, instream = self._readLine(input), input
        else:
            text, instream = "", None

        parts   = []
        last    = 0
        option, value, text, pos = self.getArg(text, 0, instream, **argmap)

        while (option, value) != (None, None):
            parts.append((option, value, text[last:pos]))
            last = pos
            option, value, text, pos = self.getArg(text, pos, instream, **argmap)

        return text, parts


    def expandValue (self, rawtext, **argmap):
        option, value, text, pos = self.getArg(rawtext, 0, **argmap)
        return value


    _argX = _tokenSearch(BACKSLASH, SUBEXPRESSION, SUB_END,
                         HIDDEN, ARGUMENT,
                         OPTION, SINGLEQUOTE, DOUBLEQUOTE,
                         LITERAL, LITERALXML, SPACE)


    def getArg (self, text, pos, instream=None, **argmap):
        '''
        Obtain one argument starting at position "pos" in the supplied
        text string.  A two-element tuple is returned:
         - If the argument is of the form "-option=value", the first
           element is "option", and the second is "value".

         - If the argument is of the form "-option", the first
           element is "option", and the second is None.

         - Otherwise, the first element is None, and the second
           is the argument.
        '''
        
        try:
            arg, text, pos, endtoken = \
                 self._expandText(text, pos, instream, self._argX,
                                  expansions=self.expansions,
                                  argmap=argmap,
                                  skip=(SPACE, ),
                                  end=(SPACE, ))
            return None, arg, text, pos


        except self.Option, e:
            return e.args


#    _textX = _tokenSearch(BACKSLASH, SUBEXPRESSION, SUB_END,
#                          HIDDEN, ARGUMENT)

###                          LITERAL, LITERALXML)
    ### TODO: Check whether the last two should be removed

#    def expandText (self, text, **argmap):
#        '''
#        Perform backslash substitutions and "$" expansions in the
#        supplied text, and return the result.
#        '''
#        arg, text, pos, end = self._expandText(text, 0, None, self._textX,
#                                               expansions=self.expansions,
#                                               argmap=argmap)
#
#        assert pos == len(text), \
#               'pos=%d, len(text)=%d'%(pos, len(text))
#
#        return arg



    def collapseParts (self, parts=(), tag='', quoted='auto'):
        args = []
        for part in parts:
            if isinstance(part, (tuple, list)):
                opt, raw = part[:2]
            else:
                opt, raw = None, part

            if raw is not None:
                arg  = self.protectString(str(raw), tag, quoted)
                item = '='.join(filter(None, (opt and '-'+opt, arg)))
                args.append(item)

            elif opt:
                args.append('-'+opt)

        return args
    
        
    def collapseArgs (self, parts=(), tag='', quoted='auto', separator=' '):
        return separator.join(self.collapseParts(parts, tag, quoted))




    ########################################################################
    ### Methods to provide substituted text for $(), ${}, and $[] expressions

    def _getInputArgument (self, arg, **kwargs):
        '''
        Return a substitution for $1, $2... arguments.
        '''
        raise NotImplementedError, \
              '%s._getInputArgument(%r)'%(self.__class__.__name__, command)
              

    def _getCommandOutput (self, command, **kwargs):
        '''
        Execute "text" as a command, and return the reply value.
        '''
        raise NotImplementedError, \
              '%s._getCommandOutput(%r)'%(self.__class__.__name__, command)


    def _getVariable (self, name, **kwargs):
        '''
        Obtain the value of the variable "name".
        '''
        raise NotImplementedError, \
              '%s._getVariable(%r)'%(self.__class__.__name__, name)


    def _getEvaluationResult (self, expression, **kwargs):
        '''
        Evaluate "expression" natively in Python, and return the result.
        '''
        raise NotImplementedError, \
              '%s._getEvaluationResult(%r)'%(self.__class__.__name__, expression)





    ########################################################################
    ### Processing of whitespace

    def _process_space (self, start, text, pos, instream, expansions, argmap):
        return None, text, pos


    ########################################################################
    ### Processing of the equal sign

    def _process_equalsign (self, start, text, pos, instream, expansions, argmap):
        return None, text, pos


    ########################################################################
    ### Processing of the backslash ('\') character

    def _process_backslash (self, start, text, pos, instream, expansions, argmap):
        eolMatch = _eolX.match(text, pos)
        if eolMatch:
            pos = eolMatch.end()

            if len(text) == pos:
                try:
                    text += self._readLine(instream)
                except EOFError:
                    raise ParseError(text, None,
                                     'End of input while reading extended line')

            return None, text, pos
        else:
            return self._unescape(text, pos)



    ########################################################################
    ### Processing of "-option[=value]" subexpressions

    _optX = _tokenSearch(BACKSLASH, SUBEXPRESSION, SUB_END, ARGUMENT,
                         SINGLEQUOTE, DOUBLEQUOTE, SPACE, EQUALSIGN,
                         LITERAL, LITERALXML)

    _optArgX = _tokenSearch(BACKSLASH, SUBEXPRESSION, SUB_END,
                            HIDDEN, ARGUMENT,
                            SINGLEQUOTE, DOUBLEQUOTE, SPACE,
                            LITERAL, LITERALXML)

    def _process_option (self, start, text, pos, instream, expansions, argmap):
        option, text, pos, equalsign = \
                self._expandText(text, pos, instream, self._optX,
                                 expansions=expansions,
                                 argmap=argmap,
                                 end=(SPACE, EQUALSIGN))

        if equalsign == '=':
            arg, text, pos, endtoken = \
                 self._expandText(text, pos, instream, self._optArgX,
                                  expansions=expansions,
                                  argmap=argmap,
                                  end=(SPACE,))
        else:
            arg = ""

        raise self.Option(option, arg, text, pos)



    ########################################################################
    ### Processing of "$..." subexpressions

    _subX = _tokenSearch(BACKSLASH, SUBEXPRESSION, SUB_END, ARGUMENT)
    

    def _process_subexpression (self, start, text, pos, instream, expansions, argmap):
        arg, text, pos, end = self._expandText(text, pos, instream,
                                               self._subX,
                                               expansions=expansions,
                                               argmap=argmap,
                                               end=(SUB_END,))

        if end != _endTokens[start]:
            raise ParseError(text, pos, 'Expected %r, not %r'%(_endTokens[start], end))

        else:
            try:
                method = expansions[start+end]

            except KeyError:
                arg = arg.join((start, end))

            else:
                try:
                    arg = str(method(arg, **argmap))

                except NotImplementedError:
                    arg = arg.join((start, end))

                except RuntimeError:
                    raise

                except Exception, e:
                    raw = arg.join((start, end))
                    raise ParseError(raw, len(raw), str(e), e)

        return arg, text, pos


    def _process_sub_end (self, start, text, pos, instream, expansions, argmap):
        raise ParseError(text, pos, 'Mismatched %r'%start)



    _hiddenX = _tokenSearch(BACKSLASH, HIDDEN_END)

    def _process_hidden (self, start, text, pos, instream, expansions, argmap):
        startpos = pos
        arg, text, pos, end = self._expandText(text, pos, instream,
                                               self._hiddenX,
                                               expansions=expansions,
                                               argmap=argmap,
                                               end=(HIDDEN_END,))


#        replacement = '.'*len(arg)
        replacement = '*'
        text = text[:startpos] + replacement + end + text[pos:]
        pos  = startpos + len(replacement) + len(end)
        return arg, text, pos



    def _process_argument (self, start, text, pos, instream, expansions, argmap):
        if expansions:
            return self._getInputArgument(start[1:], **argmap), text, pos
        else:
            return start, text, pos

    
    ########################################################################
    ### Processing of quoted subexpressions

    _sqX = _tokenSearch(SINGLEQUOTE)

    def _process_singlequote (self, start, text, pos, instream, expansions, argmap):
        arg, text, pos, end = self._expandText(text, pos, instream,
                                               self._sqX,
                                               expansions=expansions,
                                               argmap=argmap,
                                               end=(SINGLEQUOTE,))
        if end != "'":
            raise ParseError(text, pos, 'Missing quote character (\')')

        return arg, text, pos


    _dqX = _tokenSearch(DOUBLEQUOTE, BACKSLASH, SUBEXPRESSION, ARGUMENT)

    def _process_doublequote (self, start, text, pos, instream, expansions, argmap):
        arg, text, pos, end = self._expandText(text, pos, instream,
                                               self._dqX,
                                               expansions=expansions,
                                               argmap=argmap,
                                               end=(DOUBLEQUOTE,))

        if end != '"':
            raise ParseError(text, pos, 'Missing quote character (")')

        return arg, text, pos



    ########################################################################
    ### Procssing of <quote<literal text>quote>

    def _process_literal (self, start, text, pos, instream, expansions, argmap, reX=_literalX, reEnd='>'):
        tagtype, tag = reX.search(start).groups()

        if tagtype == reEnd:
            raise ParseError(text, pos, 'Mismatched quotation tag: %s'%start)

        balance  = 1
        lines    = [ text ]
        startpos = pos

        while balance > 0:
            match = reX.search(text, pos)
            while match:
                if match.group(2) == tag:
                    balance += (1, -1)[match.group(1) == reEnd]
                    if balance == 0:
                        break

                match = reX.search(text, match.end())

            else:
                try:
                    text = self._readLine(instream)
                    pos  = 0
                    lines.append(text)
                except EOFError:
                    raise ParseError(''.join(lines), None,
                                     'End of input reached within literal quotation (%s)'%start)


        text      = ''.join(lines)
        linestart = len(text) - len(lines[-1])
        arg       = text[startpos:linestart+match.start()]
        pos       = linestart + match.end()

        return arg, text, pos
                



    ########################################################################
    ### Processing of <quote>literal text</quote>


    def _process_literalxml (self, start, text, pos, instream, expansions, argmap):
        return self._process_literal(start, text, pos, instream, expansions, argmap,
                                     reX=_literalXmlX, reEnd='/')
    



    def _process_literal_experimental (self, start, text, pos, instream, expansions, argmap):

        slash, tag = _literalXmlX.match(start).groups()
        if slash:
            raise ParseError(text, pos, 'Mismatched quotation tag: %s'%start)

        lines    = [ text ]
        opentag  = '<%s>'%tag
        closetag = '</%s>'%tag
        subtext  = text[pos:]
        balance  = 1 + subtext.count(opentag) - subtext.count(closetag)
        startpos = pos

        try:
            while balance > 0:
                text     = self._readLine(instream)
                balance += text.count(opentag) - text.count(closetag)
                lines.append(text)

        except EOFError:
            raise ParseError(''.join(lines), None,
                             'End of input reached within literal quotation %s'%opentag)
            
        if balance < 0:
            raise ParseError(text, text.rindex(closetag),
                             'Mismatched quoatation tag: %s'%closetag)


        text  = ''.join(lines)
        pos   = text.rindex(closetag)
        arg   = text[startpos:pos]
        pos  += len(closetag)

        return arg, text, pos



    matchMethods = {
        SPACE         : _process_space,
        BACKSLASH     : _process_backslash,
        SUBEXPRESSION : _process_subexpression,
        SUB_END       : _process_sub_end,
        HIDDEN        : _process_hidden,
        ARGUMENT      : _process_argument,
        OPTION        : _process_option,
        SINGLEQUOTE   : _process_singlequote,
        DOUBLEQUOTE   : _process_doublequote,
        EQUALSIGN     : _process_equalsign,
        LITERAL       : _process_literal,
        LITERALXML    : _process_literalxml }


    def _expandText (self, text, pos, instream, regexp, expansions, argmap={}, skip=(), end=()):
        parts   = []
        token   = None

        while pos < len(text):
            match   = regexp.search(text, pos)
            if not match:
                parts.append(text[pos:])
                pos = len(text)
                break
            
            index = match.lastindex
            group = match.lastgroup
            token = match.group(index)
            start = match.start(index)
            intro = text[pos:start]
            pos   = match.end(index)

            if intro:
                parts.append(intro)

            elif not parts and group in skip:
                continue

            if group in end:
                parts.append('')
                break

            else:
                method = self.matchMethods[group]
                arg, text, pos = method(self, token, text, pos, instream, expansions, argmap)
                if arg is not None:
                    parts.append(arg)


        if parts:
            arg = ''.join(map(str, parts))
        else:
            arg = None

        return arg, text, pos, token

        
    _escapeChars   = re.compile('(\\n)|(\\r)|(\\t)|(\')|(")|(\\$)|(\\\\)|(\x00-x1F\x7F-xAF)')
    _escapes       = (None, '\\n', '\\r', '\\t', '\\\'', '\\"', '\\$', '\\\\', None)


    def _escape (self, text, pos=0, keep=(), quote=None):
        match = self._escapeChars.search(text)
        parts = [ quote ]

        while match:
            parts.append(text[pos:match.start()])
            char   = match.group()

            if char in keep:
                esc = char

            else:
                esc = self._escapes[match.lastindex] or r'\x%02X'%ord(char)
                
            parts.append(esc)
            pos    = match.end()
            match  = self._escapeChars.search(text, pos)

        parts.append(text[pos:])
        parts.append(quote)
        return ''.join(filter(None, parts))

        

    _escapeX      = re.compile(r'[0-7]{3}|x[0-9a-fA-F]{2}|[0abnfrtv]')

    def _unescape (self, text, pos):
        match = self._escapeX.match(text, pos)
        if match:
            return eval('"\\%s"'%match.group()), text, match.end()
        else:
            return text[pos], text, pos+1


    _protectX = _tokenSearch(SINGLEQUOTE, DOUBLEQUOTE, BACKSLASH, SPACE)


    def protectString (self, text, tag=None, quoted=None, escaped=None):
        tagPrefix = None
#        line      = text.rstrip('\r\n')

        if tag is not None:
            match = _protectTags.search(text)
            if match:
                tagPrefix = match.lastgroup


        if tagPrefix:
            if tag:
                basetag = "%s.%s"%(tagPrefix, tag)
                idx     = 0
                while basetag in text:
                    idx += 1
                    basetag = "%s.%s%d"%(tagPrefix, tag, idx)

                opentag  = "<%s>%s"%(basetag,
                                     ("\n", "")[text.startswith("\n")])
                closetag = "</%s>"%(basetag,)


            else:
                opentag = "<<<"
                closetag = ">>>"
                for tag in opentag, closetag:
                    parts = text.split(tag)
                    glue = '>>>"%s"<<<'%(tag,)
                    text = glue.join(parts)

            return text.join((opentag, closetag))

#            if tagPrefix == 'binary':
#                opentag  = '<%s size=%d>'%(opentag, len(text))
#                closetag = '</%s>'%closetag
#            else:
#                opentag = '<%s>\n'%opentag
#                closetag = '</%s>'%closetag
#            return text.join((opentag, closetag))


        elif (escaped or (quoted is not False)) and _protectEscapes.search(text):
            if quoted is False:
                keep  = ()
                quote = None

            elif quoted is True:
                keep  = ("'",)
                quote = '"'

            elif text[:1] == text[-1:] == '"':
                keep  = ('"', "'")
                quote = None

            else:
                keep  = ("'",)
                quote = '"'

            return self._escape(text, keep=keep, quote=quote)


        elif quoted is True:
            return '"%s"'%text

        else:
            return text


    def _readLine (self, instream):
        try:
            text = instream.readline()
        except AttributeError:
            raise EOFError
        except SocketError:
            raise EOFError
        else:
            if not text:
                raise EOFError

        return text
    

# -*- coding: utf-8 -*-
"""
Created on Tue Aug  9 09:33:13 2016

@author: habersmn
"""

import time
import csv
import os.path

import epb_config_anode_current_calibration as cfg
import epb_fixture

class ToleranceLimit(object):
    def __init__(self, proportional, absolute):
        self.proportional = proportional
        self.absolute = absolute
        
    def minimum(self, standard):
        return standard - abs(standard * self.proportional) - abs(self.absolute)
        
    def maximum(self, standard):
        return standard + abs(standard * self.proportional) + abs(self.absolute)
        
    def test_within_limits(self, value, standard):
        return (value >= self.minimum(standard)) and (value <= self.maximum(standard))

    def error(self, value, standard):
        error = value - standard
        abs_error = abs(error)
        if abs_error <= self.absolute:
            absolute = abs_error
            proportional = 0.0
        else:
            absolute = self.absolute
            try:            
                proportional = (abs_error - absolute) / abs(standard)
            except ZeroDivisionError:
                proportional = float('inf')
        if error < 0.0:
            absolute *= -1.0
            proportional *= -1.0                 
        return error, proportional, absolute
        
class CalibrationPoint(object):
    def __init__(self, uut_target_voltage, test_load_conductance, limit):
        self.test_conditions = [uut_target_voltage, test_load_conductance]
        self.uut_measurement = None
        self.standard_measurement = None
        self.limit = limit        
    def measure(self, fixture):
        fixture.set_target_voltage(self.test_conditions[0])
        fixture.set_test_load_conductance(self.test_conditions[1])
        fixture.turn_on_hv()
        uut_current = []
        standard_current = []
        for i in xrange(cfg.AVERAGING):
            uut_current.append(fixture.get_uut_anode_current())
            standard_current.append(fixture.get_standard_anode_current())
        self.uut_measurement = sum(uut_current) / cfg.AVERAGING
        self.standard_measurement = sum(standard_current) / cfg.AVERAGING
        fixture.turn_off_hv()

    def uut_anode_current(self, calibration_coefficients ):
        return (self.uut_measurement * calibration_coefficients.coefficients[0]
                + calibration_coefficients.coefficients[1])
                
    def test_within_limits(self, calibration_coefficients ):
        return self.limit.test_within_limits(self.uut_anode_current(calibration_coefficients), self.standard_measurement)
                
    def error(self, calibration_coefficients):
        return self.limit.error(self.uut_cathode_current(calibration_coefficients), self.standard_measurement)

    def csv_header(self):
        return ['target [V]',
                'test load [nS]',
                'UUT current [uA]',
                'standard current [uA]', 
                'UUT calibrated current [uA]',
                'error [uA]',
                'relative error [%]',
                'relative error [uA]',
                'lower limit [uA]',
                'upper limit [uA]', 
                'result']

    def csv_data(self, calibration_coefficients):
        uut_calibrated_anode_current = self.uut_anode_current(calibration_coefficients)       
        err, err_rel, err_abs = self.limit.error(uut_calibrated_anode_current, self.standard_measurement )
        return [ self.test_conditions[0], # target [kV]
                 self.test_conditions[1] * 1e9, # test load [nS]
                 self.uut_measurement * 1e6, # UUT current [uA]
                 self.standard_measurement * 1e6, # standard current [uA]
                 uut_calibrated_anode_current * 1e6, # UUT calibrated current [uA]
                 err * 1e6, # error [uA]
                 err_rel * 1e2, # relative error [%]
                 err_abs * 1e6, # relative error [uA]
                 self.limit.minimum(self.standard_measurement) * 1e6, # lower limit [uA]
                 self.limit.maximum(self.standard_measurement) * 1e6, # upper limit [uA] 
                 self.limit.test_within_limits(uut_calibrated_anode_current, self.standard_measurement) and "pass" or "fail" # result 
               ]
       
    def report_measurement_header(self):    
        return " target | test load | UUT current | standard current"

    def report_measurement(self):
        return "%5.0f V |%7.2f nS |%9.3f uA |%14.3f uA"%(
                self.test_conditions[0], 
                self.test_conditions[1] * 1e9,
                self.uut_measurement * 1e6, 
                self.standard_measurement * 1e6)  
    
    def report_result_header(self):    
        return " target | test load | standard current | UUT current | UUT cal. current |       error |   relative error | lower limit | upper limit | result"
    
    def report_result(self, calibration_coefficients):
        uut_calibrated_anode_current = self.uut_anode_current(calibration_coefficients)       
        err, err_rel, err_abs = self.limit.error(uut_calibrated_anode_current, self.standard_measurement )
        return "%5.0f V |%7.2f nS |%14.3f uA |%9.3f uA | %13.3f uA |%9.3f uA | %5.1f%% %+6.3f uA |%9.3f uA | %8.3f uA | %6s"%(
            self.test_conditions[0], 
            self.test_conditions[1] * 1e9,            
            self.standard_measurement * 1e6,
            self.uut_measurement * 1e6,
            uut_calibrated_anode_current * 1e6,
            err * 1e6,
            err_rel * 1e2,
            err_abs * 1e6,
            self.limit.minimum(self.standard_measurement) * 1e6,
            self.limit.maximum(self.standard_measurement) * 1e6,
            self.limit.test_within_limits(uut_calibrated_anode_current, self.standard_measurement) and "pass" or "fail")  

class CalibrationCoefficients(object):
    def __init__(self, calibration_points = None):
        if calibration_points:
            self.fit_calibration_points(calibration_points)    
        else: self.coefficients = [1.0, 1.0, 0.0] 
        
    def fit_calibration_points(self, calibration_points):
        x = [cp.uut_measurement for cp in calibration_points]
        y = [cp.standard_measurement for cp in calibration_points]
        
        xx = [a**2 for a in x]
        xy = [a * b for a,b in zip(x,y)]
        
        ssxx = sum(xx) - sum(x)**2 / len(x)
        ssxy = sum(xy) - sum(x) * sum(y) / len(x)       
        
        if (ssxx==0.0) or (len(x)==0) or (len(y)!=len(x)):
            b, a = float('nan'), float('nan')
        else:
            b = ssxy / ssxx 
            a = ( sum(y) - b * sum(x) ) / len(y)
        
        self.coefficients = [b, a]
        
    def is_within_limits(self):
        return ( (cfg.SLOPE_MIN_LIMIT <= self.coefficients[0]) 
                 and (self.coefficients[0] <= cfg.SLOPE_MAX_LIMIT)
                 and (cfg.OFFSET_MIN_LIMIT_MICROAMP <= (self.coefficients[1] * 1e6))
                 and ((self.coefficients[1] * 1e6) <= cfg.OFFSET_MAX_LIMIT_MICROAMP) ) 

    def csv_header(self):
        return ['slope', 'limit min', 'limit max', 'offset [uA]', 'limit min [uA]', 'limit max[uA]', 'result' ]

    def csv_data(self):
        return [ self.coefficients[0], cfg.SLOPE_MIN_LIMIT, cfg.SLOPE_MAX_LIMIT, 
                 self.coefficients[1] * 1e6, cfg.OFFSET_MIN_LIMIT_MICROAMP, cfg.OFFSET_MAX_LIMIT_MICROAMP, 
                 self.is_within_limits() and 'passed' or 'failed' ]
    
    def print_report(self, file=None):
        print >> file, "Calibration coefficients:"
        print >> file, "slope = %r, offset = %r uA"%(
            self.coefficients[0],
            self.coefficients[1] * 1e6 )     
        print >> file
        print >> file, "Test Limits:"
        print >> file, "%0.3f <= slope <= %0.3f"%(cfg.SLOPE_MIN_LIMIT, cfg.SLOPE_MAX_LIMIT)
        print >> file, "%0.3f uA <= offset <= %0.3f uA"%(cfg.OFFSET_MIN_LIMIT_MICROAMP, cfg.OFFSET_MAX_LIMIT_MICROAMP)
        print >> file
        if self.is_within_limits():
            print >> file, 'Passed. Calibration coefficients meet test limits.'
        else:
            print >> file, 'Failed. Calibration coefficients do NOT meet test limits.'
        
    def __str__(self):
        return "slope = %r, offset = %r uA"%(
            self.coefficients[0],
            self.coefficients[1] * 1e6 )

class Calibration(object):
    def __init__(self, fixture):
        self.fixture = fixture
        self.limit = ToleranceLimit(cfg.TOLERANCE_SPEC_PERCENT * 1e-2,
                                    cfg.TOLERANCE_SPEC_MICROAMP * 1e-6)
        self.calibration_points = [CalibrationPoint(V,G, self.limit) for V,G in cfg.CALIBRATION_POINTS]
        self.calibration_coefficients = CalibrationCoefficients()    
        
        self.calibration_coefficients_committed = False        
        
        self.execute()

    def execute(self):
            print "--- EPB Anode Current Monitor Calibation ---"
            self.update_metadata()
            if self.serial_number:
                self.print_metadata()
                self.fixture.get_standard_anode_current() # dummy read to configure for current measurements
                self.measure()
                self.fit_calibration_coefficients()
                self.print_calibration_coefficients()
                self.print_calibrated_data()
                self.print_pass_fail()
                self.commit_calibration_coefficients()
                self.write_calibration_report()
                self.append_csv_log()
            else:
                print                
                print 'Serial number of EPB not set. Please set serial number before calibrating.'

    def measure(self):
        print    
        print "Collecting calibration data:"
        print self.calibration_points[0].report_measurement_header()
        for calibration_point in self.calibration_points:
            calibration_point.measure(self.fixture)
            print calibration_point.report_measurement()

    def fit_calibration_coefficients(self):
        self.calibration_coefficients.fit_calibration_points(self.calibration_points)

    def print_calibration_coefficients(self, file=None):
        print >> file
        print >> file, "Fitted calibration coefficients:"
        self.calibration_coefficients.print_report(file)

    def print_calibrated_data(self, file=None):
        print >> file 
        print >> file, "Calibrated data:"
        print >> file, self.calibration_points[0].report_result_header()
        for calibration_point in self.calibration_points:
            print >> file, calibration_point.report_result(self.calibration_coefficients)

    def has_passed(self):
            passed = True
            passed = passed and all([ cp.test_within_limits(self.calibration_coefficients) for cp in self.calibration_points])
            passed = passed and self.calibration_coefficients.is_within_limits()
            return passed 
            
    def print_pass_fail(self, file=None):
        print >> file 
        if self.has_passed():
            print >> file, "Calibration PASSED."
        else:
            print >> file, "Calibration FAILED."
            
    def commit_calibration_coefficients(self):
        print
        answer = None
        while not answer in ['y', 'n']:
            answer = raw_input('> Accept calibration? [y/n] ').lower()
        print 
        if answer == 'y':
            print "Committing calibration coefficients ..."
            self.fixture.commit_anode_current_calibration_coefficients(self.calibration_coefficients.coefficients)
            print "Calibration coefficients committed to EPB."
            self.calibration_coefficients_committed = True
        else:
            print "Calibration coefficients discarded."
            self.calibration_coefficients_committed = False
     
    def update_metadata(self, file=None):
        self.hv_type = self.fixture.get_hv_type()
        self.firmware_version = self.fixture.get_firmware_version()
        self.bootloader_version = self.fixture.get_bootloader_version()
        self.hardware_version = self.fixture.get_hardware_version()
        self.serial_number = self.fixture.get_serial_number()
        self.calibration_date = time.localtime()

    def print_metadata(self, file=None):
        print >> file
        print >> file, 'EPB serial number:   %d'%self.serial_number
        print >> file, 'Firmware version:    0x%x'%self.firmware_version
        print >> file, 'Bootloader version:  0x%x'%self.bootloader_version
        print >> file, 'Hardware version:    0x%x'%self.hardware_version
        print >> file, 'High voltage supply: %s (%d)'%(self.hv_type[1], self.hv_type[0])
        print >> file, 'Calibration date:    %s'%time.strftime('%d %B %Y, %I:%M:%S %p',self.calibration_date)
        print >> file, 'Averaging:           %d readings'%cfg.AVERAGING
    
    def write_calibration_report(self):
        filename = time.strftime('%Y-%m-%d-%H-%M-%S',self.calibration_date) + '-SN%d'%self.serial_number + '-' + cfg.CALIBRATION_REPORT_NAME_SUFFIX 
        with open(cfg.CALIBRATION_REPORT_PATH+filename, 'w') as f:
            print >> f, 'EPB Anode Current Monitor Calibration Report'
            print >> f, '=============================================='
            self.print_pass_fail(f)
            self.print_metadata(f)
            self.print_calibration_coefficients(f)
            print >> f
            if self.calibration_coefficients_committed:
                print >> f, 'Calibration coefficients committed to NVRAM.'
            else:            
                print >> f, 'Calibration coefficients not committed to NVRAM.'            
            self.print_calibrated_data(f)  
        print 
        print 'Calibration report written: %s'%(cfg.CALIBRATION_REPORT_PATH+filename)            

    def append_csv_log(self):
        header = [ 'Calibration Date', 
                   'Calibration Result',
                   'Serial Number', 
                   'FW Version', 
                   'Bootloader Version', 
                   'Hardware Version', 
                   'High Voltage Supply Type', 
                   'High Voltage Supply Model']
        header += self.calibration_coefficients.csv_header()
        header += [ 'Committed to NVRAM','Averaging']

        data = [time.strftime('%Y-%m-%d %H:%M:%S',self.calibration_date),
                self.has_passed() and 'passed' or 'failed',
                self.serial_number,
                self.firmware_version,
                self.bootloader_version,
                self.hardware_version,
                self.hv_type[0],
                self.hv_type[1] ]
        data += self.calibration_coefficients.csv_data()
        data += [ self.calibration_coefficients_committed and 'yes' or 'no',
                  cfg.AVERAGING]
                
        for cp in self.calibration_points:
            header.append('-->')
            data.append('-->')            
            header += cp.csv_header()
            data += cp.csv_data(self.calibration_coefficients)

        exists = os.path.exists(cfg.CALIBRATION_LOG)
        with open(cfg.CALIBRATION_LOG, 'ab') as csvfile:
            writer = csv.writer(csvfile)
            if not exists:
                writer.writerow(header)
            writer.writerow(data)
            
        if exists:
            print 'Calibration log appended: %s'%cfg.CALIBRATION_LOG
        else:
            print 'Calibration log created: %s'%cfg.CALIBRATION_LOG
                     
if __name__ == '__main__':
    Calibration(epb_fixture.fixture_init()) 
    
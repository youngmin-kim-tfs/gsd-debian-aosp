# -*- coding: utf-8 -*-
"""
Created on Sat Aug 27 15:49:49 2016

@author: habersmn
"""

import random
import time

import numpy as np

import scpiClientFluke
import scpiClient
import epb_config_fixture as cfg


HV_TYPES = {0: "Spellman UM15N4",
            1: "Ultravolt 15A12-N4",
            15: "Simulator"}
         

class FixtureHW(object):    
    def __init__(self, scpi_client_fluke, scpi_client_is):
        self.sc_fluke = scpi_client_fluke
        self.sc_is = scpi_client_is
        self.test_load_conductance = None        
        self.fluke_mode = None         
         
        self._fluke_init()
        self._epb_init()
                
    def get_serial_number(self):
        status, reply = self.sc_is.sendReceive('EPB:SN?')
        return eval(reply)

    def get_hv_type(self):
        status, reply = self.sc_is.sendReceive('EPB:VOLTage:CAPillary:STATus?')
        hv_type = (eval(reply) >> 24) & 0xF
        try:
            return (hv_type, HV_TYPES[hv_type])
        except KeyError:
            return (hv_type, 'unknown type')

    def get_firmware_version(self):
        status, reply = self.sc_is.sendReceive('EPB:FirmwareVersion?')
        return eval(reply)

    def get_bootloader_version(self):
        status, reply = self.sc_is.sendReceive('EPB:BootVersion?')
        return eval(reply)

    def get_hardware_version(self):
        status, reply = self.sc_is.sendReceive('EPB:HardwareVersion?')
        return eval(reply)

    def set_target_voltage(self, target_voltage):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA0 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA1 1.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA2 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA3 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:TARGet %f'%target_voltage)
        
    def set_test_load_conductance(self, test_load_conductance):
        if test_load_conductance != self.test_load_conductance:
            print
            if test_load_conductance == 0.0:
                raw_input('> Disconnect BNC cable from test load, then press enter to continue.')
            else:
                raw_input('> Connect BNC cable to %.0f Megaohm test load, then press enter to continue.'%(1e-6/test_load_conductance))
            self.test_load_conductance = test_load_conductance
            print "> continuing ..."
            print
            
    def turn_on_hv(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x11', ignoreNext=True)
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x15', ignoreNext=True)
        time.sleep(1.0)
    
    def turn_off_hv(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x12', ignoreNext=True)
       
    def get_uut_voltage(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA0 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA1 1.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA2 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA3 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageSLope 1.0')
        status, reply = self.sc_is.sendReceive('EPB:VOLTage:CAPillary:VOLTage?')
        return float(reply)

    def get_uut_total_cathode_current(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateCathodeCurrentOffset 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateCathodeCurrentSlope 1.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateInternalSupplyCurrentSlope 0.0')
        status, reply = self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CathodeCURrent?')
        return float(reply) * 1e-6
                               
    def get_uut_supply_internal_current(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateCathodeCurrentOffset 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateCathodeCurrentSlope 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateInternalSupplyCurrentSlope -1.0')
        status, reply = self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CathodeCURrent?')
        return float(reply) * 1e-6

    def get_uut_anode_current(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateAnodeCurrentOffset 0.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateAnodeCurrentSlope 1.0')
        status, reply = self.sc_is.sendReceive('EPB:VOLTage:CAPillary:AnodeCURrent?')
        return float(reply) * 1e-6
    
    def get_standard_cathode_current(self):
        self._fluke_current_mode()
        status, reply = self.sc_fluke.sendReceive('READ?')
        current = -float(reply) * cfg.STANDARD_CATHODE_CURRENT_CORRECTION_FACTOR
        return current

    def get_standard_anode_current(self):
        self._fluke_current_mode()
        status, reply = self.sc_fluke.sendReceive('READ?')
        return -float(reply) 

    def get_standard_voltage(self):
        self._fluke_voltage_mode()
        status, reply = self.sc_fluke.sendReceive('READ?')
        return -float(reply) * cfg.HV_PROBE_VOLTAGE_SCALING 

    def commit_cathode_current_calibration_coefficients(self, coefficients):
        self._epb_reset()
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x2', ignoreNext=True)        
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateCathodeCurrentSlope %r'%coefficients[0])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateInternalSupplyCurrentSlope %r'%coefficients[1])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateCathodeCurrentOffset %r'%(coefficients[2] * 1e6))
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x05', ignoreNext=True) # store dirty registers      
        self._epb_init()
 
    def commit_anode_current_calibration_coefficients(self, coefficients):
        self._epb_reset()
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x2', ignoreNext=True)        
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateAnodeCurrentSlope %r'%coefficients[0])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateAnodeCurrentOffset %r'%(coefficients[1] * 1e6))
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x05', ignoreNext=True) # store dirty registers      
        self._epb_init()

    def commit_target_voltage_calibration_coefficients(self, coefficients):
        self._epb_reset()
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x2', ignoreNext=True)        
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA0 %r'%coefficients[0])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA1 %r'%coefficients[1])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA2 %r'%coefficients[2])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateTargetVoltageCoefficientA3 %r'%coefficients[3])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x05', ignoreNext=True) # store dirty registers      
        self._epb_init()

    def commit_voltage_monitor_calibration_coefficients(self, coefficients):
        self._epb_reset()
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x2', ignoreNext=True)        
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA0 %r'%coefficients[0])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA1 %r'%coefficients[1])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA2 %r'%coefficients[2])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CalibrateVoltageCoefficientA3 %r'%coefficients[3])
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x05', ignoreNext=True) # store dirty registers 
        self._epb_init()

    def _epb_reset(self, timeout=30, pollPeriod=0.5):
        self.sc_is.sendReceive('EPB:BOOT:COMMand 0x2', ignoreNext=True) 
        self.sc_is.sendReceive('EPB:BOOT:COMMand 0x11', ignoreNext=True)        
        start = time.time()
        
        reply = None
        while reply != 'COFB':
            if time.time() >= start+timeout:
                raise RuntimeError('Timeout: EPB did not enter bootmode after reset.')
            status, reply = self.sc_is.sendReceive('EPB:ApplicationTYPe?', ignoreError=True)
            time.sleep(pollPeriod)
         
        while reply != '<binary.reply>\nEPB\x00</binary.reply>':
            if time.time() >= start+timeout:
                raise RuntimeError('Timeout: EPB did not enter application after reset.')
            status, reply = self.sc_is.sendReceive('EPB:ApplicationTYPe?', ignoreError=True)
            time.sleep(pollPeriod)
       
    def _fluke_init(self):
        self.sc_fluke.sendReceive('*RST')
        self.sc_fluke.sendReceive('*CLS')
        self.sc_fluke.sendReceive('SYST:REM')        
    
    def _fluke_current_mode(self):
        if self.fluke_mode != 'DCI':
            print
            raw_input("> Set toggle switch for current measurement, then press enter to continue.")
            print '> continuing ...'
            print            
            self.sc_fluke.sendReceive('CONF:CURR:DC MIN ')        
            self.sc_fluke.sendReceive('CURR:DC:NPLC 10')        
            self.sc_fluke.sendReceive('CURR:DC:FILT OFF')        
            self.fluke_mode = 'DCI'                
    
    def _fluke_voltage_mode(self):
        if self.fluke_mode != 'DCV':
            print
            print '> Connect BNC cable to high voltage probe.'
            print '> Set toggle switch for voltage measurement.'
            raw_input("> Then press enter to continue.")
            print '> continuing ...'
            print
            self.sc_fluke.sendReceive('CONF:VOLT:DC 10')        
            self.sc_fluke.sendReceive('VOLT:DC:NPLC 10')        
            self.sc_fluke.sendReceive('VOLT:DC:FILT OFF')
            if cfg.HV_PROBE_HIGH_IMPEDANCE_METER:
                self.sc_fluke.sendReceive('INP:IMP:AUTO 1')
            else:
                self.sc_fluke.sendReceive('INP:IMP:AUTO 0')
            self.fluke_mode = 'DCV'                

    def _epb_init(self):
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x1', ignoreNext=True)
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:COMMand 0x2', ignoreNext=True)        
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CONFIG 0x0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:RampRate 30000')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:RampTIMeout 2.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:AnodeCathodeCurrentRatioActiveCathodeCurrentMINimum 1000.0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CurrentMINimum -1000')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:CurrentMAXimum 1000')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:LoadResistanceActiveVoltageMINimum 20000')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:VoltageMINimum -1000')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:VoltageMAXimum 20000')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:VoltageTargetMINimum 0')
        self.sc_is.sendReceive('EPB:VOLTage:CAPillary:VoltageTargetMAXimum 15000')

class FixtureSimulator(object):
    INTERNAL_LOAD_TOLERANCE = 0.02    
    INTERNAL_LOAD_CONDUCTANCE = 1.0 / 375.0e6 # Siemens
    TARGET_VOLTAGE_TOLERANCE = 0.02
    CURRENT_MONITOR_TOLERANCE = 0.02
    VOLTAGE_MONITOR_TOLERANCE = 0.02
    CURRENT_NOISE = 0.1e-6 # Amps
    VOLTAGE_NOISE = 5 # Volts
    FIRMWARE_VERSION = 0xFFFFFFFF
    BOOTLOADER_VERSION = 0xFFFFFFFF
    HARDWARE_VERSION = 0xFFFFFFFF
    HV_TYPE = 0xF
    SERIAL_NUMBER = 0xFFFFFFFF
    
    STANDARD_ANODE_SLOPE = 1.0
    STANDARD_ANODE_OFFSET_MICROAMP = 0.0

    STANDARD_CATHODE_SLOPE = 1.0
    STANDARD_CATHODE_OFFSET_MICROAMP = 0.0
    
    STANDARD_VOLTAGE_SLOPE = 1.0
    STANDARD_VOLTAGE_OFFSET_VOLT = 0.0

    
    def __init__(self):
        self.voltage = 0.0 # supply off
        self.target_voltage = 0.0
        self.test_load_conductance = 0.0
        self.internal_load_conductance = (
            FixtureSimulator.INTERNAL_LOAD_CONDUCTANCE 
            * self._random_tolerance(FixtureSimulator.INTERNAL_LOAD_TOLERANCE))
        self.current_monitor_scale = self._random_tolerance(
                                FixtureSimulator.CURRENT_MONITOR_TOLERANCE) 

        nom_v = np.linspace(0.0, 15000, 4)
        real_v = [v * self._random_tolerance(FixtureSimulator.VOLTAGE_MONITOR_TOLERANCE) for v in nom_v]
        self.voltage_monitor_polynomial = np.polynomial.Polynomial.fit(
            np.linspace(0.0, 15000.0, 4),
            real_v, 3)

        real_v = [v * self._random_tolerance(FixtureSimulator.TARGET_VOLTAGE_TOLERANCE) for v in nom_v]
        self.target_voltage_polynomial = np.polynomial.Polynomial.fit(
            np.linspace(0.0, 15000.0, 4),
            real_v, 3)
       
    def get_serial_number(self):
        return FixtureSimulator.SERIAL_NUMBER
    def get_hv_type(self):
        hv_type = FixtureSimulator.HV_TYPE
        try:
            return (hv_type, HV_TYPES[hv_type])
        except KeyError:
            return (hv_type, 'unknown type')

    def get_firmware_version(self):
        return FixtureSimulator.FIRMWARE_VERSION

    def get_bootloader_version(self):
        return FixtureSimulator.BOOTLOADER_VERSION

    def get_hardware_version(self):
        return FixtureSimulator.HARDWARE_VERSION
        
    def set_target_voltage(self, target_voltage):
        self.target_voltage = target_voltage
        
    def set_test_load_conductance(self, test_load_conductance):
        self.test_load_conductance = test_load_conductance
    
    def turn_on_hv(self):
        self.voltage = self.target_voltage_polynomial(self.target_voltage)

    def turn_off_hv(self):
        self.voltage = 0.0

    def get_standard_voltage(self):
        standard_voltage = self.voltage * FixtureSimulator.STANDARD_VOLTAGE_SLOPE + FixtureSimulator.STANDARD_VOLTAGE_OFFSET_VOLT 
        standard_voltage += FixtureSimulator.VOLTAGE_NOISE * random.uniform(-1.0, 1.0) 
        return standard_voltage

    def get_uut_voltage(self):
        return self.voltage_monitor_polynomial(self.voltage) + FixtureSimulator.VOLTAGE_NOISE * random.uniform(-1.0, 1.0)

    def get_uut_anode_current(self):
        return ( self.voltage * self.current_monitor_scale * self.test_load_conductance 
                 + FixtureSimulator.CURRENT_NOISE * random.uniform(-1.0, 1.0) )

    def get_uut_total_cathode_current(self):
        return ( self.voltage * self.current_monitor_scale * (
                 self.internal_load_conductance + self.test_load_conductance) 
                 + FixtureSimulator.CURRENT_NOISE * random.uniform(-1.0, 1.0) )
                               
    def get_uut_supply_internal_current(self):
        return ( self.voltage_monitor_polynomial(self.voltage) * FixtureSimulator.INTERNAL_LOAD_CONDUCTANCE
                 + FixtureSimulator.CURRENT_NOISE * random.uniform(-1.0, 1.0) )
                 
    def get_standard_cathode_current(self):
        current = self.voltage * self.test_load_conductance
        current = current * FixtureSimulator.STANDARD_CATHODE_SLOPE + FixtureSimulator.STANDARD_CATHODE_OFFSET_MICROAMP * 1e-6
        current += FixtureSimulator.CURRENT_NOISE * random.uniform(-1.0, 1.0) 
        return current
        
    def get_standard_anode_current(self):
        current = self.voltage * self.test_load_conductance 
        current = current * FixtureSimulator.STANDARD_ANODE_SLOPE + FixtureSimulator.STANDARD_ANODE_OFFSET_MICROAMP * 1e-6
        current += FixtureSimulator.CURRENT_NOISE * random.uniform(-1.0, 1.0) 
        return current
        
    def commit_cathode_current_calibration_coefficients(self, coefficients):
        print
        print "> cathode monitor calibration coefficients committed"
        print coefficients
        print
        
    def commit_anode_current_calibration_coefficients(self, coefficients):
        print
        print "> anode monitor calibration coefficients committed"
        print coefficients
        print

    def commit_target_voltage_calibration_coefficients(self, coefficients):
        print
        print "> target voltage calibration coefficients committed"
        print coefficients
        print

    def commit_voltage_monitor_calibration_coefficients(self, coefficients):
        print
        print "> voltage monitor calibration coefficients committed"
        print coefficients
        print

    def _random_tolerance(self, tolerance):
        return 1.0 + tolerance * random.uniform(-1.0, 1.0)        

def fixture_init():
    if cfg.SIMULATE:
        return FixtureSimulator()
    else:
        sc_fluke = scpiClientFluke.SCPIClient()
        sc_fluke.connect(cfg.SERIALPORT, cfg.BAUDRATE)    
        
        sc_is = scpiClient.SCPIClient(cfg.SERVER, access='CONTROLLER')     
        sc_is.connect()
    
        return FixtureHW(sc_fluke, sc_is)   
   
           
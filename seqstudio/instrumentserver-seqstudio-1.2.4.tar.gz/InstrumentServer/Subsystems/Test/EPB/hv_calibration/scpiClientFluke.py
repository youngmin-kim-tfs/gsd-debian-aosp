# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 07:39:58 2016

@author: habersmn
"""

import time
import serial

class SCPIClient(object):
    def __init__(self, port=None, baudrate=38400):
        self.port = port
        self.baudrate = baudrate
        self.commandIndexSend = 0
        self.commandIndexReceive = 0
        self.serial = None
        if port:
            self.connect(port, baudrate)
    
    def connect(self, port, baudrate=38400):
        if self.serial is None:
            self.serial = serial.Serial(port, baudrate, timeout=1)
        else:
            raise serial.SerialException('port is already open')
        
    def disconnect(self):
        if self.serial is None:
            raise serial.SerialException('port is not open')      
        else:
            self.serial.close()
            self.serial = None
        
    def sendCommand(self, command):
        command = bytes('*OPC?;'+ command.rstrip() + '\n')
        self.serial.write(command)
        self.commandIndexSend += 1
        return self.commandIndexSend
    
    def receiveResponse(self, commandindex, exception_on_error=True):
        self.commandIndexReceive += 1
        if commandindex != self.commandIndexReceive:
            raise IndexError('commandIndex send and receive out of sync')
        reply = self._getResponse()
        status = self._get_standard_event_status()
        if exception_on_error and status:
            raise serial.SerialException('instrument standard event status non-zero: 0x%x'%status)
        return (status, reply)
       
    def sendReceive(self, command, exception_on_error=True):  
        return self.receiveResponse(self.sendCommand(command), exception_on_error)

    def _getResponse(self, timeout=None):
        start = time.time()
        while (timeout is None) or (time.time() < start+timeout):
            response = self.serial.readline().rstrip()
            if response:
                if response[0]!='1':
                    raise RuntimeError('Invalid response to *OPC received.')
                if (len(response) >= 2) and (response[1]==';'):
                    return response[2:]
                else: 
                    return response[1:]
        raise serial.SerialTimeoutException()
            
    def _get_standard_event_status(self, mask=0xFF^0x80):
        self.serial.write(b'*ESR?\n')
        esr = self.serial.readline()
        if not esr:
            raise serial.SerialTimeoutException()
            return None
        return int(esr) & mask


if __name__ == '__main__':                   
    sc = SCPIClient()
    sc.connect('/dev/tty.usbserial-A700UMUA', baudrate=9600)
    print repr(sc.sendReceive("read?"))
    sc.disconnect()
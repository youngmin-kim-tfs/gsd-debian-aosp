#!/usr/bin/python
########################################################################
### FILE:	instrumentServer.py
### PURPOSE:	Start Instrument Server
########################################################################

import sys, os, os.path, optparse, platform, glob


assert ("2.4" <= sys.version < '3.0'), 'This program requires Python 2.[4-9].x'

_baseFolders = []
_subtrees    = []
optionParser = optparse.OptionParser()
addOption    = optionParser.add_option

try:
    from os import fork
    gotFork = True
except ImportError:
    gotFork = False



def setBaseFolders (*folders):
    _baseFolders[:] = folders


def setFlavor (flavor):
    _subtrees[:] = filter(None, (os.path.join('Flavors', flavor), "."))


def getPathList (path):
    if path is None:
        return []
    if isinstance(path, str):
        return [d for d in path.split(os.pathsep) if d]
    elif isinstance(path, (list, tuple)):
        return path
    else:
        assert False, "Invalid invocation getPathList(path=%r); path must be a string, list, tuple, or None"%(path,)


def getPathVariable (name):
    return [d for d in os.getenv(name, "").split(os.pathsep) if d]


def buildPath (pathlist, initial, *subfolders):
    launchdir = os.path.dirname(sys.argv[0])

    if initial:
        for folder in initial:
            fullpath = os.path.abspath(os.path.join(launchdir, folder))
            if not fullpath in pathlist:
                pathlist.append(fullpath)

    for basefolder in filter(None, _baseFolders):
        for subtree in _subtrees:
            for subfolder in subfolders:
                fullmask = os.path.abspath(os.path.join(launchdir, basefolder, subtree, subfolder))
                for fullpath in glob.glob(fullmask):
                    if os.path.isdir(fullpath) and not fullpath in pathlist:
                        pathlist.append(fullpath)



def extendPath (path):
    archname1  = os.getenv("PLATFORM", platform.system())
    archname2  = "%s-%s"%(archname1, platform.machine())
    archname3  = "%s-Python%s.%s"%(archname2, sys.version_info[0], sys.version_info[1])

    p = [ os.path.join("Arch", name) for name in (archname3, archname2, archname1) ]
    p.append("SCPIServer")
    p.append("Tools")

    buildPath(path, None, *p)



def buildOptions (parser, **defaults):
    TRACE, DEBUG, INFO, NOTICE, WARNING = range(5)

    parser.set_usage('%prog [options] [module [class]]')

    parser.add_option(
        '--shutdown',
        dest='shutdown', default=False, action='store_const', const=True,
        help='Shut down a running server.')

    parser.add_option(
        '--status',
        dest='status', default=False, action='store_const', const=True,
        help='Get server status.')

    parser.add_option(
        '--version',
        dest='getversion', default=False, action='store_const', const=True,
        help='Get version string')

    parser.add_option(
        '--build',
        dest='getbuild', default=False, action='store_const', const=True,
        help='Get build number')

    parser.add_option(
        '-f', '--flavor',
        dest='flavor', nargs=1, default=os.getenv("FLAVOR"),
        help=('Instrument flavor (e.g. "Simulator", "ProtoX", "Production").  '
              'This controls the default search path for modules and configuration files, and may '
              'also control subsystem specific behavior.'))

    parser.add_option(
        '-c', '--config-folder',
        dest='configpath', action='append',
        help=('Append the specified folder to the path list used to look up configuration files.'
              'The default path list includes the contents of the CONFIGPATH environment variable, '
              'as well as any flavor-specific and generic "Config" subfolders.'))

    parser.add_option(
        '-m', '--module-folder',
        dest='modulepath', action='append',
        help=('Append the specified folder to the path list used to look up module files.  '
              'The default path list includes the contents of the MODULEPATH environment variable, '
              'as well as any flavor-specific and generic "Methods" subfolders.'))

    parser.add_option(
        '-b', '--bind', '-p', '--port',
        dest='bindplain', nargs=1, default=None,
        help='Listen for incoming plain socket connections on the specified network '
        'interface (specified by name or IP address) & port number [%default].')

    parser.add_option(
        '-t', '--telnet', '--telnet-interface',
        dest='bindtelnet', nargs=1, default=None,
        help='Listen for incoming telnet connections on the specified network '
        'interface (specified by name or IP address) & port number [%default].')

    parser.add_option(
        '-s', '--ssl', '--ssl-bind', '--ssl-interface',
        dest="bindssl", nargs=1, default=None,
        help='Listen for incoming SSL socket connections on the specified network '
        'interface (specified by name or IP address) & port number [%default]. '
        'Requires a SSL certificate and key. ')

    parser.add_option(
        '--ssl-certificate',
        dest="sslcertificate", nargs=1, default=os.getenv("SSLCERT"),
        help='Use in conjunction with the "--ssl" option to specify SSL certificate for incoming connections. '
        'Relative path names are searched for in the configuration file search path (see "--config-folder"). '
        '[%default].')

    parser.add_option(
        '--ssl-key',
        dest="sslkey", nargs=1, default=os.getenv("SSLKEY"),
        help='Use in conjunction with the "--ssl" option to specify SSL key for incoming connections. '
        'Relative path names are searched for in the configuration file search path (see "--config-folder"). '
        '[%default]. Note that this option does not affect preconfigured SSL listeners.')

    parser.add_option(
        '-n', '--no-debug', '--normal',
        dest='loglevel', action='store_const', const=INFO, default=INFO,
        help='Normal verbosity; messages are logged at "INFO" level or above.')

    parser.add_option(
        '-d', '--debug',
        dest='loglevel', action='store_const', const=DEBUG, default=INFO,
        help='More verbose log output')

    parser.add_option(
        '--trace',
        dest='loglevel', action='store_const', const=TRACE, default=INFO,
        help='Ridiculously verbose log output')

    parser.add_option(
        "-r", "--root", "--root-folder",
        dest="root", default=os.path.realpath(os.path.dirname(sys.argv[0])),
        help="Base directory for relative paths [%default]")

    if gotFork:
        parser.add_option(
            '--fork',
            dest='fork', default=False, action='store_const', const=True,
            help='Fork off and run in background')

    parser.add_option(
        '--pid-file', '--pidfile',
        dest='pidfile', nargs=1,
        help='Store the process ID of the server in the specified file')

    parser.add_option(
        '-o', '--output',
        dest='output', nargs=1, default="-",
        help='Redirect output to the specified file/device [(standard output)]')

    parser.add_option(
        '--output-format',
        dest='outputformat', nargs=1, default="$localtime$ $topic:20$ [$level:1$]: $message$",
        help='Message logging format')

    parser.add_option(
        '-q', '--quiet',
        dest='loglevel', action='store_const', const=NOTICE, default=INFO,
        help='More quiet log output (just notices, warnings and errors)')

    parser.add_option(
        '-l', '--load',
        dest='preload', action='append',
        help=('Preload (run) the specified module file at startup, prior to '
              'listening for client connections.  This option may be repeated '
              'to sequentially load more than one module.'))

    parser.add_option(
        '-a', '--load-asynchronously',
        dest='postload', action='append',
        help=('Load (run) the specified module file at startup, after listening '
              'for client connections.   This option may be repeated to '
              'sequentially load more than one module.'))

    parser.add_option(
        '-e', '--exit-module',
        dest='exitmodules', action='append',
        help=('Run the specified module at shutdown.  This option may be repeated '
              'to sequentially run more than one module.'))

    parser.add_option(
        "--autoinit", "--auto-initialize",
        dest="autoinit",
        default=os.getenv("AUTOINIT", True),
        nargs=1,
        help="Automatically activate/initialize hardware at startup [%default]")


    parser.set_defaults(**defaults)
    return parser



def initPythonPath ():
    extendPath(sys.path)
    return sys.path


def initLoadPath ():
    path = getPathVariable("LD_LIBRARY_PATH")
    extendPath(path)
    os.environ["LD_LIBRARY_PATH"] = os.pathsep.join(path)
    return path


def initConfigPath (configpath=None):
    path    = []
    initial = getPathList(configpath) or getPathVariable("CONFIGPATH")
    buildPath(path, initial, "Config")
    return path


def initModulePath (modulepath=None):
    path    = []
    initial = getPathList(modulepath) or getPathVariable("MODULEPATH")
    buildPath(path, initial, os.sep.join(("Subsystems", "*", "*")), "Methods")
    return path


def initialize (baseFolders=(".",), configpath=None, modulepath=None, **defaults):
    buildOptions(optionParser, configpath=configpath, modulepath=modulepath, **defaults)
    options, args = optionParser.parse_args()

    setBaseFolders(*baseFolders)
    setFlavor(options.flavor)

    initPythonPath()
    initLoadPath()

    configpath = initConfigPath(options.configpath)
    modulepath = initModulePath(options.modulepath)

    import scpiServer
    scpiServer.setConfigPath(configpath)
    scpiServer.setModulePath(modulepath)
    scpiServer.setStartupOptions(args, options)

    if options.bindplain:
        address = scpiServer.interface(options.bindplain)
    else:
        address = ()

    if options.shutdown:
        shutdownServer(*address)
        exit(0)

    elif options.status:
        exit(serverStatus(*address))

    elif options.getversion:
        printVersionInfo("version")
        exit(0)

    elif options.getbuild:
        printVersionInfo("build")
        exit(0)


def shutdownServer (host='127.0.0.1', port=7000):
    import scpiClient
    scpi = scpiClient.SCPIClient(serveraddr=(host, port))

    try:
        scpi.connect()
        scpi.sendReceive("ACCess Administrator", timeout=5)
        scpi.sendCommand("SHUTDOWN")
        exit(0)

    except Exception, e:
        sys.stderr.write("Failed to shut down server at %s, port %d: %s\n"%(host, port, e))
        exit(-1)



def serverStatus (host='127.0.0.1', port=7000):
    import scpiClient
    scpi = scpiClient.SCPIClient(serveraddr=(host, port))
    try:
        scpi.connect()
    except Exception, e:
        print("instrumentserver is stopped")
        return 2

    try:
        scpi.sendReceive("ACCess OBSERVER", timeout=5)
        ok, version = scpi.sendReceive("SYSTem:VERsion?", timeout=5)
        ok, build = scpi.sendReceive("SYSTem:BUILD?", timeout=5)
        ok, pid = scpi.sendReceive("SYSTem:PID?", timeout=5)
        ok, flavor = scpi.sendReceive("SYSTem:FLAVor?", timeout=5)

        print("instrumentserver %s build %s is running, flavor=%s, pid=%s"%
              (version, build, flavor, pid))
        return 0
    except Exception, e:
        print("instrumentserver is stale")
        return 2


def runServer(top=None, **options):
    import scpiServer
    scpiServer.runServer(top, *scpiServer.getStartupArgs(), **options)

def printVersionInfo (option):
    import config
    c = config.Config("version.ini")
    string = c.get("server", option, "-")
    print(string)


if __name__ == '__main__':
    initialize()
    runServer()

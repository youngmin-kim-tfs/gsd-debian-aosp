# This file was created automatically by SWIG.
# Don't modify this file, modify the SWIG interface instead.
# This file is compatible with both classic and new-style classes.
import _ntcan
def _swig_setattr(self,class_type,name,value):
    if (name == "this"):
        if isinstance(value, class_type):
            self.__dict__[name] = value.this
            if hasattr(value,"thisown"): self.__dict__["thisown"] = value.thisown
            del value.thisown
            return
    method = class_type.__swig_setmethods__.get(name,None)
    if method: return method(self,value)
    self.__dict__[name] = value

def _swig_getattr(self,class_type,name):
    method = class_type.__swig_getmethods__.get(name,None)
    if method: return method(self)
    raise AttributeError,name

import types
try:
    _object = types.ObjectType
    _newclass = 1
except AttributeError:
    class _object : pass
    _newclass = 0


NTCAN_FEATURE_FULL_CAN = _ntcan.NTCAN_FEATURE_FULL_CAN
NTCAN_FEATURE_CAN_20B = _ntcan.NTCAN_FEATURE_CAN_20B
NTCAN_FEATURE_DEVICE_NET = _ntcan.NTCAN_FEATURE_DEVICE_NET
NTCAN_FEATURE_CYCLIC_TX = _ntcan.NTCAN_FEATURE_CYCLIC_TX
NTCAN_FEATURE_RX_OBJECT_MODE = _ntcan.NTCAN_FEATURE_RX_OBJECT_MODE
NTCAN_MODE_OBJECT = _ntcan.NTCAN_MODE_OBJECT
NTCAN_MAX_TX_QUEUESIZE = _ntcan.NTCAN_MAX_TX_QUEUESIZE
NTCAN_MAX_RX_QUEUESIZE = _ntcan.NTCAN_MAX_RX_QUEUESIZE
NTCAN_NO_QUEUE = _ntcan.NTCAN_NO_QUEUE
NTCAN_20B_BASE = _ntcan.NTCAN_20B_BASE
NTCAN_RTR = _ntcan.NTCAN_RTR
NTCAN_NO_DATA = _ntcan.NTCAN_NO_DATA
NTCAN_NO_BAUDRATE = _ntcan.NTCAN_NO_BAUDRATE
class CIF(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CIF, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CIF, name)
    __swig_getmethods__["net"] = _ntcan.CIF_net_get
    if _newclass:net = property(_ntcan.CIF_net_get)
    __swig_getmethods__["hnd"] = _ntcan.CIF_hnd_get
    if _newclass:hnd = property(_ntcan.CIF_hnd_get)
    __swig_setmethods__["baudrate"] = _ntcan.CIF_baudrate_set
    __swig_getmethods__["baudrate"] = _ntcan.CIF_baudrate_get
    if _newclass:baudrate = property(_ntcan.CIF_baudrate_get,_ntcan.CIF_baudrate_set)
    __swig_setmethods__["ext_filter"] = _ntcan.CIF_ext_filter_set
    __swig_getmethods__["ext_filter"] = _ntcan.CIF_ext_filter_get
    if _newclass:ext_filter = property(_ntcan.CIF_ext_filter_get,_ntcan.CIF_ext_filter_set)
    __swig_getmethods__["hardware"] = _ntcan.CIF_hardware_get
    if _newclass:hardware = property(_ntcan.CIF_hardware_get)
    __swig_getmethods__["firmware"] = _ntcan.CIF_firmware_get
    if _newclass:firmware = property(_ntcan.CIF_firmware_get)
    __swig_getmethods__["driver"] = _ntcan.CIF_driver_get
    if _newclass:driver = property(_ntcan.CIF_driver_get)
    __swig_getmethods__["library"] = _ntcan.CIF_library_get
    if _newclass:library = property(_ntcan.CIF_library_get)
    __swig_getmethods__["features"] = _ntcan.CIF_features_get
    if _newclass:features = property(_ntcan.CIF_features_get)
    __swig_getmethods__["boardid"] = _ntcan.CIF_boardid_get
    if _newclass:boardid = property(_ntcan.CIF_boardid_get)
    __swig_getmethods__["msg_count"] = _ntcan.CIF_msg_count_get
    if _newclass:msg_count = property(_ntcan.CIF_msg_count_get)
    __swig_getmethods__["serial"] = _ntcan.CIF_serial_get
    if _newclass:serial = property(_ntcan.CIF_serial_get)
    __swig_getmethods__["tx_timeout"] = _ntcan.CIF_tx_timeout_get
    if _newclass:tx_timeout = property(_ntcan.CIF_tx_timeout_get)
    __swig_getmethods__["rx_timeout"] = _ntcan.CIF_rx_timeout_get
    if _newclass:rx_timeout = property(_ntcan.CIF_rx_timeout_get)
    def __init__(self,*args):
        _swig_setattr(self, CIF, 'this', apply(_ntcan.new_CIF,args))
        _swig_setattr(self, CIF, 'thisown', 1)
    def __del__(self, destroy= _ntcan.delete_CIF):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __str__(*args): return apply(_ntcan.CIF___str__,args)
    def canIdAdd(*args): return apply(_ntcan.CIF_canIdAdd,args)
    def canIdDelete(*args): return apply(_ntcan.CIF_canIdDelete,args)
    def flush_rx_fifo(*args): return apply(_ntcan.CIF_flush_rx_fifo,args)
    def __repr__(self):
        return "<C CIF instance at %s>" % (self.this,)

class CIFPtr(CIF):
    def __init__(self,this):
        _swig_setattr(self, CIF, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CIF, 'thisown', 0)
        _swig_setattr(self, CIF,self.__class__,CIF)
_ntcan.CIF_swigregister(CIFPtr)

class CMSG(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CMSG, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CMSG, name)
    __swig_setmethods__["id"] = _ntcan.CMSG_id_set
    __swig_getmethods__["id"] = _ntcan.CMSG_id_get
    if _newclass:id = property(_ntcan.CMSG_id_get,_ntcan.CMSG_id_set)
    __swig_setmethods__["len"] = _ntcan.CMSG_len_set
    __swig_getmethods__["len"] = _ntcan.CMSG_len_get
    if _newclass:len = property(_ntcan.CMSG_len_get,_ntcan.CMSG_len_set)
    __swig_getmethods__["msg_lost"] = _ntcan.CMSG_msg_lost_get
    if _newclass:msg_lost = property(_ntcan.CMSG_msg_lost_get)
    __swig_getmethods__["reserved"] = _ntcan.CMSG_reserved_get
    if _newclass:reserved = property(_ntcan.CMSG_reserved_get)
    __swig_getmethods__["data"] = _ntcan.CMSG_data_get
    if _newclass:data = property(_ntcan.CMSG_data_get)
    def __str__(*args): return apply(_ntcan.CMSG___str__,args)
    def __init__(self,*args):
        _swig_setattr(self, CMSG, 'this', apply(_ntcan.new_CMSG,args))
        _swig_setattr(self, CMSG, 'thisown', 1)
    def canSendByte(*args): return apply(_ntcan.CMSG_canSendByte,args)
    def canSendShort(*args): return apply(_ntcan.CMSG_canSendShort,args)
    def canSendLong(*args): return apply(_ntcan.CMSG_canSendLong,args)
    def canWriteByte(*args): return apply(_ntcan.CMSG_canWriteByte,args)
    def canWriteShort(*args): return apply(_ntcan.CMSG_canWriteShort,args)
    def canWriteLong(*args): return apply(_ntcan.CMSG_canWriteLong,args)
    def canTake(*args): return apply(_ntcan.CMSG_canTake,args)
    def canRead(*args): return apply(_ntcan.CMSG_canRead,args)
    def __del__(self, destroy= _ntcan.delete_CMSG):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C CMSG instance at %s>" % (self.this,)

class CMSGPtr(CMSG):
    def __init__(self,this):
        _swig_setattr(self, CMSG, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CMSG, 'thisown', 0)
        _swig_setattr(self, CMSG,self.__class__,CMSG)
_ntcan.CMSG_swigregister(CMSGPtr)

class CMSG_data(_object):
    __swig_setmethods__ = {}
    __setattr__ = lambda self, name, value: _swig_setattr(self, CMSG_data, name, value)
    __swig_getmethods__ = {}
    __getattr__ = lambda self, name: _swig_getattr(self, CMSG_data, name)
    __swig_setmethods__["c"] = _ntcan.CMSG_data_c_set
    __swig_getmethods__["c"] = _ntcan.CMSG_data_c_get
    if _newclass:c = property(_ntcan.CMSG_data_c_get,_ntcan.CMSG_data_c_set)
    __swig_setmethods__["s"] = _ntcan.CMSG_data_s_set
    __swig_getmethods__["s"] = _ntcan.CMSG_data_s_get
    if _newclass:s = property(_ntcan.CMSG_data_s_get,_ntcan.CMSG_data_s_set)
    __swig_setmethods__["l"] = _ntcan.CMSG_data_l_set
    __swig_getmethods__["l"] = _ntcan.CMSG_data_l_get
    if _newclass:l = property(_ntcan.CMSG_data_l_get,_ntcan.CMSG_data_l_set)
    def __init__(self,*args):
        _swig_setattr(self, CMSG_data, 'this', apply(_ntcan.new_CMSG_data,args))
        _swig_setattr(self, CMSG_data, 'thisown', 1)
    def __del__(self, destroy= _ntcan.delete_CMSG_data):
        try:
            if self.thisown: destroy(self)
        except: pass
    def __repr__(self):
        return "<C CMSG_data instance at %s>" % (self.this,)

class CMSG_dataPtr(CMSG_data):
    def __init__(self,this):
        _swig_setattr(self, CMSG_data, 'this', this)
        if not hasattr(self,"thisown"): _swig_setattr(self, CMSG_data, 'thisown', 0)
        _swig_setattr(self, CMSG_data,self.__class__,CMSG_data)
_ntcan.CMSG_data_swigregister(CMSG_dataPtr)



########################################################################
### FILE:	llac2esd.py
### PURPOSE:	LLAC v10 bindings to the ESD CAN module driver (Windows)
### AUTHOR:	Marc Haberstroh
###
### Copyrights (C) 2008 Applied Biosystems.  All rights reserved.
########################################################################

import ntcan
import time

cif      = None
baudrate = { 1000   : 0x0,
             800   : 0xE,
             666.6 : 0x1,
             500   : 0x2,
             333.3 : 0x3,
             250   : 0x4,
             166   : 0x5,
             125   : 0x6,
             100   : 0x7,
             83.3 : 0x10,
             66.6 : 0x8,
             50   : 0x9,
             33.3 : 0xA,
             20   : 0xB,
             12.5 : 0xC,
             10   : 0xD
            }


messageTypes = (MT_UNUSED, MT_EVENT, MT_WRITE, MT_ACK,
                MT_READ, MT_REPLY, MT_REGREQ, MT_TRANSFER) = range(8)
maxlen = ( -1, 4, 4, 0, 0, 4, 0, 8)

# Must be kept in sync with ntcan.h
NTCAN_CONTR_BUSY = "Controller busy"
NTCAN_BUSY_RETRY_COUNT = 100

def open (node=0x00, mask=0xFF):
    "Open the llac transport over ESD CAN interface."
    global cif
    assert cif==None, 'LLAC transport driver is already open.'

#    warning('### Using LLAC transport over ESD CAN interface ###')
    
    cif = ntcan.CIF(0,     # logical CAN network id
                    1024,  # rx_queuesize
                    0,     # rx_timeout (0=no timeout)
                    0,     # tx_timeout (0=no timeout)
                    128,   # tx_queuesize
                    0      # flags
                   )
                    
    cif.baudrate = baudrate[500] 
    cif.canIdAdd(ntcan.NTCAN_20B_BASE) # configure to accept extended CAN-ID messagesim

def close ():
    "Close the llac transport over ESD CAN interface."
    global cif
    assert cif!=None, 'LLAC transport driver is already closed'
    cif = None

def send (mt, dest, src, control, ref, msgid, data):
    "Send a LLAC packet"

    global cif
    assert cif!=None, 'LLAC transport driver must be open before you can send'
    assert mt in messageTypes, 'Invalid LLAC message type'   
    assert len(data) <= maxlen[mt], 'Too many data bytes to fit in CAN packet'

    d = [ord(A) for A in data] + [0,0,0,0,0,0,0,0]
 
    cmsg = ntcan.CMSG()
    
    count = NTCAN_BUSY_RETRY_COUNT
    # zero error_code in case count == 0
    error_code = 0
    while count > 0:
        try:
            if mt==MT_TRANSFER:
                error_code = cmsg.canSendByte( cif,
                                               ntcan.NTCAN_20B_BASE | (mt<<26) | (dest<<18) | ref, # CAN-ID
                                               len(data),                                          # number of CAN data bytes
                                               d[0],d[1],d[2],d[3],d[4],d[5],d[6],d[7] )
            else:
                error_code = cmsg.canSendByte( cif,
                                               ntcan.NTCAN_20B_BASE | (mt<<26) | (dest<<18) | (src<<8) | control, # CAN-ID
                                               len(data)+4,                                        # number of CAN data bytes
                                               ref>>8, ref & 0xFF, msgid>>8, msgid & 0xFF,d[0],d[1],d[2],d[3] )
            count = 0

        except IOError, e:
            #print "LLAC2ESD Error: [%s]" % " ".join([ "%s=%r"%(key, e[key]) for key in dir(e) ])
            print "LLAC2ESD Error: [%s]" % str(e)
            if NTCAN_CONTR_BUSY in str(e):
                # Wait a millisecond
                time.sleep(0.001)
                count -= 1
            else:
                raise

    assert error_code == 0, 'CAN driver returned error on canSendByte()'


def receive ():
    """
    Wait for and return one and exactly one LLAC packet.
    Returns a tuple containing:
    - The ID/header
    - The data, up to 8 bytes
    - A boolean, indicating whether this was an extended CAN frame
    """
    
    global cif
    assert cif!=None, 'LLAC transport driver must be open before you can receive'

    cmsg = ntcan.CMSG()
    assert cmsg.canRead(cif)==0, 'CAN driver returned error on canReadByte()'

    mt = (cmsg.id >> 26) & 0x7

    if mt == MT_TRANSFER:
        dest = (cmsg.id >> 18) & 0xFF
        src = 0x00
        control = 0x00
        ref = (cmsg.id >> 0) & 0xFFFF
        msgid = 0x0000
        s= ''.join([chr(A) for A in cmsg.data.c[0:cmsg.len]])
        return (mt,dest,src,control,ref,msgid,s)
    else:
        dest =    (cmsg.id >> 18) & 0xFF
        src =     (cmsg.id >> 8) & 0xFF
        control = (cmsg.id >> 0) & 0xFF
        ref =     (cmsg.data.c[0] << 8) | (cmsg.data.c[1])
        msgid =   (cmsg.data.c[2] << 8) | (cmsg.data.c[3])
        s= ''.join([chr(A) for A in cmsg.data.c[4:cmsg.len]])
        return (mt,dest,src,control,ref,msgid,s)

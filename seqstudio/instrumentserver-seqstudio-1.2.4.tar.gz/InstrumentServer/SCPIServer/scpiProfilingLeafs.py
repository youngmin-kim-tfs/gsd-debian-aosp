########################################################################
### FILE:	scpiProfilingLeafs.py
### PURPOSE:	Commands useful for performance measurement
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from time           import time
from scpiLeaf       import Leaf, CommandWrapper
from scpiSession    import SYNC, ASYNC

class RunTime_Query (CommandWrapper, Leaf):
    '''
    Measure the time it takes to run a command in seconds.
    '''

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('runtime',
                       type=float,
                       units='seconds',
                       description='Elapsed time between command invokation and reply')


    def run (self, _session, _context, synchronous=False, command=str):
        starttime  = time()
        syncmode   = (synchronous and SYNC or ASYNC)
        _session.runBlock(command, _context, nextReply=syncmode, nextCommand=syncmode, catchReturn=True)
        synctime  = time()
        return synctime - starttime

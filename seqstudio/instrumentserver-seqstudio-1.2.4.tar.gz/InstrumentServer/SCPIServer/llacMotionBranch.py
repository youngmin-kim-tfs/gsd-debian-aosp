########################################################################
### FILE:	llacMotionBranch.py
### PURPOSE:	Motion control via MCB
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase        import Hidden
from scpiBranch      import branchTypes
from scpiLeaf        import Leaf, Asynchronous, Observing, Controlling
from scpiExceptions  import Error, CommandError, RunError, NextReply, ComponentError
from llacBase        import _LLACRegisterLeaf
from motionBase      import MotionControlLeaf, MotionQueryLeaf
from llacCommandBase import LLACCommandBranch
from llacMotionBase  import LLACMotionBase, LLACAxis, LLACMotionAxis
from subscription    import debug, info, publish, warning
from time            import time, sleep
from struct          import unpack
from binascii        import a2b_hex
from locking         import Lock

CLIPPING_TOPIC = "MotionClipping"
TOTAL_REFERENCES  = 4


class LLACMotionProfile (object):
    STEP_FIELDS = 8
    (ST_PREDELAY, ST_POSTDELAY,
     ST_WAITTRIGGER, ST_SETTRIGGER,
     ST_SETTRIGGERTIME, ST_OUTPUTTRIGGERINDEX,
     ST_PAUSABLE, ST_METADATA) = range(STEP_FIELDS)


    def __init__ (self, name):
        self.name         = name
        self.tags         = {}
        self.steps        = []
        self.shadowTarget = {}
        self.ranges       = {}
        self.stepWrites   = []
        self.startStep    = None
        self.stopStep     = None
        self.currentStep  = None
        self.loaded       = False
        self.modified     = False
        self.clipping     = None
        self.bounds       = None
        self.axes         = None
        self.triggerTimes = {}


class LLACMotionProfileBranch (LLACCommandBranch):
    '''Motion Profile Commands'''

    class ProfileActive (RunError):
        '''Profile %(profile)r is already running'''

    class NoSuchProfile (RunError):
        '''No such motion profile exists: %(name)r'''

    class NoSuchStep (RunError):
        '''Step index %(step)r is beyond the end of motion profile %(name)r (size is %(size)r steps)'''

    class NoProfileLoaded (RunError):
        '''No motion profile specified, and none is loaded'''

    class TriggerNotSet (RunError):
        '''Profile %(profile)r output trigger index %(index)s is not set'''


    LLACCONFIGFILE = "motionprofile.ini"
    (RegSection, CmdSection, StatusSection, ProfConfSection, StepConfSection) = \
                 ("Registers", "Command", "Status", "ProfileConfig", "StepConfig")
    

    Registers = ("COMMAND", "STATUS?", "CONFIG", "METADATA",
                 "STEPINDEX", "STEPCOUNT", "DELETESTEPS", "STEPCONFIG",
                 "PREDELAY", "POSTDELAY", "STOPSTEP", "STEPTIMEOUT",
                 "OUTPUTTRIGGERTIME", "OUTPUTTRIGGERINDEX", "OUTPUTTRIGGERTABLE")
                 
    (R_COMMAND, R_STATUS, R_CONFIG, R_METADATA,
     R_STEPINDEX, R_STEPCOUNT, R_DELETESTEPS,
     R_STEPCONFIG, R_PREDELAY, R_POSTDELAY, R_STOPSTEP, R_STEPTIMEOUT,
     R_OUTPUTTRIGGERTIME, R_OUTPUTTRIGGERINDEX, R_OUTPUTTRIGGERTABLE) = range(len(Registers))
    

    Commands = ("Idle", "RunFromStart", "RunFromIndex", "Edit",
                "Append", "Update", "Insert", "Delete", "InsertAdvance",
                "FirstStep", "Advance", "Pause")

    (C_IDLE, C_RUNFROMSTART, C_RUNFROMINDEX, C_EDIT, C_APPEND, C_UPDATE,
     C_INSERT, C_DELETE, C_INSERT_ADVANCE,
     C_FIRSTSTEP, C_ADVANCE, C_PAUSE) = range(len(Commands))

    Statuses = ("Enabled", "Active")
    (S_ENABLED, S_ACTIVE) = range(len(Statuses))

    StepConfig = ("InputTrigger", "OutputTrigger", "Stoppable",
                  "PreDelay", "PostDelay", "WaitReadyTrigger",
                  "TimedOutputTrigger", "IndexedOutputTrigger",
                  "AxisEnable", "FocusEnable")
    (SC_INPUTTRIGGER, SC_OUTPUTTRIGGER, SC_STOPPABLE,
     SC_PREDELAY, SC_POSTDELAY, SC_WAITREADYTRIGGER,
     SC_TIMEDOUTPUTTRIGGER, SC_INDEXEDOUTPUTTRIGGER,
     SC_AXISENABLE, SC_FOCUSENABLE) = range(len(StepConfig))

    ProfileConfig = ("PauseAtFlag", )
    (PC_PAUSEATFLAG, ) = range(len(ProfileConfig))


    def __init__ (self, *args, **kwargs):
        LLACCommandBranch.__init__(self, *args, **kwargs)
        LLACMotionProfileBranch.init(self)

    def init (self):
        self.profiles      = {}
        self.activeProfile = None
        self.commands      = []
        self.statuses      = []
        self.stepConfig    = []
        self.profConfig    = []
        self.stopRequest   = False
        self.stepLock      = Lock()
        

    def getProfile (self, name):
        try:
            profile = self.profiles[name.lower()]
        except KeyError:
            raise self.NoSuchProfile(name=name)

        return profile


    def addProfile (self, name):
        if name.lower() in self.profiles:
            self.delProfile(name)

        self.profiles[name.lower()] = LLACMotionProfile(name=name)


    def delProfile (self, name):
        try:
            p = self.profiles.pop(name.lower())
        except KeyError:
            raise self.NoSuchProfile(name=name)
        else:
            if p.loaded:
                self.unloadProfile(p)


    def setStep (self, profile, index, settings, moves):
        p = self.getProfile(profile)
        i = index-1

        if index > len(p.steps):
            raise self.NoSuchStep(name=profile, size=len(p.steps), step=index)

        step    = (settings, moves)
        oldstep = p.steps[i]

        if p.loaded and (step != oldstep):
            p.shadowTarget.setdefault(i, oldstep[1])

        p.steps[i] = step
        self.clearAxes(p)


    def addStep (self, profile, settings, moves):
        p = self.getProfile(profile)

        p.steps.append((settings, moves))
        p.modified = True
        self.clearAxes(p)


    def getStep (self, profile, step):
        p = self.getProfile(profile)
        try:
            return p.steps[step-1]
        except IndexError:
            raise self.NoSuchStep(name=profile, size=len(p.steps), step=step)


    def getLength (self, name):
        p = self.getProfile(name)
        return len(p.steps)


    def checkBounds (self, p, required=True, axes=None, candidates=None):
        if candidates is None:
            candidates = self.parent.getBounds()

        bounds = set(candidates)

        if candidates:
            self.updateAxes(p)

            if axes is None:
                axes = p.axes

            axes &= self.parent.boundedAxes(bounds)

            lowerCorner, upperCorner = {}, {}
            for axis, span in p.spans.iteritems():
                if axis in axes:
                    lower, upper = span
                    lowerCorner[axis] = lower
                    upperCorner[axis] = upper

            for corner in lowerCorner, upperCorner:
                bounds &= self.parent.validBoundsBySteps(corner, candidates=bounds)

            if required and not bounds:
                kwargs = {}
                for axis, span in p.spans.iteritems():
                    kwargs[axis.name] = "(%s-%s)"%span

                candidates = ','.join([ c.name for c in candidates ])

                raise self.parent.NotWithinBounds(system=self.parent.commandPath(),
                                                  candidates=candidates,
                                                  which="profile", profile=p.name, **kwargs)
                                                  

        return bounds



    def getSpan (self, p):
        movesByAxis = {}

        for settings, moves in p.steps:
            effectiveTarget = self.parent.effectiveTarget(moves)
            for axis, target in effectiveTarget.iteritems():
                movesByAxis.setdefault(axis, []).append(target)

        spans = {}
        for axis, targets in movesByAxis.iteritems():
            spans[axis] = (min(targets), max(targets))

        return spans


    def updateAxes (self, p):
        if p.axes is None:
            p.spans = self.getSpan(p)
            p.axes  = set(p.spans)

        return p.axes


    def clearAxes (self, p):
        p.axes = None


    def loadProfile (self, p, reload=False):
        self.checkConfig()

        self.parent.clearToMove(needEnabled=False)
        try:
            self.updateAxes(p)
            self.parent.updateReservations(p.axes)
            self.stepLock.acquire()

            if reload or not p.loaded or p.modified:
                self._loadProfile(p, reload=True)
            elif p.shadowTarget:
                self._loadProfile(p, reload=False)
        finally:
            self.stepLock.release()
            self.parent.endMove()


    def _loadProfile (self, p, reload=False, clip=False):
        self.checkConfig()

        if not reload:
            ### If more than 1/2 of all steps are 'dirty', just reload the profile
            if len(p.shadowTarget) > len(p.steps) / 2:
                self.debug("Profile %r is too stale; %d of %d steps "
                           "need to be updated.  Forcing full reload."%
                           (p.name, len(p.shadowTarget), len(p.steps)))
                reload = True


        if reload:
            if p.loaded:
                self._unloadProfile(p)
            p.startStep   = self.readValue(self.R_STEPCOUNT)

        message = ("%s profile %r into MCB, startStep=%d, stepCount=%s"%
                   (("Updating", "Loading")[reload], p.name, p.startStep, len(p.steps)))
        self.debug("%s, dirtySteps=%d -- starting"%(message, len(p.shadowTarget)))

        self.command(self.C_IDLE)

        try:
            self.command(self.C_EDIT)

            self.setMask(self.R_CONFIG, self.profConfig[self.PC_PAUSEATFLAG])
            self.loadStart(p)

            dirtySteps = {}

            for index, step in enumerate(p.steps):
                loadstep = reload or (index in p.shadowTarget)
                settings, moves = step

                if clip and p.clipping:
                    clippedMoves, clippingInfo = self.parent.clipToBound(p.clipping, moves)

                    if clippingInfo:
                        clippingInfo = [ ("profile", p.name),
                                         ("step", index+1),
                                         ("metadata", settings[p.ST_METADATA]) ] + clippingInfo

                        publish(CLIPPING_TOPIC,
                                " ".join("-%s=%s"%item for item in clippingInfo))

                        dirtySteps[index] = moves = clippedMoves
                        loadstep = True

                if loadstep:
                    self.loadStep(p, index, reload, settings, moves)

        finally:
            self.command(self.C_IDLE)

        self.debug("%s, dirtySteps=%s -- completed"%(message, len(dirtySteps)))

        p.shadowTarget  = dirtySteps
        p.loaded        = True
        p.modified      = False
        p.currentStep   = 0
        p.stopStep      = p.startStep + len(p.steps)



    def loadStart (self, p):
        self.lastTarget = {}
        self.lastWrites = {}

        for axis in p.axes:
            axis.checkConfig()


    def loadStep (self, p, index, reload, settings, moves):
        (predelay, postdelay,
         waitTrigger, setTrigger, setTriggerTime, outputTriggerIndex,
         pausable, metadata) = settings

        timedTrigger = (setTriggerTime > 0) or (outputTriggerIndex is not None)

        stepflags  = (self.stepMask(self.SC_INPUTTRIGGER, waitTrigger and not timedTrigger) |
                      self.stepMask(self.SC_OUTPUTTRIGGER, setTrigger) |
                      self.stepMask(self.SC_PREDELAY, predelay) |
                      self.stepMask(self.SC_POSTDELAY, postdelay) |
                      self.stepMask(self.SC_STOPPABLE, pausable) |
                      self.stepMask(self.SC_WAITREADYTRIGGER, (waitTrigger or timedTrigger) and setTrigger) |
                      self.stepMask(self.SC_TIMEDOUTPUTTRIGGER, timedTrigger) | 
                      self.stepMask(self.SC_INDEXEDOUTPUTTRIGGER, outputTriggerIndex is not None))

        axisflag   = self.stepMask(self.SC_AXISENABLE, True)
        focusflag  = self.stepMask(self.SC_FOCUSENABLE, True)

        if reload:
            ### We are adding a new step.  Copy the last step
            stepCommand     = self.C_APPEND
            self.lastWrites = self.lastWrites.copy()
            p.stepWrites.append(self.lastWrites)
        else:
            ### We are updating an existing step; retrieve current register
            ### values and positions from profile cache.
            self.writeValue(self.R_STEPINDEX, p.startStep+index)
            stepCommand     = self.C_UPDATE
            self.lastTarget = dict(p.shadowTarget.get(index, p.steps[index][1]))
            self.lastWrites = p.stepWrites[index]

        writes      = []
        axes        = []

        try:
            for axis in self.parent.axes:
                if axis.istype((SurfaceAxis, AutoFocusAxis)):
                    stepflag = focusflag
                else:
                    stepflag = axisflag
                    axisflag <<= 1

                try:
                    target = moves[axis]
                except KeyError:
                    pass
                else:
                    lastTarget = self.lastTarget.get(axis, [])

                    if target != lastTarget:
                        writes.extend(axis.sendTarget(*target))
                        if axis.targetOptions(target) != axis.targetOptions(lastTarget):
                            writes.extend(axis.moveToTarget(sync=None, *target))

                        self.lastTarget[axis] = target

                    stepflags |= stepflag
                    axes.append(axis)


            for regindex, value in ((self.R_STEPCONFIG, stepflags),
                                    (self.R_PREDELAY, predelay),
                                    (self.R_POSTDELAY, postdelay),
                                    (self.R_METADATA, metadata),
                                    (self.R_OUTPUTTRIGGERTIME, setTriggerTime),
                                    (self.R_OUTPUTTRIGGERINDEX, outputTriggerIndex)):

                if self.lastWrites.get(regindex) != value != None:
                    writes.append(self.sendValue(regindex, value, debug=False))
                    self.lastWrites[regindex] = value

            
            synctime = time()
            writes.append(self.sendCommand(stepCommand))

        except Exception, e:
            self.finishRequests(writes)
            raise


        pending = self.waitAck(writes)
        self.waitSync(pending)
        synctime = time() - synctime

        self.debug("Loaded step #%d (MCB index %d), axes=%s, stepflags=0x%08X, "
                   "command=%s (0x%08X), msgid=%s, responseTime=%.6fs"%
                   (index+1, p.startStep+index, "/".join([axis.name for axis in axes]), stepflags,
                    self.Commands[stepCommand], self.commands[stepCommand], ref, synctime))

        return axes


    def unloadProfile (self, p):
        self.checkConfig()

        self.parent.clearToMove(needEnabled=False)
        try:
            self.parent.updateReservations(p.axes)
            self.stepLock.acquire()
            self._unloadProfile(p)
        finally:
            self.stepLock.release()
            self.parent.endMove()


    def _unloadProfile (self, p):
        self.debug('Unloading profile %r from MCB'%(p.name,))
        index  = p.startStep
        length = p.stopStep - p.startStep


        self.command(self.C_IDLE)
        self._endProfile()

        if length:
            try:
                self.command(self.C_EDIT)

                self.writeValue(self.R_STEPINDEX,   index)
                self.writeValue(self.R_DELETESTEPS, length) 

                self.command(self.C_DELETE)
            finally:
                self.command(self.C_IDLE)

        p.loaded       = False
        p.currentStep  = None
        p.shadowTarget = {}
        p.stepWrites   = []

        for p in self.profiles.values():
            if p.loaded and p.startStep >= index:
                p.startStep -= length
                p.stopStep  -= length


    def clearProfiles (self):
        self.debug("Clearing MCB profile memory")

        self.parent.clearToMove(needEnabled=False)
        try:
            self._clearProfiles()
        finally:
            self.parent.endMove()


    def _clearProfiles (self):
        self.command(self.C_IDLE)
        self.writeValue(self.R_STEPCOUNT, 0)

        self.profiles.clear()
        self.activeProfile = None


    def prepareProfile (self, name, clippingBound=None):
        p    = self.getProfile(name)

        if self.activeProfile:
            raise self.ProfileActive(profile=self.activeProfile.name)

        self.updateAxes(p)

        if clippingBound:
            try:
                boundname, axisnames = clippingBound.split(':',1)

            except ValueError:
                ### Clip all axes
                p.clipping = self.parent.getBound(clippingBound)
                p.bounds   = set([p.clipping])

            else:
                ### Clip only specified axes
                bound      = self.parent.getBound(boundname)
                checkAxes  = p.axes - set(self.parent.getAxisSelection(axisnames.split(',')))
                p.bounds   = self.checkBounds(p, axes=checkAxes, candidates=[bound])
                p.clipping = bound

        else:
            p.clipping = None
            p.bounds   = self.checkBounds(p)



        self.parent.clearToMove()
        try:
            self.stepLock.acquire()
            self.parent.updateReservations(p.axes)
            self.activeProfile = p
            self.stopRequest   = False

        except:
            self.stepLock.release()
            self.parent.endMove()
            raise



    def runProfile (self, index=0, sync=7200.0):
        p = self.activeProfile
        acquired = True

        try:
            if not p.loaded or p.modified:
                self._loadProfile(p, reload=True, clip=True)
            elif p.shadowTarget or p.clipping:
                self._loadProfile(p, reload=False, clip=True)

            try:
                if self.parent.bounds:
                    self.parent.sendMovesWithinBounds(targetBounds=p.bounds)

                self.loadTriggerTimes(p)

                self.debug("Running profile %r from step %d (MCB startStep=%d, stopStep=%d, stepIndex=%d)"%
                           (p.name, index+1, p.startStep, p.stopStep, p.startStep+index))

                self.command(self.C_IDLE)
                self.writeValue(self.R_STEPINDEX, p.startStep + index)
                self.writeValue(self.R_STOPSTEP,  p.stopStep)
                p.currentStep = index
                for axis in self.parent.axes:
                    axis._isHome = False

                ref = self.sendCommand(self.C_RUNFROMINDEX, sync=sync)
                pending = self.waitAck(ref)
                self.stepLock.release()
                acquired = False
                self.waitSync(pending)

            except (ComponentError, self.LLACTimeout), e:
                self.logCurrentState(verbose=True)
                for axis in self.parent.axes:
                    if axis in p.axes:
                        axis.logCurrentState(verbose=True)
                raise e

        finally:
            if not acquired:
                self.stepLock.acquire()

            try:
                self._endProfile()
            finally:
                self.stepLock.release()


    def stopProfile (self):
        self._stopProfile(self.C_IDLE)


    def pauseProfile (self):
        self._stopProfile(self.C_PAUSE)


    def _stopProfile (self, command):
        self.checkConfig()
        try:
            self.stopRequest = True
            self.stepLock.acquire()
            self.command(command)

            ### Workaround for issue in MCB: axes may still be moving
            ### even though STOP command returns
            if self.activeProfile:
                activeAxes = [ a for a in self.activeProfile.axes if a.isActive() ]
                if activeAxes:
                    self.debug("Profile %r is stopped, but %s %s still moving.  Sleeping..."%
                               (self.activeProfile.name,
                                [ a.name for a in activeAxes ],
                                ("axis is", "axes are")[len(activeAxes) > 1]))

                while activeAxes:
                    sleep(0.1)
                    activeAxes = [ a for a in self.activeProfile.axes if a.isActive() ]

            self._endProfile()
        finally:
            self.stepLock.release()


    def _endProfile (self):
        try:
            if self.activeProfile and self.activeProfile.loaded:
                stepindex = self.readValue(self.R_STEPINDEX)
                profile   = self.activeProfile
                profile.currentStep = stepindex - profile.startStep

                self.debug("Profile %r stopped after step #%d of %d (MCB startStep=%d, stepIndex=%d)"%
                           (profile.name,
                            profile.currentStep, len(profile.steps),
                            profile.startStep, stepindex))
        finally:
            if self.activeProfile:
                self.activeProfile = None
                self.parent.endMove()


    def resumeProfile (self, index=None, sync=7200.0):
        p = self.activeProfile
        if index > 0:
            self.runProfile(index-1, sync)

        elif p.loaded:
            self.runProfile(p.currentStep, sync)

        else:
            self.runProfile(0, sync)


    def getCurrentStepIndex (self, p=None):
        if self.activeProfile != p != None:
            return p.currentStep

        elif self.activeProfile is not None:
            return self.readValue(self.R_STEPINDEX) - \
                   self.activeProfile.startStep
        else:
            raise self.NoProfileLoaded


    def isActive (self):
        return self.statusBits(self.S_ENABLED, self.S_ACTIVE)


    def loadRegisters (self):
        LLACCommandBranch.loadRegisters(self)


        self.commands   = self.getConfigSection(self.CmdSection,      self.Commands)
        self.statuses   = self.getConfigSection(self.StatusSection,   self.Statuses)
        self.profConfig = self.getConfigSection(self.ProfConfSection, self.ProfileConfig)
        self.stepConfig = self.getConfigSection(self.StepConfSection, self.StepConfig)
        self.debug("Clearing MCB profile table")
        self.command(self.C_IDLE)
        self.writeValue(self.R_STEPCOUNT, 0)


    def clearRegisters (self):
        LLACCommandBranch.clearRegisters(self)
        for p in self.profiles.itervalues():
            p.loaded = False



    def stepMask (self, mask, enable):
        return enable and self.stepConfig[mask] or 0


    def stop (self):
        if self.activeProfile:
            self.debug("Stopping profile %s"%self.activeProfile.name)
            return self.stopProfile()


    def setTriggerTime (self, p, index, time):
        p.triggerTimes[index] = time

        if self.activeProfile is p:
            self.loadTriggerTime(index, time)


    def getTriggerTime (self, p, index):
        try:
            return p.triggerTimes[index]
        except KeyError:
            raise self.TriggerNotSet(profile=p.name, index=index)


    def loadTriggerTime (self, index, time):
        regspec    = self.registers[self.R_OUTPUTTRIGGERTABLE]
        regaddress = regspec['register'] + index

        self.debug("Updating MCB output trigger lookup entry: %s=%s"%(index, time))
        self.writeValue(self.R_OUTPUTTRIGGERTABLE, time, register=regaddress)


    def loadTriggerTimes (self, p):
        regspec    = self.registers[self.R_OUTPUTTRIGGERTABLE]
        regaddress = regspec['register']

        indexes = p.triggerTimes.keys()
        indexes.sort()

        if indexes:
            self.debug("Populating MCB output trigger lookup table: %s"%
                       ", ".join([ "%s=%s"%(i, p.triggerTimes[i]) for i in indexes ]))

            writes = []
            for i in indexes:
                writes.append(self.sendValue(self.R_OUTPUTTRIGGERTABLE,
                                             p.triggerTimes[i],
                                             register=regaddress+i,
                                             debug=False))
            self.finishRequests(writes)
        



    class NEW (Controlling, Leaf):
        '''Create a new motion profile'''

        class ProfileExists (RunError):
            'The profile %(name)r already exists'


        def run (self, replaceExisting=False, name=str):
            if not replaceExisting and name.lower() in self.parent.profiles:
                raise self.ProfileExists(name=name)
            
            self.parent.addProfile(name)



    class DELete (Controlling, Leaf):
        '''Delete an existing motion profile'''

        def run (self, ignoreMissing=False, name=str):
            try:
                self.parent.delProfile(name)
            except self.parent.NoSuchProfile:
                if not ignoreMissing:
                    raise

    class LIST_Query (Observing, Leaf):
        '''List profiles currently defined'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None),
                           description='Profile name')

        def run (self):
            profiles = self.parent.profiles.keys()
            profiles.sort()
            return tuple(profiles)


    class CLEar (Controlling, Leaf):
        '''Remove all profiles'''

        def run (self):
            self.parent.clearProfiles()



    class _StepEditLeaf (MotionControlLeaf):
        def addStepInputs (self):
            self.addInput('preDelay', type=int, named=True, default=0,
                          units='milliseconds', range=(0, 0xFFFF),
                          description='Delay time prior to moving axis to target position')
            self.addInput('postDelay', type=int, named=True, default=0,
                          units='milliseconds', range=(0, 0xFFFFF),
                          description='Delay time after axis has moved to target position')
            self.addInput('waitTrigger', type=bool, default=False, named=True,
                          description='If set, wait for an external trigger '
                          'before executing this step.')
            self.addInput('setTrigger', type=bool, default=False, named=True,
                          description='If set, generate an external trigger '
                          'after executing this step.')
            self.addInput('setTriggerTime', type=float, default=None, named=True,
                          units='milliseconds',
                          description='If set, specifies a duration for which the '
                          'output trigger is held active.')
            self.addInput('outputTrigger', type=int, default=None, named=True, range=(0, 15),
                          description='Use output trigger time from trigger time table, '
                          'see the "TriggerTime=" command.')
            self.addInput('pausable', type=bool, default=False, named=True,
                          description='If set, allow profile execution to '
                          'pause after the current step.')
            self.addInput('metaData', type=int, default=0, range=(0, (2 ** 32) - 1),
                          description='Set meta data for this step; this will be reported'
                          ' back in events as the step is executing')





    class STEP_Add (_StepEditLeaf):
        '''Add a step to the specified profile.'''

        def declareInputs (self):
            self.startInputs()
            self.addInput('profile', type=str, description='Profile name')
            self.addStepInputs()

        def run (self, profile=str, *spec):
            stepargs = spec[:LLACMotionProfile.STEP_FIELDS]
            posargs  = spec[LLACMotionProfile.STEP_FIELDS:]

            moves = self.unflattenedInputs(posargs)
            self.parent.addStep(profile, stepargs, moves)


    class STEP_Set (_StepEditLeaf):
        '''Modify an existing step in a profile.'''

        def declareInputs (self):
            self.startInputs()
            self.addInput('profile', type=str, description='Profile name')
            self.addInput('step', type=int, range=(1, None), description='Step Index')
            self.addStepInputs()


        def run (self, profile=str, step=int, *spec):
            stepargs = spec[:LLACMotionProfile.STEP_FIELDS]
            posargs  = spec[LLACMotionProfile.STEP_FIELDS:]
            moves = self.unflattenedInputs(posargs)
            self.parent.setStep(profile, step, stepargs, moves)



    class STEP_Query (MotionQueryLeaf):
        '''Return the specified step from the profile '''

        def declareInputs (self):
            self.super.declareInputs()
            self.setInput('index', type=int, range=(1, None))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('preDelay', type=int, default=0, named=True,
                           description='Delay before moving to position')
            self.addOutput('postDelay', type=int, default=0, named=True,
                           description='Delay after moving to position')
            self.addOutput('waitTrigger', type=bool, default=False, named=True,
                          description='If set, wait for an external trigger '
                          'before executing this step.')
            self.addOutput('setTrigger', type=bool, default=False, named=True,
                          description='If set, generate an external trigger '
                          'after executing this step.')
            self.addOutput('setTriggerTime', type=float, default=None, named=True,
                           units='milliseconds',
                           description='If set, specifies a duration for which the '
                           'output trigger is held active.')
            self.addOutput('pausable', type=bool, default=False, named=True,
                          description='If set, allow profile execution to '
                          'pause after the current step.')
            self.addOutput('metaData', type=int, default=0, range=(0, (2 ** 32) - 1), named=True,
                           description='Set meta data for this step; this will be reported'
                           ' back in events as the step is executing')


        def run (self, profile=str, index=int):
            stepargs, moves = self.parent.getStep(profile, index)
            posargs = self.flattenedOutputs(moves)
            return stepargs + tuple(posargs)



    class STEPS_Query (Observing, Leaf):
        '''Return the number of steps defined in this profile'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self, profile=str):
            return self.parent.getLength(profile)



    class StepIndex_Query (Leaf):
        '''Return the current step index within the specified profile'''

        def declareInputs (self):
            self.super.declareInputs()
            self.setInput('profile', type=str, default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('index', type=int, range=(1, None))


        def run (self, profile=str):
            if profile:
                p = self.parent.getProfile(profile)
                s = self.parent.getCurrentStepIndex(p)
                if s is None:
                    return 0
                else:

                    return s + 1
            else:
                return self.parent.getCurrentStepIndex() + 1

        

    class LOAD (Controlling, Leaf):
        '''Load the specified profile into the MCB'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('reload', type=bool, default=False,
                          description="Force reload of the profile, even if already loaded")

        def run (self, reload=False, profile=str):
            p = self.parent.getProfile(profile)
            self.parent.loadProfile(p, reload=reload)


    class LOAD_Clear (Controlling, Leaf):
        '''Unload the specified profile from the MCB'''

        def run (self, profile=str):
            p = self.parent.getProfile(profile)
            if p.loaded:
                self.parent.unloadProfile(p)



    class START (Controlling, Asynchronous, Leaf):
        '''Run the specified profile from the beginning'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('clip', type=str, default=None, named=True,
                          description='Clip profile coordinates to the limits of the specified '
                          'bounding box.  If not specified, and if the profile does not fit '
                          'inside any existing bounding box, an error is raised.  Optionally, '
                          'the bounding box name may be followed by a colon, then a '
                          'comma-separated list of axis names, in which case clipping occurs '
                          'only on the specified axes.')


        def prerun (self, clip=None, profile=str):
            self.parent.prepareProfile(profile, clippingBound=clip)

        def run (self, clip=None, profile=str):
            self.parent.runProfile()
                

    class STOP (Controlling, Leaf):
        '''Stop the currently running profile, if any'''

        def run (self):
            self.parent.stopProfile()


    class PAUSe (Controlling, Leaf):
        '''Pause the currently running profile, if any'''

        def run (self):
            self.parent.pauseProfile()


    class RESUME (Controlling, Asynchronous, Leaf):
        '''
        Resume the specified profile at the specified step.
        If no step is specified, resume at the current step.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('clip', type=str, default=None, named=True,
                          description='Clip profile coordinates to the limits of the specified '
                          'bounding box.  If not specified, and if the profile does not fit '
                          'inside any existing bounding box, an error is raised.  Optionally, '
                          'the bounding box name may be followed by a colon, then a '
                          'comma-separated list of axis names, in which case clipping occurs '
                          'only on the specified axes.')
            self.setInput('step', type=int, range=(0, None), default=None,
                          description='Step at which to resume')

        def prerun (self, clip=None, profile=str, step=None):
            self.parent.prepareProfile(profile, clippingBound=clip)

        def run (self, clip=None, profile=str, step=None):
            self.parent.resumeProfile(step)


    class ACTive_Query (Observing, Leaf):
        '''
        Return the name of the currently running profile, if any; otherwise
        a dash ("-").
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('profile', type=str)


        def run (self):
            isactive = self.parent.isActive()
            if not isactive:
                return "-"
            elif self.parent.activeProfile:
                return self.parent.activeProfile.name
            else:
                return "(Unknown profile)"


    class EXISTS_Query (Observing, Leaf):
        '''
        Indicate whether a profile exists or not
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('exists', type=bool)

        def run (self, name=str):
            return name.lower() in self.parent.profiles
            

    class BoundingBox_Enumerate (Observing, Leaf):
        '''
        Return list of bounding boxes in which the specified profile can run.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None),
                           description='Bounding box')

        def run (self, profile=str):
            p = self.parent.getProfile(profile)
            bounds = [ b.name for b in self.parent.checkBounds(p, required=False) ]
            bounds.sort()
            return tuple(bounds)



    class SPAN_Query (MotionQueryLeaf):
        '''
        Return the minimum and maximum absolute coordinates of all
        step moves within a profile.
        '''

        def declareInputs (self):
            MotionQueryLeaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False,
                          description='Return raw motor steps, not scaled coordinates')

        def declareAxisOutputs (self):
            for axis in self.parent.parent.axes:
                self.addAxisOutputs(axis)
            self.parent.parent.setAxisHooks(self.addAxisOutputs, self.removeAxisOutputs)

        def addAxisOutputs (self, axis):
            self.addOutput(axis.prefixedName('min', named=True),
                           type=float, named=True, default=None,
                           description="Minimum %s coordinate")
            self.addOutput(axis.prefixedName('max', named=True),
                           type=float, named=True, default=None,
                           description="Maximum %s coordinate")


        def removeAxisInputs (self, axis):
            self.removeInput(axis.prefixedName('min', named=True))
            self.removeInput(axis.prefixedName('max', named=True))


        def run (self, steps=False, profile=str):
            p     = self.parent.getProfile(profile)
            spans = self.parent.getSpan(p)

            response = []
            for axis in self.getSupportedAxes():
                try:
                    span = spans[axis]
                except KeyError:
                    span = (None, None)
                else:
                    span = [ axis.fromSteps(pos, steps=steps) for pos in span ]

                response.extend(span)

            return tuple(response)


    class TriggerTime_Set (Controlling, Leaf):
        '''
        Manipulate output trigger times in trigger time table.
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=int, range=(0, 15))


        def run (self, profile=str, index=int, time=float):
            p = self.parent.getProfile(profile)
            self.parent.setTriggerTime(p, index, time)


    class TriggerTime_Query (Observing, Leaf):
        '''
        Retrieve an output trigger time from trigger time table.
        '''

        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=int, range=(0, 15))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('time', type=float, format="%s")

        def run (self, profile=str, index=int):
            p = self.parent.getProfile(profile)
            return self.parent.getTriggerTime(p, index)




class LinearMotionAxis (LLACMotionAxis):
    '''Motion axis for linear axis, with support for reference moves'''

    Registers  = LLACMotionAxis.Registers + ("REFERENCE", "REFERENCE2", "OFFSETTARGET")
    (R_REFERENCE, R_REFERENCE2, R_OFFSETTARGET) = range(len(LLACMotionAxis.Registers),
                                                        len(Registers))
    ReferenceRegisters = (None, R_REFERENCE, R_REFERENCE2, None, None)
         
    Commands = LLACMotionAxis.Commands + ("RefMove", "RefMove2", "Commit")
    (C_REFMOVE, C_REFMOVE2, C_COMMIT) = range(len(LLACMotionAxis.Commands), len(Commands))
    ReferenceCommands = (None, C_REFMOVE, C_REFMOVE2, None, None)

    targetSpec = [ ('target',    { 'type':float, 'units':'steps'}), 
                   ('steps',     { 'type':bool,  'named':True, 'default':None }),
                   ('relative',  { 'type':bool,  'named':True, 'default':None }),
                   ('absolute',  { 'type':bool,  'named':True, 'default':None }),
                   ('reference', { 'type':int,   'named':True, 'default':None, 'range':(0, TOTAL_REFERENCES) }),
                   ('speed',     { 'type':float, 'named':True, 'default':None }) ]


    def __init__ (self, *args, **kwargs):
        LLACMotionAxis.__init__(self, *args, **kwargs)
        LinearMotionAxis.init(self)

    def init (self):
        self.defaultReference  = None
        self.references        = [0] + ([None] * TOTAL_REFERENCES)
        self.activeRefRegs     = [None] * (TOTAL_REFERENCES+1)


    def initReferences (self):
        if self.defaultReference is None:
            config     = self.parent.getMotionConfig()
            references = config.getliteral(self.parent.ReferenceSection,
                                           self.name,
                                           valuetype=tuple,
                                           default=())

            if references and references[0] != None:
                self.defaultReference = references[0]
            else:
                self.defaultReference = 0

            message = [ "default=%d"%(self.defaultReference,) ]

            for index in range(1, TOTAL_REFERENCES+1):
                try:
                    reference = self.readReference(index)
                    if reference:
                        self.references[index] = reference
                        message.append("reference%d=%d (read from firmware)"%(index, reference))

                    elif index < len(references) and references[index] is not None:
                        written = self.writeReference(index, references[index], commit=False)
                        action  = ("maintained internally", "written to firmware")[written]
                        self.references[index] = references[index]
                        message.append("reference%d=%d (%s)"%(index, references[index], action))

                    else:
                        self.references[index] = 0
                        message.append("reference%d=0 (unset)"%(index,))

                except ComponentError, e:
                    self.references[index] = 0
                    message.append("reference%d=0 (failed to initialize)"%(index,))
                    warning("Failed to initialize %s reference position #%s: [%s] %s"%
                            (self.commandPath(), index, e.name, e))

            self.debug("Initialized references: %s"%(", ".join(message)))



#    def checkConfig (self):
#        LLACMotionAxis.checkConfig(self)
#        self.initReferences()


    def setReference (self, index, value, save=False):
        self.initReferences()
        self.references[index] = value
        written = self.writeReference(index, value, commit=save)
        if save:
            self.saveReferences()

        self.debug("Set reference %d to %s, saved to file=%s, written to firmware=%s"%
                   (index, value, save, written))


    def clearReference (self, index, save=False):
        self.initReferences()

        if index is None:
            span = range(1, len(self.references))
            refs = "1-%d"%(len(self.references))
        else:
            span = range(index, index+1)
            refs = str(index)

        written = 0
        for index in span:
            written += self.writeReference(index, 0, commit=save)
            self.references[index] = None

        if save:
            self.saveReferences()
        
        self.debug("Cleared reference(s) %s, saved to file=%s, written to firmware=%s"%
                   (refs, save, bool(written)))


    def saveReferences (self):
        config     = self.parent.getMotionConfig()
        references = (self.defaultReference,) + tuple(self.references[1:])
        config.setliteral(self.parent.ReferenceSection, self.name, references)


    def isActiveReference (self, index):
        command = self.ReferenceCommands[index]
        return command is not None and self.registers[command] is not None


    def readReference (self, index):
        regindex  = self.ReferenceRegisters[index]

        if regindex is not None and self.registers[regindex] is not None:
            return self.readValue(regindex)


    def writeReference (self, index, value, commit=False):
        self.checkConfig()
        regindex = self.ReferenceRegisters[index]
        written  = False

        if regindex is not None and self.registers[regindex] is not None:
            self.writeValue(regindex, value)
            written = True
            if commit:
                self.command(self.C_COMMIT)

        return written


    def getReference (self, index, absolute=False):
        self.initReferences()

        if absolute:
            index = 0            

        elif index is None:
            index = self.defaultReference

        return self.references[index] or 0

    def getDefaultReferenceIndex (self):
        self.initReferences()
        return self.defaultReference

    def setDefaultReferenceIndex (self, index, save=False):
        self.initReferences()
        self.defaultReference = index
        if save:
            self.saveReferences()


    def targetOps (self,  target, steps, relative, absolute, reference):
        self.checkConfig()

        if absolute or (relative and reference is None):
            reference = 0

        elif reference is None:
            reference = self.getDefaultReferenceIndex()

        self.checkValidRange(target, steps=steps, relative=relative, reference=reference)

        regindex = self.ReferenceRegisters[reference]
        command  = self.ReferenceCommands[reference]

        if relative and (steps or not self.positionMap):
            ops = ('relative',
                   self.R_RELTARGET,
                   self.toSteps(target, steps=steps),
                   self.C_RELMOVE)

        elif (regindex is not None and self.registers[regindex] is not None) and \
             (command is not None and self.commands[command] is not None) and \
             (steps or not self.positionMap):
            ops = ('reference %d based'%(reference,),
                   self.R_OFFSETTARGET,
                   self.toSteps(target, steps=steps),
                   command)

        else:
            ops = ('absolute',
                   self.R_ABSTARGET,
                   self.toRawPosition(target, steps=steps, relative=relative, reference=reference),
                   self.C_ABSMOVE)

        return ops


    def sendTarget (self, target, steps=True, relative=False, absolute=False, reference=0, speed=None):
        self.checkConfig()

        mode, reg, rawsteps, command = self.targetOps(target, steps, relative, absolute, reference)

        refs  = []

        if not (speed is self.speed is None):
            if not speed:
                speed = self.speed
            elif self.scale and not steps:
                speed *= abs(self.scale)

            speed = int(speed)

            refs.append(self.sendValue(self.R_SPEED, speed))
        
        refs.append(self.sendValue(reg, rawsteps))
        return refs


    def moveToTarget (self, target, steps=True, relative=False, absolute=False, reference=0, speed=None, **regsettings):
        mode, reg, rawsteps, command = self.targetOps(target, steps, relative, absolute, reference)
        ref = self.sendCommand(command, longCommand=True, **regsettings)
        return (ref,)


    def toRawPosition (self, position, steps=False,
                       relative=False, absolute=False, reference=None,
                       speed=None, usemap=True):

        self.checkConflictingOptions(relative=relative,
                                     reference=reference,
                                     absolute=absolute)

        if position in (None, self.HOMEPOS):
            return position

        if relative:
            position += self.getPosition(steps=steps, reference=0, usemap=usemap)

        if self.positionMap and usemap and not steps:
            pmap = self.getPositionMap()
            try:
                position = pmap[int(round(position))]
            except IndexError:
                raise self.NotWithinRange(axis=self.commandPath(),
                                          target=position,
                                          lower=0,
                                          upper=len(pmap)-1)

        else:
            position = self.toSteps(position, steps=steps)


        if not relative:
            position += self.getReference(reference, absolute)

        return position


    def fromRawPosition (self, position, steps=False,
                         relative=False, absolute=False, reference=None,
                         speed=None, usemap=True, align=round, **kwargs):

        self.checkConflictingOptions(relative=relative,
                                     reference=reference,
                                     absolute=absolute)


        if position in (None, self.HOMEPOS):
            return position

        if not relative:
            position -= self.getReference(reference, absolute)

        if self.positionMap and usemap and not steps:
            pmap   = self.positionMap
            pindex = None
            pdelta = None

            for index, value in enumerate(pmap):
                delta = self.positionDelta(position, value)
                if pindex is None or delta < pdelta:
                    pindex = index
                    pdelta = delta

            position = pindex

        else:
            position = self.fromSteps(position, steps)

        if relative:
            position -= self.getPosition(steps=steps, reference=0)

        return position


    def targetTuple (self, *args, **kwargs):
        if kwargs.get('reference') is None and not kwargs.get('relative'):
            kwargs['reference'] = self.getDefaultReferenceIndex()
        return LLACMotionAxis.targetTuple(self, *args, **kwargs)



    class POSition_Query (LLACMotionAxis.POSition_Query):
        '''
        Return the current coordinate of this axis
        '''

        def declareInputs (self):
            LLACMotionAxis.POSition_Query.declareInputs(self)
            self.setInput('reference', type=int, default=None,
                          range=(0, TOTAL_REFERENCES), named=True,
                          description='Return position relative to the specified reference position; '
                          'if 0, the absolute position, and if not provided, the currently active reference')

            self.setInput('absolute', type=bool, default=False, named=True, hidden=True,
                          description='Return absolute position.  Equivalent to "-reference=0"')


        def run (self, steps=False, reference=None, cached=False, absolute=False):
            return self.parent.getPosition(cached=cached, steps=steps, absolute=absolute, reference=reference)
        

    class REFerence_Set (Controlling, Leaf):
        '''Set reference positions for this axis'''

        def declareInputs (self):
            self.startInputs()
            self.addInput('steps', type=bool, named=True, default=False)
            self.addInput('save', type=bool, named=True, default=True,
                          description='Save the reference for to persistent storage.')
            self.addInput('default', type=int, range=(0, TOTAL_REFERENCES), named=True, default=None)
            for index in range(1, len(self.parent.references)):
                self.addInput('reference%d'%(index), type=float, named=False, default=None)

        def run (self, steps=False, save=True, default=None, *offsets):
            for index, offset in enumerate(offsets):
                if offset is not None:
                    counts = self.parent.toRawPosition(offset, steps=steps, reference=0)
                    self.parent.setReference(index+1, counts)

            if default is not None:
                self.parent.setDefaultReferenceIndex(default)

            if save:
                self.parent.saveReferences()


    class REFerence_Clear (Controlling, Leaf):
        '''
        Clear the reference position for this axis.
        Subsequently, target coordinates are equivalent to absolute positions.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('save', type=bool, named=True, default=True,
                          description='Save the reference for to persistent storage.')
            self.setInput('reference', type=int, range=(0, len(self.parent.references)),
                          description='Clear the specified reference position; if none provided, clear all.')

        def run (self, save=True, reference=None):
            self.parent.clearReference(reference, save=save)
                



    class REFerence_Query (Observing, Leaf):
        '''Read reference positions for this axis'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False, named=True)
            self.setInput('named', type=bool, default=None, named=True,
                          description='Return named references.  The default is True,'
                          ' unless "default" or a specific reference is specified')
            self.setInput('default', type=bool, default=False, named=True,
                          description='Return default reference index')
            self.setInput('reference', type=int, range=(1, len(self.parent.references)), default=None,
                          description='Get the specified reference position; if none provided, get all.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('default', type=tuple, named=False, default=None)
            for index in range(1, TOTAL_REFERENCES):
                self.addOutput('reference%d'%(index), type=tuple, named=False)


        def run (self, steps=False, named=None, default=False, reference=None):
            self.parent.initReferences()
            if named is None:
                named = (reference is None) and not default

            refs   = [ ]
            format = ("%f", "%d")[steps]

            for index, name in enumerate(self.getOutputNames()):
                if not named:
                    name = None
                
                if (index == 0):
                    show  = reference is None or default
                    value = self.parent.defaultReference
                else:
                    ref   = self.parent.references[index]
                    show  = (reference == index) or (reference is None and not default)
                    value = self.parent.fromSteps(ref, steps=steps) or 0

                if show and value is not None:
                    refs.append((name, str(value)))
                else:
                    refs.append((None, None))

            return tuple(refs)


    class RANGe_Set (Controlling, Leaf):
        '''Set valid range for this motion axis'''

        def declareInputs (self):
            Leaf.declareInputs(self)

            self.setInput('steps', type=bool, default=False, named=True,
                          description='Specify values in steps, rather than scaled units')

            self.setInput('absolute', type=bool, default=False, named=True,
                          description='Range is provided in absolute coordinates, regardless of default reference')

            self.setInput('reference', type=int, default=None, named=True,
                          range=(0, TOTAL_REFERENCES),
                          description='Position reference index')

            self.setInput('save', type=bool, default=True, named=True,
                          description='Save the range to persistent storage, thus making it permanent')
            self.setInput('min', type=float, default=None,
                          description='Mininum position')

            self.setInput('max', type=float, default=None,
                          description='Maxinum position')

        def run (self, steps=False, absolute=False, reference=None, save=True, min=float, max=float):
            self.parent.setRange(min, max, steps=steps, absolute=absolute, reference=reference, save=save)


    class RANGe_Query (Observing, Leaf):
        '''Return valid position range for this axis'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False, named=True,
                          description='Return values in steps, rather than scaled units')

            self.setInput('absolute', type=bool, default=False, named=True,
                          description='Range is provided in absolute coordinates, regardless of default reference')

            self.setInput('reference', type=int, default=None, named=True,
                          range=(0, TOTAL_REFERENCES),
                          description='Position reference index')

            self.setInput("which", type=("min", "max"), named=False,
                          default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=float, named=False, repeats=(0, 2))

        def run (self, steps=False, absolute=False, reference=None, which=None):
            r = self.parent.getRange(steps=steps, absolute=absolute, reference=reference)
            if which is not None and r is not None:
                return r[which]
            else:
                return r


    class OverShoot_Set (LLACMotionAxis.OverShoot_Set):
        '''
        Set backlash compensation overshoot for this axis.

        If enabled, moves towards "destination" will cause the axis to
        move beyond the target position by the specified overshooot,
        hten back to the target.

        Moves away from the destination will remain unaffected.
        '''

        def declareInputs (self):
            LLACMotionAxis.OverShoot_Set.declareInputs(self)
            self.addInput('absolute', type=int, default=False, named=True,
                          description='Position is provided in absolute coordinates, regardless of relative reference position')

            self.addInput('reference', type=int, default=None, named=True,
                          range=(0, TOTAL_REFERENCES),
                          description='Position reference index')


    class OverShoot_Query (LLACMotionAxis.OverShoot_Query):
        '''
        Return any backlash compensation overshoot for this axis.
        '''

        def declareInputs (self):
            LLACMotionAxis.OverShoot_Query.declareInputs(self)
            self.addInput('absolute', type=int, default=False, named=True,
                          description='Position is provided in absolute coordinates, regardless of relative reference position')

            self.addInput('reference', type=int, default=None, named=True,
                          range=(0, TOTAL_REFERENCES),
                          description='Position reference index')



class RotationalMotionAxis (LLACMotionAxis):
    '''Motion axis with support for a rotational coordinate system'''

    Registers = LLACMotionAxis.Registers + ("STEPSPERREVOLUTION",)
    (R_STEPSPERREVOLUTION,) = range(len(LLACMotionAxis.Registers), len(Registers))

    Commands = LLACMotionAxis.Commands + ("ShortestMove",)
    (C_SHORTMOVE,) = range(len(LLACMotionAxis.Commands), len(Commands))

    targetSpec    = [ ('target',   { 'type':int, 'units':'steps'}), 
                      ('steps',    { 'type':bool, 'named':True, 'default':False }),
                      ('relative', { 'type':bool, 'named':True, 'default':False }),
                      ('short',    { 'type':bool, 'named':True, 'default':True  }),
                      ('speed',    { 'type':float, 'named':True, 'default':None }) ]


    def __init__ (self, *args, **kwargs):
        LLACMotionAxis.__init__(self, *args, **kwargs)
        RotationalMotionAxis.init(self)

    def init (self):
        self.stepsPerRevolution = None


    def setStepsPerRevolution (self, steps):
        if self.getBase(ignoreMissing=True):
            self.checkConfig()
            self.writeValue(self.R_STEPSPERREVOLUTION, steps)

        self.stepsPerRevolution = steps


    def getStepsPerRevolution (self):
        if self.stepsPerRevolution is None:
            self.checkConfig()
            self.stepsPerRevolution = self.readValue(self.R_STEPSPERREVOLUTION)

        return self.stepsPerRevolution


    def loadRegisters (self):
        LLACMotionAxis.loadRegisters(self)
        if self.stepsPerRevolution:
            self.writeValue(self.R_STEPSPERREVOLUTION, self.stepsPerRevolution)


    def setPositionMap (self, pmap):
        spr = self.getStepsPerRevolution()

        if spr > 0:
            pmap = tuple([ step % spr for step in pmap ])

        return LLACMotionAxis.setPositionMap(self, pmap)


    def positionDelta (self, first, second):
        delta = abs(first - second)
        spr   = self.getStepsPerRevolution()

        if spr > 0:
            delta %= spr

        if spr >= delta > spr / 2:
            delta = spr - delta

        return delta


    def toRawPosition (self, target, steps=False, relative=False, short=True, speed=None,
                       usemap=True, current=None):
        counts = LLACMotionAxis.toRawPosition(self, target,
                                              steps=steps,
                                              relative=relative,
                                              usemap=usemap)

        if isinstance(counts, int):
            spr = self.getStepsPerRevolution()
            if spr > 0:
                steps %= spr

        return counts


    def sendTarget (self, target, steps=False, relative=False, short=True, speed=None):
        if not relative:
            self.checkValidRange(target, steps=steps, relative=relative)

        position = self.toRawPosition(target, steps=steps, relative=relative)

        refs = []

        if not (speed is self.speed is None):
            if speed is None:
                speed = self.speed
            elif not steps and self.scale:
                speed *= abs(self.scale)

            speed = int(speed)

            refs.append(self.sendValue(self.R_SPEED, speed))

        refs.append(self.sendValue(self.R_ABSTARGET, position))
        return refs


    def moveToTarget (self, target, steps=False, relative=False, short=True, speed=None, **regsettings):
        if short:
            command = self.C_SHORTMOVE
        else:
            command = self.C_ABSMOVE
        return (self.sendCommand(command, longCommand=True, **regsettings),)


    class POSition (LLACMotionAxis.POSition):
        '''
        Move to the specified axis coordinate
        '''

        def declareInputs (self):
            LLACMotionAxis.POSition.declareInputs(self)
            self.addInput('absolute', type=bool, default=False, named=True, hidden=True,
                          description='Provided for backwards compatibility.  Has no effect.')

        def run (self, asynchronous=False, ignorePause=False, *target):
            LLACMotionAxis.POSition.run(self, asynchronous, ignorePause, *target[:-1])


    class POSition_Query (LLACMotionAxis.POSition_Query):
        '''
        Return the current coordinate of this axis
        '''

        def declareInputs (self):
            LLACMotionAxis.POSition_Query.declareInputs(self)
            self.setInput('absolute', type=bool, default=False, named=True, hidden=True,
                          description='Provided for backwards compatibility.  Has no effect.')


        def run (self, steps=False, cached=False, absolute=False):
            return self.parent.getPosition(cached=cached, steps=steps)


    class StepsPerRevolution  (Controlling, Leaf):
        '''Set number of steps per revolution for this axis'''

        def run (self, steps=int):
            self.parent.setStepsPerRevolution(steps)


    class StepsPerRevolution_Query (Observing, Leaf):
        '''Obtain number of steps per revolution of this axis'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('steps', type=int)

        def run (self):
            return self.parent.getStepsPerRevolution()



class LLACFocusAxis (LLACAxis):
    exclusive = True

    LLACCONFIGFILE = "motionfocus.ini"
    (RegSection, CmdSection, StatusSection, ConfigSection) = \
                 ("Registers", "Command", "Status", "Config")
    
    Registers = ("COMMAND", "STATUS?", "CONFIG", "TARGET", "POSITION?", "SLOPE", "DEFAULTZ")
    (R_COMMAND, R_STATUS, R_CONFIG, R_TARGET, R_POSITION, R_SLOPE, R_DEFAULTZ) = \
                range(len(Registers))

    Commands = ("Disable", "Idle", "Single", "Continuous",
                "PositionCalculateSingle", "PositionCalculateContinuous",
                "FocusCalculateSingle", "FocusCalculateContinuous",
                "SingleWithFallback", "MoveToDefaultZ",
                "LaserOn", "LaserOff",
                "FocusSurface1", "FocusSurface2",
                "CalculateFocusSurface1", "CalculateFocusSurface2")


    (C_DISABLE, C_IDLE, C_SINGLE, C_CONTINUOUS,
     C_POSCALCSINGLE, C_POSCALCCONTINUOUS,
     C_FOCUSCALCSINGLE, C_FOCUSCALCCONTINUOUS,
     C_SINGLE_FALLBACK, C_MOVE_DEFAULT_Z,
     C_LASER_ON, C_LASER_OFF,
     C_FOCUS1, C_FOCUS2,
     C_CALCULATE1, C_CALCULATE2) = range(len(Commands))

    FocusConfig  = ("Laser", )
    (FC_LASER, )  = range(len(FocusConfig))

    Statuses = ("Enabled", "Active", "FocusingActive")
    (S_ENABLED, S_ACTIVE, S_FOCUSINGACTIVE) = range(len(Statuses))


    def __init__ (self, *args, **kwargs):
        LLACAxis.__init__(self, *args, **kwargs)
        LLACFocusAxis.init(self)

    def init (self):
        self.focusAxis    = None

    def synchronize (self, ref, target):
        try:
            LLACAxis.synchronize(self, ref, target)
        finally:
            if self.focusAxis:
                self.focusAxis.clearRawPosition()



class SurfaceAxis (LLACFocusAxis):
    '''
    Focus surface commands.
    '''
    targetSpec = [ ('plane', { 'type':int,
                                'range':(1, 2),
                                'description':'Surface plane 1 or 2; 0 to disable' }) ]

    Surfaces   = ("SURFACE1", "SURFACE2")

    FocusCommands     = (LLACFocusAxis.C_FOCUS1, LLACFocusAxis.C_FOCUS2)
    CalculateCommands = (LLACFocusAxis.C_CALCULATE1, LLACFocusAxis.C_CALCULATE2)


    class ConflictingTargets (CommandError):
        '''Surface move conflicts with %(effectiveAxis)s target %(originalTarget)s'''

    class MissingCoordinates (CommandError):
        '''Surface move requires %(axis)s coordinate'''

    class NoSurfaceAxisMapping (CommandError):
        '''Surface axis must be mapped to motion axes prior to use'''

    class NoSurfaceCoefficients (CommandError):
        '''Polynomial coefficients have not been defined for %(focusAxis)s surface #%(surface)s'''



    def __init__ (self, *args, **kwargs):
        LLACFocusAxis.__init__(self, *args, **kwargs)
        SurfaceAxis.init(self)


    def init (self):
        self.coeffAxes    = []
        self.coeffNames   = []
        self.planaraxes   = ()
        self.startreg     = None
    
        self.surfaceMethods = []
        self.coefficients = ([], [])



    def setAxes (self, planeAxis1, planeAxis2, focusAxis):
        self.focusAxis  = focusAxis
        self.planaraxes = (planeAxis1, planeAxis2)
        self.coeffAxes  = [ (planeAxis1, planeAxis1, planeAxis1),
                            (planeAxis2, planeAxis2, planeAxis2),
                            (planeAxis1, planeAxis1, planeAxis2),
                            (planeAxis1, planeAxis2, planeAxis2),
                            (planeAxis1, planeAxis1),
                            (planeAxis2, planeAxis2),
                            (planeAxis1, planeAxis2),
                            (planeAxis1,),
                            (planeAxis2,),
                            () ]

        self.coeffNames = []
        for axes in self.coeffAxes:
            names  = []
            scale   = focusAxis.scale
            for axis in axes:
                names.append(axis.name)
                scale /= axis.scale

            self.coeffNames.append(''.join(names) or 'OFFSET')

        self.debug("Configured surface with planar axes %s and %s, focus axis %s, coefficient names: %s"%
                   (planeAxis1.name, planeAxis2.name, focusAxis.name, ', '.join(self.coeffNames)))

        for method in self.surfaceMethods:
            method()


    def setCoefficients (self, surface, scaled, coefficients):
        self.checkConfig()
        refs  = []

        clist    = self.coefficients[surface-1] or ([0] * len(coefficients))
        cstrings = []

        for index, name, c in zip(xrange(len(coefficients)),
                                  self.coeffNames,
                                  coefficients):
            if c is not None:
                if scaled:
                    c *= self.getScale(index)

                clist[index] = c
                cstrings.append("%s=%s"%(name, c))


        self.debug("Setting polynomial coefficients for surface %d: %s"%
                   (surface, " ".join(cstrings)))


        startreg = self.startreg[surface-1]

        self.parent.clearToMove(needEnabled=False)
        try:
            for index, c in enumerate(clist):
                refs.append(self.sendValue(startreg + index, c))

            self.finishRequests(refs)
            self.coefficients[surface-1][:] = clist

        finally:
            self.parent.endMove()



    def getCoefficients (self, surface, scaled=False):
        self.checkConfig()
        coefficients = self.coefficients[surface-1]
        if not coefficients:
            raise self.NoSurfaceCoefficients(focusAxis=self.focusAxis.name, surface=surface)

        if scaled:
            coefficients = [ c / self.getScale(index)
                             for index, c in enumerate(coefficients) ]

        return coefficients


    def getScale (self, coeffIndex):
        scale = self.focusAxis.scale
        for axis in self.coeffAxes[coeffIndex]:
            scale /= axis.scale

        return scale
        


    def loadRegisters (self):
        LLACFocusAxis.loadRegisters(self)

        if not self.focusAxis:
            raise self.NoSurfaceAxisMapping()

        if not self.startreg:
            self.startreg = []
            for sindex, surface in enumerate(self.Surfaces):
                startreg = len(self.registers)
                self.startreg.append(startreg)
                for suffix in self.coeffNames:
                    regname = surface + suffix
                    regspec = self.regbranch.getRegisterLeafSpec(regname, _LLACRegisterLeaf)
                    self.registers.append(regspec)
        


    def clearRegisters (self):
        LLACFocusAxis.clearRegisters(self)
        self.startreg = None


    def sendTarget (self, surface, **regsettings):
        return []

    def moveToTarget (self, surface, steps=True, **regsettings):
        return (self.sendCommand(self.FocusCommands[surface-1], longCommand=True, **regsettings),)


    def targetOptions (self, target):
        names = dict(self.targetSpec).keys()
        return dict(zip(names, target))


    def isMove (self, target, *args, **kwargs):
        return bool(target)


    def effectiveTarget (self, target, positionmap={}):
        surface      = target[0]
        coefficients = self.getCoefficients(surface)
        et = 0

        for coeff, axes in zip(coefficients, self.coeffAxes):
            term = coeff
            for axis in axes:
                try:
                    term *= positionmap[axis]
                except KeyError:
                    self.debug("Missing %s target in map: %s"%(axis.name, positionmap))
                    raise self.MissingCoordinates(axis=axis.name)

            et += term

        if self.focusAxis in positionmap:
            raise self.ConflictingTargets(axis=self.commandPath(),
                                          target=surface,
                                          effectiveAxis=self.focusAxis.name,
                                          effectiveTarget=et,
                                          originalTarget=positionmap[self.focusAxis])

        return { self.focusAxis: int(et) }


    def readRawPosition (self):
        self.checkConfig()
        return None



    class SurfaceAXIS_Set (Controlling, Leaf):
        '''
        Map axes to be used for surface focus calculations.
        '''

        def declareInputs (self):
            self.startInputs()
            self.addInput('planarAxis1', type=str)
            self.addInput('planarAxis2', type=str)
            self.addInput('focusAxis', type=str)

        def run (self, *axes):
            axes = self.parent.parent.getAxisSelection(axes, LLACMotionAxis)
            self.parent.setAxes(*axes)
            


    class SurfaceAXIS_Query (Observing, Leaf):
        '''
        Map axes to be used for surface focus calculations.
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('planarAxis1', type=str, default=None)
            self.addOutput('planarAxis2', type=str, default=None)
            self.addOutput('focusAxis', type=str, default=None)

        def run (self):
            axes = []

            if self.parent.focusAxis:
                axes = [ a.name for a in self.parent.planaraxes ]
                axes.append(self.parent.focusAxis.name)

            return tuple(axes)



    class SURFace_Set (Controlling, Leaf):
        '''
        Set coefficients for polynomial function used to define shape of surface.
        '''

        def __init__ (self, *args, **kwargs):
            Leaf.__init__(self, *args, **kwargs)
            self.parent.surfaceMethods.append(self.declareInputs)
            

        def declareInputs (self):
            self.startInputs()
            self.addInput('steps', type=bool, named=True, default=False, description=
                          'Coordinates on the planar axes and the surface axis are not scaled')
            self.addInput('surface', type=int, range=(1, 2), 
                          description='Surface index')

            for name in self.parent.coeffNames:
                self.addInput(name, type=float, named=True, default=None)


        def run (self, steps, surface, *coefficients):
            self.parent.setCoefficients(surface, not steps, coefficients)



    class SURFace_Query (Observing, Leaf):
        '''
        Return coefficients for polynomial function used to define shape of surface.
        '''

        def __init__ (self, *args, **kwargs):
            Leaf.__init__(self, *args, **kwargs)
            self.parent.surfaceMethods.append(self.declareOutputs)
            

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, named=True, default=False, description=
                          'Coordinates on the planar axes and the surface axis are not scaled')
            self.setInput('surface', type=int, range=(1, 2), 
                          description='Surface index')

        def declareOutputs (self):
            self.startOutputs()
            for name in self.parent.coeffNames:
                self.addOutput(name, type=float, named=True, default=None)

        def run (self, steps=False, surface=int):
            return tuple(self.parent.getCoefficients(surface, not steps))



    class FloatingPoint_Set (Controlling, Leaf):
        '''
        Set coefficients for polynomial function used to define shape
        of surface, using a raw 32-bit or 64-bit big endian floating
        point representation of each coefficient.

        To set the coefficients using normal, human readable numbers,
        use the "SURFace=" command instead.
        '''

        packing = { None: '!',
                    'network': '!',
                    'native': '=',
                    'big-endian': '>',
                    'little-endian': '<' }

        sizes   = { 4: 'f',
                    8: 'd' }

        class InvalidCoefficientLength (CommandError):
            'Each coefficient must be given as a 8 or 16 character hexadecimal string'
            

        class InvalidCoefficient (CommandError):
            'Invalid coefficient: %(message)s'


        def __init__ (self, *args, **kwargs):
            Leaf.__init__(self, *args, **kwargs)
            self.parent.surfaceMethods.append(self.declareInputs)
            

        def declareInputs (self):
            self.startInputs()

            self.addInput('steps', type=bool, named=True, default=False, description=
                          'Coordinates on the planar axes and the surface axis are not scaled')
            self.addInput('surface', type=int, range=(1, 2), 
                          description='Surface index')

#            self.addInput('byteorder', type=self.packing, named=True description=
#                          'Packing order of bytes in each floating point number.  The default is '
#                          'network byte order (big endian).')

            for name in self.parent.coeffNames:
                self.addInput(name, type=str, named=True, default=None,
                              description='8 or 16 character hexadecimal string representation '
                              'of a 32-bit or 64-bit big endian floating point coefficient.')


        def run (self, steps, surface, *coefficients):
            floats = []
            
            
            for coeffName, coeff in zip(self.parent.coeffNames, coefficients):
                if coeff:
                    try:
                        formatcode   = self.sizes[len(coeff)/2]
                        formatstring = a2b_hex(coeff)

                    except (KeyError, TypeError):
                        raise self.InvalidCoefficient(coefficient=coeff)

                    else:
                        value, = unpack('>%s'%formatcode, formatstring)
                else:
                    value = None

                floats.append(value)
                        
            self.parent.setCoefficients(surface, not steps, floats)





class AutoFocusAxis (LLACFocusAxis):
    '''Support for position sense (autofocus)'''


    targetSpec  = [ ('target',     { 'type':float, 'named':True }),
                    ('slope',      { 'type':float, 'named':True, 'default':None }),
                    ('fallbackZ',  { 'type':float, 'named':True, 'default':None }),
                    ('predictedZ', { 'type':float, 'named':True, 'default':None }),
                    ('steps',      { 'type':bool, 'named':True, 'default':False }) ]


    class ConflictingTargets (RunError):
        '''Autofocus move conflicts with %(effectiveAxis)s target %(originalTarget)s'''


    class UnknownFocusCommand (RunError):
        'Uknnown MCB autofocus command value: %(command)s'



    def loadRegisters (self):
        LLACAxis.loadRegisters(self)
        self.statuses    = self.getConfigSection(self.StatusSection, self.Statuses)
        self.focusConfig = self.getConfigSection(self.ConfigSection, self.FocusConfig)

    def sendHome (self):
        return None


#    def toSteps (self, target=None, slope=None, fallbackZ=None, predictedZ=None, 
#                 steps=False, continous=False, usemap=True):
#        return target


    def sendTarget (self, target=None, slope=None, fallbackZ=None, predictedZ=None, 
                    steps=True, continuous=False, **junk):
        ref = []

        if target is not None:
            ref.append(self.sendValue(self.R_TARGET, target))

        if slope is not None:
            ref.append(self.sendValue(self.R_SLOPE, slope))

        defaultZ = (predictedZ, fallbackZ)[predictedZ is None]
        if defaultZ is not None:
            if self.focusAxis:
                defaultZ = self.focusAxis.toSteps(defaultZ, steps=steps)
            ref.append(self.sendValue(self.R_DEFAULTZ, defaultZ))

        self.debug('Setting autofocus target=%s, slope=%s, defaultZ=%s, msgids=%s'%
                   (target, slope, defaultZ, ref))
        return (ref,)


    def moveToTarget (self, target=None, slope=None, fallbackZ=None, predictedZ=None,
                      steps=True, continuous=False, **regsettings):

        if predictedZ is not None:
            command = self.C_MOVE_DEFAULT_Z
        elif fallbackZ is not None:
            command = self.C_SINGLE_FALLBACK
        elif continuous:
            command = self.C_CONTINUOUS
        else:
            command = self.C_SINGLE

        self.setMask(self.R_CONFIG, self.focusConfig[self.FC_LASER], enable=True)

        return (self.sendCommand(command, longCommand=True, **regsettings),)


    def effectiveTarget (self, target, positionmap={}):
        target, slope, fallbackZ, predictedZ, steps = self.targetTuple(*target)
        tt = self.targetTuple(*target)
        et = (fallbackZ, predictedZ)[predictedZ is not None]

        if self.focusAxis in positionmap:
            targetspec = [ (spec[0], value)
                           for spec, value in zip(self.targetSpec, target)
                           if value is not None ]
            targetspec = dict(targetspec)
            raise self.ConflictingTargets(axis=self.commandPath(),
                                          effectiveAxis=self.focusAxis.name,
                                          effectiveTarget=et,
                                          originalTarget=positionmap[self.focusAxis],
                                          **targetspec)

        return { self.focusAxis: self.focusAxis.toRawPosition(et, steps=steps) }


    def setFocus (self, command):
        self.checkConfig()
        ref = self.command(command)
        self.finishRequests((ref,))


    def getFocus (self):
        self.checkConfig()
        command = self.readValue(self.R_COMMAND)

        try:
            return self.commands.index(command)
        except ValueError:
            raise self.UnknownFocusCommand(command=command)


    def readRawPosition (self, calculate=False):
        self.checkConfig()
        
        if calculate:
            self.setMask(self.R_CONFIG, self.focusConfig[self.FC_LASER], enable=True)
            self.setFocus(self.C_POSCALCSINGLE, waitSync=True)
        
        return self.readValue(self.R_POSITION)


    def isActive (self):
        #return self.statusBits(self.S_ENABLED, self.S_FOCUSINGACTIVE)
        return False

    def stop (self):
        pass


    class FOCus (Controlling, Leaf):
        '''
        Autofocus control.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('command', type=self.parent.Commands, default=self.parent.C_SINGLE)

        def run (self, command):
            try:
                self.parent.setFocus(command, waitSync=False)
            except NextReply, e:
                leaf, method, args, opts = e.args
                raise NextReply(self, method, args, opts)


    class FOCus_Clear (Controlling, Leaf):
        '''
        Stop Autofocus Control.
        '''

        def run (self):
            self.parent.setFocus(self.parent.C_IDLE, waitSync=True)


    class STOP (Leaf):
        '''
        Stop  continuous autofocus
        '''

        def run (self):
            self.parent.setFocus(self.parent.C_DISABLE, waitSync=True)



    class FOCus_Query (Observing, Leaf):
        '''
        Read current autofocus command value
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('command', type=self.parent.Commands)

        def run (self):
            return self.parent.getFocus()


    class FocusAXIS_Set (Controlling, Leaf):
        '''
        Specify which motion axis is being controlled by this autofocus axis.
        This affects how input arguments are scaled.
        '''

        def run (self, axis=str):
            a, = self.parent.parent.getAxisSelection((axis,))
            self.parent.focusAxis = a


    class FocusAXIS_Clear (Controlling, Leaf):
        '''
        Remove any specification about what motion axis is being conrolled by
        this autofocus axis.  After this, all coordinates will be unscaled.
        '''

        def run (self):
            self.parent.focusAxis = None


    class FocusAXIS_Query (Observing, Leaf):
        '''
        Return the name of any motion axis being controlled by this autofcus axis.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('axis', type=str, default="-")

        def run (self):
            if self.parent.focusAxis:
                return self.parent.focusAxis.name


    class POSition (LLACAxis.POSition):
        '''
        Move to the specified autofocus coordinate
        '''

        def declareInputs (self):
            LLACAxis.POSition.declareInputs(self)
            self.addInput('continuous', type=bool, named=True, default=False)


    class POSition_Query (Observing, Leaf):
        '''
        Return the current autofocus position/slope.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('calculate', type=bool, default=False,
                          description="(Re-)calculate PSD position.  With this option, the laser "
                          "is briefly turned on in order to get an accurate position reading; "
                          "however doing so may interfere with any concurrent optical reading.")

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('position', type=float, units='steps')

        def run (self, calculate=False):
            return self.parent.getRawPosition(calculate=calculate)
    



class LLACMotionControlBranch (LLACMotionBase):

    axisTypes = {
        None         : LinearMotionAxis,
        'linear'     : LinearMotionAxis,
        'rotational' : RotationalMotionAxis }
    
    Sections = (ReferenceSection,) = ("Reference Positions",)
    Sections = LLACMotionBase.Sections + Sections


    class REFerence_Set (MotionControlLeaf):
        '''
        Set reference positions for subsequent moves.
        '''

        SupportedType = LinearMotionAxis

        def declareInputs (self):
            MotionControlLeaf.declareInputs(self)
            self.addInput('save', type=bool, named=True, default=True,
                          description='Save the updated reference for to persistent storage.')

            self.addInput('steps', type=bool, default=False, named=True,
                          description='Coordinates are given in raw motor counts, '
                          'irrespective of scaling')

            self.addInput('index', type=int, default=1, range=(1, TOTAL_REFERENCES), named=False)

        def addAxisInputs (self, axis):
            self.addInput(axis.name, type=float, default=None, named=True)

        def removeAxisInputs (self, axis):
            self.removeInput(axis.name)

        def run (self, save=True, steps=False, index=int, *values):
            values = list(values)
            for (axis, value) in zip(self.getSupportedAxes(), values):
                if value is not None:
                    counts = axis.toRawPosition(value, steps=steps, reference=0)
                    axis.setReference(index, counts, save=save)


    class REFerence_Clear (MotionControlLeaf):
        '''
        Clear the reference position for subsequent moves.
        '''

        SupportedType = LinearMotionAxis

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('save', type=bool, named=True, default=True,
                          description='Save the updated reference for to persistent storage.')

            self.setInput('index', type=int, default=None, range=(1, TOTAL_REFERENCES),
                          named=False,
                          description='Reference index; if not provided, clear all references')

        def declareAxisInputs (self):
            pass

        def run (self, save=True, index=int):
            for axis in self.getSupportedAxes():
                axis.clearReference(index, save=save)


    class REFerence_Query (MotionQueryLeaf):
        '''Read reference positions for axes within this motion control system.'''

        SupportedType = LinearMotionAxis

        def declareInputs (self):
            MotionQueryLeaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False, named=True,
                          description='Return coordinates as raw motor counts, '
                          'rather than scaled steps')
            self.setInput('index', type=int, default=1, range=(1, TOTAL_REFERENCES), named=False)

        def addAxisOutputs (self, axis):
            self.addOutput(axis.name, type=float, named=True, format="%s")

        def removeAxisOutputs (self, axis):
            self.removeOutput(axis.name)

        def run (self, steps=False, index=int):
            format = ("%f", "%d")[steps]
            refs = [ axis.fromRawPosition(axis.getReference(index), steps=steps, reference=0)
                     for axis in self.getSupportedAxes() ]

            return tuple([format%ref for ref in refs])



    class POSition_Query (MotionQueryLeaf):
        '''
        Return the axis coordinates of the current position
        '''

        def declareInputs (self):
            MotionQueryLeaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False, named=True,
                          description='Return position as raw motor counts, '
                          'not scaled coordinates')

            self.setInput('absolute', type=bool, default=False, named=True,
                          description='Return absolute position, '
                          'irrespective of the current default position reference.')
                          
            self.setInput('reference',
                          type=int, range=(0, TOTAL_REFERENCES), default=None, named=True,
                          description='Return position relative to the specified reference. '
                          'If not provided, the current active position reference is used. '
                          'If 0, the absolute position is returned.')

            self.setInput('cached',
                          type=bool, default=True, named=True,
                          description='Return cached position if available')

        def addAxisOutputs (self, axis):
            self.addOutput(axis.name, type=float, default=None, named=True, units='steps')

        def run (self, steps=False, absolute=False, reference=None, cached=True, *axes):
            
            axes    = self.parent.getAxisSelection(axes) or self.getSupportedAxes()
            poslist = [ (axis.name,
                         axis.getPosition(steps=steps,
                                          absolute=absolute,
                                          reference=reference,
                                          cached=cached))
                         for axis in axes ]
            return dict(poslist)



class LLACMotionControlWithProfileBranch (LLACMotionControlBranch):

    axisTypes = {
        None         : LinearMotionAxis,
        'linear'     : LinearMotionAxis,
        'rotational' : RotationalMotionAxis,
        'autofocus'  : AutoFocusAxis,
        'surface'    : SurfaceAxis }


    class PROFile (LLACMotionProfileBranch):
        pass


branchTypes['Motion'] = LLACMotionControlBranch
branchTypes['MotionWithProfile'] = LLACMotionControlWithProfileBranch

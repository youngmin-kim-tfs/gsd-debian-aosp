########################################################################
### FILE:       scpiFileBranch.py
### PURPOSE:    File operations
### AUTHOR:     Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from SysConfig          import sysconfig
from commandParser      import QUOTE_ALWAYS, parser
from scpiBase           import Hidden
from scpiBranch         import branchTypes
from scpiExceptions     import RunError, ComponentError, ReturnCall
from scpiFileContexts   import Context, ContextSchemes, Location, \
    PermissionScopes, FilePermissions, FilePermissionMasks, P_READ, P_WRITE, P_EXECUTE, \
    FileOps, OP_READ, OP_WRITE, OP_APPEND, \
    FileTypes, FOLDER, ANY, \
    AttributeFile, NotSupported, \
    IncludeSpec, INCL_VISIBLE, INCL_ALL
from scpiFilesystemBase import FilesystemBase, FilesystemLeaf
from scpiFullBranch     import FullBranch
from scpiLeaf           import Leaf, Administrative, Controlling, Observing, Background
from scpiSession        import AccessLevels, OBSERVER, CONTROLLER, ADMINISTRATOR
from subscription       import warning, info, debug
from threadControl      import checkThread
from scpiExceptions     import NextReply

from base64             import encodestring, decodestring
from binascii           import Error as B64DecodeError
from cStringIO          import StringIO
from config             import Config
from fnmatch            import filter as fnfilter
from gzip               import GzipFile
from stat               import ST_MODE, ST_MTIME, ST_SIZE, S_ISREG, S_ISDIR, S_ISLNK
from time               import localtime, timezone, altzone, time
from urlparse           import urlsplit
from zipfile            import ZipFile, ZipInfo, BadZipfile, ZIP_DEFLATED, ZIP_STORED
from hashlib            import md5, sha256, sha1, sha512, sha384, sha224
import zlib

import errno, os, os.path


Encodings = {None:True, "plain":False, "base64":True}

class Base64Stream (object):
    pending   = None
    position  = 0

    linesize  = 80 - 1
    linechunk = linesize / 4 * 3
    chunksize = 1024 * linechunk
    lastinstance = 0

    def __init__ (self, fp):
        self.original = fp
        Base64Stream.lastinstance += 1
        self.instance = self.lastinstance

    def __del__ (self):
        self.close()

    def tell (self):
        return self.position

    def write (self, data):
        if self.pending is None:
            self.pending = []
            self.plength = 0

        self.pending.append(data)
        self.plength  += len(data)
        self.position += len(data)

        while self.plength >= self.chunksize:
            self._send(self.chunksize)

    def cleanup (self):
        if self.pending:
            self._send(self.plength)

    def close (self):
        self.cleanup()
        #self.original.close()

    def flush (self):
        pass
        #self.original.flush()

    def _send (self, length):
        buf = ""
        while len(buf) + len(self.pending[0]) < length:
            buf += self.pending.pop(0)

        slice = self.pending[0]
        bite  = length - len(buf)
        buf  += slice[:bite]
        self.pending[0] = slice[bite:]

        self.plength -= length
        string = encodestring(buf)
        self.original.write(string)



class PlainStream (object):
    position  = 0
    chunksize = 8192

    def __init__ (self, fp):
        self.original = fp

    def tell (self):
        return self.position

    def write (self, data):
        self.original.write(data)
        self.position += len(data)

    def cleanup (self):
        pass

    def close (self):
        self.cleanup()
        #self.original.close()

    def flush (self):
        pass


class FileStreamLeaf (FilesystemLeaf):

    def read (self, fp, size, blocking=True, oneline=False, timeout=0):
        if not blocking and hasattr(fp, "fileno"):
            buf = bytearray()
            fd  = fp.fileno()
            inp, outp, errp = [ fd ], [], []

            for count in xrange(size):
                ins, outs, errs = select(inp, outp, errp, timeout)
                if not ins:
                    break
                buf.extend(os.read(fd, 1))

            return str(buf)
        elif oneline:
            return fp.readline(size)
        else:
            return fp.read(size)


    def sendfile (self, outputstream, inputfile, chunksize=8192, block=True, oneline=False, timeout=0):
        end = False
        while not end:
            buf = self.read(inputfile, chunksize, block, oneline, timeout)
            end = (len(buf)==0, len(buf) < chunksize)[block]
            if oneline and buf.endswith(("\r", "\n")):
                end = True
                buf = buf.rstrip("\r\n")

            outputstream.write(buf)

        inputfile.close()
        outputstream.cleanup()


    def startStream (self, loc, opener, streamer,
                     ignoreMissing=False, runTriggers=True, base64=True):

        self.enterLocations(loc)
        try:
            method, args, kwargs = opener
            streamerargs = method(*args, **kwargs)

        except EnvironmentError as e:
            self.exitLocations(loc)
            if not ignoreMissing:
                raise
            return ""

        except Exception as e:
            self.exitLocations(loc)
            raise

        else:
            method, args, kwargs = streamer

            if isinstance(streamerargs, tuple):
                args += streamerargs
            elif isinstance(streamerargs, dict):
                kwargs.update(streamerargs)
            else:
                args += (streamerargs,)

            raise ReturnCall(self, self.sendStream, (loc, runTriggers, base64, method, args, kwargs), {})


    def sendStream (self, outputstream, loc, runTriggers, base64, method, args, opts):
        if base64:
            stream = Base64Stream(outputstream)
        else:
            stream = PlainStream(outputstream)

        try:
            return method(stream, *args, **opts)
        finally:
            self.exitLocations(loc)



_compression = {
    "STORE"  : ZIP_STORED,
    "DEFLATE": ZIP_DEFLATED,
    None     : ZIP_DEFLATED}



class _ZipLeaf (FilesystemLeaf):

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput("all",
                      description=
                      "Include ALL paths (also hidden/'dot' files)")
        self.setInput("prepend",
                      description=
                      "Inserted before each file name in the ZIP file/stream.")


    def raiseError (self, e):
        raise e

    ZIP_EPOCH = (1980, 1, 1, 0, 0, 0, 0, 0, 0)



    def getZipItems (self, loc, paths, show=INCL_VISIBLE, include=("*",), exclude=()):
        items     = []
        includes  = [ pattern for pattern in include if pattern ]
        excludes  = [ pattern for pattern in exclude if pattern ]

        for pattern in paths or ("",):
            for candidate in loc.glob(pattern, include=show):
                cparts = candidate.parts[len(loc.parts):]

                if candidate.isdir():
                    d = candidate.context.join(*cparts)
                    items.append((d, includes, excludes))

                elif candidate.isreg():
                    d = candidate.context.join(*cparts[:-1])
                    f = cparts[-1]
                    items.append((d, (f,), ()))

        return items


    def zip (self, output, loc, items, prepend, append=False, compression=ZIP_DEFLATED, allowZip64=True):
        mode = append and "a" or "w"

        try:
            zipfile = ZipFile(output, mode, compression, allowZip64)
        except RuntimeError:
            warning("Unable to create ZIP file %s with DEFLATE compression, using STORE instead."%(output,))
            zipfile = ZipFile(output, mode, ZIP_STORED)

        with zipfile:
            for path, includes, excludes in items:
                self.zipdir(zipfile, loc, path, includes, excludes, prepend)

        zipfile.close()
        output.close()


    def zipdir (self, zipfile, loc, folder, includes, excludes, prepend):
        ### Filter folder contents according to includes and excludes
        names   = loc.context.listdir(loc.filepath(folder))

        filteredNames = set()
        for mask in includes:
            filteredNames |= set(fnfilter(names, mask))
        for mask in excludes:
            filteredNames -= set(fnfilter(names, mask))

        for name in sorted(filteredNames):
            checkThread()
            relpath  = loc.context.join(folder, name)
            zippath  = prepend+relpath
            fullpath = loc.filepath(relpath)
            st       = loc.context.stat(fullpath)

            if S_ISDIR(st[ST_MODE]):
                ### This is a folder; recurse into subfolders
                self.zipdir(zipfile, loc, relpath, includes, excludes, prepend)

            else:
                ### Add file to ZIP file
                mtime   = max(localtime(st[ST_MTIME]), self.ZIP_EPOCH)
                data    = loc.context.open(fullpath).read()
                zipinfo = ZipInfo(filename=relpath, date_time=mtime)

                zipinfo.compress_type = zipfile.compression
                zipinfo.external_attr = (st[ST_MODE] & 0xFFFF) << 16
                zipfile.writestr(zipinfo, data)



class _UnzipLeaf (FilesystemLeaf):
    class UnzipError (RunError):
        pass

    class BadFileInZip (RunError):
        "Bad file in zip archive: %(filename)r"

    class BadZipFile (RunError):
        "Bad ZIP contents: %(filename)r"


    def openZip (self, inputfile, zipname):
        try:
            zipfile = ZipFile(inputfile)
        except RuntimeError, e:
            raise self.UnzipError(e)
        except BadZipfile, e:
            raise self.BadZipFile(filename=zipname)

        return zipfile


    def listzip (self, zipfile, paths=(), verify=False, includes=("*",), excludes=()):
        if verify:
            zipfile.testzip()

        allnames = zipfile.namelist()
        if paths:
            names = set()
            for mask in paths:
                names |= set(fnfilter(allnames, mask))
        else:
            names = allnames

        filteredNames = set()
        for mask in includes:
            filteredNames |= set(fnfilter(names, mask))
        for mask in excludes:
            filteredNames -= set(fnfilter(names, mask))

        return [name for name in allnames if name in filteredNames]




    def unzip (self, inputfile, zipname, target, paths, strip="", verify=False, includes=("*",), excludes=()):
        with self.openZip(inputfile, zipname) as zipfile:
            names = self.listzip(zipfile, paths, verify, includes, excludes)

            lastdir = None
            for zippath in names:
                filepath = zippath
                if filepath.startswith(strip):
                    filepath=filepath[len(strip):]

                isdir    = filepath.endswith(("/", "\\"))
                filepath = target.filepath(filepath)

                if not isdir:
                    folder = target.context.dirname(filepath)
                    if (folder != lastdir) and not target.context.isdir(folder):
                        target.context.mkdirs(folder)
                        lastdir = folder

                    text = zipfile.read(zippath)
                    fp = target.context.open(filepath, mode=OP_WRITE)
                    fp.write(text)
                    fp.close()

                elif (target.path != lastdir) and not target.context.isdir(filepath):
                    target.context.mkdirs(filepath)
                    lastdir = filepath



    def unzipfile (self, inputfile, zipname, filepath):
        with self.openZip(inputfile, zipname) as zipfile:
            try:
                return zipfile.read(filepath)
            except EnvironmentError, e:
                raise self.IOError(errno=e.errno, message=e.args[-1], filename=e.filename)



class _FileWriteLeaf (FilesystemLeaf):
    class DecodeError (ComponentError):
        pass

    class NoSuchUser (RunError):
        "No such user: %(owner)s"

    class NoSuchGroup (RunError):
        "No such group: %(group)s"

    class NoSuchMode (RunError):
        "No such %(scope)s permission: %(mode)s"


    def declareProps (self):
        if "owner" in self.inputMap:
            self.setInput("owner", type=str, named=True)

        if "group" in self.inputMap:
            self.setInput("group", type=str, named=True)

        for scope, who in enumerate(PermissionScopes):
            if who in self.inputMap:
                items = [(what, perm)
                          for (perm, what) in enumerate(FilePermissions)
                          if perm in FilePermissionMasks[scope]]
                self.setInput(who, type=dict(items), named=True, split=",")


    def decode (self, data):
        try:
            return decodestring(data)
        except B64DecodeError, e:
            raise self.DecodeError(e)




class FilesystemBranch (FilesystemBase, FullBranch):
    """
    File system operations
    """

    defaultContext = "default"


    class CHecKSUM_Query(Observing, FilesystemLeaf):
        """
        Calculate the checksum of a given file
        """
        buf_size = 8192

        def declareInputs(self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('filename', type=str,
                          description='Path to the file to calculate the md5 checksum')
            self.setInput('asynchronous', type=bool, default=False,
                          description='True if this command should run as an asynchronous command')
            self.setInput('method', type=str, named=True, default="MD5",
                          description='The algorithm used to calculate the checksum [CRC32 | ALDER32 | MD5 | SHA1 | SHA224 | SHA256 | SHA384 | SHA512]')
            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                                      "for the source or destination contexts. This may be useful "
                                      "where the hook(s) are executed manually (for instance to "
                                      "mount a removable storage once before a large batch operation "
                                      "and keep it mounted until completed).")

        def declareOutputs(self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('checksum', type=int)

        def performCRC32(self, _session, filename, skipTriggers=False):
            src = self.openLocation(filename, _session, P_READ, not skipTriggers)
            fp = src.open(mode=OP_READ)

            hash = 0
            try:
                data = fp.read(self.buf_size)
                while data:
                    hash = zlib.crc32(data, hash)
                    data = fp.read(self.buf_size)
            finally:
                fp.close()

            return "%08X" % (hash & 0xFFFFFFFF)

        def performAdler32(self, _session, filename, skipTriggers=False):
            src = self.openLocation(filename, _session, P_READ, not skipTriggers)
            fp = src.open(mode=OP_READ)

            hash = 0
            try:
                data = fp.read(self.buf_size)
                while data:
                    hash = zlib.adler32(data, hash)
                    data = fp.read(self.buf_size)
            finally:
                fp.close()

            return "%08X" % (hash & 0xFFFFFFFF)

        def run(self, _session, filename, method="MD5", skipTriggers=False, asynchronous=False):

            if asynchronous:
                raise NextReply(self, self.run, (_session, filename, method, skipTriggers, False), {})

            method = method.lower()

            if method == "md5":
                m = md5()
            elif method == "sha1":
                m = sha1()
            elif method == "sha224":
                m = sha224()
            elif method == "sha256":
                m = sha256()
            elif method == "sha384":
                m = sha384()
            elif method == "sha512":
                m = sha512()
            elif method == "crc32":
                return self.performCRC32(_session, filename, skipTriggers)
            elif method == "alder32":
                return self.performAdler32(_session, filename, skipTriggers)
            else:
                raise NotSupported, "This algorithm is not support %s" % method

            src = self.openLocation(filename, _session, P_READ, not skipTriggers)
            fp = src.open(mode=OP_READ)

            try:
                data = fp.read(self.buf_size)
                while data:
                    m.update(data)
                    data = fp.read(self.buf_size)
            finally:
                fp.close()

            return m.hexdigest()


    class EXISts_Query (Observing, FilesystemLeaf):
        """
        Return a boolean (True or False) indicating whether or not the
        specified file exists.
        """
        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("type",
                          type=FileTypes,
                          named=True,
                          default=ANY)

            self.setInput("pattern",
                          repeats=(1,None))


        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput("exists", type=bool)

        def run (self, _session, type, all=True, skipTriggers=False, *pattern, **attributes):
            include = (INCL_VISIBLE, INCL_ALL)[all]
            matches, contexts =  self.glob(pattern, _session, P_READ, include=include,
                                           filetype=type, attributefilter=attributes,
                                           verify=True, ignoreMissing=True, runTriggers=not skipTriggers)

            self.exitContexts(contexts, runTriggers=not skipTriggers)
            return bool(matches)


    class ACCess_Query (Observing, FilesystemLeaf):
        """
        Return True if the specified location is writable.
        If location is omitted, use the root of the default
        context for this branch.
        """

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput("allowed", type=bool)

        def run (self, _session, ignoreMissing=False, skipTriggers=False, mode=FilePermissions, location=""):
            with self.openLocation(location, _session, runTriggers=not skipTriggers) as loc:
                required = (loc.context.read, loc.context.write)[mode == P_WRITE]
                if _session.accessLevel < required:
                    return False
                else:
                    return loc.access(mode, ignoreMissing)


    class LIST_Query (Observing, FilesystemLeaf):
        """
        List files and folders that match the specified pattern(s).
        If no pattern is given, list all files and folders at the
        top level of the default context for this branch.

        The mask may consist of the following components:
          - A context mask, followed by a colon.  If not specified,
            the default context is assumed.

          - Zero or more subdirectory masks, separated by one of
            the valid directory separators, "/", "\\", and ";".

          - A filename mask.  If specified, restricts the list to
            matching filenames; otherwise all items in the given
            subdirectory are listed.

        Each mask may contain the following special characters:
          ?         - matches any single character
          *         - matches zero or more characters
          [  ] - matches any character whose ASCII value

    Examples:
      - Let us say that "default:" is the default context for
        the FILe branch.  The following commands are equivalent,
        and lists all files and folders in the root folder of that
        context:
            C: FILe:LIST?
            C: FILe:LIST? -directory *
            C: FILe:LIST? default:.
            C: FILe:LIST? -directory default:*
            C: FILe:LIST? .
            C: FILe:LIST? default:

      - Get a list of all files and folders in all context:
            C: FILe:LIST? *:

      - Get a list of filenames that contain the word "upgrade" within
        the "Scripts" subdirectory of every context that starts with
        "UPGR":
            C: FILe:LIST? UPGR*:Scripts/*upgrade*
            S: OK ... <multiline.reply>
            s: UPGRADE:Scripts/upgrade.sh
            s: </multiline.reply>

      - Get a list of files in the EXPERIMENTS: context where a "state"
        attribute exists with a value of either "ended" or "collected":
            C: FILe:LIST? -state=ended,collected
        """

        sortkeys = "name", "type", "size", "mtime", "atime", "ctime"
        S_NAME, S_SIZE, S_TYPE, S_MTIME, S_ATIME, S_CTIME = range(len(sortkeys))

        class NoContextMatch (RunError):
            "No match for file context %(mask)r"


        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)

            self.setInput("asynchronous", type=bool, named=True, default=False,
                          description="Runs this command as an asynchronous task, useful for remote / virtual file contexts")

            self.setInput("ignoreMissing", type=bool, named=True, default=False,
                          description="Do not complain if no files match the specified "
                          "pattern(s), keep going to the next.")

            self.setInput("directory",
                          type=bool,
                          default=False,
                          description="Include directory matches in the "
                          "result, rather than descending into them.")

            self.setInput("include",
                          type=IncludeSpec,
                          named=True,
                          default=INCL_VISIBLE,
                          split=",",
                          description="Include visible files, hidden files, names that  begin with '.', "
                          "the current folder %r and parent folder %r, "
                          "and shares/files containing a '$' character, respectively."%
                          (os.path.curdir, os.path.pardir))

            self.setInput("all",
                          type=bool,
                          named=True,
                          default=False,
                          description="Include all files, not just visible ones. "
                          "Equivalent to -include=%s."%(",".join(IncludeSpec)))

            self.setInput("verbose",
                          type=bool,
                          default=False,
                          description="Return a verbose listing, where "
                          "additional information is appended to each "
                          "item in the result: Type (file or folder), "
                          "last modification time, last access time, "
                          "and any assigned attributes.")

            self.setInput("strip",
                          type=str,
                          default=None,
                          description="Strip the supplied text from the "
                          "end of each matching filename.  By default, "
                          "the entire filename is provided.")

            self.setInput("basename",
                          type=bool,
                          default=False,
                          description="List only the 'base name' of each file, "
                          "i.e. remove the path leading up to it")

            self.setInput("dirsuffix",
                          type=str,
                          named=True,
                          default=None,
                          description=
                          "Appended to directory names in the list. "
                          "For non-verbose listings, the default is \"/\".")

            self.setInput("unique",
                          type=bool,
                          default=False,
                          description="Return duplicate names only once. "
                          "Duplicate names may occur with the 'strip' or 'basename' options, "
                          "or if more than one matching pattern are given.")

            self.setInput("type",
                          type=FileTypes,
                          default=ANY,
                          named=True,
                          description="List files, folders, or both")

            self.setInput("sort",
                          type=self.sortkeys,
                          named=True,
                          split=",",
                          default=[self.S_NAME],
                          description="Sort items by the specified attribute(s), "
                          "in order of precedence")

            self.setInput("reverse",
                          type=bool,
                          default=False,
                          named=True,
                          description="Reverse sort order")

            self.setInput("max",
                          type=int,
                          default=None,
                          named=True,
                          description="Limit the output to this many entries")

            self.setInput("utc", type=bool, named=True, default=False,
                          description="Force Universal timestamps, even if "
                          "'localtime' is specified in filesystem context.")

            self.setInput("attributes",
                          description=
                          "Any number of attributes and masks, where each "
                          "attribute must exist and match the specified "
                          "mask.  Multiple alternate masks may be "
                          "separated by commas.")

            self.setInput("patterns",
                          description="Shell-style pattern indicating "
                          "what items to list")


        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput("list", type=list, default=[""],
                           description="List of files and/or folders within "
                           "the specfied location(s)")


        def run (self, _session, asynchronous=False, ignoreMissing=False,
                 directory=False, include=IncludeSpec, all=False, verbose=False,
                 strip=None, basename=False, dirsuffix=None, unique=False,
                 type=FileTypes, sort=sortkeys, reverse=False, max=None,
                 utc=False, skipTriggers=False,
                 *patterns, **attributes):

            if asynchronous:
                raise NextReply(self, self.run,
                                (_session, False, ignoreMissing, directory, include, all, verbose,
                                 strip, basename, dirsuffix, unique, type, sort, reverse, max, utc,
                                 skipTriggers) + patterns, {})

            if all:
                include = INCL_ALL

            matches, contexts = self.glob(patterns, _session, P_READ,
                                          filetype=type, attributefilter=attributes,
                                          verify=True, ignoreMissing=ignoreMissing,
                                          runTriggers=not skipTriggers,
                                          descend=not directory,
                                          include=include)

            try:
                results = []
                names   = set()

                if dirsuffix is None and not verbose and not basename:
                    dirsuffix = "/"

                for key in reversed(sort):
                    if key == self.S_NAME:
                        matches.sort(key=lambda loc: loc.path, reverse=reverse)
                    else:
                        sortkey = self.sortkeys[key]
                        matches.sort(key=lambda loc: loc.getDetails()[sortkey], reverse=reverse)


                err = None
                for loc in matches:
                    if basename:
                        name = loc.basename()
                    else:
                        name = loc.vfspath(sanitized=False)

                    if strip and name.endswith(strip):
                        name = name[:-len(strip)]

                    if dirsuffix and loc.isdir():
                        name += dirsuffix

                    if unique:
                        if name in names:
                            continue
                        names.add(name)


                    if verbose:
                        try:
                            results.append(self.listverbose(loc, name, utc))
                        except EnvironmentError, e:
                            if not err:
                                err = e
                    else:
                        results.append(name)

                if results:
                    return results[:max]
                elif err:
                    raise err
            finally:
                self.exitContexts(contexts, runTriggers=not skipTriggers)


        def listverbose (self, loc, name, utc):
            fields = [ parser.protectString(name, quoting=QUOTE_ALWAYS) ]
            try:
                details = loc.getDetails(localtime=not utc, withAttributes=True, followLinks=False)
            except OSError, e:
                details = loc.getDetails(localtime=not utc, withAttributes=True, followLinks=True)
                details.update(filetype="brokenlink", size=0)

            details.update(loc.context.permissionStrings(**details))

            dynamicKeys = set(details) - set(loc.context.StaticAttributes)
            keys = list(loc.context.StaticAttributes) + sorted(dynamicKeys)

            for key in keys:
                try:
                    value = details[key]
                except KeyError:
                    pass
                else:
                    if isinstance(value, list):
                        value = ",".join(value)
                    fields.append("-%s=%s"%(key, parser.protectString(str(value))))

            return " ".join(fields)



    class LIST_Enumerate (LIST_Query):
        """
        Return files and folders matching the specified pattern(s).
        If no pattern is given, list all files and folders at the
        top level of the default context for this branch.

        The mask may consist of the following components:
          - A context mask, followed by a colon.  If not specified,
            the default context is assumed.

          - Zero or more subdirectory masks, separated by one of
            the valid directory separators, "/", "\\", and ";".

          - A filename mask.  If specified, restricts the list to
            matching filenames; otherwise all items in the given
            subdirectory are listed.

        Each mask may contain the following special characters:
          ?         - matches any single character
          *         - matches zero or more characters
          [  ] - matches any character whose ASCII value


        """

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput("items", type=str, repeats=(0, None),
                           description="Files and/or folders within "
                           "the specfied location(s)")

        def execute (self, args, kwargs, argmap):
            return tuple(self.run(*args, **kwargs) or ())


    class READ_Query (Observing, FileStreamLeaf):
        """
        Read a file and return its contents.
        """

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("encoding", named=True, type=Encodings)
            self.setInput("oneline", type=bool, named=True, default=False,
                          description="Read a single line and return. Useful mainly for devices, like serial ports.")

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput("text", type=str, default=None)

        def run (self, _session, noblock=False, oneline=False, encoding=Encodings, ignoreMissing=False, skipTriggers=False, filename=str):
            loc = self.openLocation(filename, _session, P_READ, not skipTriggers)

            chunksize = (PlainStream.chunksize, Base64Stream.chunksize)[encoding]

            return self.startStream(loc,
                                    opener=(loc.open, (), dict(mode=OP_READ)),
                                    streamer=(self.sendfile, (), dict(chunksize=chunksize, block=not noblock, oneline=oneline)),
                                    ignoreMissing=ignoreMissing,
                                    runTriggers=not skipTriggers,
                                    base64=encoding)



    class WRITe (Observing, _FileWriteLeaf):
        """
        Write the provided text to the specified file.

        Write the data to the specific file, in plain or base64 encoding.
        Configurable parameters include ownership, group and file permissions.
        """

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("encoding", named=True, default=True)
            self.setInput("utc", type=bool, named=True, default=False,
                          description="Force Universal timestamps, even if "
                          "'localtime' is specified in filesystem context.")

            self.declareProps()

        def run (self, _session, encoding=Encodings,
                 owner=None, group=None, uperm=None, gperm=None, wperm=None,
                 append=False, skipTriggers=False,
                 utc=False, filename=str, data=str):


            if encoding:
                data = self.decode(data)

            with self.openLocation(filename, _session, P_WRITE, not skipTriggers) as loc:
                fp = loc.open(mode=(OP_WRITE, OP_APPEND)[append])
                fp.write(data)
                fp.close()
                loc.setPermissions(owner, group, uperm, gperm, wperm)



    class REMove (Observing, FilesystemLeaf):
        """
        Remove the specified file(s) and/or folder(s).
        """


        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)

            self.setInput("ignoreMissing", type=bool, named=True, default=False,
                          description="Do not complain if no files match the specified "
                          "pattern(s), keep going to the next.")

            self.setInput("recursive", type=bool, named=True, default=False,
                          description="If specified location is a directory, "
                          "recursively remove the directory tree.")

            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the source or destination contexs. This may be useful "
                          "where the hook(s) are executed manually (for instance to "
                          "mount a removable storage once before a large batch operation "
                          "and keep it mounted until completed).")

            self.setInput("type",
                          type=FileTypes,
                          default=ANY,
                          named=True,
                          description="Match files, folders, or both")

            self.setInput("attributes", type=str, split=",",
                          description=
                          "Any number of attributes and masks, where each must exist "
                          "and  match the specified mask. Multiple alternate masks may "
                          "be separated by commas.")

            self.setInput("patterns",
                          description="Shell-style pattern indicating what items to list. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")


        def run (self, _session, ignoreMissing=False, recursive=False,
                 skipTriggers=False, type=FileTypes, all=False, *patterns, **attributes):

            found = False
            include = (INCL_VISIBLE, INCL_ALL)[all]
            matches, contexts = self.glob(patterns, _session, P_WRITE,
                                          filetype=type, attributefilter=attributes,
                                          ignoreMissing=ignoreMissing,
                                          runTriggers=not skipTriggers,
                                          include=include)
            try:
                for loc in matches:
                    loc.remove(recursive=recursive, ignoreMissing=ignoreMissing)
            finally:
                self.exitContexts(contexts, runTriggers=not skipTriggers)


    class MOVe (Observing, Background, FilesystemLeaf):
        """
        Move the given file or folder.
        """

        def declareInputs(self):
            FilesystemLeaf.declareInputs(self)

            self.setInput("replaceExisting", type=bool, named=True, default=False,
                          description="If destination already exists as a file, "
                          "allow file specified as source to replace it.")

            self.setInput("createParents", type=bool, named=True, default=False,
                          description="If the parent folder of the destination "
                          "does not exist, recursively create it.")

            self.setInput("utc", type=bool, named=True, default=False,
                          description="Force Universal timestamps, even if "
                          "'localtime' is specified in filesystem context.")

            self.setInput("attributes", type=bool, named=True, default=True,
                          description="Preserve custom attributes of source.")

            self.setInput("preserve", type=bool, default=None, named=True,
                          description="Equivalent to '-attributes'.")

            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the source or destination contexs. This may be useful "
                          "where the hook(s) are executed manually (for instance to "
                          "mount a removable storage once before a large batch operation "
                          "and keep it mounted until completed).")

            self.setInput("source", type=str,
                          description="Source location.  This must exist as a plain file, "
                          "Unless the '-recursive' option is given. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")

            self.setInput("destination", type=str,
                          description="Target location. This must not already exist, "
                          "except if it is a non-directory file and the '-replaceExisting' "
                          "option is given. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")


        def run (self, _session, replaceExisting=False, createParents=False, utc=False,
                 attributes=True, preserve=None, skipTriggers=False,
                 source=str, destination=str):

            if preserve is not None:
                attributes = preserve

            src = self.openLocation(source, _session, P_READ, not skipTriggers)
            dst = self.openLocation(destination, _session, P_WRITE, not skipTriggers)
            self.enterLocations(src, dst)

            try:
                self.checkTarget(src, dst,
                                 replaceExisting=replaceExisting,
                                 createParents=createParents,
                                 recursive=True)
            except Exception, e:
                self.exitLocations(src, dst)
                raise
            else:
                nextargs = (src, dst, utc)
                if src.context is dst.context:
                    self.next(*nextargs)
                else:
                    return nextargs

        def next (self, src, dst, utc):
            try:
                self.move(src, dst, localtime=not utc)
            finally:
                self.exitLocations(src, dst)



    class COPy (Observing, Background, FilesystemLeaf):
        """
        Copy the given source location to the given target location.
        The target must not already exist, unless "-replaceExisting" is given.
        """

        def declareInputs(self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("replaceExisting", type=bool, named=True, default=True,
                          description="If destination already exists as a file, "
                          "allow file specified as source to replace it.")

            self.setInput("overwrite", type=bool, named=True, default=False,
                          description="If destination already exists as a directory, "
                          "allow its contents to be overwritten with contents from "
                          "the source directory with the '-recursive' option.")

            self.setInput("createParents", type=bool, named=True, default=False,
                          description="If the parent folder of the destination "
                          "does not exist, recursively create it.")

            self.setInput("recursive", type=bool, named=True, default=False,
                          description="If source is a directory, recursively copy "
                          "the directory tree. Unless '-overwrite' is specified, "
                          "the target must not already exist.")

            self.setInput("update", type=bool, named=True, default=False,
                          description="Copy only items that do not already exist on target "
                          "or that are older than the corresponding items on the source.")

            self.setInput("skipExisting", type=bool, named=True, default=False,
                          description="Do not copy items that already exist on target.")

            self.setInput("times", type=bool, default=False, named=True,
                          description="Preserve access and modification time of source.")

            self.setInput("permissions", type=bool, default=False, named=True,
                          description="Preserve ownership and permissions of source.")

            self.setInput("attributes", type=bool, named=True, default=True,
                          description="Preserve custom attributes of source.")

            self.setInput("preserve", type=bool, default=None, named=True,
                          description="Shorthand for '-times', '-permissions', and '-attributes'.")

            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force Universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')

            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the source or destination contexs. This may be useful "
                          "where the hook(s) are executed manually (for instance to "
                          "mount a removable storage once before a large batch operation "
                          "and keep it mounted until completed).")

            self.setInput("source", type=str,
                          description="Source location.  This must exist as a plain file, "
                          "Unless the '-recursive' option is given. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")

            self.setInput("destination", type=str,
                          description="Target location. This must not already exist, "
                          "except if it is a non-directory file and the '-replaceExisting' "
                          "option is given. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")

        def run (self, _session, replaceExisting=False, overwrite=False, createParents=False, recursive=False,
                 update=False, skipExisting=False,
                 times=False, permissions=True, attributes=True, preserve=False, utc=False, skipTriggers=False,
                 source=str, destination=str):

            src = self.openLocation(source, _session, P_READ, not skipTriggers)
            dst = self.openLocation(destination, _session, P_WRITE, not skipTriggers)

            if preserve is not None:
                times = permissions = attributes = preserve

            return (src, dst, replaceExisting, overwrite, createParents, recursive,
                    update, skipExisting, times, permissions, attributes, utc)

        def next (self, src, dst, replaceExisting, overwrite, createParents, recursive,
                  update, skipExisting, times, permissions, attributes, utc):

            with src, dst:
                self.checkTarget(src, dst,
                                 replaceExisting=overwrite or replaceExisting,
                                 overwrite=recursive and (overwrite or update),
                                 createParents=createParents,
                                 recursive=recursive)

                return self.copy(src, dst, recursive,
                                 times=times,
                                 permissions=permissions,
                                 attributes=attributes,
                                 update=update,
                                 skipExisting=skipExisting,
                                 localtime=not utc)


    class LINK (Observing, Background, FilesystemLeaf):
        """
        Create a link to given file
        """

        class CrossContext (RunError):
            '''Links are not supported across context schemes'''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("symbolic", type=bool, named=True, default=False,
                          description="Create symbolic links, not hard links.")

            self.setInput("fallbackToCopy", type=bool, named=True, default=False,
                          description="If an error occurs (e.g. if the underlying "
                          "operating system does not support links, do a copy instead.")

            self.setInput("replaceExisting", type=bool, named=True, default=False,
                          description="If destination already exists as a file, "
                          "allow file specified as source to replace it.")

            self.setInput("overwrite", type=bool, named=True, default=False,
                          description="If destination already exists as a directory, "
                          "allow its contents to be overwritten with contents from "
                          "the source directory with the '-recursive' option.")

            self.setInput("createParents", type=bool, named=True, default=False,
                          description="If the parent folder of the destination "
                          "does not exist, recursively create it.")

            self.setInput("recursive", type=bool, named=True, default=False,
                          description="If source is a directory, recursively copy "
                          "the directory tree, but plain files are linked.  This "
                          "is the only way to create a hard (non-symbolic) link "
                          "of a directory.  Unless '-overwrite' is specified, "
                          "the target directory must not already exist.")

            self.setInput("attributes", type=bool, named=True, default=True,
                          description="Preserve custom attributes of source.")

            self.setInput("preserve", type=bool, default=None, named=True,
                          description="Equivalent to '-attributes'.")

            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the source or destination contexs. This may be useful "
                          "where the hook(s) are executed manually (for instance to "
                          "mount a removable storage once before a large batch operation "
                          "and keep it mounted until completed).")

            self.setInput("source", type=str,
                          description="Source location.  This must exist as a plain file, "
                          "Unless the '-recursive' option is given. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")

            self.setInput("destination", type=str,
                          description="Target location. This must not already exist, "
                          "except if the '-overwrite' option is used, or if it is a "
                          "non-directory file and the '-replaceExisting' option is given. "
                          "See 'HELP? FILESYSTEM' for more information about locations.")


        def run (self, _session, symbolic=False, fallbackToCopy=False,
                 replaceExisting=False, overwrite=False,
                 createParents=False, recursive=False,
                 attributes=True, preserve=None, skipTriggers=False,
                 source=str, destination=str):

            replaceExisting = overwrite or replaceExisting
            if preserve is not None:
                attributes = preserve

            src = self.openLocation(source, _session, P_READ, not skipTriggers)
            dst = self.openLocation(destination, _session, P_WRITE, not skipTriggers)

            self.enterLocations(src, dst)
            try:
                self.checkTarget(src, dst,
                                 replaceExisting=replaceExisting,
                                 overwrite=recursive and overwrite,
                                 createParents=createParents,
                                 recursive=recursive)

                self.link(src, dst, replaceExisting=replaceExisting,
                          symbolic=symbolic, recursive=recursive, attributes=attributes)
            except NotSupported, e:
                if fallbackToCopy:
                    return (src, dst, recursive, attributes)
                else:
                    self.exitLocations(src, dst)
                    raise
            except Exception, e:
                self.exitLocations(src, dst)
                raise


        def next (self, src, dst, recursive, attributes):
            try:
                self.copy(src, dst, recursive=recursive,
                          times=True, permissions=True, attributes=attributes, localtime=False)
            finally:
                self.exitLocations(src, dst)


    class LINK_Query (Observing, FilesystemLeaf):
        """
        Return the target of the specified symbolic link.
        """

        class NotALink (RunError):
            '''Location %(location)r is not a symbolic link'''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('localpath', type=bool, named=True, default=False,
                          description='Return the target name as a local path instead of a virtual location.')

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('target', type=str, default=None)

        def run (self, _session, skipTriggers=False, ignoreErrors=False, localpath=False, location=str):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                if not ignoreErrors or loc.islink():
                    relpath = loc.readlink(localpath=localpath, ignoreErrors=ignoreErrors)
                    if relpath is not None:
                        return loc.vfspath(relpath)


    class SIZe_Query (Observing, FilesystemLeaf):
        """
        Show the size of the given file.
        """

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('filesize', type=int)

        def run (self, _session, skipTriggers=False, filename=str):
            with self.openLocation(filename, _session, P_READ, not skipTriggers) as loc:
                return loc.stat()[ST_SIZE]


    class VolumeSIZe_Query (Observing, FilesystemLeaf):
        '''
        Return available or used space in the specified volume
        '''

        TYPE = ("total", "used", "available")
        (TOTAL, USED, AVAILABLE) = range(len(TYPE))

        UNITS = ("B", "KB", "MB", "GB", "TB")
        (BYTES, KB, MB, GB, TB) = range(len(UNITS))

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("asynchronous", type=bool, named=True, default=False)
            self.setInput("types", type=self.TYPE, named=True, split=",", default=())
            self.setInput("units", type=self.UNITS, named=True)
            self.setInput("named", type=bool, named=True, default=False,
                          description="Return named outputs. By default outputs unnamed "
                          "when specific types are specified.")
            self.setInput("location", type=str, default=None)

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('space', type=tuple, repeats=(0, None))

        def run (self, _session, asynchronous=False, skipTriggers=False, ignoreMissing=False,
                 types=None, units=BYTES, named=False, location=str):

            if asynchronous:
                raise NextReply(self, self.run,
                                (_session, False, skipTriggers, ignoreMissing, types, units,
                                 named, location))

            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                try:
                    total, avail = loc.volsize()
                except EnvironmentError, e:
                    if not ignoreMissing or (e.errno != errno.ENOENT):
                        raise
                else:
                    sizes  = [ total, total-avail, avail ]
                    scaled = [ s/(1024**units) for s in sizes ]

                    if not types:
                        types = range(len(self.TYPE))
                        named = True

                    items = [ ((None, self.TYPE[t])[named], str(scaled[t])) for t in types ]
                    return tuple(items)



    class SPACE_Query (Observing, Hidden, FilesystemLeaf):
        '''
        Deprecated. Please use "VolumeSIZe?" instead.
        '''

        TYPE = ("total", "used", "available")
        (TOTAL, USED, AVAILABLE) = range(len(TYPE))

        UNITS = ("B", "KB", "MB", "GB", "TB")
        (BYTES, KB, MB, GB, TB) = range(len(UNITS))

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("type", type=self.TYPE, default=self.TOTAL)
            self.setInput("units", type=self.UNITS, default=self.BYTES)
            self.setInput("location", type=str, default=None)

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('space', type=int, default=None)

        def run (self, _session, skipTriggers=False, ignoreMissing=False, type=TYPE, units=UNITS, location=str):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                try:
                    total, avail = loc.volsize()
                except EnvironmentError:
                    if not ignoreMissing:
                        raise
                else:
                    sizes = [ total, total-avail, avail ]
                    return sizes[type] / (1024 ** units)



    class TIMe_Query (Observing, FilesystemLeaf):
        '''
        Return last modification, access, and/or creation timestamps of the specified location.
        '''

        _getTime   = { None:             None,
                       'access':         'atime',
                       'modification':   'mtime',
                       'creation':       'ctime' }

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("type", type=self._getTime, split=",", named=True, default=['mtime'],
                          description='Which timestamp to return.  If not specified, '
                          'all 3 timestamps are returned as named outputs.')
            self.setInput("decimals", type=int, default=3, range=(0, None))
            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force Universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs (self)
            self.addOutput('timestamp',
                           type=float,
                           format="%s",
                           repeats=(1, 3),
                           units="seconds since epoch")

        def run (self, _session, type=_getTime, decimals=3, utc=False, skipTriggers=False, filename=str):
            with self.openLocation(filename, _session, P_READ, not skipTriggers) as loc:
                times = loc.getTimes(localtime=not utc)
                outputs = [ "%.*f"%(decimals, times[t]) for t in type ]
                return tuple(outputs)


    class TIMe_Set (Observing, FilesystemLeaf):
        '''
        Modify the access and/or modifiation time of the specified location.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the source or destination contexs. This may be useful "
                          "where the hook(s) are executed manually (for instance to "
                          "mount a removable storage once before a large batch operation "
                          "and keep it mounted until completed).")

            self.setInput("access", type=float, named=True, default=None,
                          description='Last access time')
            self.setInput("modification", type=float, named=True, default=None,
                          description='Last modification time')
            self.setInput("creation", type=float, named=True, default=None, hidden=True,
                          description='Last creation time. Ignored.')

            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')


        def run (self, _session, skipTriggers=False, utc=False, access=None, modification=None, creation=None, location=str):
            with self.openLocation(filename, _session, P_WRITE, not skipTriggers) as loc:
                loc.setTimes(access, modification, creation, localtime=not utc)



    class PATH_Query (Observing, FilesystemLeaf):
        '''
        Return the absolute native filesystem path to the specified
        context/location.  This may be useful for clients who share
        filesystem with the Instrument Server.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('path', type=str)

        def run (self, location=''):
            return self.openLocation(location, runTriggers=False).localpath()


    class UniformResourceIdentifier_Query (Observing, FilesystemLeaf):
        '''
        Return the absolute native filesystem path to the specified
        context/location.  This may be useful for clients who share
        filesystem with the Instrument Server.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('path', type=str)

        def run (self, location=''):
            return self.openLocation(location, runTriggers=False).uri()


    class PERMission_Query (Observing, FilesystemLeaf):
        '''
        Return ownership and permissions on the specified file(s)
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('mode', type=int, named=True)
            self.addOutput('uid', type=int, named=True)
            self.addOutput('gid', type=int, named=True)
            self.addOutput('owner', type=str, named=True, default=None)
            self.addOutput('group', type=str, named=True, default=None)

            for who, scope in enumerate(PermissionScopes):
                self.addOutput(scope,
                               type=FilePermissions,
                               split=",", named=True, default=None)


        def run (self, _session, skipTriggers=False, location=str):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                return loc.getDetails(followLinks=True)


    class PERMission_Set (Observing, _FileWriteLeaf):
        '''
        Set ownership and/or permissions of the specified file.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.declareProps()


        def run (self, _session, skipTriggers=False, mode=None,
                 uid=None, gid=None, owner=None, group=None, uperm=None, gperm=None, wperm=None,
                 location=str):

            with self.openLocation(location, _session, P_WRITE, not skipTriggers) as loc:
                details = loc.getDetails()
                perms = dict(uperm=uperm, gperm=gperm, wperm=wperm)
                for key, value in perms.items():
                    if value is None:
                        perms[key] = details.get(key)

                loc.setPermissions(owner, group, **perms)


    class BaseName_Query (Observing, FilesystemLeaf):
        '''
        Return the "base name" of the specified location.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('name', type=str)

        def run (self, location=str, suffix=''):
            with self.openLocation(location, runTriggers=False) as loc:
                return loc.basename(suffix)

    class DirectoryName_Query (Observing, FilesystemLeaf):
        '''
        Return the "directory name" of the specified location.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('name', type=str)

        def run (self, location=str):
            context, path = self.splitLocation(location, None)
            cxt =  self.getContext(context)
            return self.joinLocation(context, cxt.dirname(path), None)


    class ContextName_Query (Observing, FilesystemLeaf):
        '''
        Return the "context name" of the specified location.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('name', type=str)

        def run (self, location=str):
            context, path = self.splitLocation(location, '')
            return context


    class MaKeDIRectory (Observing, _FileWriteLeaf):
        '''
        Create a new directory.
        '''
        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force Universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')
            self.setInput("allowExisting",
                          description=
                          'Do not complain if the directory already exists')
            self.setInput("createParents",
                          description=
                          'Create any intermediate parent folders as needed. '
                          'If not set, the parent folder must already exist. '
                          'Conversely, with this option set, no error is '
                          'reported even if the requested folder already '
                          'exists.')
            self.setInput("followLinks",
                          description=
                          "If the destination exists as a symbolic link, use "
                          "link target as the target folder")
            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the location context.")

            self.declareProps()

        def run (self, _session, allowExisting=False, createParents=False, followLinks=False,
                 owner=None, group=None, uperm=None, gperm=None, wperm=None,
                 utc=False, skipTriggers=False, location=str):

            with self.openLocation(location, _session, P_WRITE, not skipTriggers) as loc:
                if not allowExisting or not loc.isdir(followLinks=True):
                    loc.makedir(createParents, owner, group, uperm, gperm, wperm, followLinks=followLinks)
                    if not utc:
                        loc.adjustTimes()


    class ReMoveDIRectory (Observing, FilesystemLeaf):
        '''
        Remove an existing directory.

        See the "LIST?" command for an explanation of the "pattern" and
        "attributes" input parameters.

        '''
        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("followLinks",
                          description=
                          "If the destination exists as a symbolic link, use "
                          "link target as the target folder")

        def run (self, _session, ignoreMissing=False, skipTriggers=False, followLinks=False, all=False, *pattern, **attributes):
            include = (INCL_VISIBLE, INCL_ALL)[all]
            matches, contexts = self.glob(pattern, _session, P_WRITE, attributefilter=attributes, include=include,
                                          filetype=FOLDER, followLinks=followLinks, ignoreMissing=ignoreMissing, runTriggers=not skipTriggers)

            try:
                for loc in matches:
                    loc.removedir(ignoreMissing=ignoreMissing, followLinks=followLinks)
            finally:
                self.exitContexts(contexts, runTriggers=not skipTriggers)



    class ZIP (Observing, _ZipLeaf, _FileWriteLeaf):
        '''
        Pack the contents of the specified location into the specified ZIP file.

        For more information on file locations, see the LOCATIONS topic
        (e.g. "HELP? LOCATIONS")
        '''

        def declareInputs (self):
            _ZipLeaf.declareInputs(self)
            self.declareProps()
            self.setInput("attributes", type=bool, named=True, default=True,
                          description="Preserve custom attributes of source.")

            self.setInput("preserve", type=bool, default=None, named=True,
                          description="Equivalent to '-attributes'.")

            self.setInput("include", type=str, split=',', named=True, default=('*',))
            self.setInput("exclude", type=str, split=',', named=True, default=(AttributeFile,))
            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force Universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')


        def run (self, _session, all=False, append=False, prepend='', include='*', exclude='',
                 compression=_compression, allowZip64=False,
                 owner=None, group=None, uperm=None, gperm=None, wperm=None,
                 utc=False, attributes=True, preserve=None, skipTriggers=False,
                 zipfile=str, location=str, *paths):


            with self.openLocation(zipfile, _session, P_WRITE) as ziploc, \
                 self.openLocation(location, _session, P_READ) as dirloc:


                incl = (INCL_VISIBLE, INCL_ALL)[all]
                zipitems   = self.getZipItems(dirloc, paths, incl, include, exclude)
                outputfile = ziploc.open(mode=OP_WRITE)

                self.zip(outputfile, dirloc, zipitems, prepend, append, compression, allowZip64)
                outputfile.close()

                ziploc.setPermissions(owner, group, uperm, gperm, wperm)

                if not utc:
                    ziploc.adjustTimes()

                if preserve is not None:
                    attributes = preserve

                self.copyprops(dirloc, ziploc, permissions=False, attributes=attributes)



    class UNZip (Observing, _UnzipLeaf):
        '''
        Unpack the specified file into the specified folder.

        For more information on file locations, see the LOCATIONS topic
        (e.g. "HELP? LOCATIONS")
        '''

        def declareInputs (self):
            _UnzipLeaf.declareInputs(self)
            self.setInput("verify", type=bool, named=True, default=False,
                          description='Verify contents of ZIP file before listing')

            self.setInput("createParents", type=bool, named=True, default=False,
                          description="If the parent folder of the destination "
                          "does not exist, recursively create it.")

            self.setInput("overwrite", type=bool, named=True, default=False,
                          description="If destination already exists as a directory, "
                          "allow its contents to be overwritten with contents from "
                          "the ZIP archive.")

            self.setInput("strip",
                          description=
                          'Strip this from the beginning of each each file name '
                          'in the specified ZIP file/stream.')

            self.setInput("include", type=str, split=',', named=True, default=('*',))
            self.setInput("exclude", type=str, split=',', named=True, default=())


        def run (self, _session, createParents=False, overwrite=False, strip='', skipTriggers=False, skipAttributes=False, verify=False,
                 utc=False, include=('*',), exclude=(), zipfile=str, location=str, *paths):

            with self.openLocation(zipfile, _session, P_READ) as ziploc, \
                 self.openLocation(location, _session, P_WRITE) as dirloc:

                inputfile = ziploc.open(mode=OP_READ)

                try:
                    if not dirloc.isdir() or (not overwrite and not createParents and len(dirloc.listdir()) > 0):
                        dirloc.makedir(createParents=createParents)
                    self.unzip(inputfile, ziploc.vfspath(), dirloc, paths, strip, verify, include, exclude)
                finally:
                    inputfile.close()

                if not utc:
                    ziploc.adjustTimes()

                self.copyprops(ziploc, dirloc, permissions=False, attributes=not skipAttributes)



    class ZipLIST_Query (Observing, _UnzipLeaf):
        '''
        Return a list of contents in the specified archive.
        '''

        def declareInputs (self):
            _UnzipLeaf.declareInputs(self)
            self.setInput("verify", type=bool, named=True, default=False,
                          description='Verify contents of ZIP file before listing')
            self.setInput("include", type=str, split=',', named=True, default=('*',))
            self.setInput("exclude", type=str, split=',', named=True, default=())


        def declareOutputs (self):
            _UnzipLeaf.declareOutputs(self)
            self.addOutput('list', type=list, default=[""],
                           description='List of files and/or folders within the specified ZIP archive')

        def run (self, _session, verbose=False, verify=False, include=("*",), exclude=(), filename=str, *paths):
            with self.openLocation(filename, _session, P_READ) as ziploc:
                inputfile = ziploc.open(mode=OP_READ)
                try:
                    with self.openZip(inputfile, ziploc.vfspath()) as zipfile:
                        files = self.listzip(zipfile, paths, verify, include, exclude)
                        return (files,)
                finally:
                    inputfile.close()



    class UnZipREAD_Query (Observing, _UnzipLeaf):
        '''
        Unpack a single file from the specified specified ZIP file,
        and return its contents.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('contents', type=str)

        def run (self, _session, encoding=Encodings, skipTriggers=False, zipfile=str, filename=str):
            with self.openLocation(zipfile, _session, P_READ) as ziploc:
                fp = ziploc.open(mode=OP_READ)
                try:
                    with self.openZip(fp, zipfile) as zf:
                        text = zf.read(filename)

                    if encoding:
                        return "\n"+encodestring(text)
                    else:
                        return "\n"+text
                finally:
                    fp.close()


    class ZipREAD_Query (Observing, _ZipLeaf, FileStreamLeaf):
        '''
        Return the contents of the specified directory in a ZIP stream.
        '''

        def declareInputs(self):
            _ZipLeaf.declareInputs(self)
            self.setInput("include", type=str, split=',', named=True, default=('*',))
            self.setInput("exclude", type=str, split=',', named=True, default=(AttributeFile,))

        def declareOutputs (self):
            _ZipLeaf.declareOutputs(self)
            self.addOutput('zipstream', type=str)


        def run (self, _session, encoding=Encodings, all=False, prepend='', include=('*',), exclude=(),
                 skipTriggers=False, ignoreMissing=False,
                 compression=_compression, allowZip64=False, location=str, *paths):

            loc = self.openLocation(location, _session, P_READ)
            return self.startStream(loc,
                                    opener=(self.openZipStream, (loc, paths, all, include, exclude), {}),
                                    streamer=(self.zip, (), dict(prepend=prepend, compression=compression, allowZip64=allowZip64)),
                                    ignoreMissing=ignoreMissing,
                                    runTriggers=not skipTriggers,
                                    base64=encoding)


        def openZipStream (self, loc, paths, all, include, exclude):
            incl = (INCL_VISIBLE, INCL_ALL)[all]
            zipitems = self.getZipItems(loc, paths, incl, include, exclude)
            return (loc, zipitems)



    class ZipWRITe (Observing, _UnzipLeaf, _FileWriteLeaf):
        '''
        Unpack the supplied ZIP stream into the specified folder.
        '''

        def declareInputs (self):
            _UnzipLeaf.declareInputs(self)
            self.setInput("overwrite", type=bool, named=True, default=True,
                          description="If the destination folder already "
                          "exists, allow its contents to be overwritten.")

            self.setInput("strip",
                          description=
                          'Strip this from the beginning of each each file name '
                          'in the specified ZIP file/stream.')

        def run (self, _session,
                 encoding=Encodings, strip='',
                 overwrite=False, createParents=False,
                 skipTriggers=False, location=str, data=str):

            if encoding:
                data = self.decode(data)

            buf  = StringIO(data)
            data = None

            with self.openLocation(location, _session, P_WRITE, not skipTriggers) as target:
                if not target.isdir():
                    target.makedir(createParents)
                elif not overwrite:
                    raise self.TargetExists(location=target.vfspath())

                self.unzip(buf, "inline", target, strip)


    class ZipTEST (Observing, _UnzipLeaf):
        '''
        Test integrity of the specified ZIP file
        '''

        class ZipTestFailure (RunError):
            '''ZIP archive %(archive)r failed verification in file %(badfile)r'''

        def run (self, _session, skipTriggers=False, verify=False, zipfile=str):
            with self.openLocation(zipfile, _session, P_READ, not skipTriggers) as loc:
                fp = loc.open(mode=OP_READ)
                zf = None
                try:
                    with self.openZip(fp, loc.vfspath()) as zf:
                        zf.namelist()
                        if verify:
                            badfile = zf.testzip()
                            if badfile:
                                raise self.ZipTestFailure(archive=zipfile, badfile=badfile)
                finally:
                    fp.close()



    class GnuZIP (Observing, FilesystemLeaf):
        '''
        Compress the specified file using GNU ZLib compression.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("preserve", type=bool, default=False, named=True,
                          description="Preserve modification time and permissions "
                          "of original file in compressed file.")

            self.setInput("outputfile", type=str, default=None, named=True,
                          description="Name of copmressed file.  By default, "
                          "'.gz' is appended to the name of the 'filename'.")

            self.setInput("filename", type=str,
                          description="File to compress")

            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force Universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')


        def run (self, _session, preserve=False, utc=False, keepOriginal=False, compressionLevel=6,
                 skipTriggers=False, skipAttributes=False, outputfile="",
                 filename=str):

            if not outputfile:
                outputfile = filename + ".gz"

            with self.openLocation(filename, _session, P_READ, not skipTriggers) as src, \
                 self.openLocation(outputfile, _session, P_WRITE, not skipTriggers) as dst:

                infile = outfile = None
                try:
                    st = src.stat()
                    infile = src.open(mode=OP_READ)
                    outfile = dst.open(mode=OP_WRITE)
                    with GzipFile(src.basename(src.path), "wb", compressionLevel, outfile, st[ST_MTIME]) as gzout:
                        self.copyfileobj(infile, gzout)

                finally:
                    if infile:
                        infile.close()
                    if outfile:
                        outfile.close()

                self.copyprops(src, dst, times=preserve, permissions=preserve, attributes=not skipAttributes, localtime=not utc)

                if not keepOriginal:
                    src.remove()



    class GnuUNZIP (Observing, FilesystemLeaf):
        '''
        Uncompress the specified GNU-zipped file.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("preserve", type=bool, default=False, named=True,
                          description="Preserve modification time and permissions "
                          "of original file in uncompressed file.")

            self.setInput("utc", type=bool, named=True, default=False,
                          description='Force Universal timestamps, even if '
                          '"localtime" is specified in filesystem context.')

            self.setInput("outputfile", type=str, default=None, named=True,
                          description="Name of uncompressed file.  "
                          "By default, any trailing '.gz' or '.Z' is "
                          "stripped from the name of 'filename'.")

            self.setInput("filename", type=str,
                          description="File to uncompress.  If it does not "
                          "end with '.gz' or '.Z', and no separate 'outputfile' "
                          "is specified, a '.gz' suffix is assumed.")


        def run (self, _session, preserve=False, utc=False, keepOriginal=False, skipAttributes=False, skipTriggers=False, outputfile="", filename=str):
            if not outputfile:
                outputfile = filename
                for extension in ".gz", ".Z":
                    if outputfile.endswith(extension):
                        outputfile = outputfile[:-len(extension)]
                        break
                else:
                    filename += ".gz"

            with self.openLocation(filename, _session, P_READ, not skipTriggers) as src, \
                 self.openLocation(outputfile, _session, P_WRITE, not skipTriggers) as dst:

                infile = outfile = None
                try:
                    st = src.stat()
                    infile = src.open(mode=OP_READ)
                    outfile = src.open(mode=OP_WRITE)
                    with GzipFile(None, "rb", 9, infile) as gzin:
                        self.copyfileobj(gzin, outfile)

                finally:
                    if infile:
                        infile.close()
                    if outfile:
                        outfile.close()

                self.copyprops(src, dst, times=preserve, permissions=preserve, attributes=not skipAttributes, localtime=not utc)
                if not keepOriginal:
                    self.remove(src)



    class GnuZipREAD_Query (Observing, FileStreamLeaf):
        '''
        Compress the specified file using GNU ZLib compression, and
        return the resulting compressed contents.
        '''

        def run (self, _session, encoding=Encodings, compressionLevel=6, ignoreMissing=False, skipTriggers=False, filename=str):
            with self.openLocation(filename, _session, P_READ, not skipTriggers) as src:
                basename = src.basename(src.path)
                return self.startStream(src,
                                        opener=(src.open, (), dict(mode=OP_READ)),
                                        streamer=(self.sendgzip, (basename, compressionLevel), {}),
                                        ignoreMissing=ignoreMissing,
                                        runTriggers=not skipTriggers,
                                        base64=encoding)

        def sendgzip (self, outstream, infile, filename, compressionLevel):
            with GzipFile(filename, "wb", compressionLevel, outstream) as gzout:
                self.copyfileobj(infile, gzout)



    class _ContextSetter (Controlling, Leaf):

        def declareInputs (self):
            Leaf.declareInputs(self)

            self.setInput("read",
                          type=AccessLevels,
                          named=True,
                          description=
                          'Access level required to read files and '
                          'list folders within this context, limited '
                          'to the access level of the current session.')

            self.setInput("write",
                          type=AccessLevels,
                          named=True,
                          description=
                          'Access level required to add, remove, or '
                          'write files within this context, limited '
                          'to the access level of the current session')

            self.setInput("replace",
                          type=AccessLevels,
                          named=True,
                          description=
                          'Access level required to remove or replace '
                          'this context, limited to the access level '
                          'of the current session.')

#            self.setInput("device",
#                          type=str,
#                          named=True,
#                          description=
#                          'Device node or other path which must exist '
#                          'before this context can be accessed')

            self.setInput("preexec",
                          type=str,
                          named=True,
                          description='Command that will be executed before entering this context. '
                          'Example: "USB+"')

            self.setInput("postexec",
                          type=str,
                          named=True,
                          description='Command that will be executed after exiting this context. '
                          'Example: "USB-"')

            self.setOptionalInput("save", type=bool, named=True, default=True,
                                  description="Save this location context to persistent storage.")

            self.setOptionalInput("name",
                                  type=str,
                                  description=
                                  'Name of the new context. Any trailing colon is stripped.')

            self.setInput("uri",
                          type=str,
                          description='Uniform Resource Identifier to which this new '
                          'context will be mapped, in the form "[scheme:[//][username[:password]@]host]path". '
                          'If only "path" is provided, the scheme is assumed to be "file".')

            self.setInput("options",
                          type=str,
                          description='Additional arguments specific to the provided URI scheme.')



        def defineContext (self, _session, replaceExisting, save, read, write, replace, preexec, postexec, name, uri, **options):

            spec = self.decodeURI(uri)
            spec.update(options)

            self.parent.addContext(name, session=_session,
                                   replaceExisting=replaceExisting,
                                   read=min(_session.accessLevel, read),
                                   write=min(_session.accessLevel, write),
                                   replace=min(_session.accessLevel, replace),
                                   preexec=preexec,
                                   postexec=postexec,
                                   **spec)

            if save:
                self.parent.saveContext(name)


        def decodeURI (self, uri):
            u = urlsplit(uri)

            result = dict(scheme = u.scheme,
                          hostname = u.hostname,
                          port = u.port,
                          username = u.username,
                          password = u.password,
                          path = u.path or '/')

            if not u.scheme:
                if u.hostname:
                    result.update(scheme='smb')
                else:
                    result.update(scheme='file')
            elif u.scheme == 'file' and u.hostname:
                result.update(hostname=None, path=u.hostname+u.path)

            return result


    class ConteXTTEST (_ContextSetter):
        '''
        Test a context specification. Return OK if the specification
        is valid, otherwise an error indicating the issue.

        This may be used to test validity of context location before
        actually adding it.
        '''

        def run (self, _session, asynchronous=False, replaceExisting=False,
                 read=OBSERVER, write=CONTROLLER, replace=ADMINISTRATOR,
                 preexec=None, postexec=None, uri=str, *args, **options):

            if asynchronous:
                raise NextReply(self, self.run,
                                (_session, False, replaceExisting, read, write, replace, preexec,
                                 postexec, uri) + args, options)

            spec = self.decodeURI(uri)
            spec.update(options)

            context = self.parent.newContext(name=None, **spec)
            context.listdir("")


    class ConteXT_Add (_ContextSetter):
        '''
        Add a new file location context.

        Examples:
          - Map the context "USBDRIVE:" to the local folder "/mnt/usb", such that
            the command "USB+" is executed before accessing locations within this
            context and "USB-" is executed once the operation is completed:
               C: FILe:ConteXT+ USBDRIVE: /mnt/usb -preexec="USB+" -postexec="USB-"
               C: FILe:ConteXT+ USBDRIVE: file:///mnt/usb -preexec="USB+" -postexec="USB-"

          - Map the context "MYSHARE:" to the SMB share "//myserver/myshare" with
            authentication:
               C: FILe:ConteXT+ MYSHARE: smb://myserver/myshare -domain=MYDOMAIN -username=myname -password=$<mypassword>
               C: FILe:ConteXT+ MYSHARE: smb://MYDOMAIN\\myname:$<mypassword>@myserver/myshare

          - Map the context "IMAGERDATA:" to the context "DATA:" on the remote SCPI server at 192.168.144.2:
               C: FILe:ConteXT+ IMAGERDATA scpi://192.168.144.2/data

          - Map the context "IMAGERDATA:" to the context "DATA:" on the remote SCPI server linked to the "IMAGER:" SCPI branch:
               C: FILe:ConteXT+ IMAGERDATA scpi:IMAGER/DATA

        For more information on file locations, see the LOCATIONS topic (e.g. "HELP? LOCATIONS")
        '''


        def declareInputs (self):
            FilesystemBranch._ContextSetter.declareInputs(self)
            self.setInput("replaceExisting", type=bool, named=True, default=False,
                          description="Replace any existing location context by the same name.")


        def run (self, _session, replaceExisting=False,
                        read=OBSERVER, write=CONTROLLER, replace=ADMINISTRATOR,
                        preexec=None, postexec=None, save=True,
                        name=str, uri="", **options):

            return self.defineContext(_session, replaceExisting, save, read, write, replace,
                                      preexec, postexec, name, uri, **options)


    class ConteXT_Set (_ContextSetter):
        '''
        Modify settings for the specified location context.
        If no options are provided, change the default location context for this branch.
        '''

        def run (self, _session,
                 read=None, write=None, replace=None,
                 preexec=None, postexec=None, save=True,
                 name=str, uri=None, **options):

            if read is write is replace is preexec is postexec is uri is None and not options:
                cxt = self.parent.getContext(name)
                self.parent.setDefaultContextName(cxt.name)
            else:
                return self.defineContext(_session, True, save, read, write, replace,
                                          preexec, postexec, name, uri, **options)



    class ConteXT_Remove (Controlling, FilesystemLeaf):
        '''
        Remove an existing location context from this branch.

        For more information on file locations, see the LOCATIONS topic
        (e.g. "HELP? LOCATIONS")
        '''

        def run (self, _session, ignoreMissing=False, name=str):
            self.removeContext(name, session=_session, ignoreMissing=ignoreMissing)


    class ConteXT_Query (Observing, FilesystemLeaf):
        '''
        Return settings for the specified location context.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('settings', type=tuple, named=True, repeats=(0, None))

        def run (self, name=str):
            properties = self.getContext(name).properties().items()
            return tuple(sorted(properties))


    class ConteXT_Enumerate (Observing, FilesystemLeaf):
        '''
        Return a list of all existing location categories.

        For more information on file locations, see the LOCATIONS topic
        (e.g. "HELP? LOCATIONS")
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('scheme', type=ContextSchemes, named=True, default=Context)

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('context', type=str, repeats=(0, None))

        def run (self, scheme):
            names = [ cxt.name+':' for cxt in self.getContexts() if isinstance(cxt, scheme) ]
            return tuple(names)


    class SPLit_Query (Observing, FilesystemLeaf):
        '''
        Split a location path into context, and path.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('context', type=str, named=True)
            self.addOutput('dirname', type=str, named=True)
            self.addOutput('basename', type=str, named=True)

        def run (self, location=str):
            context, path = self.splitLocation(location, '')
            cxt = self.getContext(context)
            dirname = cxt.dirname(path)
            basename = cxt.basename(path)
            return context, dirname, basename


    class TRIGGer (Observing, FilesystemLeaf):
        '''Run pre-exec or post-exec trigger specified in the context of the provided path'''

        def run (self, _session, ignoreErrors=False, trigger=Context.TriggerNames, location=str):
            with self.openLocation(location, _session, P_EXECUTE, runTriggers=False) as loc:
                triggername = Context.TriggerNames[trigger]
                loc.context.runtrigger(trigger, getattr(loc.context, triggername), _session, ignoreErrors)


    class TRIGGer_Query (Observing, FilesystemLeaf):
        '''Return the pre-exec or post-exec trigger specified in the context of the provided path'''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('trigger', type=str, default=None)

        def run (self, trigger=Context.TriggerNames, location=str):
            with self.openLocation(location, _session, P_READ, runTriggers=False) as loc:
                triggername = Context.TriggerNames[trigger]
                return (getattr(loc.context, triggername),)



    class ATTRibute_Set (Observing, FilesystemLeaf):
        '''
        Set an attribute on the specified file or folder.
        '''

        class Mismatched (RunError):
            'Missing value for option %(option)s'

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("create", type=bool, named=True, default=True,
                          description='Create the attribute if it does not already exist')

            self.setInput("keepExisting", type=bool, named=True, default=False,
                          description='If attribute already exists, do not overwrite.')

            self.setInput("ignoreMissing", type=bool, named=True, default=False,
                          description='Ignore missing file, rather than raising an error')

            self.setInput("path", description='File or folder on which to set the attribute')
            self.setInput("pairs", type=str, repeats=(0, None), description='Attribute/Value pairs')
            self.setInput("options", type=str, description='Attribute/Value pairs')


        def run (self, _session, create=True, keepExisting=False,
                 ignoreMissing=False, skipTriggers=False,
                 path=str, *pairs, **options):

            if len(pairs) % 2:
                raise self.Mismatched(option=pairs[-1])

            items = [ (key.lower(), value) for key, value in zip(pairs[0::2], pairs[1::2]) + options.items() ]
            attributes = dict(items)

            with self.openLocation(path, _session, P_WRITE, not skipTriggers) as loc:
                if keepExisting:
                    for attribute in loc.getAttributes():
                        attributes.pop(attribute, None)

                elif not create:
                    new = set(attributes) - set(loc.getAttributes())
                    if new:
                        loc.getAttribute(loc.path, new.pop()) # Trigger missing attribute error

                if attributes:
                    loc.setAttributes(attributes, ignoreMissing=ignoreMissing)


    class ATTRibute_Clear (Observing, FilesystemLeaf):
        '''
        Clear all attributes on the specified file or folder.
        '''

        def run (self, _session, ignoreMissing=False, skipTriggers=False, location=str):
            with self.openLocation(location, _session, P_WRITE, not skipTriggers) as loc:
                loc.clearAttributes(ignoreMissing=ignoreMissing)


    class ATTRibute_Remove (Observing, FilesystemLeaf):
        '''
        Set an attribute on the specified file or folder.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("id", type=str, repeats=(1, None))

        def run (self, _session, ignoreMissing=False, skipTriggers=False, location=str, *id):
            with self.openLocation(location, _session, P_WRITE, not skipTriggers) as loc:
                loc.removeAttributes(id, ignoreMissing=ignoreMissing)


    class ATTRibute_Query (Observing, FilesystemLeaf):
        '''
        Obtain a specific attribute for the specified file.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("default", type=str, named=True, default=None)
            self.setInput("named", type=bool, named=True, default=False,
                          description="Return named outputs. By default outputs unnamed "
                          "when specific attribute IDs are specified.")
            self.setInput("id", type=str, repeats=(0, None))


        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('item', type=tuple, default=None, repeats=(0, None))


        def run (self, _session, ignoreMissing=False, skipTriggers=False, named=False, default=None, location=str, *id):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                attributes = loc.getAttributes(ignoreMissing=ignoreMissing)
                if not id:
                    items = attributes.items()
                    items.sort()
                else:
                    items = []
                    for key in id:
                        try:
                            items.append(((None, key)[named], attributes[key.lower()]))
                        except KeyError:
                            if not ignoreMissing:
                                raise
                            elif not named:
                                items.append((None, ""))
                return tuple(items)


    class ATTRibute_Exists (Observing, FilesystemLeaf):
        '''
        Indicate whether the specified attribute exists
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput("nonEmpty", type=bool, named=True, default=False,
                          description='Require the contents of the attribute to be non-empty')
            self.setInput("id", type=str, repeats=(1, None))

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('exists', type=bool)

        def run (self, _session, ignoreMissing=False, skipTriggers=False, nonEmpty=False, location=str, *id):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                attributes = loc.getAttributes(ignoreMissing=ignoreMissing)
                try:
                    for key in id:
                        if not attributes[key.lower()] and nonEmpty:
                            return False
                except KeyError:
                    return False
                else:
                    return True


    class ATTRibute_Enumerate (Observing, FilesystemLeaf):
        '''
        List attributes of the specified file.
        '''

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('attribute', type=str, repeats=(0, None))

        def run (self, _session, ignoreMissing=False, skipTriggers=False, location=str):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                attributes = loc.getAttributes(ignoreMissing=ignoreMissing)
                return tuple(sorted(attributes))


    class CoPyATTRibutes (Controlling, FilesystemLeaf):
        '''
        Copy attributes from the specified source paths
        '''

        def run (self, _session, ignoreMissing=False, skipTriggers=False, source=str, destination=str, *attributes):
            with self.openLocation(source, _session, P_READ, not skipTriggers) as src, \
                 self.openLocation(destination, _session, P_WRITE, not skipTriggers) as dst:

                attrmap = src.getAttributes(ignoreMissing=ignoreMissing)
                if attributes:
                    newmap = {}
                    for attr in attributes:
                        try:
                            newmap[attr] = attrmap[attr]
                        except KeyError, e:
                            if not ignoreMissing:
                                raise self.NoSuchAttribute(id=attr, path=source)
                    attrmap = newmap

                dst.setAttributes(attrmap, ignoreMissing=ignoreMissing)



    class MountPoint_Query (Observing, FilesystemLeaf):
        '''Indicate whether the specified location exists as a mount point.'''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('skipTriggers', type=bool, named=True, default=False)
            self.setInput('location', type=str, default=None)

        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('ismount', type=bool)

        def run (self, _session, skipTriggers=False, location=str):
            with self.openLocation(location, _session, P_READ, not skipTriggers) as loc:
                return loc.ismount()


branchTypes['FilesystemBranch'] = FilesystemBranch


class FILe (FilesystemBranch):
    '''
    File system operations.
    '''

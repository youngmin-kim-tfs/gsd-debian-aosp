########################################################################
### FILE:	scpiDynamicCommands.py
### PURPOSE:	Manipulate dynamic branches, aliases
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase        import Base, addCommandType
from scpiLeaf        import Controlling, Observing
from scpiBranch      import Branch, branchTypes
from scpiDynamicBase import Dynamic, DynamicCommandLeaf
from scpiSession     import AccessLevels
from scpiParameter   import Missing
from scpiExceptions  import RunError, CommandError
from scpiConfigBase  import ConfigBase
from subscription    import debug, info
from copy            import copy, deepcopy
from weakref         import ref
from types           import MethodType

########################################################################
### Commands: DESCription=, DESCription-, DESCription?

class DESCription_Add (Controlling, DynamicCommandLeaf):
    '''
    Add a description to a user-defined branch or macro.
    '''

    def run (self, _session, name=str, *description):
        obj = self.findModifiableCommand(_session, name,
                                         anyType=True,
                                         parent=self.parent)
        obj.description = ' '.join(description)


class DESCription_Remove (Controlling, DynamicCommandLeaf):
    '''
    Remove a description from a user-defined branch or macro.
    This reinstates the default description for this command type,
    if applicable.
    '''
    def run (self, _session, name=str):
        obj = self.findModifiableCommand(_session, name,
                                         anyType=True,
                                         parent=self.parent)
        obj.description = obj.__class__.__doc__


class DESCription_Query (Observing, DynamicCommandLeaf):
    '''
    Return the current description of a command.
    '''

    def declareOutputs (self):
        DynamicCommandLeaf.declareOutputs(self)
        self.addOutput('description', type=str)


    def run (self, name=str):
        obj = self.findDynamicCommand(name, anyType=True, parent=self.parent)
        return obj.description or '(No description)'



class DynamicBranch (Dynamic, Branch):
    TypeName = 'dynamic branch'


class _DynamicBranchLeaf (DynamicCommandLeaf):
    _dynamicCommandType = DynamicBranch


class BRANch_Add (Controlling, _DynamicBranchLeaf):
    '''
    Create a new branch by the given name within the current comamnd
    scope of the command tree.

    By default, the new branch contains just the "generic" set of
    commands that are common across all branches (such as "HELP",
    "MACRo", etc).  However, different branch types are available
    for specialized purposes (e.g. "FilesystemBranch" can be used
    to create a new branch with file I/O support).

Examples:
    * Create a generic branch:
        BRANch+ MyBranch

    * Create a new "METHod" branch with file I/O support
        BRANch+ -type=FilesystemBranch METHod
    '''


    def declareInputs (self):
        _DynamicBranchLeaf.declareInputs(self)
        self.setInput('replaceExisting',
                      description=
                      'If another dynamic command by the same name already '
                      'exists, replace it')

        self.setInput('modifyAccess', type=AccessLevels,
                      description=
                      'Access level required to delete or replace the branch')

        self.setInput('type',
                      type=branchTypes,
                      named=True,
                      description='Which type of branch to create.')

        self.setInput('name',
                      type=str,
                      description='Name of the new branch')


    def run (self, _session, replaceExisting=False, hidden=False,
             modifyAccess=None, type=branchTypes, name=str):

        new = self.incarnate(name, type, parent=self.parent)
        obj = self.addinstance(_session, name, new,
                               replaceExisting=replaceExisting,
                               modifyAccess=modifyAccess,
                               hidden=hidden,
                               parent=self.parent)


class BRANch_Remove (Controlling, _DynamicBranchLeaf):
    '''
    Delete a dynamic branch previously created within this scope.
    '''
    def run (self, _session, ignoreMissing=False, name=str):
        self.delinstance(_session, name, ignoreMissing, parent=self.parent)



class BRANch_Query (Observing, _DynamicBranchLeaf):
    '''
    List the contents of a branch.
    '''
    def declareOutputs (self):
        _DynamicBranchLeaf.declareOutputs(self)
        self.addOutput('type', type=branchTypes)


    def run (self, branch=str):
        branch = self.findDynamicCommand(branch, parent=self.parent, searchType=DynamicBranch)
        return branch.__class__


class BRANch_Enumerate (Observing, _DynamicBranchLeaf):
    '''
    Return a list of dynamic subbranches in this branch.
    '''

    def declareOutputs (self):
        _DynamicBranchLeaf.declareOutputs(self)
        self.addOutput('command', type=str, repeats=(0, None))

    def run (self):
        return tuple(self.listinstances(parent=self.parent))



########################################################################
### Commands: ALIas+, ALIas-, ALIas?


class Alias (Dynamic):
    TypeName = 'alias'
    #original = None
    #defaults = None

    def __init__ (self, name, original, defaults):
        while isinstance(original, Alias):
            original = original.original

        self.original    = original
        self.name        = name
        self.defaults    = defaults
        self.description = original.description
        self._parentref  = original._parentref
        self.aliasrefs   = ()
        original.aliasrefs.add(ref(self))
        
    def __del__ (self):
        self.original.aliasrefs.discard(ref(self))

    def istype (self, type):
        return isinstance(self, type) or self.original.istype(type)

    @classmethod
    def getTypeName (cls):
        return cls.TypeName
#        return ' '.join((self.original.getTypeName(), self.TypeName))

    def getDocumentation (self, margin=0, columns=0, defaults=None):
        combinedDefaults = self.defaults.copy()
        if defaults is not None:
            combinedDefaults.update(defaults)
            
        return self.original.getDocumentation(margin, columns, defaults=combinedDefaults)

    def __getattr__ (self, attr):
        return getattr(self.original, attr)
        
class AliasLeaf (DynamicCommandLeaf):
    _dynamicCommandType = Alias

    class NoArgumentsAllowedHere (RunError):
        'No arguments are allowed for %(type)s aliases'


    def addAlias (self, session, branch, hidden, replaceExisting, skipConflicts, skipMissing,
                  modifyAccess, requiredAccess, name, header, args):

        try:
            path, defaults       = branch.locate(header)
        except CommandError:
            if skipMissing:
                return
            else:
                raise

        original             = path[-1]
        alias                = Alias(name, original, defaults)
#        alias                = copy(path[-1])


        if args:
            try:
                mapfunc = original.mapParts
            except AttributeError:
                raise self.NoArgumentsAllowedHere(type=original.getTypeName())

            alias.defaults = mapfunc(args, **defaults)

        else:
            alias.defaults = defaults


        try:
            self.addinstance(session, name, alias,
                             replaceExisting=replaceExisting,
                             modifyAccess=modifyAccess,
                             requiredAccess=requiredAccess,
                             hidden=hidden,
                             parent=branch)

        except (self.IncorrectType, self.DuplicateName, self.DuplicateShortName):
            if not skipConflicts:
                raise


class ALIas_Add (Controlling, AliasLeaf):
    '''
    Define an alias for another command.

Examples:
    * Create "PersistentVARiable" and associated commands to access persistent
      variables:
        ALIas+ PersistentVARiable    VARiable -scope=persistent
        ALIas+ PersistentVARiable?   VARiable? -scope=persistent
        ALIas+ PersistentVARiableS?  VARiableS? -scope=persistent
        ALIas+ PersistentREMove      VARiable- -scope=persistent
    '''

    def declareInputs (self):
        AliasLeaf.declareInputs(self)
        self.setInput('modifyAccess', type=AccessLevels, named=True, default=None)
        self.setInput('requiredAccess', type=AccessLevels, named=True, default=None)
        self.setInput('name', type=str, description='Command alias name that will be created')
        self.setInput('command',
                      type=tuple,
                      repeats=(1, None),
                      description='Original command that gets invoked')



    def run (self, _session, hidden=False, replaceExisting=False,  skipConflicts=False, skipMissing=False,
             modifyAccess=AccessLevels, requiredAccess=AccessLevels, name=str, *command):

        option, header, raw  = command[0]
        args                 = command[1:]

        self.addAlias(_session,
                      branch=self.parent,
                      hidden=hidden,
                      replaceExisting=replaceExisting,
                      skipConflicts=skipConflicts,
                      skipMissing=skipMissing,
                      modifyAccess=modifyAccess,
                      requiredAccess=requiredAccess,
                      name=name,
                      header=header,
                      args=args)



class ALIas_Remove (Controlling, AliasLeaf):
    '''
    Remove a command alias.
    '''

    def run (self, _session, ignoreMissing=False, name=str):
        self.delinstance(_session, name, ignoreMissing, parent=self.parent)



class ALIas_Query (Observing, AliasLeaf):
    '''
    Return the definition of the given alias.
    '''

    def declareOutputs (self):
        AliasLeaf.declareOutputs(self)
        self.addOutput('command', type=tuple, repeats=(1, None))


    def run (self, _session, name=str):
        obj = self.findDynamicCommand(name, parent=self.parent)

        defaults = []
        for p in obj.getInputs():
            try:
                value = obj.defaults[p.name]
            except KeyError:
                pass
            else:
                if not p.repeats:
                    defaults.append((p.name, p.toString(value)))

                elif p.named:
                    defaults.extend([(k, p.toString(v)) for (k, v) in value.items()])

                else:
                    defaults.extend([(None, p.toString(v)) for v in value])

        return ((None, obj.commandPath(scope=self), name),) + tuple(defaults)



class ALIas_Enumerate (Observing, AliasLeaf):
    '''
    Return a list of aliases defined in this branch.
    '''

    def declareInputs (self):
        AliasLeaf.declareInputs(self)
        self.setInput('all',
                      type=bool,
                      named=True,
                      default=False,
                      description='List all alises, even hidden ones.')

    def declareOutputs (self):
        AliasLeaf.declareOutputs(self)
        self.addOutput('command', type=str, repeats=(0, None))

    def run (self, all=False):
        return tuple(self.listinstances(parent=self.parent, all=all))


class ALIas_Load (Controlling, ConfigBase, AliasLeaf):
    '''Load aliases from the specified configuraiton file'''

    def declareInputs (self):
        AliasLeaf.declareInputs(self)
        self.setInput('modifyAccess', type=AccessLevels, named=True, default=None)
        self.setInput('requiredAccess', type=AccessLevels, named=True, default=None)

    def run (self, _session, ignoreMissing=False,
             hidden=False,
             replaceExisting=False,
             skipConflicts=False,
             skipMissing=False,
             modifyAccess=AccessLevels, requiredAccess=AccessLevels,
             skipTriggers=False, config=str, section=str, branch=""):
        
        items = self.getConfigItems(config, section, session=_session, mustExist=not ignoreMissing)
        for aliasname, commandtext in items:
            text, parts = _session.expandArgs(commandtext)
            if parts:
                option, header, raw  = parts.pop(0)
                if not header.startswith(":"):
                    header = ":".join(filter(None, (branch.rstrip(":"), header)))

                self.addAlias(_session, self.parent,
                              hidden=hidden,
                              replaceExisting=replaceExisting,
                              skipConflicts=skipConflicts,
                              skipMissing=skipMissing,
                              modifyAccess=modifyAccess,
                              requiredAccess=requiredAccess,
                              name=aliasname,
                              header=header,
                              args=parts)



addCommandType(Alias)
addCommandType(DynamicBranch)

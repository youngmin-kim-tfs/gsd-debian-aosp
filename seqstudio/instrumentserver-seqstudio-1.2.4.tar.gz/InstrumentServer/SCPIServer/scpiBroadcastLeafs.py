########################################################################
### FILE:	scpiBroadcastLeafs.py
### PURPOSE:	Broadcast commands to every branch in the SCPI tree
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBranch     import Branch
from scpiLeaf       import Leaf, Observing
from scpiExceptions import CommandError, RunError
from scpiSession    import SYNC

class BRoadCast (Observing, Leaf):
    '''
    Broadcast a command to every branch within the current command scope.
    
Examples:
    * Create a global "DEFine" alias for the "MACRo+" command:
        BRoadCast ALIas+ DEFine MACRo+ -replaceExisting
    '''
    class NoTakers (RunError):
        'The command %(command)r does not exist anywhere within the %(scope)s branch'

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('command', type=tuple, repeats=(1, None))

    def run (self, _session, _context, *command):
        parts = list(command)
        option, command, raw = parts.pop(0)

        if not self.runCommand(_session, _context, self.parent,
                               command, parts):
            raise self.NoTakers(command=command,
                                scope=self.parent.commandPath() or 'top level')

    def runCommand (self, session, context, branch, command, args, ignoreErrors=False):
        try:
            session.runParts(context, command, args, branch,
                             nextReply=SYNC, catchReturn=True)
            takers = 1
        except CommandError, e:
            if not ignoreErrors:
                raise
            takers = 0

        for fullname in branch.listChildren(Branch):
            takers += self.runCommand(session, context, branch.getChild(fullname), command,
                                      args, ignoreErrors=True)
                                      
        return takers
                      

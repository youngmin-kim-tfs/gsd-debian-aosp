########################################################################
### FILE:	scpiConfigBase.py
### PURPOSE:	Configuration support
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006-2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiExceptions     import RunError
from scpiFilesystemBase import FilesystemBase
from scpiFileContexts   import OP_READ, OP_WRITE, P_READ, P_WRITE, Location
from subscription       import warning
from config             import Config, NoSectionError, NoOptionError, ParsingError, ConfigError
from os                 import sep
from sys                import exc_info
from threading          import Lock
 
class ConfigBase (FilesystemBase):
    class NoSuchSection (RunError):
        'No such section in configuration file %(filename)r: [%(section)s]'

    class NoSuchOption (RunError):
        'No such option in configuration file %(filename)r, section [%(section)s]: %(option)r'

    class ParsingError (RunError):
        'Parsing error in configuration file %(filename)r, section [%(section)s]: %(error)s'

    class ConfigFileError (RunError):
        'Unable to parse configuration file %(filename)r: %(error)s'

    configCache  = {}  # Cache all configuration files requested

    def clearCache (self, filenames=None):
        if filenames is None:
            self.configCache.clear()

        else:
            try:
                self.configCache[filenames][0] = None
            except KeyError:
                pass


    def updateConfigValues (self, filenames, section, options,
                            reload=False, skipTriggers=False, session=None,
                            mustExist=False, mustHaveSection=False, mustHaveOption=False, literal=None,
                            save=True):

        if isinstance(filenames, str):
            filenames = (filenames,)

        try:
            config, lock = self.configCache[filenames]
        except KeyError:
            config, lock = self.configCache[filenames] = [None, Lock()]
        else:
            if reload:
                config = None

        with lock:
            return self._updateConfigValues(config, filenames, section, options, skipTriggers, session,
                                            mustExist, mustHaveSection, mustHaveOption, literal, save)
        

    def _updateConfigValues (self, config, filenames, section, options, skipTriggers, session,
                             mustExist, mustHaveSection, mustHaveOption, literal, save):
        
        locations = []
        saveLocation = None

        if save or not config:
            files = []
            for filename in filenames:
                cxtname, path = self.splitLocation(filename, None)
                if cxtname is not None:
                    location = self.openLocation(filename, session, (P_READ, P_WRITE)[save],
                                                 runTriggers=not skipTriggers)
                    location.__enter__()
                    try:
                        fp = location.open(mode=OP_READ)
                    except EnvironmentError, e:
                        if mustExist:
                            raise
                    else:
                        files.append(fp)

                    locations.append(location)
                    saveLocation = location
                else:
                    files.append(filename)
                    saveLocation = filename
        else:
            files = filenames

        exc = []
        try:
            if not config:
                config = Config(files, literal=literal or False)
                try:
                    self.configCache[filenames][0] = config
                except KeyError:
                    self.configCache[filenames] = [config, Lock()]


            if options:
                for option, value in options.items():
                    config.set(section, option, value,
                               mustHaveSection=mustHaveSection,
                               mustHaveOption=mustHaveOption,
                               literal=literal)

            if save:
                if isinstance(saveLocation, str):
                    config.save(filename=saveLocation)
                elif isinstance(saveLocation, Location):
                    fp = saveLocation.open(mode=OP_WRITE)
                    config.write(fp)
                    fp.close()
                else:
                    assert False, "Config save location %s has unknown object type %s"%(saveLocation, type(saveLocation))

        except ParsingError, e:
            raise self.ConfigFileError(filename=filename, error=e)

        except NoSectionError, e:
            raise self.NoSuchSection(filename=filename, section=section)

        except NoOptionError, e:
            raise self.NoSuchOption(filename=filename, section=section, option=option)

        except EnvironmentError, e:
            e_type, e_name, e_tb = exc_info()
            exc.extend((e_type, e, e_tb))
            raise

        finally:
            for location in locations:
                location.__exit__(*exc)

        return config


    def setConfigValue (self, filename, section, options,
                        reload=False, skipTriggers=False,
                        mustExist=False, mustHaveSection=False, mustHaveOption=False, literal=None,
                        save=True):
        self.updateConfigValues(filename, section, None,
                                reload, skipTriggers,
                                mustExist, mustHaveSection, mustHaveOption, literal,
                                save)


    def getConfigInstance (self, filenames, reload=False, session=None, skipTriggers=False, mustExist=False, literal=None, **kwargs):
        return self.updateConfigValues(filenames, None, None, reload=reload,
                                       mustExist=mustExist, session=session, skipTriggers=skipTriggers, literal=literal, save=False)


    def getConfigValue (self, config, section, option, vars={},
                        literal=None, valuetype=None, default=Exception, mustExist=True):

        if not isinstance(config, Config):
            config = self.getConfigInstance(config, mustExist=mustExist)

        try:
            return config.get(section, option, default, literal=literal, valuetype=valuetype, vars=vars)

        except NoSectionError, e:
            raise self.NoSuchSection(filename=",".join(config.configFiles), section=section)

        except NoOptionError, e:
            raise self.NoSuchOption(filename=",".join(config.configFiles), section=section, option=option)

        except ParsingError, e:
            raise self.ParsingError(filename=",".join(config.configFiles), section=section, error=e)
        

    def getConfigItems (self, config, section, session=None, vars={}, literal=None, valuetype=None, mustExist=True, reload=False):
        if not isinstance(config, Config):
            config = self.getConfigInstance(config, session=session, mustExist=mustExist)

        try:
            items  = config.items(section, literal=literal, valuetype=valuetype, vars=vars)

        except NoSectionError:
            if mustExist:
                raise self.NoSuchSection(filename=",".join(config.configFiles), section=section)
            else:
                items = []

        return items


    def getConfigValues (self, config, section, options, session=None, vars={},
                         literal=None, valuetype=None, mustExist=True,
                         prefix='', suffix='', default=Exception, reload=False):

        if not isinstance(config, Config):
            config = self.getConfigInstance(config, mustExist=mustExist, literal=literal)

        items    = self.getConfigItems(config, section, session, vars, literal, valuetype, mustExist, reload)
        itemdict = dict([(key.lower(), value) for (key, value) in items ])

        values = []
        for option in options:
            try:
                values.append(itemdict[''.join((prefix,option,suffix)).lower()])
            except KeyError:
                if default is Exception:
                    raise self.NoSuchOption(filename=",".join(config.configFiles), section=section, option=option)
                else:
                    values.append(None)

        return values





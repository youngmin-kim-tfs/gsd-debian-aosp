########################################################################
### FILE:	scpiResourceLeafs.py
### PURPOSE:	Support for resource Locking/MUTual EXclusion
### HISTORY:
###  2011-08-31 Tor Slettnes
###             Created
###
### Copyrights (C) 2011 Applied Biosystems.  All rights reserved.
########################################################################


from scpiLeaf          import Leaf, Controlling, Observing
from scpiMinimalBranch import MinimalBranch
from scpiExceptions    import RunError
from threading         import Lock
from time              import time

class LOCK (MinimalBranch):
    class NotAcquired (RunError):
        '''The resource %(resource)s is not acquired'''

    class NotOwned (RunError):
        '''The resource %(resource)r is owned by %(currentOwner)s, not %(specifiedOwner)s'''


    def __init__ (self, *args, **kwargs):
        MinimalBranch.__init__(self, *args, **kwargs)
        self.mutex = Lock()
        self.locks = {}


    def acquire (self, resource, owner, reentrant, relinquish):
        relinquishList = []
        relinquished   = []

        if relinquish:
            for name in relinquish:
                try:
                    rname, rowner, rrecurse, rlock = res = self.locks[name.lower()]
                except KeyError:
                    raise self.NotAcquired(resource=name)
                else:
                    locked = rlock.locked()
                    if not locked:
                        raise self.NotAcquired(resource=name)
                    elif rowner.lower() != owner.lower():
                        raise self.NotOwned(resource=name,
                                            currentOwner=('-', rowner)[locked],
                                            specifiedOwner=owner)
                    else:
                        relinquishList.append(res)


        self.mutex.acquire()
        try:
            name, currentOwner, recursion, lock = self.locks[resource.lower()]

        except KeyError:
            name, currentOwner, recursion, lock = resource, None, 0, Lock()
            lock.acquire()
            message = "created"

        else:
            if lock.acquire(False):
                recursion = 0
                message   = "no delay"

            elif reentrant and (currentOwner is not None) and (owner.lower() == currentOwner.lower()):
                recursion += 1
                message = "recursion level %d"%recursion

            else:
                starttime = time()
                names = []

                if relinquishList:
                    for r in relinquishList:
                        rname, rowner, rrecursion, rlock = r
                        rlock.release()
                        names.append(rname)
                        relinquished.append(r)

                    relString = '; temporarily relinquished: %s'%','.join(names)
                else:
                    relString = ''

                self.debug("Resource %r requested by %s; waiting for release from %s%s"%
                           (name, owner, currentOwner, relString))

                self.mutex.release()
                lock.acquire()
                self.mutex.acquire()

                if relinquished:
                    good, bad   = [], []
                    outstanding = []

                    for rname, rowner, rrecursion, rlock in relinquished:
                        if rlock.acquire(False):
                            good.append(rname)
                        else:
                            bad.append(rname)
                            outstanding.append(rlock)

                    while outstanding:
                        if good:
                            reacquired = ' re-acquired %s;'%','.join(good)
                        else:
                            reacquired = ''

                        self.debug("Resource %r acquired by %s;%s still waiting for %s"%
                                   (name, owner, reacquired, ','.join(bad)))

                        l = outstanding.pop(0)
                        n = bad.pop(0)
                        self.mutex.release()
                        l.acquire()
                        self.mutex.acquire()
                        good.append(n)

                elapsed   = time() - starttime
                recursion = 0
                message   = "%.3fs delayed"%elapsed

        self.debug("Resource %r acquired by %s; %s"%(name, owner, message))
        self.locks[resource.lower()] = resource, owner, recursion, lock
        for r in relinquished:
            self.locks[r[0].lower()] = r
        
        self.mutex.release()



    def release (self, resource, owner, recursively, ignoreMissing):
        try:
            self.mutex.acquire()
            try:
                name, currentOwner, recursion, lock = self.locks[resource.lower()]
                locked = lock.locked()
            except KeyError:
                locked = False
            else:
                if locked and owner and (owner.lower() != (currentOwner or '').lower()):
                    raise self.NotOwned(resource=resource,
                                        currentOwner=currentOwner or '-',
                                        specifiedOwner=owner)

                elif locked:
                    if recursion and not recursively:
                        message = "recursion level %d"%recursion
                        self.locks[resource.lower()] = name, currentOwner, recursion-1, lock
                    else:
                        del self.locks[resource.lower()]
                        message = "freed"
                        #self.locks[resource.lower()] = name, None, 0, lock
                        lock.release()

                    self.debug("Resource %r released from %s, %s"%(name, currentOwner, message))

        finally:
            self.mutex.release()


        if not locked and not ignoreMissing:
            raise self.NotAcquired(resource=resource)


    def clear (self, owner):
        try:
            self.mutex.acquire()
            if owner is not None:
                owner = owner.lower()

            for key, value in self.locks.items():
                name, currentOwner, recursion, lock = value
                owned = lock.locked() and (owner in (None, (currentOwner or '').lower()))
                if owned:
                    self.debug("Resource %r released from %s, freed"%(name, currentOwner))
                    del self.locks[key]
                    lock.release()
        finally:
            self.mutex.release()


    def list (self, owner):
        if owner is not None:
            owner = owner.lower()

        resources = [ name for name, currentOwner, recursion, lock in self.locks.values()
                      if lock.locked() and (owner in (None, (currentOwner or '').lower())) ]
        return resources



    class ACQuisition_Add (Controlling, Leaf):
        '''
        Acquire the specified resource.  If it has already been acquired
        in a different thread/session, wait until released.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('reentrant', type=bool, default=False, named=True,
                          description='Allow this resource to be acquired recursively with the same owner.')

            self.setInput('owner', type=str, named=True, default="Default",
                          description='Ownership for this resource acquisition. '
                          'This can later be used to clear or list all acquisitions with '
                          'a specific ownership.')

            self.setInput('relinquish', type=str, split=",", default=(), named=True,
                          description="other resources that can be temporarily "
                          "relinquished if we cannot immediately obtain the requested resource.  This can "
                          "be used to prevent a deadlock situation, where two or more parties are waiting "
                          "for resources from each other.")

            self.setInput('resource', type=str,
                          description='Name of this resource.')


        def run (self, reentrant=False, relinquish=None, owner=str, resource=str):
            self.parent.acquire(resource, owner, reentrant, relinquish)



    class ACQuisition_Remove (Controlling, Leaf):
        '''
        Release the specified resource, unless it has been acquired
        recursively (see the "-reentrant" option to ACQuire+).
        In this case, the lock counter is decremented by one.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('recursively', type=bool, default=False,
                          description='Normally, if the resource lock has been acquired recursively, '
                          'it is not actually released, but instead an internal lock count is decremented. '
                          'With this option, recursion levels are ignored, and the lock is released regardless.')

            self.setInput('owner', type=str, named=True, default=None,
                          description='If provided, release this resource only if it '
                          'matches the current ownership of the resource')


        def run (self, ignoreMissing=False, recursively=False, owner=None, resource=str):
            self.parent.release(resource, owner, recursively, ignoreMissing)



    class ACQuisition_Clear (Controlling, Leaf):
        '''
        Clear all resources held by the current thread, or all threads.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('owner', type=str, default=None, named=True,
                          description='If provided, release only resources with matching ownership')

        def run (self, owner=None):
            self.parent.clear(owner)



    class ACQuisition_Query (Observing, Leaf):
        '''
        List the owner of the specified resource.
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('owner', type=str, default="")
            self.addOutput('reentries', type=int, default=None, named=True,
                           description='Recursion count')


        def run (self, ignoreMissing=False, resource=str):
            try:
                name, currentOwner, recursionLevel, lock = self.parent.locks[resource.lower()]
            except KeyError:
                if not ignoreMissing:
                    raise self.parent.NotAcquired(resource=resource)
            else:
                return currentOwner, recursionLevel
        


    class ACQuisition_Enumerate (Observing, Leaf):
        '''
        List all acquisitions currently held by the specified owner. If no
        owner is specified, list all acquisitions currently held by
        anyone.
        '''
        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('owner', type=str, default=None, named=True,
                          description='If provided, list only resources with matching ownership')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('resource', type=str, repeats=(0, None))


        def run (self, owner=None):
            return tuple(self.parent.list(owner))

########################################################################
### FILE:	fluidicsBase.py
### PURPOSE:	Abstract fluidics control
### AUTHORS:	Tor Slettnes
###
### Copyrights (C) 2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch  import FullBranch
from scpiExceptions  import Error, RunError, CommandError, NextReply
from scpiLeaf        import Leaf, Background, Administrative, Controlling, Observing, EstimationCriteria
from scpiSession     import ASYNC
from motionBase      import MotionAxis, MotionControlLeaf, MotionQueryLeaf, MotionBase
from locationBase    import LocationSystem, LocationAwareMotionBase, LocationLeaf
from scpiDynamicBase import Dynamic, DynamicCommandBase
from scpiConfigBase  import ConfigBase
from threadControl   import safeInvoke
from schedule        import sleep
from runplan         import RunPlan
from subscription    import publish, info, warning
from locking         import Event
from cStringIO       import StringIO
from fnmatch         import fnmatchcase
from time            import time, gmtime, localtime, strftime

class VerticalAxis (MotionAxis):
    exclusive = True

class Syringe (MotionAxis):
    '''
    This is a mix-in class for the Syringe axis
    '''

    class ExceedsSyringeCapacity (RunError):
        '''
        Aspirating %(aspirationVolume)s uL on top of %(currentVolume)s uL current volume
        would exceed %(capacity)s uL syringe capacity.
        '''


    exclusive     = True   ### There may only be one syringe axis

    def __init__ (self, *args, **kwargs):
        MotionAxis.__init__(self, *args, **kwargs)
        Syringe.init(self)

    def __del__ (self):
        self.parent.syringe = None

    def init (self):
        self.parent.syringe = self


    def startAspirate (self, volume, rate=None):
        target = self.targetTuple(volume, relative=True, speed=rate)
        return self.startMove(target)

    def startDispense (self, volume, rate=None):
        target = self.targetTuple(-volume, relative=True, speed=rate)
        return self.startMove(target)

    def getCapacity (self):
        r = self.getRange(steps=False)
        if r:
            low, high = r
            return high

    def getRemainingCapacity (self):
        capacity = self.getCapacity()
        if capacity is not None:
            return capacity - self.getPosition(steps=False)

    def getCurrentVolume (self):
        return self.getPosition()



    class ASPirate (Controlling, Background, Leaf):
        '''
        Aspirate into the syringe.
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignorePause', type=bool, named=True, default=False)
            self.setInput('rate', type=float, default=None, named=True)
            self.setInput('volume', type=float)

        def prerun (self, ignorePause=False, *args):
            self.parent.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.parent.endMove()

        def run (self, ignorePause=False, rate=None, volume=float):
            return self.parent.startAspirate(volume, rate=rate)

        def next (self, *ref):
            self.parent.completeMove(*ref)


    class DISPense (Controlling, Background, Leaf):
        '''
        Dispense from the syringe.
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignorePause', type=bool, named=True, default=False)
            self.setInput('rate', type=float, default=None, named=True)
            self.setInput('volume', type=float)

        def prerun (self, ignorePause=False, *args):
            self.parent.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.parent.endMove()

        def run (self, ignorePause=False, rate=None, volume=float):
            return self.parent.startDispense(volume, rate=rate)

        def next (self, *ref):
            self.parent.completeMove(*ref)


    class VOLume_Query (Observing, Leaf):
        '''
        Return current syringe volume
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('volume', type=float)


        def run (self):
            return int(self.parent.getCurrentVolume() * 1000) / 1000.0

        
    class CAPacity_Query (Observing, Leaf):
        '''
        Return current syringe volume
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('volume', type=float)

        def run (self):
            return self.parent.getCapacity()
        




class Robot (LocationAwareMotionBase):
    class NoVerticalAxis (RunError):
        'There is no vertical axis in %(robot)s'

    class NoSyringeAxis (RunError):
        'There is no syringe axis in %(robot)s'

    class NotEnoughReagent (RunError):
        'Can only get %(available)s of %(needed)s uL reagent from location(s) %(locations)s'

    TypeName = 'robot'


    def __init__ (self, *args, **kwargs):
        LocationAwareMotionBase.__init__(self, *args, **kwargs)
        Robot.init(self)


    def init (self):
        self.syringe  = None


    def getSyringe (self):
        if not self.syringe:
            raise self.NoSyringeAxis(robot=self.commandPath())

        return self.syringe


    def getBottomCoordinate (self, context, location):
        axis   = self.getVerticalAxis()
        target = self.getLocationCoordinates(context, location, axes=(axis,))
        return axis.toRawPosition(*target)


    def getHeightFromBottom (self, context, location, position):
        bottom = self.getBottomCoordinate(context, location)
        return bottom - position


    def getVerticalAxis (self, ignoreMissing=False):
        for axis in self.axes:
            if axis.istype(VerticalAxis):
                return axis
        else:
            if not ignoreMissing:
                raise self.NoVerticalAxis(robot=self.commandPath())


    def getAspirations (self, context, source, purpose, volume, ignoreTracking=False, ignoreExpiration=False):
        sortedlist  = self.parent.getPrioritizedLocations(context, source, purpose,
                                                          ignoreExpiration=ignoreExpiration)
        aspirations = []
        totalNeeded = needed = volume

        for expiration, stripvolume, remaining, location in sortedlist:
            if ignoreTracking or (remaining is None):
                volume = needed

            elif needed == 0:
                ### We do not need any more; stop here.
                break

            elif remaining <= 0:
                ### Discard empty locations for aspiration purposes
                continue

            else:
                volume = min(remaining, needed)

            aspirations.append((location, volume))
            needed -= volume

        if needed:
            raise self.NotEnoughReagent(locations=",".join([loc[-1] for loc in sortedlist]),
                                        reagent=source,
                                        available=sum([volume for (location, volume) in aspirations]),
                                        needed=totalNeeded)

        return aspirations


    def startAspirate (self, context, source, volume, rate, purpose,
                       ignoreTracking=False, ignoreExpiration=False,
                       dwell=None, *args, **kwargs):
        if not volume:
            return
        
        if source:
            aspirations = self.getAspirations(context, source, purpose, volume, ignoreTracking, ignoreExpiration)
            legend      = "Aspirating %s uL from %s"%(volume, self.locationName(context, source))
        else:
            aspirations = [ (None, volume) ]
            legend      = "Aspirating %s uL in place"%(volume,)

        plan     = RunPlan("Aspirate", legend, logMethod=self.debug)
        syringe  = self.getSyringe()

        for location, volume in aspirations:
            aspRate  = rate
            aspDwell = dwell

            if location is not None:
                if not aspRate:
                    aspRate = (self.parent.getValue(context, location, self.parent.AspirateRate) or
                               self.parent.getValue(context, location, self.parent.Rate))
                if aspDwell is None:
                    aspDwell = self.parent.getValue(context, location, self.parent.AspirateDwell)
                           
                plan.addStep(self.moveToLocation, (context, location), {}, self.completeMoves,
                             legend="Moving to location %s"%(self.locationName(context, location),))

            plan.addStep(syringe.startAspirate, (volume, aspRate), {}, syringe.completeMove,
                         legend="Aspirating %s uL%s"%(volume, aspRate and " at %s uL/s"%(aspRate,) or ""))

            if location:
                plan.addStep(self.parent.addLiquidVolume, (context, location, -volume))

            if aspDwell:
                plan.addStep(sleep, (aspDwell,), {},
                             legend="dwelling for %ss"%(aspDwell,))

        plan.start()
        return plan.complete, ()


    def startDispense (self, context, destination, volume, rate, purpose,
                       pullbackDwell=None, pullbackVolume=None, pullbackRate=None,
                       releaseDwell=None, releaseSteps=None, releaseRate=None,
                       *args, **kwargs):

        if not volume:
            return

        if destination:
            locations = self.parent.getPrioritizedLocations(context, destination, purpose)
            location  = locations[0][-1]

            if not rate:
                rate = (self.parent.getValue(context, location, self.parent.DispenseRate) or
                        self.parent.getValue(context, location, self.parent.Rate))

            if pullbackDwell == None:
                pullbackDwell = self.parent.getValue(context, location, self.parent.PullbackDwell)

            if pullbackVolume == None:
                pullbackVolume = self.parent.getValue(context, location, self.parent.PullbackVolume)
                                                   
            if not pullbackRate:
                pullbackRate  = self.parent.getValue(context, location, self.parent.PullbackRate)

            if releaseDwell == None:
                releaseDwell = self.parent.getValue(context, location, self.parent.ReleaseDwell)

            if releaseSteps == None:
                releaseSteps  = self.parent.getValue(context, location, self.parent.ReleaseSteps)

            if not releaseRate:
                releaseRate  = self.parent.getValue(context, location, self.parent.ReleaseRate)

            legend = "Dispensing %s uL to %s"%(volume, self.locationName(context, location))

        else:
            location = None
            legend  = "Dispensing %s uL in place"%(volume,)
            
        plan    = RunPlan("Dipense", legend, logMethod=self.debug)
        syringe = self.getSyringe()

        if location:
            plan.addStep(self.moveToLocation, (context, location), {}, self.completeMoves,
                         legend="Moving to %s"%(self.locationName(context, location)))

        dispVolume = volume + (pullbackVolume or 0)
        plan.addStep(syringe.startDispense, (dispVolume, rate), {}, syringe.completeMove,
                     legend="Dispensing %s uL%s"%(dispVolume, rate and " at %s uL/s"%(rate,) or ""))

        if location:
            plan.addStep(self.parent.addLiquidVolume, (context, location, volume))

        if pullbackVolume:
            if pullbackDwell:
                plan.addStep(sleep, (pullbackDwell,),
                             legend='Dwelling %ss before pullback'%(pullbackDwell,))

            plan.addStep(syringe.startAspirate, (pullbackVolume, pullbackRate), {}, syringe.completeMove,
                         legend="Pulling back %s uL%s"%(pullbackRate and " at %s uL/s"%(pullbackRate,) or "",))


        if releaseSteps:
            if releaseDwell:
                plan.addStep(sleep, (releaseDwell,),
                             legend='Dwelling %ss before release'%(releaseDwell,))

            axis = self.getVerticalAxis() 
            target = axis.targetTuple(-releaseSteps, relative=True, steps=False, speed=releaseRate)
            plan.addStep(axis.startMove, (target,), {}, axis.completeMove)

        plan.start()
        return plan.complete, ()


    def startTransfer (self, _context,
                       context, source, destinations, volume, purpose,
                       preAspirate, aspirateRate, aspArgs,
                       preDispense, dispenseRate, dispArgs,
                       ignoreTracking=False, ignoreExpiration=False,
                       pullbackDwell=None,  pullbackVolume=None, pullbackRate=None):


        totalVolume, targets, volumes, pulls = \
            self.transferTargets(context, destinations, volume, pullbackVolume)

        aspirations = self.getAspirations(context, source, purpose, totalVolume)
        syringe     = self.getSyringe()
        capacity    = syringe.getRemainingCapacity()
        laps        = []
        lapVolume   = 0

        ### Split deliveries into laps, based on total syringe capacity
        for target, volume, pullback in zip(targets, volumes, pulls):
            if not laps or (capacity and (lapVolume + volume + pullback > capacity)):
                laps.append([])
                lapVolume = 0
                capacity  = syringe.getCapacity()

            laps[-1].append((target, volume, pullback))
            lapVolume += volume


        legend = "Transferring %s from %s to %s"%\
                 (volume,
                  self.locationName(context, source),
                  ",".join([self.locationName(context, tgt) for tgt in targets]))
        plan = RunPlan("Transfer", legend, logMethod=self.debug)
        

        ### Go through each lap
        for lapindex, lap in enumerate(laps):
            neededVolume  = 0
            lastPullback  = 0
            lapTargets    = []
               
            for target, volume, pullback in lap:
                lapTargets.append(target)
                neededVolume += volume
                lastPullback -= volume
                if lastPullback < pullback:
                    lastPullback = pullback


            if (lapindex == 0) and preAspirate:
                legends.append("run pre-aspirate commands")
                plan.addStep(self.runBlock, (preAspirate, _context, self),
                             legend="Invoking pre-aspirate clause")

            neededVolume += lastPullback
            args = (context, source, neededVolume, aspirateRate, purpose, ignoreTracking, ignoreExpiration)
            legend = "Aspirating %s uL from %s"%(neededVolume, source)
            plan.addStep(self.startAspirate, args, aspArgs, self.completeMoves, legend)
            neededVolume = -lastPullback

            if (lapindex == 0) and preDispense:
                plan.addStep(self.runBlock, (preDispense, _context, self),
                             legend="Invoking pre-dispense clause")

            for target, volume, pullback in lap:
                args = (context, target, volume, dispenseRate, purpose,
                        pullbackDwell, pullbackVolume, pullbackRate)
                legend = "Dispensing %s uL to %s"%(volume, self.locationName(context, target))
                plan.addStep(self.startDispense, args, dispArgs, self.completeMoves, legend)

        plan.start()
        return plan.complete, ()


    def transferTargets (self, context, destinations, dispenseVolumes, pullbackVolumes):

        ### Replicate volumes to ensure there are enough for the 
        ### supplied number of destination groups
        while 0 < len(dispenseVolumes) < len(destinations):
            raise self.TooFewVolumes(volumeCount=len(dispenseVolumes),
                                     groups=len(destinations))

        while len(pullbackVolumes) < len(destinations):
            pullbackVolumes.append(0)

        targets        = []
        volumes        = []
        pullbacks      = []
        lastPullback   = 0

        ### Determine transfer volume for each destination, based on group
        for group, volume, pullback in zip(destinations,
                                           dispenseVolumes,
                                           pullbackVolumes):
            groupTargets = [ self.parent.getLocations(context, target)[0]
                             for target in group
                             if target ]

            if not groupTargets:
                ### If a location groups is empty, we stop here.
                ### E.g. "TRANsfer TMAX ${ActiveLanes} Rinse" should not
                ### go to "Rinse" if ${ActiveLanes} is empty.
                break

            ### Sort targets.  This is a crude hack to ensure that we
            ### move between 5500 injection ports in incrementing
            ### order, thus avoid having the theta axis move the
            ### needle into the splash guard.
            groupTargets = self.sortedLocations(context, groupTargets)

            targets.extend(groupTargets)
            volumes.extend([volume] * len(groupTargets))
            pullbacks.extend([pullback] * len(groupTargets))
            lastPullback = pullback

        totalVolume = sum(volumes) + lastPullback
        return totalVolume, targets, volumes, pullbacks



    class ASPirate (Controlling, Background, Leaf):
        '''
        Aspirate from the specified source.  This must be either an
        existing location name, or a reagent name that exists in one
        or more locations.

        If no robot is specified, the first robot whose location map
        includes a matching location or reagent name is chosen.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('rate', type=float, units='microliters/second',
                          range=(0.0, None), default=None)
            self.setInput('allowEmpty', type=bool, named=True, default=False,
                          description='Allow aspiration from empty wells')
            self.setInput('allowExpired', type=bool, named=True, default=False,
                          description='Allow aspiration from expired wells')
            self.setInput('dwell', type=float, named=True, default=None, units='seconds')
            self.setInput('purpose', type=str, named=True, default=None)
            self.setInput('context', type=str, named=True, default=None)
            self.setInput('source', default=None, description="Source location or reagent name")
            self.setInput('volume', units='microliters')


        def estimateReagents (self, _context,
                              rate, allowEmpty, allowExpired, dwell, purpose, context, source, volume):

            if source:
                usage = self.parent.parent.reagentUsage(context, source, purpose, volume, allowExpired)
                self.addResults(_context, usage)


        def prerun (self, *args):
            self.parent.clearToMove()

        def postrun (self, *args):
            self.parent.endMove()

        def run (self, _context, rate=None, allowEmpty=False, allowExpired=False, dwell=None, purpose=None, context=None,
                 source=str, volume=float):
            return self.parent.startAspirate(context, source, volume, rate, purpose,
                                             dwell=dwell, ignoreTracking=allowEmpty, ignoreExpiration=allowExpired)

        def next (self, *ref):
            self.parent.completeMoves(*ref)



    class DISPense (Controlling, Background, Leaf):
        '''
        Dispense to the specified destination.  This must be either an
        existing location name, or a reagent name that exists in one
        or more locations.

        If no robot is specified, the first robot whose location map
        includes a matching location or reagent name is chosen.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('rate', type=float, units='microliters/second', range=(0.0, None),
                          default=None,
                          description='Dispense speed.  By default, the default speed '
                         'for the specified destination is used.')

            self.setInput('pullbackDwell', type=float, units='seconds',
                          range=(0.0, None), default=None)

            self.setInput('pullbackVolume', type=float, units='microliters',
                          default=None, named=True,
                          description='After dispense, pull the syringe back '
                          '(aspirate) the specified amount.  This can be used '
                          'to mitigate back pressure from the flow chip.')

            self.setInput('pullbackRate', type=float,
                          units='microliters/second', default=None,
                          named=True,
                          description='Rate at which to pull back syringe after dispense')
            
            self.setInput('releaseDwell', type=float, units='seconds',
                          range=(0.0, None), default=None)

            self.setInput('releaseSteps', type=float, units='steps',
                          default=None, named=True,
                          description='After dispense to Injection Port, pull the vertical axis up'
                          'the specified steps to release pressure.')

            self.setInput('releaseRate', type=float, units='steps/second',
                          default=None, named=True,
                          description='After dispense to Injection Port, pull the vertical axis up'
                          'at the specified rate to release pressure.')

            self.setInput('purpose', type=str, named=True, default=None)
            self.setInput('context', type=str, named=True, default=None)
            self.setInput('destination', type=str, default=None,
                          description='Destination location or reagent')
            self.setInput('volume', units='microliters')



        def estimateReagents (self, _context, rate,
                              pullbackDwell, pullbackVolume, pullbackRate,
                              releaseDwell, releaseSteps, releaseRate,
                              purpose, context, destination, volume):

            if destination:
                usage = self.parent.parent.reagentUsage(context, destination, purpose, -volume)
                self.addResults(_context, usage)


        def prerun (self, *args):
            self.parent.clearToMove()

        def postrun (self, *args):
            self.parent.endMove()


        def run (self, _context, rate=None,
                 pullbackDwell=None, pullbackVolume=None, pullbackRate=None, 
                 releaseDwell=None, releaseSteps=None, releaseRate=None, 
                 purpose=None, context=None, destination=str, volume=float):

            return self.parent.startDispense(context, destination, volume, rate, purpose,
                                             pullbackDwell  = pullbackDwell,
                                             pullbackVolume = pullbackVolume,
                                             pullbackRate   = pullbackRate,
                                             releaseDwell   = releaseDwell,
                                             releaseSteps   = releaseSteps,
                                             releaseRate    = releaseRate)

        def next (self, *ref):
            self.parent.completeMoves(*ref)


    class TRANsfer (Controlling, Background, Leaf):
        '''
        Transfer reagent from the specified source location to each of the specified
        destination locations.  All locations must have been defined within the location
        map of the specified robotic robot, or if no robot is specified, within the location
        map of at least one robotic robot in the system.
        '''

        class MismatchedVolumes (CommandError):
            '%(numvolumes)s volumes but %(numdestinations)s sets of destinatons specified: %(destinations)s'


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('aspirateRate',  type=float,
                          units='microliters/second',
                          range=(0.0, None), default=None)

            self.setInput('dispenseRate', type=float,
                          units='microliters/second',
                          range=(0.0, None), default=None)

            self.setInput('aspirateDwell', type=float, units='seconds', range=(0.0, None), default=None)

            self.setInput('pullbackDwell', type=float, units='seconds', range=(0.0, None), default=None)
            self.setInput('pullbackVolume', split=",", type=float, units='microliters',
                          default=None, named=True,
                          description='volume(s) to pull back after dispense. '
                          'This can be used to mitigate back pressure from the flow chip.')
            self.setInput('pullbackRate', type=float,
                          units='microliters/second', default=None,
                          named=True,
                          description='Rate at which to pull back syringe after dispense')
            
            self.setInput('releaseDwell', type=float, units='seconds', range=(0.0, None), default=None)
            self.setInput('releaseSteps', type=float, units='counts',
                          default=None, named=True,
                          description='After dispense, move the needle up he specified steps'
                          'This can be used minimize springing of'
                          'the needle when undocking from the port')
            self.setInput('releaseRate', type=float,
                          units='steps/second', default=None,
                          named=True,
                          description='Rate at which to pull up needle after dispense')

            self.setInput('preAspirate', type=str, default=None,
                          description="Command(s) to execute prior to aspiration")
            self.setInput('preDispense', type=str, default=None,
                          description="Command(s) to execute prior to dispense")
            
            self.setInput('allowEmpty', type=bool, named=True, default=False,
                          description='Allow aspiration from empty wells')
            self.setInput('allowExpired', type=bool, named=True, default=False,
                          description='Allow aspiration from expired wells')

            self.setInput("purpose", type=str, default=None, named=True)
            self.setInput("context", type=str, named=True, default=None)
            self.setInput("volume", type=float, spilt=",", units='microliters',
                          description="volumes to be dispensed into each of the specified "
                          "lists of destinations. The number of volumes must match the number of "
                          "destination lists.")
            self.setInput("source", description="Source location or reagent name")
            self.setInput("destinations", type=str, split=",", repeats=(0, None), description=
                          "Comma-separated list of destination locations")



        def estimateReagents (self, _context,
                              aspirateRate=None, dispenseRate=None, aspirateDwell=None,
                              pullbackDwell=None, pullbackVolume=None, pullbackRate=None,
                              releaseDwell=None, releaseSteps=None, releaseRate=None,
                              preAspirate=None, preDispense=None,
                              allowEmpty=False, allowExpired=False,
                              purpose=None, context=None, volume=str, source=str, *destinations):

            totalVolume, targets, volumes, pullbacks =\
                self.parent.transferTargets(context, destinations, volume, pullbackVolume)

            usage = self.parent.parent.reagentUsage(context, source, purpose, totalVolume, allowExpired)
            self.addResults(_context, usage)

            for target, volume in zip(targets, volumes):
                usage = self.parent.parent.reagentUsage(context, target, purpose, -volume)
                self.addResults(_context, usage)


        def prerun (self, *args):
            self.parent.clearToMove()

        def postrun (self, *args):
            self.parent.endMove()


        def run (self, _context,
                 aspirateRate=None, dispenseRate=None, aspirateDwell=None,
                 pullbackDwell=None, pullbackVolume=None, pullbackRate=None, 
                 releaseDwell=None, releaseSteps=None, releaseRate=None,
                 preAspirate=None, preDispense=None,
                 allowEmpty=False, allowExpired=False,
                 purpose=None, context=None, volume=str, source=str, *destinations):

            aspArgs  = dict(dwell = aspirateDwell)

            dispArgs = dict(releaseDwell = releaseDwell,
                            relaseSteps = releaseSteps,
                            releaseRate = releaseRate)

            return self.parent.startTransfer(_context,
                                             context, source, destinations, volume, purpose,
                                             preAspirate, aspirateRate, aspArgs,
                                             preDispense, dispenseRate, dispArgs,
                                             ignoreTracking = allowEmpty,
                                             ignoreExpiration  = allowExpired,
                                             pullbackDwell = pullbackDwell,
                                             pullbackVolume = pullbackVolume,
                                             pullbackRate = pullbackRate)

        def next (self, *ref):
            self.parent.completeMoves(*ref)





class RobotBase (Dynamic):
    _dynamicCommandType  = Robot
    

class FluidicsBase (RobotBase, DynamicCommandBase, LocationSystem, FullBranch):
    '''
    Fluidics commands
    '''

    class InvalidRobotIndex (RunError):
        'Invalid robot index: %(index)s'

    class NoSuchLocation (RunError):
        'No such location exists: %(location)r'

    class NoSuchReagent (RunError):
        'No such reagent is stored at any location within context %(context)r: %(reagent)r'

    class NoSuchStrip (RunError):
        'No such reagent strip exists: %(name)r'

    class ExpiredReagent (RunError):
        'All reagent in location(s) %(locations)s is expired (as of epoch %(time)s == %(date)s)'

    class InvalidPurpose (RunError):
        'No %(location)s location is available for %(required)r, only for %(provided)r/other purposes'

    class NoVolumeTracking (RunError):
        'There is no volume tracking in location %(location)r'

    class NoExpiration (RunError):
        'There is no expiration date in location %(location)r'

    class NoSuitableRobot (RunError):
        'No robot reaches all needed locations: %(locations)s'

    class NoSuchRobot (RunError):
        'Robot index %(index)s is out of range'

    class InvalidVolume (CommandError):
        'Invalid volume %(volume)s'

    class TooFewVolumes (CommandError):
        'Please specify delivery volume for each destination group'


    LocationAttributes = (LocationType, Reagent, Strip, Purpose, DeadVolume,
                          AspirateRate, DispenseRate, Rate, AspirateDwell,
                          PullbackDwell, PullbackVolume, PullbackRate,
                          ReleaseDwell, ReleaseSteps, ReleaseRate) = \
                         ('type', 'reagent', 'strip', 'purpose', 'deadvolume',
                          'aspirateRate', 'dispenseRate', 'rate', 'aspirateDwell',
                          'pullbackDwell', 'pullbackVolume', 'pullbackRate',
                          'releaseDwell', 'releaseSteps', 'releaseRate')
                          
    LocationDynamicData = (Expiration, LiquidVolume, AspirateCount, DispenseCount) = \
                          ('expiration', 'liquidVolume', 'aspirateCount', 'dispenseCount')

    LocationDataTypes = {
        LocationType:   str,
        Reagent:        str,
        Strip:          str,
        Purpose:        str,
        DeadVolume:     float,
        Rate:           float,
        AspirateRate:   float,
        DispenseRate:   float,
        AspirateDwell:  float,
        PullbackDwell:  float,
        PullbackVolume: float,
        PullbackRate:   float,
        ReleaseDwell:   float,
        ReleaseSteps:   int,
        ReleaseRate:    float,
        Expiration:     int,
        LiquidVolume:   float,
        AspirateCount:  int,
        DispenseCount:  int
        }
    

    _dynamicCommandType = Robot

    robotTypes = { None: Robot }

    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        LocationSystem.__init__(self, *args, **kwargs)
        self.init()


    def init (self):
        self.robots      = []


    def configFileName (self):
        return self.name.lower() + '.ini'

    def trackingFileName (self):
        return self.name.lower() + "-tracking.ini"


    def getConfigObject (self, attribute):
        if attribute in self.LocationDynamicData:
            return self.getConfigInstance(self.trackingFileName())
        else:
            return LocationSystem.getConfigObject(self, attribute)



    def getValue (self, context, location, attribute, default=None, valuetype=None):
        if valuetype is None and attribute in self.LocationDataTypes:
            valuetype = self.LocationDataTypes[attribute]

        return LocationSystem.getValue(self, context, location, attribute,
                                       default=default, valuetype=valuetype)


    def addRobot (self, name, type, session, replaceExisting=False):
        child = self.getChild(name, allowMissing=True)
        new   = self.incarnate(name, type)
        obj   = self.addinstance(session, name, new,
                                 replaceExisting=replaceExisting)

        if child:
            self.robots.remove(child)

        self.robots.append(obj)
        return obj


    def removeRobot (self, name, session, ignoreMissing=False):
        child = self.delinstance(session, name, ignoreMissing)
        if child:
            self.robots.remove(child)


    def getRobot (self, name, ignoreMissing=False):
        return self.findDynamicCommand(name, allowMissing=ignoreMissing)

        child = self.getChild(name, ignoreMissing)
        if child is None:
            return None
        elif child in self.robots:
            return child
        else:
            raise self.NotAnRobot(name=name)


    def findSuitableRobot (self, robot, context,
                           locations=(), axisTypes=(Syringe,)):
        if robot == 0:
            robots = self.robots
        elif 0 < robot <= len(self.robots):
            robots = self.robots[robot-1:robot]
        else:
            raise self.NoSuchRobot(index=robot)

        result = []
        for robot in robots:
            suitable = True
            for location in filter(None, locations):
                if not robot.hasLocation(context, location):
                    suitable = False
                    break

            needs = set(axisTypes)
            for axisType in axisTypes:
                for axis in robot.axes:
                    if axis.istype(axisType):
                        needs.discard(axisType)
                        break

            if needs:
                suitable = False

            if suitable:
                result.append(robot)

        try:
            return result[-1]
        except IndexError:
            raise self.NoSuitableRobot(locations=", ".join(locations))



    def setLiquidVolume (self, context, location, volume):
        self.setValue(context, location, self.LiquidVolume, volume)

    def clearLiquidVolume (self, context, location, save=True):
        self.clearValue(context, location, self.LiquidVolume, save=save)

    def getLiquidVolume (self, context, location, default=None):
        return self.getValue(context, location, self.LiquidVolume, default)

    def addLiquidVolume (self, context, location, delta):
        previousVolume = self.getLiquidVolume(context, location)
        nextVolume = self.getUpdatedValue(previousVolume, delta)
        if nextVolume is not None:
            self.setLiquidVolume(context, location, nextVolume)


    def getUpdatedValue (self, previous, change, default=None):
        if previous is None:
            previous = default

        if previous is not None:
            return previous + change



    def mapLocations (self):
        LocationSystem.mapLocations(self)

        self.reagents  = {}
        self.strips    = {}
        config = self.getLocationConfig()

        for context, locations in self.locations.items():
            locationnames = locations.keys()
            locationnames.sort()
            for location in locationnames:
                section = locations[location]
                reagents = config.getliteral(section, self.Reagent, str, "").lower()
                strip    = config.getliteral(section, self.Strip, str, "").strip().lower()
                if reagents:
                    for reagent in reagents.split(","):
                        prefix, cxt, loc = section.split(':', 2)
                        cxtmap  = self.reagents.setdefault(context, {})
                        loclist = cxtmap.setdefault(reagent.strip(), [])
                        loclist.append(loc)

                if strip:
                    loclist = self.strips.setdefault(strip, [])
                    loclist.append((context, location))




    def setReagent (self, context, location, reagent):
        self.setValue(context, location, self.Reagent, reagent)
        self.mapReagents()

    def getReagent (self, context, location, default=None):
        return self.getValue(context, location, self.Reagent, default)


    def setLocationType (self, context, location, type):
        self.setValue(context, location, self.LocationType, type)
        self.mapReagents()


    def getLocationType (self, context, location, default=None):
        return self.getValue(context, location, self.LocationType, default)


    def locationsByType (self, context, candidates, types, mask=None):
        if candidates is None:
            candidates = self.listLocations(context)

        candidates = self.sortedLocations(context, candidates)

        if mask:
            mask = mask.lower()
            candidates = [ c for c in candidates if fnmatchcase(c.lower(), mask) ]

        types = [ t.lower() for t in types ]

        return [ location
                 for location in candidates
                 if (not types) or (self.getLocationType(context, location, '').lower() in types) ]




    def listReagents (self, context):
        locations = self.listLocations(context)
        reagents  = {}
        for loc in locations:
            reag = self.getReagent(context, loc)
            if reag is not None:
                reagents[reag.lower()] = reag

        reaglist = reagents.values()
        reaglist.sort()
        return reaglist


    def getReagentLocations (self, context, reagent, ignoreMissing=False):
        maps = [ self.reagents.get(None, {}) ]

        if context:
            maps.append(self.reagents.get(context.lower(), {}))

        locations = []
        for reagentmap in maps:
            locations.extend(reagentmap.get(reagent.lower(), []))

        if not locations and not ignoreMissing:
            raise self.NoSuchReagent(context=context, reagent=reagent)

        locations.sort()
        return locations



    def delLocation (self, context, location, ignoreMissing=False):
        if LocationSystem.delLocation(self, context, location, ignoreMissing):
            for robot in self.robots:
                robot.delLocation(context, location, ignoreMissing=True)
            
        

    def getLocations (self, context, name, ignoreMissing=False):
        try:
            self.getLocationSection(context, name)

        except self.NoSuchLocation, e:
            locations = self.getReagentLocations(context, name, ignoreMissing=True)
            if not locations and not ignoreMissing:
                raise

        else:
            locations = [ name ]

        return locations


    def getPrioritizedLocations (self, context, source,
                                 purpose=None, allowLocations=True,
                                 ignoreMissing=False, ignoreExpiration=False):
        result       = []
        currentTime  = time()
        expired      = None
        wrongPurpose = None
        discarded    = []
        stripVolumes = {}

        if allowLocations:
            locations = self.getLocations(context, source)
        else:
            locations = self.getReagentLocations(context, source)

        for location in locations:
            rpurpose   = self.getValue(context, location, self.Purpose)
            expiration = self.getValue(context, location, self.Expiration, "-")
            stripname  = self.getValue(context, location, self.Strip)
            deadvolume = self.getValue(context, location, self.DeadVolume, 0)
            remaining  = self.getLiquidVolume(context, location)
            if remaining:
                available = max(remaining - deadvolume, 0)
            else:
                available = "-"
            
            if stripname:
                name = stripname.lower()
                try:
                    stripvol = stripVolumes[name]
                except KeyError:
                    stripvol = stripVolumes[name] = self.getStripVolume(name, "-")
            else:
                stripvol = "-"


            if (currentTime > expiration > None) and not ignoreExpiration:
                discarded.append("%s (expired at %s)"%(location, expiration))

                if expired < expiration:
                    expired = expiration

            elif purpose and rpurpose and (purpose.upper() != rpurpose.upper()):
                discarded.append("%s (purpose %s)"%(location, rpurpose))
                if wrongPurpose == None:
                    wrongPurpose = rpurpose

            else:
                self.debug("Selected location %s; requested purpose=%s, reagent purpose=%s"%
                           (location, purpose, rpurpose))
                result.append((expiration, stripvol, available, location))

        result.sort()

        fieldnames = ('expirationTime', 'stripVolume', 'wellVolume')
        lastfields = []
        output     = []
        for fields in result:
            location = fields[-1]
            for name, this, last in zip(fieldnames, fields, lastfields):
                if this != last:
                    output.append("<<%s<< %s"%(name, location))
                    break
            else:
                output.append(location)

            lastfields = fields

        if output:
            self.debug("Prioritized locations for %r, purpose=%r: %s"%
                       (self.locationName(context, source), purpose,
                        " ".join(output) or "(None)"))

        if discarded:
            self.debug("Discarded locations for %r, purpose=%r: %s"%
                       (self.locationName(context, source), purpose,
                        " ".join(discarded) or "(None)"))

        if not result and not ignoreMissing:
            locstring = ",".join(locations)
            if expired:
                datestring = strftime("%Y-%m-%d %H:%M:%S %Z", localtime(expired))
                                      
                raise self.ExpiredReagent(locations=locstring,
                                          time=expired,
                                          date=datestring)
            elif wrongPurpose is not None:
                raise self.InvalidPurpose(location=self.locationName(context, source),
                                          required=purpose, provided=wrongPurpose)


        return result


    def getValidLocations (self, context, name, purpose=None, allowLocations=True, ignoreExpiration=False):
        locations = [ l[-1] for l in self.getPrioritizedLocations(context, name, purpose, allowLocations, ignoreExpiration) ]
        locations.sort()
        return locations


    def getStripVolume (self, stripname, default=None):
        try:
            locations = self.strips[stripname.lower()]
        except KeyError:
            raise self.NoSuchStrip(name=stripname)

        volumes = [ self.getLiquidVolume(cxt, loc, None)
                    for cxt, loc in locations ]

        volumes = filter(lambda v: v is not None, volumes)
        if volumes:
            return sum(volumes)
        else:
            return default


    def getReagentVolume (self, context, reagent, purpose=None, ignoreExpiration=False, default=None):
        locations = self.getValidLocations(context, reagent,
                                           purpose=purpose,
                                           allowLocations=False,
                                           ignoreExpiration=ignoreExpiration)

        volumes = [ self.getLiquidVolume(context, loc, None)
                    for loc in locations ]

        volumes = filter(lambda v: v is not None, volumes)
        if volumes:
            return sum(volumes)
        else:
            return default


    def reagentUsage (self, context, source, purpose, volume, allowExpired=False):
        location      = self.getValidLocations(context, source, purpose=purpose, ignoreExpiration=allowExpired)[0]
        reagentString = self.getReagent(context, location)
        usage         = {}

        if reagentString:
            candidates = reagentString.split(',')
            for reagent in reversed(candidates):
                if reagent.lower() == source.lower():
                    break

            usage[reagent] = usage.get(reagent, 0) + volume

        return usage






    class LOCation_Set (LocationSystem.LOCation_Set):
        '''
        Specify coordinates for a given location.  
        '''

        def declareInputs (self):
            LocationSystem.LOCation_Set.declareInputs(self)
            for attr in (self.parent.LocationAttributes +
                         self.parent.LocationDynamicData):
                self.addInput(attr, type=self.parent.LocationDataTypes[attr], named=True, default=None)


    class LOCation_Query (LocationSystem.LOCation_Query):
        '''
        Return specific information about this location
        '''

        def declareOutputs (self):
            LocationSystem.LOCation_Query.declareOutputs(self)

            self.addOutput('robots', type=str, named=True, default=None)

            for attr in (self.parent.LocationAttributes +
                         self.parent.LocationDynamicData):
                self.addOutput(attr, type=self.parent.LocationDataTypes[attr], named=True, default=None)

            

        def run (self, context="", location=str):
            robots     = [ robot.name for robot in self.parent.robots
                         if robot.hasLocation(context, location) ]

            response = [ ",".join(robots) or "-" ]
            response.extend([ self.parent.getValue(context, location, p.name)
                              for p in self.getOutputs()[1:] ])

            return tuple(response)



    class LOCation_Enumerate (Observing, LocationLeaf):
        '''
        List available location
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('types', type=str, split=",", named=True, default=None,
                          description="Comma-separated list of location types")
            self.setInput('mask', type=str, named=False, default="*")


        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))


        def run (self, context=None, types=None, mask=str):
            if types:
                types = [ t.lower() for t in types if t ]

            locations = self.parent.locationsByType(context, None, types, mask)
            return tuple(locations)


    class LiquidVOLume_Add (Controlling, LocationLeaf):
        '''
        Add to the liquid volume count for the given location.
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('volume', type=float, units='microliters')

        def run (self, ignoreMissing=False, context="", location=str, volume=float):
            current = self.parent.getLiquidVolume(context, location)
            if current is None:
                if ignoreMissing:
                    current =  0.0
                else:
                    raise self.parent.NoVolumeTracking(location=self.parent.locationName(context, location))

            self.parent.setLiquidVolume(context, location, current + volume)


    class LiquidVOLume_Remove (Controlling, LocationLeaf):
        '''
        Subtractk from the liquid volume count for the given location.
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('volume', type=float, units='microliters')

        def run (self, ignoreMissing=False, context="", location=str, volume=float):
            current = self.parent.getLiquidVolume(context, location)
            if current is None:
                if ignoreMissing:
                    current =  0.0
                else:
                    raise self.parent.NoVolumeTracking(location=self.parent.locationName(context, location))

            self.parent.setLiquidVolume(context, location, max(0, current - volume))

    class LiquidVOLume_Set (Controlling, LocationLeaf):
        '''
        Set the liquid volume counter for the given location.  As
        reagents are aspirated from or dispensed to this location,
        this volume is adjusted.  Once there is less volume remaining
        than requested for an aspiration, this location can no longer
        be used.

        Where there are several locations containing the same reagent,
        the the remaining volume is used among other factors to which
        location is selected.  Locations with lower remaining volume
        get higher priority, and locations with no set volume counter
        get lower priority.
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('volume', type=float, units='microliters')


        def run (self, context="", location=str, volume=float):
            self.parent.setLiquidVolume(context, location, volume)


    class LiquidVOLume_Query (Observing, LocationLeaf):
        '''
        Return the liquid volume counter for the specified location.

        Where there are several locations containing the same reagent,
        the the remaining volume is used among other factors to which
        location is selected.  Locations with lower remaining volume
        get higher priority, and locations with no set volume counter
        get lower priority.
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('default', type=str,
                          description='If there is no volume tracking in the '
                          'specified location, return the specified value '
                          'rather than raising an error')

            self.setInput('decimals', type=int, default=3, range=(0, None))

        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('volume', type=float, format="%s", default=None, units='microliters')

        def run (self, ignoreMissing=False, decimals=3, default=None, context="", location=str):
            volume  = self.parent.getLiquidVolume(context, location, default)

            if volume is not None:
                return "%.*f"%(decimals, volume)
            elif not ignoreMissing:
                raise self.parent.NoVolumeTracking(location=self.parent.locationName(context, location))




    class LiquidVOLume_Clear (Controlling, LocationLeaf):
        '''
        Clear the liquid volume counter for the given locations, thus
        disabling volume tracking.  This location will now be a
        candidate for aspriate and dispense operations without regard
        to volume tracking.

        Where there are several locations containing the same reagent,
        the the remaining volume is used among other factors to which
        location is selected.  Locations with lower remaining volume
        get higher priority, and locations with no set volume counter
        get lower priority.

        Examples:
         * Clear volume in all locations of type "Well" or "Bottle":
             LiquidVOLume~ -types=Well,Bottle

         * Clear volume in A1 and A2:
             LiquidVOLume~ A1 A2
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('types', type=str, split=",", named=True, default=["Well", "Bottle", "MixingWell"],
                          description="location types")
            self.setInput('locations', type=str, repeats=(0, None), 
                          description="Location(s) or reagents to be cleared")


        def run (self, context="", types=(), *locations):
            if locations:
                candidates   = set()
                for location in locations:
                    if '*' in location or '?' in location:
                        locs = self.parent.locationsByType(context, None, types, location)
                        candidates.update(locs)
                    else:
                        self.parent.getLocationSection(context, location)
                        candidates.add(location)

                locations = sorted(list(candidates))

            elif types:
                locations = self.parent.locationsByType(context, None, types)


            self.parent.debug("Clearing liquid volumes in location(s): %s"%
                              (", ".join(locations) or "(None)"))

            for location in locations:
                self.parent.clearLiquidVolume(context, location, save=False)



    class RATe_Set (Controlling, LocationLeaf):
        '''
        Set asiration/disense rates for the specified location
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('aspirate', type=int, range=(1, None), named=True, default=None,
                          units='microliters per second')
            self.setInput('dispense', type=int, range=(1, None), named=True, default=None,
                          units='microliters per second')
            self.setInput('default', type=int, range=(1, None), default=None,
                          units='microliters per second')


        def run (self, context="", location=str, aspirate=int, dispense=int, default=int):
            for key, rate in ((self.parent.AspirateRate, aspirate),
                               (self.parent.DispenseRate, dispense),
                               (self.parent.Rate, default)):
                if rate is not None:
                    self.parent.setvalue(context, location, key, rate)


    class RATe_Clear (Controlling, LocationLeaf):
        '''
        Clear aspirate/disense rates for the specified location
        '''

        def run (self, context="", location=str):
            for key in self.parent.AspirateRate, self.parent.DispenseRate, self.parent.Rate:
                self.parent.clearValue(context, location, key)


    class RATe_Query (Observing, LocationLeaf):
        '''
        Return the aspirate/dispense rates for the specified location
        '''

        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('aspirate', type=int, default=None, named=True,
                           units='microliters per second')
            self.addOutput('dispense', type=int, default=None, named=True,
                           units='microliters per second')
            self.addOutput('default', type=int, default=None,
                           units='microliters per second')

        def run (self, context="", location=str):
            rates = [ self.parent.getValue(context, location, key)
                      for key in (self.parent.AspirateRate,
                                  self.parent.DispenseRate,
                                  self.parent.Rate) ]
            return tuple(rates)


    class EXPiration_Set (Controlling, LocationLeaf):
        '''
        Set the expiration time for the specified location.

        Where there are several locations containing the same reagent,
        the the expiration time is used among other factors to
        determine which location is selected. The location which is to
        expire soonest gets higher priority, and locations with no set
        expiration time get lower priority.

        This location will no longer be used for reagent transfers once the
        specified expiration time has passed.
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('expiration', type=int,
                          units='seconds since epoch',
                          description='Expiration time of reagent stored in this '
                          'location.')


        def run (self, context="", location=str, expiration=int):
            self.parent.setValue(context, location,
                                 self.parent.Expiration,
                                 expiration)


    class EXPiration_Clear (Controlling, LocationLeaf):
        '''
        Clear expiration time for the specified location.

        This location will now be used for reagent transfers with no
        consideration to expiration time.

        Where there are several locations containing the same reagent,
        the the expiration time is used among other factors to
        determine which location is selected. The location which is to
        expire soonest gets higher priority, and locations with no set
        expiration time get lower priority.
        '''

        def run (self, context="", location=str):
            self.parent.clearValue(context, location,
                                   self.parent.Expiration)


    class EXPiration_Query (Observing, LocationLeaf):
        '''
        Obtain the expiration time for the specified location.

        Where there are several locations containing the same reagent,
        the the expiration time is used among other factors to
        determine which location is selected. The location which is to
        expire soonest gets higher priority, and locations with no set
        expiration time get lower priority.
        '''


        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('default', type=str,
                          description='If there is no expiration time for '
                          'specified location, return the specified value '
                          'rather than raising an error')

        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('time', type=int, units='seconds since epoch')

        def run (self, ignoreMissing=False, default=None, context="", location=str):
            expiration = self.parent.getValue(context, location, self.parent.Expiration, default)
            if expiration is None and not ignoreMissing:
                raise self.parent.NoExpiration(location=self.parent.locationName(context, location))

            return expiration



    class REAGent_Set (Controlling, LocationLeaf):
        '''
        Specify reagent to be stored in a given location.
        This can subsequently be used instead of the location name in
        ASPirate, DISPense and TRANsfer commands.

        Multiple locations may use the same reagent name.  If a reagent name
        is mapped to multiple locations, subsequent aspirate/dispense/transfer
        commands will choose the location with the least amount of reagent volume
        left, if known; otherwise the first location sorted alphabetically by name.
        '''

        def run (self, context="", location=str, reagent=str):
            self.parent.setReagent(context, location, reagent)


    class REAGent_Clear (Controlling, LocationLeaf):
        '''
        Clear any reagent specification from the given location.
        '''

        def run (self, context="", location=str):
            self.parent.setReagent(context, location, None)


    class REAGent_Query (Observing, LocationLeaf):
        '''
        Return locations that contain the specified reagent.

        By default, all such locations are listed in alphabetical
        order.  However, if "-prioritized" is given, locations are
        qualified and prioritized as follows:

          * If there is an expiration time defined for this location,
            it is disqualified if it is in the past.

          * If volume tracking is enabled for this location,
            it is disqualified if it is empty.

        Remaining qualifying locations are sorted as follows:

          * If "-purpose" is given, then reagent with matching purpose
            fields are listed first.

          * Next, locations are ordered by expiration time, soonest first.
            Locations without expiration time are listed last.

          * Next, locations are ordered by remaining reagent volume,
            least first.  Locations with no volume counting are listed
            last.

        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('ignoreMissing',
                          description='Do not raise an error if the reagent is not found')

            self.setInput('ignoreExpiration',
                          description='Include expired reagents')

            self.setInput('purpose', type=str, default=None,
                          description='Reagent purpose, e.g. "A" or "ECC"')

            self.setInput('prioritized',
                          description='Qualify and sort locations in priority order')

            self.setInput('allowLocations', type=bool, default=False,
                          description='If supplied name is not a reagent, use it as location')


        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('locations', type=str, default=None, repeats=(0, None))


        def run (self, ignoreMissing=False, ignoreExpiration=False, purpose=None, prioritized=False, allowLocations=False,
                 context=None, reagent=str):

            if prioritized:
                sortedlist = self.parent.getPrioritizedLocations(context, reagent,
                                                                 purpose=purpose,
                                                                 allowLocations=allowLocations,
                                                                 ignoreMissing=ignoreMissing,
                                                                 ignoreExpiration=ignoreExpiration)
                locations  = [ item[-1] for item in sortedlist ]

            else:
                locations = self.parent.getReagentLocations(context, reagent, ignoreMissing=ignoreMissing)

            return tuple(locations)


    class REAGent_Enumerate (Observing, LocationLeaf):
        '''
        Return a list of available reagents.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs (self)
            self.addOutput('reagent', type=str, repeats=(0, None))

        def run (self, context=""):
            return tuple(self.parent.listReagents(context))



    class ReagentVOLume_Query (Observing, LocationLeaf):
        '''
        Return total volume of the specified reagent.
        '''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput('allowExpired', type=bool, named=True, default=False,
                          description='Allow aspiration from expired wells')
            self.setInput('purpose', type=str, default=None,
                          description='Reagent purpose, e.g. "A" or "ECC"')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('volume', type=float, units='microliters', default='-')

        def run (self, allowExpired=False, purpose=None, context="", reagent=str):
            return self.parent.getReagentVolume(context, reagent, purpose=purpose, ignoreExpiration=allowExpired)



    class STRIP_Set (Controlling, LocationLeaf):
        '''
        Identify the strip for the specified location.
        This information is used to prioritize locations for reagent
        aspirations, such that locations within the same strip are
        prioritized simultaneously.
        '''

        def run (self, context="", location=str, strip=str):
            self.parent.setValue(context, location,
                                 self.parent.Strip, strip)

    class STRIP_Clear (Controlling, LocationLeaf):
        '''
        Remove strip information for the specified location.
        '''

        def run (self, context="", location=str):
            self.parent.clearValue(context, location,
                                   self.parent.Strip)


    class STRIP_Query (Observing, Leaf):
        '''
        List locations includeed in the specified strip.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('location', type=str, repeats=(1, None))


        def run (self, strip=str):
            try:
                locations = self.parent.strips[strip.lower()]
            except KeyError:
                raise self.parent.NoSuchStrip(name=strip)

            locnames = [ self.parent.locationName(*loc) for loc in locations ]
            return tuple(locnames)


    class STRIP_Enumerate (Observing, Leaf):
        '''
        List all location strips
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('strip', type=str, repeats=(0, None))

        def run (self):
            strips = self.parent.strips.keys()
            strips.sort()
            return tuple(strips)


    class StripVOLume_Query (Observing, Leaf):
        '''
        Return total volume of all locations in the specified strip.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('volume', type=float, units='microliters', default='-')

        def run (self, strip=str):
            return self.parent.getStripVolume(strip)



    class PURPose_Set (Controlling, LocationLeaf):
        '''
        Set a purpose identifier for this reagent location.

        Where several locations contain the same reagent, setting a
        purpose will keep this location from being used for subsequent
        aspirations with different purpose specified, until all other
        locations with either matching purpose or no purpose are empty.

    Examples:
      * Say that locations A3, B3 and C3 all contain the same reagent,
        "FwdProbeB".  The first two will be used for standard cycles
        (purpose "A"), whereas C3 will be used for ECC cycles (purpose
        "ECC"):

           FLUidics:PURPose -context=FlowChip1 A3 "A"
           FLUidics:PURPose -context=FlowChip1 B3 "A"
           FLUidics:PURPose -context=FlowChip1 C3 "ECC"

        In this case, the following command will aspirate from C3 if
        there is any reagent left there, otherwise fall back to A3 or
        B3:

           FLUidics:ASPirate -purpose=ECC -volume=30 FwdProbeB

        '''

        def run (self, context="", location=str, purpose=str):
            self.parent.setValue(context, location,
                                 self.parent.Purpose, purpose.upper())

    class PURPose_Clear (Controlling, LocationLeaf):
        '''
        Clear purpose for this location.  See the "PURPose=" command to
        learn more.
        '''

        def run (self, context="", location=str):
            self.parent.clearValue(context, location, self.parent.Purpose)


    class PURPose_Query (Observing, LocationLeaf):
        '''
        Return the purpose of this reagent location, if any.
        '''

        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('purpose', type=str, default="-")

        def run (self, context="", location=str):
            return self.parent.getValue(context, location,
                                        self.parent.Purpose)

    class ROBot_Add (Administrative, RobotBase, Leaf):
        '''
        Add a robot 
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('type', type=self.parent.robotTypes)

        def run (self, _session, replaceExisting=False, type=None, name=str):
            self.parent.addRobot(name, type, _session, replaceExisting)

    class ROBot_Remove (Administrative, RobotBase, Leaf):
        '''
        Remove a robot 
        '''

        def run (self, _session, ignoreMissing=False, name=str):
            self.parent.removeRobot(name, _session, ignoreMissing)


    class ROBot_Enumerate (Observing, RobotBase, Leaf):
        '''
        Return the names of robots in this system
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self):
            return tuple([robot.name for robot in self.parent.robots])


    class ROBot_Count (Observing, RobotBase, Leaf):
        '''
        Return the number of robots in this system
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self):
            return len(self.parent.robots)




EstimationCriteria["reagents"] = ("estimateReagents", ())



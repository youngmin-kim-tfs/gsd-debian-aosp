########################################################################
### FILE:	scpiIdleBranch.py
### PURPOSE:	Define and execute tasks during idle times (e.g. waits)
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2011 Life Technologies.  All rights reserved.
########################################################################

from scpiFullBranch import FullBranch
from scpiLeaf       import Leaf, Controlling, Observing, CommandWrapper
from scpiExceptions import RunError, InternalError
from scpiSession    import ASYNC
from schedule       import getUptime as uptime, sleep
from subscription   import warning
from cStringIO      import StringIO


class IDLE (CommandWrapper, FullBranch):

    tasks = {}
    _TaskFields = DUETIME, NAME, INTERVAL, DURATION, COMMAND, IGNOREERRORS = range(6)

    class TaskExists (RunError):
        'There is already an idle task named %(name)r'

    class NoSuchTask (RunError):
        'There is no idle task named %(name)r'

    def addTask (self, name, interval, duration, command,
                 ignoreErrors, replaceExisting=False):
        if not replaceExisting and name.lower() in self.tasks:
            raise self.TaskExists(name=self.tasks[name.lower()][self.NAME])

        self.tasks[name.lower()] = [uptime(), name, interval, duration, command, ignoreErrors]


    def delTask (self, name, ignoreMissing=False):
        try:
            del self.tasks[name.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchTask(name=name)

    def clearTasks (self):
        self.tasks.clear()

    def getTask (self, name, ignoreMissing):
        try:
            task = self.tasks[name.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchTask(name=name)
        else:
            duetime, name, interval, duration, command, ignoreErrors = task
            duetime -= uptime()
            return int(duetime), interval, duration, ignoreErrors, command


    def getTaskNames (self):
        return [ task[self.NAME] for task in self.tasks.values() ]


    def runTasks (self, _context, duration, skipWait=False):
        now     = uptime()
        endtime = now + duration
        tasks   = self.tasks.values()
        tasks.sort()


        duetasks = [ task[self.NAME] for task in tasks if task[self.DUETIME] <= now ]
        self.debug("Starting %.1fs idle period; tasks due for execution: %s"%
                   (duration, ", ".join(duetasks) or None))

        for task in tasks:
            remaining = endtime - now
            if (task[self.DUETIME] < now) and (task[self.DURATION] <= remaining):
                self.debug("Remaining idle time=%.1fs; starting task %r, expected duration=%.1fs"
                           %(remaining, task[self.NAME], task[self.DURATION]))

                starttime = now
                try:
                    self.runBlock(task[self.COMMAND], _context)
                except Error, e:
                    now  = uptime()
                    message = e.format(showArgs=True, showContext=True)
                    self.debug("Idle task %r failed: %s"%(task[self.NAME], message))
                    if task[self.IGNOREERRORS]:
                        warning("While running idle task %r: %s"%(task[self.NAME], e))
                    else:
                        raise

                else:
                    now  = uptime()
                    self.debug("Idle task %r completed, actual duration=%.1fs"%
                               (task[self.NAME], now - starttime))
                    
                task[self.DUETIME] = now + task[self.INTERVAL]


        if duration <= 0:
            progress = "without taking action"

        elif now > endtime:
            progress = "%.1fs late"%(now - endtime)

        elif skipWait:
            progress = "%.1fs early"%(endtime - now)

        else:
            remaining = endtime - now
            self.debug("Remaining idle time=%.1fs, sleeping."%(remaining,))
            sleep(remaining)
            now += remaining
            progress = "on time"

        self.debug("Ended %.1fs idle period %s"%(duration, progress))




    class WORK (Controlling, Leaf):
        '''
        Allow any pending idle tasks to run for the specified duration.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('skipWait', type=bool, default=False, named=True,
                          description='After completing idle tasks, return '
                          'immediately without waiting for idle time to elapse.')
            self.setInput('duration', type=float,
                          description='Anticipated idle time.  This is used to '
                          'determine which idle tasks(s) can be performed.')

        def run (self, _context, skipWait=False, duration=float):
            self.parent.runTasks(_context, duration, skipWait=skipWait)



    class TASK_Add (Controlling, Leaf):
        '''
        Add a task to be performed at idle times.
        '''
        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('replaceExisting', type=bool, named=True, default=False)

            self.setInput('interval', type=int, named=True, units='seconds',
                          description='Approximate desired gap between invocations '
                          'of this task.  If the interval is 0, try to execute it '
                          'at every idle moment.')

            self.setInput('duration', type=float, named=True, units='seconds',
                          description='Expected duration of each invocation')

            self.setInput('ignoreErrors', type=bool, named=True, default=False,
                          description='Ignore any errors raised during execution '
                          'of this task')

            self.setInput('name', type=str,
                          description='Unique name for this idle task')

            self.setInput('command', type=str,
                          description='Commands to execute')


        def run (self, replaceExisting=False,
                 interval=int, duration=float,
                 ignoreErrors=False,
                 name=str, command=str):
            self.parent.addTask(name, interval, duration, command, ignoreErrors,
                                replaceExisting)


    class TASK_Remove (Controlling, Leaf):
        '''
        Remove an existing idle task.
        '''

        def run (self, ignoreMissing=False, name=str):
            self.parent.delTask(name, ignoreMissing)


    class TASK_Clear (Controlling, Leaf):
        '''
        Clear all idle tasks.
        '''

        def run (self):
            self.parent.clearTasks()
        

    class TASK_Query (Observing, Leaf):
        '''
        Return information about an existing idle task
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('duetime', type=float, named=True, default=None)
            self.addOutput('interval', type=float, named=True, default=None)
            self.addOutput('duration', type=float, named=True, default=None)
            self.addOutput('ignoreErrors', type=bool, named=True, default=None)
            self.addOutput('command', type=str, repeats=(0, 1))
            
        def run (self, ignoreMissing=False, name=str):
            return self.parent.getTask(name, ignoreMissing)
            

    class TASK_Enumerate (Observing, Leaf):
        '''
        Return a list of names for each idle tasks.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self):
            return tuple(self.parent.getTaskNames())

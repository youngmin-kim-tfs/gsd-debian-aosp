########################################################################
### FILE:	scpiFlowControl.py
### PURPOSE:	Flow Control (IF, ELIF, ELS, UNLess, WHIL, UNTil)
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf       import Leaf, Public, CommandWrapper
from scpiExceptions import RunError
from threading      import currentThread
from subscription   import warning, info
from scpiSession    import ASYNC, SYNC, RAISE, PASSTHROUGH


class _FlowControlLeaf (Public, CommandWrapper, Leaf):
    delegateEstimation = True

    class OutOfContext (RunError):
        '''Previous command was not IF or ELseIF'''

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('command', repeats=(1, None))

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('outputs', type=tuple, repeats=(0, None))

    def hasBranched (self, context):
        if isinstance(context.leaf, _FlowControlLeaf):
            return context.branched
        else:
            raise self.OutOfContext()

    def setBranched (self, context, branched):
        context.branched = branched


class IF (_FlowControlLeaf):
    '''
    Execute "command" if "condition" is TRUE.
    To learn how conditions are evaluated, see "HELP? CONDITIONS".

Examples:
    * Set the variable "RunTitle" to "MyNewRun", but only
      if its current contents is "-":
        IF $["${RunTitle}" == "-"] <<<
           VAR= RunTitle MyNewRun
        >>>
    '''

    def run (self, _session, _context, condition=bool, *command):
        try:
            if condition:
                return _session.runBlock(command, _context, nextCommand=PASSTHROUGH)
        finally:
            self.setBranched(_context, condition)


class ELseIF (_FlowControlLeaf):
    '''
    Appicable only where the previous command was IF or ELSEIF.
    
    Execute "command" if the previous command returned False, and
    "condition" is True.

    To learn how conditions are evaluated, see: "HELP? CONDITIONS"
    '''

    def run (self, _session, _context, condition=bool, *command):
        try:
            if not self.hasBranched(_context) and condition:
                return _session.runBlock(command, _context, nextCommand=PASSTHROUGH)
        finally:
            if condition:
                self.setBranched(_context, True)


class ELSe (_FlowControlLeaf):
    '''
    Execute "command" if the previous command returned False,
    "condition" is True.

    To learn how conditions are evaluated, see: "HELP? CONDITIONS"
    '''

    def run (self, _session, _context, *command):
        try:
            if not self.hasBranched(_context):
                _session.runBlock(command, _context, nextCommand=PASSTHROUGH)
        finally:
            self.setBranched(_context, True)


class UNLess (_FlowControlLeaf):
    '''
    Execute "command" if "condition" is False.
    To learn how conditions are evaluated, see "HELP? CONDITIONS".

Examples:
    * Collect data from the scanner into the file ${file}, unless
      the file already exists.
        UNLess $(FILe:EXISts? ${file}) SCANner:COLLect 1 ${file}
    '''

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('condition', type=bool)

    def run (self, _session, _context, condition=bool, *command):
        try:
            if not condition:
                return _session.runBlock(command, _context, nextCommand=PASSTHROUGH)
        finally:
            self.setBranched(_context, not condition)



class WHILe (_FlowControlLeaf):
    '''
    Execute "command" repeatedly while "condition" is TRUE.
    To learn how conditions are evaluated, see "HELP? CONDITIONS".

Examples:
    * Invoke the "RunCycle" command 50 times (unless the "CycleTarget"
      variable is modified by a different thread in the mean time):
    
        VAR CycleIndex  0
        VAR CycleTarget 50
        WHILe $[ ${CycleIndex} < ${CycleTarget} ] RUN <multiline>
            RunCycle ${CycleIndex}
            ADDValue CycleIndex 1
        </multiline>

    '''

    def declareInputs (self):
        _FlowControlLeaf.declareInputs(self)
        self.setInput('testCondition', type=bool, named=True, default=None)
        self.setInput('synchronous', type=bool, named=True, default=False,
                      description='Wait for completion of all commands')
        self.setInput('condition', type=bool, form=tuple)


    def run (self, _session, _context,
             testCondition=None, synchronous=False, condition=bool, *command):

        param = self.getInput('condition')
        opt, cond, raw = condition
        runmode  = (ASYNC, SYNC)[synchronous]

        while cond:
            self.setBranched(_context, True)
            _session.runBlock(command, _context, nextCommand=ASYNC)
            arg  = _session.expandValue(raw, context=_context)
            cond = param.fromString(arg)



class UNTil (_FlowControlLeaf):
    '''
    Execute "command" repeatedly while "condition" is FALSE.
    To learn how conditions are evaluated, see "HELP? CONDITIONS".

    Each invocation will not start until the prior invocation has
    completed, even in the case of an asynchronous command.
    '''

    def declareInputs (self):
        _FlowControlLeaf.declareInputs(self)
        self.setInput('synchronous', type=bool, named=True, default=False,
                      description='Wait for completion of all commands')
        self.setInput('condition', type=bool, form=tuple)


    def run (self, _session, _context, 
             testCondition=None, synchronous=False, condition=bool, *command):

        param = self.getInput('condition')
        opt, cond, raw = condition
        runmode  = (ASYNC, SYNC)[synchronous]

        while not cond:
            self.setBranched(_context, True)
            _session.runBlock(command, _context, nextCommand=ASYNC)
            arg  = _session.expandValue(raw, context=_context)
            cond = param.fromString(arg)


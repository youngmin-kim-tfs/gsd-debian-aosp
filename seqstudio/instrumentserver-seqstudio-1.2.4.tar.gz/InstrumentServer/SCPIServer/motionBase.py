########################################################################
### FILE:	motionBase.py
### PURPOSE:	Base class for motion control
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch  import FullBranch
from scpiExceptions  import Aborted, Error, RunError, CommandError, NextReply, ExternalError
from scpiLeaf        import Leaf, Background, Controlling, Observing
from scpiBase        import Hidden
from scpiDynamicBase import DynamicCommandBase
from scpiConfigBase  import ConfigBase
from subscription    import debug, info, warning, publish
from runplan         import RunPlan
from locking         import Lock, Event
from thread          import error as ThreadError
from weakref         import ref
from math            import floor, ceil
from re              import compile


class SimpleAxis (FullBranch):
    '''Abstract superclass for axes'''

    HOMEPOS   = 'home'
    HOMEMOVE  = (HOMEPOS,)
    NOMOVE    = (None,)

    targetSpec = [ ('target',   { 'type':float, 'units':'steps'}) ]
    exclusive  = False

    def __init__ (self, prehome=NOMOVE,
                  skiphome=True, safe=True, *args, **kwargs):

        FullBranch.__init__(self, *args, **kwargs)
        SimpleAxis.init(self, prehome, skiphome, safe)


    def init (self, prehome, skiphome, safe):
        self.prehomepos      = prehome
        self.skiphome        = skiphome
        self.safeaxis        = safe
        self.powerstate      = True
        self._position       = None
        self._isHome         = None
        self._isHomed        = None
        self._moving         = False


    def setRawPosition (self, position):
        self._position = position

    def clearRawPosition (self):
        self._position = None


    def readRawPosition (self):
        return NotImplemented


    def getRawPosition (self, cached=True, **kwargs):
        if not cached or self._position is None or self._moving:
            self._position = self.readRawPosition(**kwargs)

        return self._position


    def getPosition (self, **kwargs):
        return self.getRawPosition()


    def sendToTarget (self, target, message):
        ### Should return a 2-element tuple: syncMethod, syncArgs
        self.debug("%s -- started"%(message,))
        
        raise NotImplemented


    def effectiveTarget (self, target, positionmap={}):
        return { self: target[0] }


    def setPowerState (self, state):
        self.powerstate = state


    def getPowerState (self):
        return self.powerstate


    def startHome (self, prehome=False, message="Homing"):
        targets = [self.HOMEMOVE]

        if prehome and self.isMove(*self.prehomepos) and self.isHomed():
            if message:
                message += " via pre-home position %s"%(self.targetString(*self.prehomepos))
                targets.insert(0, self.prehomepos)

        ref = self._nextMove(targets[0])

        if message:
            self.debug("%s -- starting"%(message,))

        return ref, targets, message


    def startMove (self, target, message="Moving to %s"):
        if message:
            message = message%(self.targetString(*target),)
            self.debug("%s -- starting"%(message,))

        ref = self._nextMove(target)
        return ref, [ target ], message


    def _nextMove (self, target):
        try:
            self._moving = True
            if self.equalPos(target, self.HOMEPOS):
                ref = self.sendHome()
            else:
                ref = self.sendToTarget(*target)

            return ref

        except Error, e:
            self.logFailure("Failed to initiate move to target %r"%(self.targetString(*target),),
                            target, e, verbose=True)
            self._moving = False
            raise

        
    def _syncMove (self, ref, target):
        try:
            try:
                self.clearRawPosition()
                return self.synchronize(ref)

            except Aborted, e:
                try:
                    self.stop(force=True)
                except Error, e2:
                    message = "Failed to abort motion"
                    error = e2
                else:
                    message = "Aborted move"
                    error = ExternalError(e, e.__class__.__name__)

                self.logFailure(message, target, error, verbose=True)
                raise

            except Error, e:
                self.logFailure("Failed during move", target, e, verbose=True)
                raise

        finally:
            self._moving = False
            self.clearRawPosition()


    def completeMove (self, ref, targets, message):
        for step, target in enumerate(targets):
            if step > 0:
                ref = self._nextMove(target)

            self._syncMove(ref, target)

        if message:
            try:
                rawpos = self.getRawPosition()
                curpos = self.fromRawPosition(rawpos)
            
            except Exception:
                rawpos = curpos = "(unknown)"

            self.debug("%s -- completed; now at position %s (step %s)"%(message, curpos, rawpos))


    def logFailure (self, message, target, e=None, verbose=True):
        if target:
            message += ", target=%s"%(self.targetString(*target),)

        try:
            message += ", current position=%s"%(self.getPosition(),)
        except Error:
            message += ", current position is unknown"

        if e:
            message += ": [%s] %s"%(e.name, e)

        self.info(message)

        if verbose:
            self.logCurrentState(verbose=True)

    def logCurrentState (self, verbose=False):
        pass

    def sendHome (self):
        pass

    def isHome (self, cached=False):
        return bool(self._isHome)

    def isHomed (self, cached=False):
        return bool(self._isHomed)

    def isMove (self, *target):
        for arg, value in zip(self.targetSpec, target):
            name, spec = arg
            if not 'default' in spec:
                return value is not None
        else:
            return False

    def equalPos (self, first, second):
        steplist = []
        for pos in first, second:
            if isinstance(pos, (tuple, list)):
                steplist.append(tuple(pos))
            else:
                steplist.append((pos,))
        return steplist[0] == steplist[1]

    def isActive (self, cached=True):
        return self._moving

    def synchronize (self, ref, abortable=True):
        self._isHome = False

        if ref:
            method, args, opts = ref
            method(*args, **opts)

        home = (target == self.HOMEPOS)
        self._isHome   = home
        self._isHomed |= home


#    def addParams (self, method, params, **options):
#        for name, props in params:
#            defaults = options.copy()
#            defaults.update(props)
#            method(name, **defaults)

    def targetString (self, *args, **kwargs):
        t = self.targetTuple(*args, **kwargs)
        l = []

        for spec, value in zip(self.targetSpec, args):
            name, props = spec
            if not props.get('named'):
                l.append("%s"%(value,))
            elif not value in (None, props.get('default')):
                l.append("%s=%s"%(name, value))

        l.extend([ "%s=%s"%item for item in kwargs.items() ])

        return "(%s)"%", ".join(l)


    def targetTuple (self, *args, **kwargs):
        l = []
        for argindex, spec in enumerate(self.targetSpec):
            name, options = spec
            if name in kwargs:
                value = kwargs[name]
            elif len(args) > argindex:
                value = args[argindex]
            else:
                value = options.get('default')

            l.append(value)

        return tuple(l)


    def targetOptions (self, target):
        options = {}
        for arg, value in zip(self.targetSpec, target):
            name, spec = arg
            if 'default' in spec:
                options[name] = value
        return options

    def addTargetParams (self, method, **defaults):
        for option, props in self.targetSpec:
            spec = defaults.copy()
            spec.update(props)
            method(option, **spec)

    def prefixedName (self, name, named=False, **props):
        n = self.name
        if named:
            n += name[:1].upper() + name[1:]
        return n


    def stop (self, force=False):
        ref = self.sendStop(force)
        self.waitStop(ref)

    def sendStop (self, force):
        pass

    def waitStop (self, ref):
        pass

    def logCurrentState (self, verbose=False):
        pass
    

    class POWer (Controlling, Leaf):
        '''Power axis on/off.'''

        def run (self, state=bool):
            self.parent.setPowerState(state)


    class POWer_Query (Observing, Leaf):
        '''Indicate whether motion axis is powered on'''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('state', type=bool)

        def run (self):
            return self.parent.getPowerState()


    class STOP (Controlling, Leaf):
        '''
        Stop a move
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('force', type=bool, named=True, default=False,
                          description='Send STOP command even if axis is not currently moving.')

        def run (self, force=False):
            self.parent.stop(force)

        def prerun (self, *args):
            self.parent.parent.addToMove()

        def postrun (self, *args):
            self.parent.parent.endMove()


    class HOMe (Controlling, Background, Leaf):
        '''
        Home the axis
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignorePause', type=bool, named=True, default=False)
            self.setInput('preHome', type=bool, named=True, default=True,
                          description='Move the axis to its pre-home position, if any, '
                          'prior to homing.  See the "PreHOMe=" command.')

        def prerun (self, ignorePause=False, *args):
            self.parent.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.parent.endMove()

        def run (self, ignorePause=False, preHome=True):
            return self.parent.startHome(prehome=preHome)

        def next (self, *ref):
            self.parent.completeMove(*ref)


    class MOVe (Controlling, Background, Leaf):
        '''
        Move to the specified axis coordinate
        '''

        def declareInputs (self):
            self.startInputs()
            self.addInput('ignorePause', type=bool, named=True, default=False)
            self.parent.addTargetParams(self.addInput)

        def prerun (self, ignorePause=False, *args):
            self.parent.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.parent.endMove()

        def run (self, ignorePause=False, *target):
            return self.parent.startMove(target)

        def next (self, *ref):
            return self.parent.completeMove(*ref)



    class POSition (Hidden, MOVe):
        '''
        Depricated.  Please use "MOVe" instead.
        '''


    class PreHOMe_Set (Controlling, Leaf):
        '''
        Set pre-home position, to which this axis will be moved before
        homing with the "prehome" option enabled.

        This move is only performed when the axis has been homed at
        least once since power-on.
        '''

        def declareInputs (self):
            self.startInputs()
            self.parent.addTargetParams(self.addInput, default=None)

        def run (self, *position):
            self.parent.prehomepos = position


    class PreHOMe_Query (Observing, Leaf):
        '''
        Return pre-home position, to which this axis is moved before
        homing with the "prehome" option enabled.
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.parent.addTargetParams(self.addOutput, default=None)

        def run (self):
            return self.parent.prehomepos


    class HOMe_Query (Observing, Leaf):
        '''
        Return True if this axis is at home, False otherwise.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('cached', type=bool, default=False, named=True,
                          description='Use cached information if available')

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('home', type=bool)

        def run (self, cached=False):
            return self.parent.isHome(cached)


    class HOMeD_Query (Observing, Leaf):
        '''
        Return True if this axis has been homed, False otherwise.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('cached', type=bool, default=False, named=True,
                          description='Use cached information if available')

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('homed', type=bool)

        def run (self, cached=False):
            return self.parent.isHomed(cached)




class MotionAxis (SimpleAxis):
    '''Abstract superclass for axes that support direct motion'''

    ### List all input parameters used to set target coordinates.
    ### These are used for command such as "MOVe", as well as for commands
    ### that operate several axes concurrently (e.g. commands in the parent branch,
    ### profile commands, etc).
    ###
    ### Each item in the list should be a tuple containing:
    ###  * The argument name for commands within this branch.
    ###
    ###  * A dictionary containing argument attributes, e.g. type, default, etc
    ###    If this dictionary contains a 'named' attribute that is set to True,
    ###    the name of the argument is appended to the axis name for use in
    ###    commands in the parent branch; for instance, "steps" on the X axis
    ###    turns into an option named "-Xsteps".
    ###    Thus, at most one argument should remain unnamed.

    targetSpec    = [ ('target',   { 'type':float, 'units':'steps'}),
                      ('steps',    { 'type':bool, 'named':True, 'default':False }),
                      ('relative', { 'type':bool, 'named':True, 'default':False }) ]


    class NotWithinRange (RunError):
        '''Cannot move axis %(axis)s to position %(target)s: Allowed range is %(lower)s to %(upper)s'''

    class NotHomed (RunError):
        '''%(axis)s axis must be homed before it can be moved.'''

    def __init__ (self, skiphome=False, safe=False, overshoot=None, *args, **kwargs):
        SimpleAxis.__init__(self, skiphome=skiphome, safe=safe, *args, **kwargs)
        MotionAxis.init(self, overshoot)

    def init (self, overshoot=None):
        self.slack           = 0
        self.speed           = None
        self._defaultpos     = [ prop.get('default') for name, prop in self.targetSpec ]

        config               = self.parent.getMotionConfig()
        self.range           = config.getliteral(self.parent.RangeSection, self.name, tuple, None)
        self.positionMap     = config.getliteral(self.parent.PositionMap, self.name, tuple, None)
        self.scale           = config.getliteral(self.parent.ScaleSection, self.name, None, 1)
        self.overshoot       = overshoot


    def startMove (self, target, message="Moving to %s"):
        targets = [ target ]
        if message:
            firstmessage = message = message%(self.targetString(*target),)

        if self.overshoot:
            os, ostarget = self.overshoot
            current      = self.getRawPosition()
            destination  = self.toRawPosition(*target)

            if (current < destination < ostarget):
                temptarget = min(ostarget, destination + os)
            elif (current > destination > ostarget):
                temptarget = max(ostarget, destination - os)
            else:
                temptarget = None

            if temptarget is not None:
                if self.range:
                    lower, upper = self.range
                    if temptarget < lower != None:
                        temptarget = lower
                    if temptarget > upper != None:
                        temptarget = upper

                targetOptions = self.targetOptions(target)
                usesteps = targetOptions.get('steps', True)
                speed    = targetOptions.get('speed')

                if speed is not None and not usesteps:
                    speed = int(speed * abs(self.scale))

                targets = [ self.targetTuple(temptarget, steps=True, speed=speed),
                            self.targetTuple(destination, steps=True, speed=speed) ]

                overshoot = self.fromSteps(temptarget-destination, steps=usesteps)
                if message:
                    firstmessage += (", overshoot=%s"%(overshoot,))
                    

        if message:
            self.debug("%s -- starting"%(firstmessage,))

        ref = self._nextMove(targets[0])
        return ref, targets, message


    def sendToTarget (self, target, steps=True, relative=False):
        raise NotImplemented


    def getPosition (self, cached=True, steps=False, usemap=True, **kwargs):
        raw = self.getRawPosition(cached=cached)
        return self.fromRawPosition(raw, steps=steps, usemap=usemap, **kwargs)


    def clearSpeed (self):
        self.speed = None

    def setSpeed (self, speed, steps=False):
        if self.scale and not steps:
            speed *= abs(self.scale)
        self.speed = int(speed)

    def getSpeed (self, steps=False):
        speed = self.speed
        if speed and self.scale and not steps:
            speed /= abs(self.scale)
        return speed


    def clearScale (self):
        self.scale = 1
        self.parent.getMotionConfig().remove_option(self.parent.ScaleSection, self.name)


    def setScale (self, factor, save=False):
        self.scale = factor
        self.parent.getMotionConfig().set(self.parent.ScaleSection, self.name, self.scale, save=save)

    def getScale (self):
        return self.scale

    def setPositionMap (self, pmap, save=False):
        for step in pmap:
            self.checkValidRange(step, steps=True)

        self.positionMap = pmap
        self.parent.getMotionConfig().set(self.parent.PositionMap, self.name, self.positionMap, save=save)

    def clearPositionMap (self):
        self.positionMap = None
        self.parent.getMotionConfig().remove_option(self.parent.PositionMap, self.name)

    def getPositionMap (self):
        return self.positionMap

    def clearRange (self):
        self.range = None
        self.parent.getMotionConfig().remove_option(self.parent.RangeSection, self.name)


    def setRange (self, lower, upper, save=False, **options):
        r = [ self.toRawPosition(p, usemap=False, **options) for p in (lower, upper) ]
        self.range = min(r), max(r)

        if save:
            self.parent.getMotionConfig().set(self.parent.RangeSection, self.name, self.range)


    def getRange (self, steps=False, usemap=True, **options):
        if self.positionMap and not steps and usemap:
            return 0, len(self.positionMap)-1

        elif self.range:
            r = [ self.fromRawPosition(raw, steps=steps, **options) for raw in self.range ]
            return min(r), max(r)

        return None


    def checkValidRange (self, target, steps=False, relative=False, usemap=True, **kwargs):
        position = self.toRawPosition(target, steps=steps, relative=relative, usemap=usemap, **kwargs)

        if self.range and (steps or not (self.positionMap and usemap)):
            lower, upper = self.range
            if (position < lower != None) or (position > upper != None):
                validrange = [ self.fromRawPosition(raw, steps=steps, usemap=usemap, **kwargs) for raw in self.range ]
                target = self.fromRawPosition(position, steps=steps, usemap=usemap, **kwargs)
                try:
                    current = self.getPosition()
                except Exception:
                    current = '(unknown)'

                raise self.NotWithinRange(axis=self.commandPath(),
                                          target=target,
                                          lower=min(validrange),
                                          upper=max(validrange),
                                          current=current,
                                          steps=steps,
                                          **kwargs)



    def effectiveTarget (self, target, positionmap={}):
        return { self: self.toRawPosition(*target) }


    def toSteps (self, position, steps=False):
        if position in (None, self.HOMEPOS):
            return position

        elif self.scale and not steps:
            return int(position * self.scale)

        else:
            return position


    def fromSteps (self, step, steps=False, align=round):
        if (step in (None, self.HOMEPOS)):
            return step

        elif self.scale and not steps:
            position = step / float(self.scale)
            if isinstance(self.scale, int):
                position = int(align(position))

            return position
        
        else:
            return step


    def toRawPosition (self, position, steps=False, relative=False, usemap=True):
        if position in (None, self.HOMEPOS):
            return position

        if relative:
            current = self.getPosition(steps=steps, usemap=usemap)
            if current is None:
                return None

            position += current


        if self.positionMap and usemap and not steps:
            pmap = self.getPositionMap()
            try:
                position = pmap[int(round(position))]
            except IndexError:
                raise self.NotWithinRange(axis=self.commandPath(),
                                          target=position,
                                          lower=0,
                                          upper=len(pmap)-1)

        else:
            position = self.toSteps(position, steps)

        return position



    def fromRawPosition (self, position, steps=False, relative=False, usemap=True, align=round, **kwargs):
        if position in (None, self.HOMEPOS):
            return position


        if self.positionMap and usemap and not steps:
            pmap   = self.positionMap
            pindex = None
            pdelta = None

            for index, value in enumerate(pmap):
                delta = self.positionDelta(position, value)
                if pindex is None or delta < pdelta:
                    pindex = index
                    pdelta = delta

            position = pindex
        else:
            position = self.fromSteps(position, steps)


        if relative:
            current = self.getPosition(steps=steps)
            if current is None:
                return None

            position -= current

        return position


    def positionDelta (self, first, second):
        return abs(first - second)


    def equalPos (self, first, second):
        steplist = []
        for pos in first, second:
            if isinstance(pos, (tuple, list)):
                steplist.append(self.toRawPosition(*pos))
            else:
                steplist.append(pos)
        return steplist[0] == steplist[1]


    class SAFe_Set (Controlling, Leaf):
        '''
        Specify whether it is safe to move this axis without first moving
        other axes within the same motion system to their respective idle
        positions.  For instance, it may be safe to move a filter wheel,
        but unsafe to move a robotic axis.
        '''

        def run (self, safe=bool):
            self.parent.safeaxis = safe



    class SAFe_Query (Observing, Leaf):
        '''
        Indicate whether this axis is currently flagged as a "safe"
        axis, that is allowed to move without first moving other
        axes to their idle positions.
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('safe', type=bool)


        def run (self):
            return self.parent.safeaxis


    class SKIP_Set (Controlling, Leaf):
        '''
        If set, this axis will not be homed as part of the parent
        motion control system, unless specifically included.

        Note: If an idle position or idle home is specified for
        this axis, it will still be moved or homed prior to other
        axes.
        '''

        def run (self, skip=bool):
            self.parent.skiphome = skip


    class SKIP_Query (Observing, Leaf):
        '''
        Indicate whether this axis is skipped by default when homing
        the parent motion control system.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('skipped', type=bool)

        def run (self):
            return (self.parent.skiphome,)



    class POSition_Query (Observing, Leaf):
        '''
        Return the current coordinate of this axis
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False, named=True,
                          description='Return position as raw motor counts, '
                          'not scaled coordinates')
            self.setInput('cached', type=bool, default=True, named=True,
                          description='Use cached position if available')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('position', type=float, units='steps')

        def run (self, steps=False, cached=True):
            return self.parent.getPosition(steps=steps, cached=cached)


    class EffectivePOSition_Query (Observing, Leaf):
        '''
        Return the effective position of the specified coordinate.
        '''

        def declareInputs (self):
            self.startInputs()
            self.parent.addTargetParams(self.addInput)

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('position', type=int, default=None, description='Step position')

        def run (self, *position):
            return self.parent.toRawPosition(*position)


    class SPEED_Set (Controlling, Leaf):
        '''Set default motion speed/velocity for this axis'''

        def run (self, steps=False, speed=float):
            self.parent.setSpeed(speed, steps)


    class SPEED_Clear (Controlling, Leaf):
        '''Clear any default speed for this axis, thus allowing speed to be controlled elsewhere'''

        def run (self):
            self.parent.clearSpeed()


    class SPEED_Query (Observing, Leaf):
        '''
        Return current default speed setting for this axis.
        This may be different from the current actual speed in firmware.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, named=True, default=False,
                          description='Return speed in raw motor steps/second')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('speed', type=float, default=None)

        def run (self, steps=False):
            return self.parent.getSpeed(steps)


    class SCALe_Set (Controlling, Leaf):
        '''Set scale/position coefficient for this axis'''

        class ZeroScale (RunError):
            '''Zero scale factor not allowed'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("real", type=bool, default=False,
                          description="Return scaled position as a real number "
                          "rather than integer")
            self.setInput("save", type=bool, default=True,
                          description="save scale to persistent storage, thus making it permanent")
            self.setInput("scale", type=float,
                          description="Scaling factor")

        def run (self, real=False, save=True, scale=float):
            if not real:
                scale = int(scale)

            if scale:
                self.parent.setScale(scale, save=save)
            else:
                raise self.ZeroScale()


    class SCALe_Clear (Controlling, Leaf):
        '''Clear scale/position coeffient for this axis, i.e. turn off scaled coordinates'''

        def run (self):
            self.parent.clearScale()


    class SCALe_Query (Observing, Leaf):
        '''Read scale/position coeffeicent for this axis'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('real', type=bool, named=True)
            self.addOutput('scale', type=float)

        def run (self):
            scale = self.parent.getScale()
            real  = not isinstance(scale, int)
            return (real, scale)


    class PositionMAP_Set (Controlling, Leaf):
        '''
        Define a position map for this axis.

        The map consists of a series of raw step coordinates, and
        subsequent moves to a given position number, starting at 0,
        will instead move to the corresponding coordinate.

        If both a position map and a scale coefficient are specified
        for the axis, the former takes precedence.

    Examples:
      * Set coordinate positions for filter wheel positions 0 through 4,
        starting at step 5000 and spaced 10000 steps apart:
        > PositionMAP= 5000 15000 25000 35000 45000

      * Now move to filter #0, step 5000:
        > MOVe 0

        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("save", type=bool, default=True, named=True,
                          description="Save the position map to persistent storage, thus making it permanent")
            
            self.setInput("steps", type=int, repeats=(1, None), units="steps",
                          description="Step coordinates corresponding to each position.")

        def run (self, save=True, *steps):
            self.parent.setPositionMap(steps, save)


    class PositionMAP_Clear (Controlling, Leaf):
        '''
        Clear the position map for this axis.  Subsequently, moves to
        a given position will move to the corresponding raw or scaled
        coordinate.
        '''

        def run (self):
            self.parent.clearPositionMap()


    class PositionMAP_Query (Observing, Leaf):
        '''
        Return any position map in effect for this axis.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('steps', type=int, repeats=(0, None),
                           description="Step coordinates corresponding to each position.")

        def run (self):
            return self.parent.positionMap


    class RANGe_Set (Controlling, Leaf):
        '''Set valid range for this motion axis'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, default=True, named=True,
                          description='Specify values in steps, rather than scaled units')
            self.setInput('save', type=bool, default=True, named=True,
                          description='Save the range to persistent storage, thus making it permanent')
            self.setInput('min', type=float, default=None,
                          description='Mininum position')

            self.setInput('max', type=float, default=None,
                          description='Maxinum position')

        def run (self, steps=False, save=True, min=float, max=float):
            self.parent.setRange(min, max, save=save, steps=steps)


    class RANGe_Clear (Controlling, Leaf):
        '''Clear valid range for this motion axis'''

        def run (self):
            self.parent.clearRange()



    class RANGe_Query (Observing, Leaf):
        '''Return valid position range for this axis'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("steps", type=bool, named=True, default=False)
            self.setInput("which", type=("min", "max"), named=False,
                          default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=float, named=False, repeats=(0, 2))

        def run (self, steps=False, which=None):
            r = self.parent.getRange(steps=steps)
            if which is not None and r is not None:
                return r[which]
            else:
                return r


    class SLACK_Set (Controlling, Leaf):
        '''
        Set the maximum allowed "slack", used to determine whether the
        current position falls within a bounding box.  This is needed
        in cases where after moving to the edge of a bounding box, the
        physical position is slightly outside the edge.
        '''

        def run (self, steps=False, slack=float):
            slack = self.parent.toSteps(slack, steps=steps)
            self.parent.slack = abs(slack)


    class SLACK_Query (Observing, Leaf):
        '''
        Return the maximum allowed "slack", used to determine whether
        the current position of this axis falls within a bounding box.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('steps', type=bool, default=False, named=True,
                          description='Return position as raw motor counts, '
                          'not scaled coordinates')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.parent.addTargetParams(self.addOutput, default=None)

        def run (self, steps=False):
            return abs(self.parent.fromSteps(self.parent.slack, steps=steps))


    class OverShoot_Set (Controlling, Leaf):
        '''
        Set overshoot (a.k.a. backlash compensation) for this axis.

        If enabled, moves towards "destination" will cause the axis to
        move beyond the target position by the specified overshoot,
        then back to the target.

        Moves away from the destination will remain unaffected.
        '''

        def declareInputs (self):
            self.startInputs()
            self.addInput('steps', type=bool, named=True, default=False)
            self.addInput('overshoot', type=float)
            self.addInput('destination', type=float, default=0)
            ### Subclasses may add additional inputs; these are handled in run().


        def run (self, steps=False, overshoot=float, destination=0.0, *targetParams):
            os  = abs(self.parent.toSteps(overshoot, steps=steps))

            args = (destination, steps, False) + targetParams
            ost = self.parent.toRawPosition(*args)

            self.parent.debug("Setting backlash overshoot to %s steps on moves towards raw target %s"%
                              (os, ost))

            self.parent.overshoot = (os, ost)
            

    class OverShoot_Clear (Controlling, Leaf):
        '''
        Clear backlash compensation overshoot for this axis.
        '''

        def run (self):
            self.parent.debug("Clearing backlash overshoot")
            self.parent.overshoot = None


    class OverShoot_Query (Observing, Leaf):
        '''
        Return any overshoot (a.k.a. backlash compensation) for this axis.
        '''

        def declareInputs (self):
            self.startInputs()
            self.addInput('steps', type=bool, named=True, default=False)

        def declareOutputs (self):
            self.startOutputs()
            self.addInput('overshoot', type=float, named=True, default=None)
            self.addInput('destination', type=float, named=True, default=None)


        def run (self, steps=False, *targetParams):
            try:
                os, ost = self.parent.overshoot

            except TypeError:
                pass

            else:
                overshoot = abs(self.parent.fromSteps(os, steps=steps))
                destination = self.parent.fromRawPosition(ost, steps, False, *targetParams)
                return overshoot, destination






class MotionLeaf (Leaf):
    '''Abstract superclass for robot/motion commands'''

    SupportedType = SimpleAxis

    def __init__ (self, *args, **kwargs):
        Leaf.__init__(self, *args, **kwargs)
        MotionLeaf.init(self)

    def init (self):
        self.motionBranch = self.parent
        while not self.motionBranch.istype(MotionBase):
            self.motionBranch = self.motionBranch.parent

    def getSupportedAxes (self):
        return [ axis
                 for axis in self.motionBranch.axes
                 if axis.istype(self.SupportedType) ]



class MotionControlLeaf (Controlling, MotionLeaf):
    '''Abstract superclass to perform operations on all axes at the same time'''


    def __init__ (self, *args, **kwargs):
        MotionLeaf.__init__(self, *args, **kwargs)
        MotionControlLeaf.init(self)

    def init (self):
        self.declareAxisInputs()

    def declareInputs (self):
        self.startInputs()

    def declareAxisInputs (self):
        self.commonInputIndex = self.axisInputIndex = len(self.inputList)

        for axis in self.motionBranch.axes:
            if axis.istype(self.SupportedType):
                self.addAxisInputs(axis)
        self.motionBranch.setAxisHooks(self.addAxisInputs,
                                      self.removeAxisInputs,
                                      self.SupportedType)

    def addAxisInputs (self, axis):
        '''
        Add input parameters associated with a new axis.
        '''
        axis.addTargetParams(self.addAxisInput, axis=axis, default=None)

    def removeAxisInputs (self, axis):
        axis.addTargetParams(self.removeAxisInput, axis=axis, default=None)


    def addAxisInput (self, name, axis, named=False, **options):
        try:
            if not named:
                param = self.addInput(axis.name, named=True, **options)

            elif name in self.inputMap:
                param = self.inputMap[name]
                param.refcount = getattr(param, 'refcount', 1) + 1

            else:
                param = self.insertInput(self.axisInputIndex, name, named=True, **options)
                self.axisInputIndex += 1
        except Exception, e:
            self.info("Could not add parameter %r for axis %s: [%s] %s"%(name, axis.name, e.__class__.__name__, e))
            raise

        return param

    def removeAxisInput (self, name, axis, named=False, **options):
        if not named:
            name = axis.name

        param = self.getInput(name)
        if getattr(param, 'refcount', 1) > 1:
            param.refcount -= 1

        else:
            return self.removeInput(name, named=True, **options)


    def getInputValue (self, name, arguments):
        try:
            param = self.getInput(name)
            index = self.inputList[self.commonInputIndex:].index(param)
            return arguments[index]
        except (KeyError, ValueError, IndexError):
            return None


    def unflattenedInputs (self, arguments, **attributes):
        params = self.inputList[self.commonInputIndex:]
        attributes.update([(param.name, value)
                           for (param, value) in zip(params, arguments) ])
        targets = self.motionBranch.unflattenedTarget(attributes)
        return targets




class MotionQueryLeaf (Observing, MotionLeaf):
    '''Abstract superclass to query parameters from several axes at the same time'''

    def __init__ (self, *args, **kwargs):
        MotionLeaf.__init__(self, *args, **kwargs)
        MotionQueryLeaf.init(self)

    def init (self):
        self.declareAxisOutputs()

    def declareAxisOutputs (self):
        self.commonOutputIndex = self.axisOutputIndex = len(self.outputList)
        for axis in self.motionBranch.axes:
            if axis.istype(self.SupportedType):
                self.addAxisOutputs(axis)
        self.motionBranch.setAxisHooks(self.addAxisOutputs, self.removeAxisOutputs, self.SupportedType)


    def addAxisOutputs (self, axis):
        axis.addTargetParams(self.addAxisOutput, axis=axis, default=None)


    def removeAxisOutputs (self, axis):
        axis.addTargetParams(self.removeAxisOutput, axis=axis, default=None)


    def addAxisOutput (self, name, axis, named=False, **options):
        if not named:
            param = self.addOutput(axis.name, named=True, **options)

        elif name in self.outputMap:
            param = self.outputMap[name]
            param.refcount = getattr(param, 'refcount', 1) + 1

        else:
            param = self.insertOutput(self.axisOutputIndex, name, named=True, **options)
            self.axisOutputIndex += 1

        return param


    def removeAxisOutput (self, name, axis, named=False, **options):
        if not named:
            name = axis.name

        param = self.getOutput(name, ignoreMissing=True)
        if param and getattr(param, 'refcount', 1) > 1:
            param.refcount -= 1

        elif param:
            return self.removeOutput(name, ignoreMissing=True)


    def flattenedOutputs (self, target):
        flatTarget = dict(self.motionBranch.flattenedTarget(target))
        return [ flatTarget.get(output.name) for output in self.outputList[self.commonOutputIndex:] ]



class BoundingBox (object):
    HOMEPOS = 'home'
    LimitFields   = ('min', 'max', 'home', 'idlemin', 'idlemax')
    LimitDefaults = (None,  None,  False,  None,      None)

    def __init__ (self, name):
        self.name   = name
        self.limits = {}

    def setLimits (self, axis, min=None, max=None, home=False, idlemin=None, idlemax=None):
        self.limits[axis] = (min, max, home, idlemin, idlemax)

    def getLimits (self, axis):
        return self.limits.get(axis, self.LimitDefaults)

    def getIdlePosition (self, coordinates):
        idle = []

        for (axis, pos) in coordinates.items():
            lower, upper, home, idlemin, idlemax = self.getLimits(axis)
            if pos <= idlemin != None:
                idle.append((axis, idlemin))
            elif pos >= idlemax != None:
                idle.append((axis, idlemax))
            elif idlemin or idlemax:
                idle.append((axis, pos))

        return dict(idle)


    def distanceToIdle (self, coordinates):
        idlepos  = self.getIdlePosition(coordinates)
        distance = {}
        for (axis, current) in coordinates.items():
            if axis in idlepos:
                distance[axis] = abs(current - idlepos[axis])
        return distance



    def includes (self, coordinates, slack={}):
        for axis, limits in self.limits.items():
            low, high, home, idlemin, idlemax = limits
            try:
                pos = coordinates[axis]
            except KeyError:
                pass
            else:
                slk = slack.get(axis, 0)
                if pos == self.HOMEPOS:
                    if not home:
                        return False
                elif None < pos+slk < low:
                    return False
                elif pos-slk > high > None:
                    return False
        else:
            return True

    def nearestPoint (self, coordinates, axes=()):
        nearest = {}

        for axis in axes or self.limits:
            pos = coordinates.get(axis)
            if pos == self.HOMEPOS:
                pos = None

            elif pos is not None:
                low, high, home, idlemin, idlemax = self.getLimits(axis)
                
                if low < idlemin:
                    low = idlemin

                if high > idlemax > None:
                    high = idlemax

                if None < pos < low:
                    pos = low
                elif pos > high > None:
                    pos = high

            if pos is not None:
                nearest[axis] = pos

        return nearest


    def intersects (self, other):
        for axis, mylimits in self.limits.items():
            mymin, mymax, myhome, myidlemin, myidlemax = mylimits
            othermin, othermax, otherhome, otheridlemin, otheridlemax = other.getLimits(axis)
            if None < mymax < othermin:
                return False
            if mymin > othermax > None:
                return False
        else:
            return True



class MotionBase (DynamicCommandBase, ConfigBase, FullBranch):
    occupations     = {}      # Currently occupied motion reservations
    occupationMutex = Lock()

    class NoSuchReservation (RunError):
        '''There is no such reservation defined: %(name)s'''

    class ReservationWithNoAxes (RunError):
        '''Cannot require reservation %(name)r with no axes specified'''

    class ReservationWithSafeAxis (RunError):
        '''Cannot require reservation %(name) for safe axis %(axis)r'''

    class MotionDisabled (RunError):
        '''Motion is currently disabled'''

    class NoSuchAxis (RunError):
        '''There is no such axis: %(name)s'''

    class DuplicateAxisInstance (RunError):
        '''Cannot add axis %(name)r, because there can only be one %(type)s instance'''

    class DuplicateBoundingBox (RunError):
        '''There is already a bounding box named %(name)r'''

    class NoSuchBoundingBox (RunError):
        '''There is no bounding box named %(name)r'''

    class EmptyBoundingBox (RunError):
        '''Cannot create a bounding box with no motion limits'''

    class NotWithinBounds (RunError):
        '''%(system)s %(which)s is not within bounds'''

    class NoPathToTarget (RunError):
        '''Unable to move %(system)s to target position within existing bounding boxes'''



    Sections = (RangeSection, PositionMap, BoundingBoxSection, ScaleSection) = \
               ("Ranges", "Position Map", "BoundingBox", "Scales")

    _boundX = compile(r'%s:(\w+)$'%BoundingBoxSection)
    _config = None

    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        MotionBase.init(self)

    def init (self):
        self.axes           = []
        self.axishooks      = []
        self.motionLock     = Lock()
        self.motionActions  = 0
        self.reservations   = {}
        self.enabled        = True
        self.bounds         = None
        self.runnable       = Event()
        self.runnable.set()


    def configFileName (self):
        return self.name.lower() + "-motion.ini"

    def getMotionConfig (self):
        return self.getConfigInstance(self.configFileName(), literal=True)


    def setPowerState (self, state):
        for axis in self.axes:
            axis.setPowerState(state)

    def getPowerState (self):
        state = True
        for axis in self.axes:
            state &= axis.getPowerState()

        return state
    

    def disable (self):
        self.debug("Disabling motion")
        self.enabled = False

    def enable (self):
        self.debug("Enabling motion")
        self.enabled = True

    def pause (self):
        self.debug("Pausing motion")
        self.runnable.clear()

    def resume (self):
        self.debug("Resuming motion")
        self.runnable.set()


    def addAxis (self, session, name, cls, *args, **kwargs):
        if cls.exclusive:
            for axis in self.axes:
                if axis.istype(cls):
                    raise self.DuplicateAxisInstance(name=self.commandPath(name),
                                                     type=cls.__name__)

        axis = self.newAxis(session, name, cls, *args, **kwargs)
        self.axes.append(axis)
        for addhook, removehook, supportedType in self.axishooks:
            if axis.istype(supportedType):
                addhook(axis)
        return axis


    def removeAxis (self, session, name, ignoreMissing=False, type=MotionAxis):
        axis = self.delinstance(session, name, ignoreMissing=ignoreMissing,
                                commandType=type, parent=self)

        if axis:
            for addhook, removehook, supportedType in self.axishooks:
                if axis.istype(supportedType):
                    removehook(axis)
            self.axes.remove(axis)

        return axis


    def newAxis (self, session, name, axisclass,
                 replaceExisting=False, modifyAccess=None, type=MotionAxis, **kwargs):

        branch = axisclass(name=name, parent=self, **kwargs)
        self.addinstance(session, name, branch,
                         replaceExisting=replaceExisting,
                         modifyAccess=modifyAccess,
                         parent=self)

        return branch

    def setAxisHooks (self, addmethod, removemethod, supportedType=SimpleAxis):
        self.axishooks.append((addmethod, removemethod, supportedType))


    def sendHome (self, axes=None, prehome=True, reserve=True):
        if axes is None:
            axes = [ axis for axis in self.axes if not axis.skiphome ]

        plan    = RunPlan(legend="Homing %s"%("/".join(self.getAxisNames(axes))), logMethod=self.debug)

        if prehome:
            moves = {}
            for axis in axes:
                if axis.isMove(*axis.prehomepos) and axis.isHomed():
                    moves[axis] = axis.prehomepos

            if moves:
                legend = "Moving to pre-home position"
                plan.addStep(self.sendMoves, (moves,), {}, self.completeMoves, legend)

        moves  = dict([ (axis, axis.HOMEMOVE) for axis in axes ])
        plan.addStep(self.sendMoves, (moves,), {}, self.completeMoves, "Homing")
        plan.start()
        return plan.complete, ()

    def isHome (self, axes=None, cached=False):
        if axes is None:
            axes = [ axis for axis in self.axes if not axis.skiphome ]

        for axis in axes:
            if not axis.isHome(cached):
                return False
        else:
            return True

    def isHomed (self, axes=None, cached=False):
        if axes is None:
            axes = [ axis for axis in self.axes if not axis.skiphome ]

        for axis in axes:
            if not axis.isHomed(cached):
                return False
        else:
            return True


    def effectiveTarget (self, moves):
        etargets = {}

        for axis in self.axes:
            try:
                move = moves[axis]
            except KeyError:
                pass

            else:
                et = axis.effectiveTarget(move, etargets)
                etargets.update(et)

        return etargets


    def flattenedTarget (self, target, logitems=None):
        '''flattenedTarget(dict) -> list

        Translate a dictionary of lists with target positions for each axis into
        a flat list of (option, value) tuples.'''

        options = []
        if logitems:
            options.extend(logitems)
        coords  = []
        seen    = set()

        for axis in self.axes:
            if axis in target:
                values = target[axis]
                if not isinstance(values, (list, tuple)):
                    values = (values,)

                for targetSpec, value in zip(axis.targetSpec, values):
                    option, argspec = targetSpec
                    if not argspec.get('named'):
                        coords.append((axis.name, value))
                    elif not option in seen:
                        if value is None:
                            value = argspec.get('default')

                        if value is not None:
                            options.append((option, value))
                            seen.add(option)

        return coords + options


    def unflattenedTarget (self, attributes):
        '''unflattenedTarget(list) -> dict

        Translate input arguments, some of which are shared/named options, to
        a dictionary of lists with target inputs for each axis.
        '''

        if not isinstance(attributes, dict):
            attributes = dict(attributes)

        targets       = {}
        for axis in self.axes:
            target = []
            for option, argspec in axis.targetSpec:
                if not argspec.get('named'):
                    option = axis.name
                target.append(attributes.get(option))

            if axis.isMove(*target):
                targets[axis] = target

        return targets


    def targetString (self, target, logitems=None):
        try:
            items = [ "%s=%s"%item for item in (self.flattenedTarget(target, logitems)) ]
        except TypeError:
            self.info("Failed to get flattened target %s"%(target,))
            raise

        return ", ".join(items)


    def currentPositionString (self, currentPos=None, axes=None, **kwargs):
        if axes is None:
            axes = [ axis for axis in self.axes if axis.isHomed() ]
                
        if currentPos is None:
            currentPos = self.getCurrentPosition(axes=axes, **kwargs)
       
        items = [ "%s=%s"%(axis.name, currentPos.get(axis)) for axis in axes ]
        return ", ".join(items)


    def clipToBound (self, bound, moves):
        clippingInfo = []
        clippedMoves = {}
        etargets     = {}

        for axis in self.axes:
            try:
                move     = moves[axis]
            except KeyError:
                pass
            else:
                et = axis.effectiveTarget(move, etargets)
                etargets.update(et)
                clipped  = False
                emove    = {}

                for eaxis, etarget in et.iteritems():
                    lower, upper, home, idlemin, idlemax = bound.getLimits(eaxis)

                    if None < etarget < lower:
                        etarget = lower
                        clipped = True
                    elif etarget > upper > None:
                        etarget = upper
                        clipped = True

                    emove[eaxis] = eaxis.targetTuple(etarget, steps=True)
                    if clipped:
                        clippingInfo.append((eaxis.name, etarget))

                if clipped:
                    clippedMoves.update(emove)
                else:
                    clippedMoves[axis] = move

        return clippedMoves, clippingInfo


    def getAxisSelection (self, names, axisType=SimpleAxis, ignoreMissing=False):
        names      = set([ axis.lower() for axis in names ])
        selections = []

        for candidate in self.axes:
            cname = candidate.name.lower()
            if candidate.istype(axisType) and cname in names:
                selections.append(candidate)
                names.remove(cname)

        if names and not ignoreMissing:
            raise self.NoSuchAxis(name=names.pop())

        return selections


    def getAxisNames (self, axes=None, axisType=SimpleAxis):
        if axes is None:
            axes = [ axis for axis in self.axes if axis.istype(axisType) ]

        return [ axis.name for axis in axes ]


    def sendMoves (self, moves, logitems=None, ignoreErrors=False, reserve=True, force=False):
        if logitems is None:
            logitems = []
            
        if self.getBounds():
            ref = self.sendMovesWithinBounds(moves, logitems=logitems, reserve=reserve, force=force)
            return self.completeMovesWithinBounds, ref
        else:
            ref = self.sendDirectMoves(moves, logitems=logitems, reserve=reserve, force=force)
            return self.completeDirectMoves, ref


    def completeMoves (self, method, args):
        method(*args)


    def sendDirectMoves (self, targets, logitems, force=False, reserve=True, release=None, currentPos=None):
        self.debug("Direct move starting: %s, reserve=%s"%
                   (" ".join(["-%s=%s"%item for item in logitems + self.flattenedTarget(targets)]),
                    reserve))

        ops = []
        for axis in self.axes:
            try:
                target = targets[axis]
            except KeyError:
                pass
            else:
                if currentPos and axis in currentPos:
                    current = currentPos[axis]
                else:
                    current = axis.getRawPosition()

                if axis.equalPos(target, axis.HOMEPOS):
                    ops.append((axis, axis.startHome, (True, None)))
                elif force or not axis.isHomed() or not axis.equalPos(target, current):
                    ops.append((axis, axis.startMove, (target, None)))

        failure = None
        moves   = []

        if ops:
            if reserve:
                self.acquireReservations(targets)

            for axis, method, args in ops:
                try:
                    ref = method(*args)
                except Error, e:
                    if not failure:
                        failure = e
                else:
                    moves.append((axis, axis.completeMove, ref))
                

        return targets, moves, logitems, reserve, release, failure


    def completeDirectMoves (self, targets, moves, logitems, reserve, release, failure):
        currentPos = []
        result     = "completed"
        logitems   = list(logitems or [])

        try:
            for axis, method, args in moves:
                try:
                    method(*args)

                except Error, e:
                    if not failure:
                        result  = "failed"
                        failure = e
                        failure.update(axis=axis.commandPath())
        except Aborted, e:
            failure = e
            for axis, method, args in moves:
                try:
                    axis.stop(force=True)
                except Exception, e:
                    self.debug("Failed to abort direct move: [%s] %s"%
                               (e.__class__.__name__, e))
                    result = "failed"
                else:
                    result = "aborted"

        for axis in targets:
            try:
                pos = axis.getRawPosition()
            except Exception, e:
                logitems.append((axis.name, "(unknown)"))
            else:
                logitems.append((axis.name, pos))


        if release or (reserve and release is None):
            self.releaseUnusedReservations(targets)

        self.debug("Direct move %s; now at: %s"%
                   (result, " ".join(["-%s=%s"%item for item in logitems])))

        if failure:
            raise failure


    def shortestPath (self, targetBounds, currentPos):
        currentBounds = self.validBounds({},
                                         required=True,
                                         currentPos=currentPos,
                                         which="current position")


        path = self._shortestPath(currentBounds, targetBounds, startingPos=currentPos)

        currentString = ",".join([b.name for b in currentBounds])
        targetString  = ",".join([b.name for b in targetBounds])
        if not path:
            raise self.NoPathToTarget(system=self.commandPath(),
                                      currentBounds=currentString,
                                      targetBounds=targetString)
        return path


    def _shortestPath (self, currentBounds, targetBounds, visited=None, startingPos=None):
        if visited == None:
            visited = set()

        common = currentBounds & targetBounds
        if common:
            if startingPos:
                distances  = [ (sorted(b.distanceToIdle(startingPos).items()), b)
                               for b in common ]
                distances.sort()
                distance, bound = distances[0]
            else:
                bound = common.pop()
            return [ bound ]

        else:
            visited |= currentBounds

            path  = None
            found = None
            for bound in currentBounds:
                frontier  = self.neighbors(bound) - visited
                candidate = self._shortestPath(frontier, targetBounds, visited)
                if candidate and (not path or len(candidate) < len(path)):
                    path  = candidate
                    found = bound

            if found:
                path.insert(0, found)

            return path



    def validBounds (self, target, required=False, which=None, currentPos=None):
        targetmap  = self.effectiveTarget(target)

        stepmap    = {}
        if currentPos is not None:
            stepmap.update(currentPos)
        stepmap.update(targetmap)

        slack      = {}
        for axis in stepmap:
            if not axis in targetmap:
                slack[axis] = axis.slack

        bounds = self.validBoundsBySteps(stepmap, slack=slack)

        if required and not bounds:
            coordinates = dict([(a.name, pos) for (a, pos) in stepmap.iteritems()])
            raise self.NotWithinBounds(system=self.commandPath(),
                                       which=which, **coordinates)

        return bounds


    def validBoundsBySteps (self, stepmap, slack={}, candidates=None):
        if candidates is None:
            candidates = self.getBounds()

        bounds  = set()
        for bound in candidates:
            if bound.includes(stepmap, slack=slack):
                bounds.add(bound)

        return bounds


    def sendMovesWithinBounds (self, moves={}, logitems=None, targetBounds=None, force=False, reserve=True):
        ### Determine the "effective" target position.  This is the
        ### absolute destination after considering relative moves,
        ### reference based moves, or moves on axes that affect other
        ### axes (for instance, hardware autofocus)
        targetPos    = self.effectiveTarget(moves)

        ### Obtain the current position, but only for those axes
        ### that are relevant because they are subject to bounding
        ### limits, or are included in the target position.
        relevantAxes = self.boundedAxes()
        relevantAxes.update(targetPos)
        currentPos   = self.getRawPosition(axes=[axis for axis in relevantAxes if axis.isHomed()])

        ### Unless we were told explicitly what bounding box to move
        ### to, determine this from the effective target.
        if targetBounds is None:
            targetBounds = self.validBounds(moves, required=True,
                                            currentPos=currentPos,
                                            which="target")

        ### Find what bounding boxes we need to navigate through to
        ### get to the target.
        path       = self.shortestPath(targetBounds, currentPos)
        plan       = []
        moved      = False

        ### Create a motion plan, containing the successive nearest
        ### point from the current postion to each bounding box along
        ### the way to the target.
        posmap       = currentPos.copy()
        currentBound = path[0]
        for nextBound in path[1:]:
            posmap.update(currentBound.getIdlePosition(posmap))
            stepmap = nextBound.nearestPoint(posmap)
            plan.append(stepmap)
            posmap.update(stepmap)
            currentBound = nextBound

        ### Now, start an the target and go backwards, modifying
        ### intermediate target positions such that they end up closer
        ### to the final target.
        posmap.update(targetPos)
        currentBound = path[-1]
        for previousBound, planStep in zip(path[-2::-1], plan[-1::-1]):
            posmap.update(currentBound.getIdlePosition(posmap))
            nearestPoint = previousBound.nearestPoint(posmap, axes=planStep.keys())
            planStep.update(nearestPoint)
            posmap  = planStep
            currentBound = previousBound
        
        ### Create move plan by filling in idle moves within each bound.
        targetString = [("bounds", ",".join([b.name for b in path]))] + self.flattenedTarget(moves)
        self.debug("Bounded move starting: %s"%" ".join(["-%s=%s"%item for item in logitems+targetString]))

        moveplan  = RunPlan(logMethod=self.debug)
        posmap    = currentPos.copy()
        for currentBound, nextBound, point in zip(path, path[1:]+[None], plan):
            self.appendBoundedMove(moveplan, point, posmap, currentBound, nextBound, reserve=reserve, force=force)

        ### If we are not yet at the final target, add a final move to get us there.
        needsFinalMove = False
        for axis in moves:
            if force or (posmap.get(axis) != targetPos.get(axis)):
                needsFinalMove = True
                break

        if needsFinalMove:
            self.appendBoundedMove(moveplan, targetPos, posmap, path[-1], None, reserve=reserve, force=force)

        if moveplan:
            moveplan.start()

        return (moveplan, logitems)


    def completeMovesWithinBounds (self, moveplan, logitems):
        try:
            try:
                moveplan.complete()
                result = "completed"
            except Exception, e:
                result = "failed"
                raise
            
        finally:
            for axis in self.axes:
                try:
                    pos = axis.getRawPosition()
                except Exception, e:
                    logitems.append((axis.name, "(unknown)"))
                else:
                    logitems.append((axis.name, pos))

            self.debug("Bounded move %s; now at: %s"%
                       (result, " ".join([ "-%s=%s"%item for item in logitems ])))


    def appendBoundedMove (self, plan, targetmap, positionmap, currentBound, nextBound, **options):
        '''
        Perform a "pre-move" to a location that allows a subsequent
        direct move to the specified target position.  If any axes
        have "idle" positions within the specified bounding box,
        the corresponding axes are moved there first, followed by
        remaining axes being moved to their targets.
        '''

        idletarget  = currentBound.getIdlePosition(positionmap)
        hovertarget = {}
        finaltarget = targetmap.copy()

        if idletarget:
            for axis, targetstep in targetmap.items():
                if not axis in idletarget and \
                    (targetstep == axis.HOMEPOS or
                     (axis in positionmap and abs(positionmap.get(axis) - targetstep) > axis.slack)):
                    hovertarget[axis] = targetstep
                    del finaltarget[axis]
                
        if idletarget and hovertarget:
            self.appendDirectMove(plan, positionmap, idletarget, currentBound, options, "idle")
            self.appendDirectMove(plan, positionmap, hovertarget, currentBound, options, "hover")

        if not nextBound or not nextBound.includes(positionmap) and finaltarget:
            self.appendDirectMove(plan, positionmap, finaltarget, currentBound, options, "final")


    def appendDirectMove (self, plan, positionmap, target, bound, options, description):
        moves    = dict([ (axis, axis.targetTuple(step, steps=True, relative=False))
                           for axis, step in target.items()
                           if positionmap.get(axis) != step ])

        if moves:
            logitems = [ ("bound", bound.name), ("target", description) ]

            ### If we are moving a single axis, and the previous step also moved only that axis,
            ### we can optimize by eliminating that previous step.
            if len(moves)==1 and plan.steps:
                method, args, kwargs, sync, legend = laststep = plan.steps[-1]
                lastmove, lastlogitems = args
                if lastmove.keys() == moves.keys():
                    self.debug("Move plan eliminating redundant step: " + self.targetString(lastmove, lastlogitems))
                    del plan.steps[-1]
                
            self.debug("Move plan adding step: "+self.targetString(moves, logitems))
            plan.addStep(self.sendDirectMoves, (moves, logitems), options, self.completeDirectMoves)
            positionmap.update(target)
                                                                     
        

    def boundedAxes (self, bounds=None):
        axes = set()
        if bounds is None:
            bounds = self.getBounds()

        for b in bounds:
            axes.update(b.limits.keys())

        return axes


    def neighbors (self, bound):
        neighbors = set()
        for candidate in self.getBounds():
            if candidate is not bound and bound.intersects(candidate):
                neighbors.add(candidate)

        return neighbors


    def loadBounds (self):
        self.bounds = {}
        config = self.getMotionConfig()
        for section in config.sections():
            match = self._boundX.match(section)
            if match:
                name    = match.group(1)
                options = config.items(section, literal=True)
                box     = self.newBound(name, options)
                self.bounds[name.lower()] = box
                self.debug("Loaded bounding box %r"%name)


    def newBound (self, name, limits):
        box    = BoundingBox(name)
        limits = dict(limits)

        for axis in self.axes:
            valuemap = {}
            for prop in BoundingBox.LimitFields:
                try:
                    valuemap[prop] = limits.pop(axis.name + prop)
                except KeyError:
                    pass

            if valuemap:
                box.setLimits(axis, **valuemap)

        if limits:
            warning("Invalid option(s) given to bounding box %r: %s"%
                    (name, ", ".join(limits)))

        return box


    def saveBound (self, box, savetodisk=True):
        config  = self.getMotionConfig()
        section = self.boundSection(box)

        config.add_section(section)

        for axis, limits in box.limits.iteritems():
            for prop, default, value in zip(BoundingBox.LimitFields,
                                            BoundingBox.LimitDefaults,
                                            limits):
                if value is not None:
                    config.setliteral(section, axis.name + prop,
                                           value, save=False)

        if savetodisk:
            config.save()

    def boundSection (self, box):
        return ":".join((self.BoundingBoxSection, box.name))


    def addBound (self, box, replaceExisting=False, save=True):
        dupe = self.getBound(box.name, ignoreMissing=True)
        if dupe:
            if replaceExisting:
                self.delBound(dupe.name)
            else:
                raise self.DuplicateBoundingBox(name=dupe.name)

        self.bounds[box.name.lower()] = box
        if save:
            self.saveBound(box)


    def delBound (self, name, ignoreMissing=False, save=True):
        config  = self.getMotionConfig()
        box     = self.getBound(name, ignoreMissing)
        if box:
            del self.bounds[name.lower()]
            config.remove_section(self.boundSection(box), save=save)


    def getBound (self, name, ignoreMissing=False):
        try:
            if self.bounds is None:
                self.loadBounds()
            return self.bounds[name.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchBoundingBox(name=name)


    def getBounds (self, axes=None):
        if self.bounds is None:
            self.loadBounds()

        bounds = self.bounds.values()

        if axes:
            axes   = set(axes)
            bounds = [ b for b in bounds
                       if axes & set(b.limits) ]

        return bounds


    def listBounds (self, current=False, target={}):
        if current:
            currentPos = self.getRawPosition(axes=self.boundedAxes())
            bounds = self.validBounds({}, currentPos=currentPos)

        elif target:
            bounds = self.validBounds(target)

        else:
            bounds = self.getBounds()

        return [ b.name for b in bounds ]


    def clearBounds (self, save=True):
        config  = self.getMotionConfig()
        for box in self.getBounds():
            del self.bounds[box.name.lower()]
            config.remove_section(self.boundSection(box), save=save)


    def stop (self, axes, force):
        if axes is None:
            axes = self.axes
            
        stopped = []
        failure = None

        for axis in axes:
            try:
                ref = axis.sendStop(force)
            except Error, e:
                if not failure:
                    failure = e
                    failure.update(axis=axis.commandPath())
            else:
                stopped.append((axis, ref))

        for axis, ref in stopped:
            try:
                axis.waitStop(ref)
            except Error, e:
                if not failure:
                    failure = e
                    failure.update(axis=axis.commandPath())

        if failure:
            raise failure



    def moveToIdle (self, reserve=True):
        bounds     = self.getBounds()
        currentPos = self.getRawPosition(axes=self.boundedAxes(bounds))
        idlebound  = self.getIdleBound(bounds, currentPos)
        
        if idlebound:
            target   = idlebound.getIdlePosition(currentPos)
            logitems = [("bound", idlebound.name), ("target", "idle")]
            return self.sendDirectMoves(target, logitems=logitems, reserve=reserve, release=False)


    def getIdleBound (self, bounds, currentPos):
        distances  = [ (b.distanceToIdle(currentPos), b)
                       for b in bounds
                       if b.includes(currentPos) ]

        if distances:
            distances.sort()
            distance, bound = distances[0]
            return bound
            

    def getCurrentPosition (self, axes=None, cached=True, **kwargs):
        position = {}

        if axes is None:
            axes = self.axes

        for axis in axes:
            position[axis] = axis.getPosition(cached=cached, **kwargs)

        return position


    def getRawPosition (self, axes=None, cached=True, **kwargs):
        position = {}
        if axes is None:
            axes = self.axes

        for axis in axes:
            position[axis] = axis.getRawPosition(cached=cached, **kwargs)

        return position


    def clearRawPosition (self, axes=None):
        if axes is None:
            axes = self.axes

        for axis in axes:
            axis.clearRawPosition()


    def clearToMove (self, needEnabled=True, ignorePause=False):
        if needEnabled:
            if not self.enabled:
                raise self.MotionDisabled()

            if not ignorePause and not self.runnable.isSet():
                self.debug("Currently paused; waiting...")
                self.runnable.wait()

        if not self.motionLock.acquire(0):
            self.debug("Waiting for motion lock...")
            self.motionLock.acquire()

        self.debug("Acquired motion lock")
        self.clearRawPosition()

    def addToMove (self):
        self.motionActions += 1

    def endMove (self):
        if self.motionActions:
            self.motionActions -= 1
        else:
            self.debug("Releasing motion lock")
            self.motionLock.release()


    def updateReservations (self, axes):
        self.acquireReservations(axes)
        self.releaseUnusedReservations(axes)


    def hasReservations (self, axes):
        for reservation in self.findReservations(axes):
            if not self.occupiesReservation(reservation):
                return False
        return True


    def acquireReservations (self, axes):
        reservations = self.findReservations(axes)
        self.debug("Reservations required for axes %s: %s"%
                   ("/".join([a.name for a in axes]),
                    ", ".join(reservations) or "(None)"))

        if reservations:
            try:
                self.occupationMutex.acquire()

                for name in reservations:
                    self.acquireReservation(name)

            finally:
                self.occupationMutex.release()


    def acquireReservation (self, name):
        while not self.occupiesReservation(name):
            try:
                other = self.occupations[name]()
            except KeyError:
                other = None

            if other:
                other.relinquishReservation(name, self)

            else:
                self.occupations[name] = ref(self)

        self.debug('Reservation "%s" acquired'%(name,))


    def releaseUnusedReservations (self, axes):
        consideredAxes = [ a for a in axes if not a.safeaxis ]

        if consideredAxes:
            reservations = self.findReservations(axes)
            try:
                self.occupationMutex.acquire()

                for name, occupation in self.occupations.items():
                    if occupation() is self and not name in reservations:
                        del self.occupations[name]
                        self.debug('Reservation "%s" released'%(name,))
            finally:
                self.occupationMutex.release()


    def relinquishReservation (self, name, requestor):
        if self.occupiesReservation(name):
            self.debug('Reservation "%s" release to %s'%(name, requestor.commandPath()))
            del self.occupations[name]


    def addReservation (self, name, acquire, axes):
        if axes:
            for axis in axes:
                if axis.safeaxis:
                    raise self.ReservationWithSafeAxis(name=name, axis=axis.name)

        self.reservations[name.lower()] = set(axes)

        if acquire:
            self.acquireReservation(name.lower())


    def delReservation (self, name, ignoreMissing=False):
        try:
            del self.reservations[name.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchReservation(name=name)

    def getReservation (self, name, ignoreMissing=False):
        try:
            return self.reservations[name.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchReservation(name=name)


    def getReservations (self):
        return self.reservations


    def findReservations (self, targetAxes):
        return [ name for name, reservedAxes in self.reservations.items()
                 if not reservedAxes or (set(targetAxes) & set(reservedAxes)) ]


    def occupiesReservation (self, name):
        oref = self.occupations.get(name.lower(), False)
        return oref and (oref() is self)


    class ENABle (Controlling, Leaf):
        '''Enable motion'''

        def run (self):
            self.parent.enable()


    class DISable (Controlling, Leaf):
        '''Disable motion'''

        def run (self):
            self.parent.disable()


    class ENABled_Query (Observing, Leaf):
        '''Indicate whether motion is enabled'''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('enabled', type=bool)

        def run (self):
            return self.parent.enabled


    class POWer (Controlling, Leaf):
        '''Power on/off motion axes.'''

        def run (self, state=bool):
            self.parent.setPowerState(state)


    class POWer_Query (Observing, Leaf):
        '''Indicate whether motion axes are enabled'''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('state', type=bool)

        def run (self):
            return self.parent.getPowerState()



    class PAUSe (Controlling, Leaf):
        '''Pause motion until explicitly resumed'''

        def run (self):
            self.parent.runnable.clear()

    class RESume (Controlling, Leaf):
        '''Resume motion after pause'''

        def run (self):
            self.parent.runnable.set()

    class PAUSed_Query (Observing, Leaf):
        '''Indicate whether motion is currently paused'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('paused', type=bool)

        def run (self):
            return not self.parent.runnable.isSet()


    class STOP (Controlling, Leaf):
        '''
        Stop any motion currently in progress.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('force', type=bool, named=True, default=False,
                          description='Send STOP command even if axis is not currently moving.')

        def run (self, force=False, *axes):
            axes = self.parent.getAxisSelection(axes) or None
            self.parent.stop(axes, force)

        def prerun (self, *args):
            self.parent.addToMove()

        def postrun (self, *args):
            self.parent.endMove()



    class HOMe (Controlling, Background, Leaf):
        '''
        Move to home.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignorePause', type=bool, named=True, default=False)
            self.setInput('preHome', type=bool, named=True, default=True,
                          description="Move axes to their pre-home position prior to homing.")

        def prerun (self, ignorePause=False, *args):
            self.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.endMove()

        def run (self, ignorePause=False, preHome=True, *axes):
            axes = self.parent.getAxisSelection(axes, MotionAxis) or None
            return self.parent.sendHome(axes, prehome=preHome)

        def next (self, method, args):
            method(*args)


    class HOMe_Query (Observing, Leaf):
        '''
        Return True if all of the specified axes are at their home position, False otherwise.
        If no axes are specified, use all axes for which the SKIP flag is not set.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('cached', type=bool, default=False, named=True,
                          description='Use cached information if available')

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('home', type=bool)

        def run (self, cached=False, *axes):
            axes = self.parent.getAxisSelection(axes, MotionAxis) or None
            return self.parent.isHome(axes, cached)


    class HOMeD_Query (Observing, Leaf):
        '''
        Return True if the home positions for all the specified axes are valid.
        If no axes are specified, use all axes for which the SKIP flag is not set.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('cached', type=bool, default=False, named=True,
                          description='Use cached information if available')

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('homed', type=bool)

        def run (self, cached=False, *axes):
            axes = self.parent.getAxisSelection(axes, MotionAxis) or None
            return self.parent.isHomed(axes, cached)


    class IDLe (Background, Leaf):
        '''
        Move to idle position
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignorePause', type=bool, named=True, default=False)

        def prerun (self, ignorePause=False, *args):
            self.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.endMove()

        def run (self, ignorePause=False):
            self.parent.moveToIdle(ignorePause=ignorePause)

        def next (self, method=None, args=None):
            if method and args is not None:
                return method(*args)


    class MOVe (Background, MotionControlLeaf):
        '''
        Move to the specified coordinate
        '''

        def declareInputs (self):
            MotionControlLeaf.declareInputs(self)
            self.addInput('ignorePause', type=bool, named=True, default=False)
            self.addInput('force', type=bool, named=True, default=False,
                          description='Force move, even if already at position')

        def prerun (self, ignorePause=False, *args):
            self.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.endMove()

        def run (self, ignorePause=False, force=False, *position):
            target = self.unflattenedInputs(position)
            return self.parent.sendMoves(target, reserve=True, force=force)

        def next (self, *args):
            self.parent.completeMoves(*args)


    class MOVing_Query (Observing, Leaf):
        '''
        Indicate whether the subsytem is currently moving.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('moving', type=bool)

        def run (self):
            return self.parent.motionLock.locked()


    class POSition (Hidden, MOVe):
        '''
        Depricated.  Please use "MOVe" instead.
        '''


    class POSition_Query (MotionQueryLeaf):
        '''
        Return the axis coordinates of the current position
        '''

        def addAxisOutputs (self, axis):
            self.addOutput(axis.name, type=float, default=None, named=True)

        def run (self, steps=False, cached=False, *axes):
            axes = self.motionBranch.getAxisSelection(axes) or self.getSupportedAxes()
            pos  = [ (axis.name, axis.getPosition(steps=steps, cached=cached)) for axis in axes ]
            return dict(pos)


    class EffectivePOSition_Query (MotionControlLeaf, MotionQueryLeaf):
        '''
        Return the effective position of the specified coordinate.
        '''

        def __init__ (self, *args, **kwargs):
            MotionControlLeaf.__init__(self, *args, **kwargs)
            MotionQueryLeaf.init(self)

        def declareInputs (self):
            self.startInputs()
            self.addInput('steps', type=bool, default=False, named=True)


        def addAxisOutputs (self, axis):
            self.addOutput(axis.name, type=int, default=None, named=True,
                           description='Axis %s step position'%(axis.name,))

        def removeAxisOutputs (self, axis):
            self.removeOutput(axis.name)

#        def removeAxisOutputs (self, axis):
#            axis.addTargetParams(self.removeOutput, prefixed=True, default=None)
#            axis.addTargetParams(self.removeInput, prefixed=True, default=None)


        def run (self, steps=False, *position):
            target = self.unflattenedInputs(position, steps=steps)
#            steps = self.getInputValue('steps', position)

            return  dict([ (axis.name, pos)
                           for (axis, pos) in self.motionBranch.effectiveTarget(target).iteritems() ])

#            return  dict([ (axis.name, axis.fromRawPosition(pos, steps=steps))
#                           for (axis, pos) in self.parent.effectiveTarget(target).iteritems() ])


    class REServation_Add (MotionControlLeaf):
        '''
        Add a reservation spec where this motion subsystem requires exclusive access.
        If a reservation by the same name is defined in another motion subsystem,
        only one of these will be able to move within these respective zones at one time.

        This can be used to prevent robotic arms from crashing into each other,
        syringes from being bent while inserted into a movable stage underneath, etc.

    Example:
        STAGe:REServation+ Stage -X -Y
        FLUidics:ARM:REServation+ Stage -StageX -StageY

        FLUidics:ARM1:REServation+ Reagents -X -Theta
        FLUidics:ARM2:REServation+ Reagents -X -Theta
        '''


        def declareInputs (self):
            MotionControlLeaf.declareInputs(self)
            self.addInput('name', type=str)
            self.addInput('acquire', type=bool, default=False, named=True,
                          description='Acquire reservation immediately')
            self.addInput('axes', type={}, named=True, default=[], split=",")

        def addAxisInputs (self, axis):
            axes = [ (axis.name, axis) for axis in self.motionBranch.axes ]
            self.setInput('axes', type=dict(axes))

        def removeAxisInputs (self, axis):
            axes = [ (axis.name, axis) for axis in self.motionBranch.axes ]
            self.setInput('axes', type=dict(axes))

        def run (self, name, acquire, axes):
            self.parent.addReservation(name, acquire, axes)


    class REServation_Remove (Observing, Leaf):
        '''
        Remove the specified reservation zone.
        '''
        def run (self, ignoreMissing=False, name=str):
            self.parent.delReservation(name, ignoreMissing=ignoreMissing)


    class REServation_Query (Observing, Leaf):
        '''
        Return axis coordinates associated with the specified reservation zone.
        '''
        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('active', type=bool, default=None, named=True,
                           description=
                           "The specified reservation is currently held by this motion system")
            self.addOutput('axes', type=str, default=None, named=True)

        def run (self, ignoreMissing=False, name=str):
            active = self.parent.occupiesReservation(name)
            axes   = self.parent.getReservation(name, ignoreMissing=ignoreMissing)
            names  = [ axis.name for axis in axes ]
            return (active, ",".join(names) or None)


    class REServation_Enumerate (Observing, Leaf):
        '''
        List all reservation zones used by this motion control system.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self):
            return tuple(self.parent.getReservations())



    class BoundingBox_Add (MotionControlLeaf):
        '''
        Add a new Bounding Box, defining limits for motion.
        '''

        class UnrestrictedBound (RunError):
            '''
            Cowardly refusing to create bounding box %(name)r with no limits,
            as it is self-defeating.  Use '-allowEmpty' to override.
            '''

        class NamingPolicyViolation (CommandError):
            '''
            The name %(name)r does not start with an uppercase letter.
            '''

        SupportedType = MotionAxis

        def declareInputs (self):
            self.startInputs()
            self.addInput('replaceExisting', type=bool, default=False, named=True)
            self.addInput('allowEmpty', type=bool, default=False, named=True,
                          description='Create this bounding box even if no limits are provided. '
                          'Doing so will allow unrestricted motion, thus render all other '
                          'bounding boxes ineffective.')

            self.addInput('save', type=bool, default=True, named=True,
                          description='Do not save this bounding box to persistent storage. '
                          'This means it will not be available after restart.')

            self.addInput('steps', type=bool, default=False, named=True)
            self.addInput('name', type=str,
                          description="Name of bounding box")


        def addAxisInputs (self, axis):
            '''
            Add input parameters associated with a new axis.
            '''
            self.addInput(axis.prefixedName('min', named=True),
                          type=float, named=True, default=None,
                          description="Lower %s axis limit"%(axis.name))

            self.addInput(axis.prefixedName('max', named=True),
                          type=float, named=True, default=None,
                          description="Upper %s axis limit"%(axis.name))

            self.addInput(axis.prefixedName('home', named=True),
                          type=bool, named=True, default=False,
                          description="This box includes the %s axis home position"%(axis.name))

            self.addInput(axis.prefixedName('idlemin', named=True),
                          type=float, named=True, default=None,
                          description="When moving within this box, ensure that the %s "
                          "axis is moved to the specified position or higher"%(axis.name,))

            self.addInput(axis.prefixedName('idlemax', named=True),
                          type=float, named=True, default=None,
                          description="When moving within this box, ensure that the %s "
                          "axis is moved to the specified position or lower"%(axis.name,))



        def removeAxisInputs (self, axis):
            for name in ('min', 'max', 'home', 'idle'):
                self.removeInput(axis.prefixedName(name, named=True))


        def run (self, replaceExisting=False, allowEmpty=False, save=True,
                 steps=False, name=str, *limits):

            if not name[:1].isupper():
                raise self.NamingPolicyViolation(name=name)


            index      = 0
            restricted = False
            fieldsize  = len(BoundingBox.LimitFields)
            box        = BoundingBox(name)

            for axis in self.getSupportedAxes():
                low, high, home, idlemin, idlemax  = limits[index:index+fieldsize]
                if max(low, high, idlemin, idlemax) is not None:
                    low   = axis.toRawPosition(low, steps=steps)
                    high  = axis.toRawPosition(high, steps=steps)
                    idlemin = axis.toRawPosition(idlemin, steps=steps)
                    idlemax = axis.toRawPosition(idlemax, steps=steps)
                    box.setLimits(axis, low, high, home, idlemin, idlemax)
                    restricted = True
                index += fieldsize

            if not restricted and not allowEmpty:
                raise self.UnrestrictedBound(name=name)

            self.parent.addBound(box, replaceExisting=replaceExisting, save=save)



    class BoundingBox_Remove (Controlling, Leaf):
        '''
        Remove an existing bounding box.  If no boxes remain active, motion is unrestricted.
        '''

        def run (self, ignoreMissing=False, save=True, name=str):
            self.parent.delBound(name, ignoreMissing=ignoreMissing, save=save)


    class BoundingBox_Clear (Controlling, Leaf):
        '''
        Remove all existing bounding boxes, leaving motion unrestricted.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('save', type=bool, named=True, default=True)

        def run (self, save=True):
            self.parent.clearBounds(save=save)


    class BoundingBox_Query (MotionQueryLeaf):
        '''
        List limits in the specified motion bound.
        '''

        SupportedType = MotionAxis

        def addAxisOutputs (self, axis):
            '''
            Add output parameters associated with a new axis.
            '''
            self.addOutput(axis.prefixedName('min', named=True),
                           type=float, named=True, default=None,
                           description="Lower %s axis limit"%(axis.name))

            self.addOutput(axis.prefixedName('max', named=True),
                           type=float, named=True, default=None,
                           description="Upper %s axis limit"%(axis.name))

            self.addOutput(axis.prefixedName('home', named=True),
                           type=bool, named=True, default=False,
                           description="Set if this box is to include the axis home position")

            self.addOutput(axis.prefixedName('idlemin', named=True),
                           type=float, named=True, default=None,
                           description="Axis minimum %s position while moving other axes"%(axis.name))

            self.addOutput(axis.prefixedName('idlemax', named=True),
                           type=float, named=True, default=None,
                           description="Axis maximum %s position while moving other axes"%(axis.name))



        def removeAxisOutputs (self, axis):
            for name in ('min', 'max', 'home', 'idlemin', 'idlemax'):
                self.removeOutput(axis.prefixedName(name, named=True))
        


        def run (self, ignoreMissing=False, steps=False, name=str):
            box = self.parent.getBound(name, ignoreMissing=ignoreMissing)

            if box:
                limits = []
                for axis in self.getSupportedAxes():
                    low, high, home, idlemin, idlemax = box.getLimits(axis)
                    low     = axis.fromRawPosition(low, steps=steps)
                    high    = axis.fromRawPosition(high, steps=steps)
                    idlemin = axis.fromRawPosition(idlemin, steps=steps)
                    idlemax = axis.fromRawPosition(idlemax, steps=steps)
                    limits.extend((low, high, home, idlemin, idlemax))

                return tuple(limits)


    class BoundingBox_Enumerate (Observing, MotionControlLeaf):
        '''
        List available motion bounds
        '''

        def declareInputs (self):
            MotionControlLeaf.declareInputs(self)
            self.addInput('current', type=bool, default=False, named=True,
                          description="List only bounding boxes that include the current position")

        def declareOutputs (self):
            MotionControlLeaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self, current=False, *position):
            target = self.unflattenedInputs(position)
            bounds = self.parent.listBounds(current, target)
            bounds.sort()
            return tuple(bounds)



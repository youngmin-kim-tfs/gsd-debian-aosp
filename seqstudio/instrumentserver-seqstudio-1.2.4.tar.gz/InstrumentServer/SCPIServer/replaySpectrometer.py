########################################################################
### FILE:	replaySpectrometer.py
### PURPOSE:	IS interface to Replay Spectrometer for simulation
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2015 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBranch           import branchTypes
from scpiLeaf             import Controlling, Observing, Background, Leaf
from scpiFilesystemBase   import FilesystemLeaf
from scpiFileContexts     import P_READ, OP_READ
from scanningSpectrometer import ScanningSpectrometer
from spectrometerBase     import SpectrometerBase
from scpiExceptions       import RunError
from subscription         import info, warning
from threadControl        import currentThread

import re, time, sys


SpectrometerInfo = [ (123, 'Camera SN: 12345', 'Replay Spectrometer') ]


class Spectrometer (object):
    '''Replay Spectrometer: Process data from a previously-acquired CSV file.'''

    FirmwareVersion = 3.141592653589793238
    LibraryVersion  = '1.2.3.4'
    
    gainname  = 'Gain 0'
    speedname = 'Speed 0'


    def __init__(self):
        self.ProductID    = 0
        self.SerialNumber = ""
        self.DeviceType   = ""
        self.reset()
        self.frameDelay   = None
        self.startFrame   = None


    def reset (self):
        self.regions       = []
        self.coefficients  = []
        self.coeffDivisor  = 1
        self.description   = ""
        self.binning       = 1
        self.exposure      = 0
        self.gainname      = None
        self.speedname     = None
        self.chipSize      = (2048, 70)
        self.chipCount     = 1
        self.data          = []
        self.datasize      = []
        self.dataslices    = []
        self.customData    = []
        self.collected     = 0
        self.capturedate   = None
        self.capturetod    = None
        self.capturetime   = None
        self.starttime     = None
        self.filename      = None
        self.acquiring     = False
        self.startFrame    = None
        self.endFrame      = None
        self.customColumn  = None


    ### Spectrometer API, modelled after the HoribaSpectrometer C++ extension module

    def GetDataRegions (self):
        return self.regions

    def GetChipSize (self):
        return self.chipSize

    def GetNumChipsInUse (self):
        return self.chipCount

    def GetPixelBinning (self, channel=None):
        binning = self.binning
        if channel is not None:
            x1, x2, y1, y2 = self.regions[channel]
            if x1 > x2:
                binning = -binning

        return binning

    def GetDataSize (self, channel=None):
        if channel is None:
            return max([self.GetDataSize(channel) for channel in len(self.regions)])

        elif channel < len(self.datasize):
            return self.datasize[channel]

        elif channel < len(self.regions):
            x1, x2, y1, y2 = region = self.regions[channel]
            binning  = self.binning[channel]
            reversed = x1 > x2
            size = abs((x2 - x1)/binning) + 1
            warning("ReplaySpectrometer: Unknown data size for channel %d; "
                    "calculated from region %s, binning %d = %d."%
                    (channel, region, binning, size))

        else:
            warning("ReplaySpectrometer: Unknown data size for channel %d"%(channel,))
            return 0

    def GetExposureTime (self):
        return self.exposure

    def GetExposureTimeOffset (self):
        return 0

    def GetReadoutTime (self):
        return 4192

    def GetGains (self):
        return [(0, self.gainname),
                (1, "Gain 1"),
                (8, "Gain 8")]

    def GetSpeeds (self):
        return [(0, self.speedname),
                (1, "Speed 1"),
                (2, "Speed 9")]


    def CheckChannelRegions (self, regions):
        pass


    def SetupForAcquisition (self, count):
        self.acquiring = True
        self.starttime = time.time()
        self.endFrame  = min(count, len(self.data))


    def StartAcquisition (self, count):
        self.acquiring = True
        self.starttime = time.time()
        self.endFrame  = min(count, len(self.data))


    def ReplayAcquisition (self, startFrame, count):
        self.acquiring = True
        self.starttime = None
        self.collected = startFrame
        self.endFrame  = len(self.data)

        if (count != None) and (startFrame + count < self.endFrame):
            self.endFrame = startFrame+count
        

    def StopAcquisition (self):
        self.acquiring = False

    def AbortAcquisition (self):
        self.acquiring = False

    def ResetDevice (self, resetOptions=None):
        pass

    def Acquiring (self):
        return self.acquiring

    def WaitForData (self, index):
        currentThread().check()
        if self.acquiring and index < self.endFrame:
#            if self.starttime:
#                if self.frameDelay is not None:
#                    timestamp = index * (self.frameDelay / 1000.0)
#                else:
#                    timestamp, data = self.data[index]
#
#                nap = max(0, self.starttime + timestamp - time.time())
#                time.sleep(nap)

            return True
        else:
            self.acquiring = False
            return False

    def GetData (self, index):
        if index < self.endFrame:
            return self.data[index]
        else:
            raise IndexError("Buffer index %d is not available"%(index,))


    def GetCustomData (self, index):
        if index < self.endFrame:
            return self.customData[index]
        else:
            raise IndexError("Buffer index %d is not available"%(index,))


    def SetCollectedCount (self, index):
        self.collected = index


    def ClearData (self):
        self.collected = 0
        

    def GetDataProperties (self):
        return (
            ('filename', self.filename),
            ('serialnumber', self.SerialNumber),
            ('devicetype', self.DeviceType),
            ('productid', self.ProductID),
            ('capturedate', self.capturedate),
            ('capturetime', self.capturetod),
            ('exposuretime', self.exposure),
            ('binning', self.binning),
            ('channels', len(self.datasize)),
            ('pointsPerRegion', ",".join(map(str, self.datasize))),
            ('frames', len(self.data)) )

    def GetSerialNumber (self):
        return 987




    ### Process Data from CSV file

    _methodMap = {
        "CameraInfo"    : r"Camera Info",
        "CaptureTime"   : r"Capture Date",
        "CaptureTime"   : r"Capture Time",
        "Description"   : r"Description",
        "Exposure"      : r"Exposure\(MS\)",
        "Gain"		: r"Gain",
        "Speed"		: r"Speed",
        "ChipDimensions": r"Chip Dimensions",
        "Binning"       : r"Binning",
        "PointCount"    : r"Number of Points per Region",
        "ChannelRegion" : r"Channel Region \d+",
        "Coefficients"  : r"Channel \d+ Polynomial Coefficients",
        "Signal"        : r"Spectrum +\d+",
        }

    _methodX = re.compile('|'.join([ r"(?P<%s>%s)"%item for item in _methodMap.items() ]))
    _digitX  = re.compile(r"(\d+)")

    def LoadData (self, input, filename):
        self.reset()
        self.filename = filename
        loaded = False
        for lineno, line in enumerate(input):
            fields  = line.rstrip().split(",")
            match   = self._methodX.match(fields[0])
            if match:
                index = match.lastindex
                token = match.lastgroup
                method = getattr(self, "_process"+token, None)
                if method:
                    try:
                        method(*fields)
                    except (ValueError, IndexError), e:
                        warning("Processing %s, line %s: _process%s%s: %s"%
                                (filename, lineno+1, token, tuple(fields), e))
                    else:
                        loaded = True
                else:
                    warning("Method not defined: _process%s()"%(token,))

        return loaded


    def _processCameraInfo (self, key, serial, devicetype, productid, *remaining):
        self.SerialNumber = serial
        self.DeviceType   = devicetype
        self.ProductID    = int(productid.split()[-1])


    def _processDescription (self, key, *description):
        self.description = ",".join(description)

    def _processCaptureDate (self, key, capturedate, *remaining):
        self.capturedate = capturedate
        if self.capturetod:
            self._setCaptureTime(self.capturedate, self.capturetod)

    def _processCaptureTime (self, key, capturetime, *remaining):
        self.capturetod = capturetime
        if self.capturedate:
            self._setCaptureTime(self.capturedate, self.capturetod)

    def _setCaptureTime (self, capturedate, capturetime, *remaining):
        t = time.strptime(" ".join((capturedate, capturetime.split('.')[0])), "%Y-%m-%d %H:%M:%S")
        self.capturetime = time.mktime(t)

    def _processExposure (self, key, exposure, *remaining):
        self.exposure = exposure

    def _processGain (self, key, gain, *remaining):
        self.gainname = gain

    def _processSpeed (self, key, speed, *remaining):
        self.speedname = speed

    def _processChipDimensions (self, key, legend, width, height, count, *remaining):
        try:
            self.chipSize  = int(width), int(height)
            self.chipCount = int(count)
        except ValueError:
            warning("Unable to parse chip dimensions, legend=%r, width=%r, height=%r, count=%r"%
                    (legend, width, height, count))

    def _processBinning (self, key, data, *remaining):
        self.binning = int(data)

    def _processChannelRegion (self, key, legend, *region):
        self.regions.append(tuple(map(int, filter(None, region))))

    def _processCoefficients (self, key, legend, *coeffs):
        match = self._digitX.match(legend)
        if match and match.group(1):
            self.coeffDivisor = int(match.group(1))
        else:
            self.coeffDivisor = 1

        self.coefficients.append(tuple(map(float, filter(None, coeffs))))

    def _processPointCount (self, key, legend, *bincounts):
        self.datasize = map(int, filter(None, bincounts))
        pos = 0
        for size in self.datasize:
            self.dataslices.append(slice(pos, pos+size))
            pos += size

        self.customColumn = pos


    def _processSignal (self, key, timestamp, *values):
        data = [ map(int, values[span])
                 for span in self.dataslices ]

        self.data.append((float(timestamp) / 1000.0, data))

        if self.customColumn is not None:
            custom = map(eval, values[self.customColumn:])
        else:
            custom = []

        self.customData.append(custom)


class ReplaySpectrometer (ScanningSpectrometer):
    '''Replay Spectrometer branch.  Data is fed from a previously-acquired CSV file.'''

    class NoDataLoaded (RunError):
        "You must first load spectrometer data from a .CSV file; see the \"LOAD\" and \"DATA=\" commands"

    class NoData (RunError):
        "No spectrometer data was found in %(filename)s"


    IMAGE, SCAN      = range(2)
    TRIGGER_MODES    = ("Off",
                        "Once/RisingEdge", "Once/FallingEdge",
                        "Each/RisingEdge", "Each/FallingEdge")

    SIGNAL_MODES     = ("Off",
                        "ShutterOpen/ActiveHigh", "ShutterOpen/ActiveLow",
                        "StartExperiment/ActiveHigh", "StartExperiment/ActiveLow",
                        "ReadyForTrigger/ActiveHigh", "ReadyForTrigger/ActiveLow")
                        



    def __init__ (self, *args, **kwargs):
        ScanningSpectrometer.__init__(self, *args, **kwargs)
        self.device = Spectrometer()

    def listDevices (self, rescan=False):
        return SpectrometerInfo

    def getConfig (self):
        files = ('spectrometer.ini', 'replayspectrometer.ini')
        return self.getConfigInstance(files, casePreserving=False, literal=True)


    def connectDevice (self, rescan=False, serial=None, productID=None):
        self.ProductID    = productID
        self.SerialNumber = serial
        self.DeviceType   = "Replay Spectrometer"




    def getCoefficientsByChannel (self, binning, ignoreMissing=False):
        coeffs = self.device.coefficients or ( [(0,)] * len(self.device.datasize) )
        return coeffs, self.device.coeffDivisor

    def loadData (self, input, filename=None):
        if not self.device.LoadData(input, filename):
            raise self.NoData(filename=filename or "input")

    def getDataProperties (self):
        return self.device.GetDataProperties()

    def startAcquisition (self, count, duration=None, *args, **kwargs):
        if not self.device.data:
            raise self.NoDataLoaded()

        if not count:
            count = len(self.device.data)

        self.device.StartAcquisition(count)


    def replayAcquisition (self, startFrame, count):
        if not self.device.data:
            raise self.NoDataLoaded()
        
        self.device.ReplayAcquisition(startFrame, count)
 	
 	
    def setStartFrame (self, startFrame):
        self.device.startFrame = startFrame

    def clearStartFrame (self):
        self.device.startFrame = None

    def getStartFrame (self):
        return self.device.startFrame

    def waitForData (self, index):
        if SpectrometerBase.waitForData(self, index):
            customData = self.device.GetCustomData(index)
            self.framedata.extend([ (item[0], value) for (item, value) in zip(self.pollItems, customData) ])
            return True
        else:
            return False


    class LOAD (Controlling, Background, FilesystemLeaf):
        '''
        Set Load CSV file for subsequent data acquisition
        '''

        def run (self, _session, setAttributes=False, location=str):
            loc = self.openLocation(location, _session, P_READ)
            fp = self.parent.openFile(loc, OP_READ)
            return _session, loc, fp, setAttributes


        def next (self, _session, loc, fp, setAttributes):
            try:
                self.parent.loadData(fp, loc.vfspath())
                if setAttributes:
                    attributes = dict(self.parent.getDataProperties())
                    attributes.pop('filename', 0)
                    loc.setAttributes(attributes)

            finally:
                self.parent.closeFile(loc)


    class DATA_Set (Controlling, Leaf):
        '''
        Set Load CSV file for subsequent data acquisition
        '''

        def run (self, _session, data=list):
            self.parent.loadData(data)


    class DATA_Query (Observing, Leaf):
        '''
        Return some statistics on loaded CSV data
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            for key, value in self.parent.getDataProperties():
#                self.addOutput(key, type=tuple, named=True, default=None)
                self.addOutput(key, type=(type(value), str)[value is None], named=True, default=None)
                

        def run (self):
            if self.parent.device.data:
                return dict(self.parent.getDataProperties())


    class REPLay (Controlling, FilesystemLeaf):
        '''Replay data from the specified .CSV file.'''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('resumeIndex', type=int, range=(0, None), named=True, default=None,
                          description="Index of first frame to be replayed.  Note that 'startIndex' "
                          "is subtracted from this number to determine the actual data frame")

            self.setInput('startIndex', type=int, range=(0, None), named=True, default=1,
                          description="Index reference; the number of the very first data frame acquired.")

            self.setInput('count', type=int, range=(0, None), named=True, default=None,
                          description="Number of frames to be replayed.")

            self.setInput('dataBinning', type=int, named=True, range=(0, None), default=None,
                          description='Number of analog bins per spectral value in the published data '
                          '(a.k.a. "software binning").  The default value is set with the "DATA=" '
                          'command. Note that this does NOT affect data saved to CSV output file.')

            self.setInput('maxDataBins', type=int, named=True, range=(0, None), default=None,
                          description='Limit the number of values in the published data to this '
                          'number. If the number of available spectral values exceeds this, '
                          'remaining values are truncated.')

            self.setInput('minDataWavelength', type=float, named=True, default=None,
                          description='Minimum wavelength of bins included in published data.')

            self.setInput('maxDataWavelength', type=float, named=True, default=None,
                          description='Maximum wavelength of bins included in published data.')

            self.setInput('minCorrectionRatio', type=int, named=True, default=None, range=(0, None),
                          description='Correct pixel values that deviate more than the specified threshold '
                          'away from its expected value, based on neighboring pixels. ')

            self.setInput('minCorrectionThreshold', type=int, named=True, default=None, range=(0, None),
                          description='Correct pixel values that deviate more than the specified threshold '
                          'away from its expected value, based on neighboring pixels. ')

            self.setInput('topic', type=str, named=True, default=self.parent.DEFAULT_TOPIC,
                           description='Message topic used for real-time data publication.')


        def run (self, resumeIndex=None, startIndex=1, count=None, dataBinning=None, maxDataBins=None,
                 minDataWavelength=None, maxDataWavelength=None,
                 minCorrectionRatio=None, minCorrectionThreshold=None, topic=''):

            if resumeIndex is None:
                start = 0
            else:
                start = max(0, resumeIndex - startIndex)

            self.parent.replayAcquisition(start, count)
            self.parent.collectData(start, startIndex, count,
                                    exposure=None, speed=None, gain=None, dark=None,
                                    pixelBinning=None, dataBinning=dataBinning,
                                    maxDataBins=maxDataBins,
                                    wlMin=minDataWavelength,
                                    wlMax=maxDataWavelength,
                                    minCorrectionRatio=minCorrectionRatio,
                                    minCorrectionThreshold=minCorrectionThreshold,
                                    loc=None,
                                    outputFile=None,
                                    topic=topic,
                                    description=None)


branchTypes['DataAcquisition'] = ReplaySpectrometer
branchTypes['ReplaySpectrometer'] = ReplaySpectrometer


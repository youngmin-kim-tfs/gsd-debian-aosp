########################################################################
### FILE:	scpiFullBranch.py
### PURPOSE:	Branch with a full set of 'standard' commands/leaves
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBranch          import branchTypes
from scpiMinimalBranch   import MinimalBranch
from scpiDynamicCommands import DynamicBranch

class FullBranch (MinimalBranch):
    __slots__ = ()
         
    from scpiBroadcastLeafs import \
        BRoadCast

    from scpiWaitLeaf import \
        WAIT  #, ExpressionWAit, MessageWAit, TextWAit, NumericWAit

    from scpiModuleLeaf import \
        MODule_Query

    from scpiReturnLeaf import \
        NEXT, BREak, RETurn

    from scpiExceptionLeafs import \
        TRY, ERRor, ABORt, PASS

    from scpiConfigLeafs import \
        CONFiguration_Enumerate, CONFiguration_Exists, CONFiguration_Query, \
        CONFiguration_Add, CONFiguration_Remove, \
        CONFiguration_Set, CONFiguration_Load
    
    from scpiDynamicCommands import \
        BRANch_Add, BRANch_Remove, BRANch_Query, BRANch_Enumerate

    from scpiMacro import \
        MACRo_Add, MACRo_Remove, MACRo_Query, MACRo_Enumerate

    from scpiTracker import \
        TRACKer_Add, TRACKer_Remove, TRACKer_Query, TRACKer_Enumerate

    from scpiEstimation import ESTimate, \
        ESTimation_Enumerate, ESTimation_Set, ESTimation_Clear, ESTimation_Query

    from scpiEvalLeaf import EVALuate_Query 
    
    from scpiFlowControl import \
        IF, ELseIF, ELSe, UNLess, WHILe, UNTil

    from scpiRepeatLeaf import \
        REPeat, SCHedule_Add, SCHedule_Remove, SCHedule_Query, SCHedule_Enumerate, SCHedule_Exists, ITERate

    from scpiDebugLeaf import TRACe, DEBug, INFo, NOTice, WARNing

    from scpiMath import RANDom_Query

    #from scpiCommandHooks import HOOK_Set, HOOK_Clear, HOOK_Query, HOOK_Enumerate


class DynamicFullBranch (DynamicBranch, FullBranch):
    TypeName = 'dynamic full branch'

branchTypes[None] = branchTypes['Generic'] = DynamicFullBranch


########################################################################
### FILE:	scpiTaskLeafs.py
### PURPOSE:	Commands to run/wait for asynchronous command execution
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch import FullBranch
from scpiLeaf       import Leaf, Asynchronous, Observing, Controlling, Background, CommandWrapper, \
    SYNCHRONOUS, ASYNCHRONOUS
from scpiExceptions import NextControl, NextReply, RunError, Error, SessionControl, scpiException
from scpiSession    import RAISE, ASYNC, SYNC, PASSTHROUGH
from threadControl  import currentThread, Aborted
from data           import DynamicData
from cStringIO      import StringIO
from locking        import Queue, Event, Empty, Lock
from sys            import exc_info
from copy           import copy

TaskElements = EVENT, THREAD, RESULT = range(3)

TaskStates   = ('Unknown', 'Running', 'Finished', 'Failed', 'Aborted')
(UNKNOWN, RUNNING, FINISHED, FAILED, ABORTED) = range(len(TaskStates))


class TASK (CommandWrapper, FullBranch):
    '''
    Named tasks that can be controlled.
    '''

    class NoSuchTask (RunError):
        'No %(name)r task is currently pending'

    class TaskExists (RunError):
        'The task %(name)r is already running'


    def __init__ (self, *args, **kwargs):
        FullBranch.__init__ (self, *args, **kwargs)
        self.tasks = DynamicData()
        self._mutex = Lock()

    def getPath (self, scope, branch, name):
        if branch:
            scope = scope.find(branch)
        return scope.commandPath(name, short=True)

    def newTask (self, scope, branch, name, replaceExisting=False, event=None, thread=None, result=None):
        path = self.getPath(scope, branch, name)
        with self._mutex:
            try:
                t = self.tasks[path]
            except KeyError:
                pass
            else:
                if not t[EVENT].isSet():
                    if not replaceExisting:
                        raise self.TaskExists(scope=self.getPath(scope, branch, None), name=name)
                    else:
                        t[RESULT] = ABORTED
                        if t[THREAD]:
                            t[THREAD].abort()

            self.tasks[path] = task = [ event or Event(), thread, result ]
        return task

    def getTask (self, scope, branch, name, ignoreMissing=False):
        path = self.getPath(scope, branch, name)
        try:
            with self._mutex:
                return self.tasks[path]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchTask(branch=self.getPath(scope, branch, None), name=name)

    def delTask (self, scope, branch, name, task=None, ignoreMissing=False):
        path = self.getPath(scope, branch, name)
        try:
            with self._mutex:
                if self.tasks[path] == task:
                    del self.tasks[path]
        except (KeyError, AttributeError):
            if not ignoreMissing:
                raise self.NoSuchTask(branch=self.getPath(scope, branch, None), name=name)

    def getTaskNames (self, scope, branch=None):
        path = self.getPath(scope, branch, '')
        return [ name[len(path):] for name in self.tasks if name.startswith(path) ]

    def getTasks (self, scope, branch=None, active=False):
        path = self.getPath(scope, branch, '')
        items = [ (name[len(path):], task)
                  for (name, task) in self.tasks.items()
                  if name.startswith(path) and (not active or not task[EVENT].isSet()) ]
        return dict(items)


    def watchTask (self, task, ignoreAbort, ignoreErrors, method, args, opts):
        task[THREAD] = currentThread()

        try:
            if not task[RESULT] == ABORTED:
                task[RESULT] = method(*args, **opts)
            task[THREAD] = None
            task[EVENT].set()
            return task[RESULT]

        except NextControl, e:
            leaf, nextfunc, nextargs, nextopts = e.args
            watchargs = task, False, False, nextfunc, nextargs, nextopts
            raise NextReply(self, self.watchTask, watchargs, {})

        except Exception, e:
            task[RESULT] = e
            task[THREAD] = None
            task[EVENT].set()
            ignore = (ignoreErrors, ignoreAbort)[isinstance(e, Aborted)]
            if not ignore:
                raise

    class START (Controlling, CommandWrapper, Leaf):
        '''
        Create a task to run the specified command block, 
        synchronously or asynchronously.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('branch', type=str, default=None, named=True,
                          description="Command branch in which to run the task "
                          "(default is the current command scope)")

            self.setInput('ignoreAbort',
                          description=
                          'Do not raise an abort exception if the task is aborted; instead, return normally.')

            self.setInput('ignoreErrors',
                          description=
                          'Errors raised by the task are normally raised; '
                          'this option ignores the error and instead returns the error message.')


            self.setInput('name', type=str, named=False)
            self.setInput('command', repeats=(1, None), type=str)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('result', type=tuple, repeats=(0, None),
                           description='Reply from task')

        def run (self, _session, _context,
                 asynchronous=False,
                 replaceExisting=False,
                 ignoreAbort=False,
                 ignoreErrors=False,
                 branch=None,
                 name=str, *command):

            task = self.parent.newTask(_context.scope, branch, name, replaceExisting=replaceExisting)

            subscope = _context.scope
            if branch:
                subscope  = subscope.find(branch)

            runmethod = _session.runBlock
            runargs   = (command, _context.clone(scope=subscope))
            runopts   = {}
            watchargs = (task, ignoreAbort, ignoreErrors, runmethod, runargs, runopts)

            self.debug("Invoking task %s, scope %s, command: %s"%
                       (name, subscope.commandPath(short=True), ' '.join(command)))

            if asynchronous:
                runopts.update(nextReply=SYNC, nextCommand=ASYNC)
                raise NextReply(self, self.parent.watchTask, watchargs, {})
            else:
                runopts.update(nextReply=RAISE, nextCommand=RAISE)
                return self.parent.watchTask(*watchargs)


        def defaultEstimate (self, _session, _context,
                             asynchronous, replaceExisting, ignoreAbort, ignoreErrors,
                             branch, name, *command):

            subscope = _context.scope
            if branch:
                subscope  = subscope.find(branch)

            _session.runBlock(command, _context.clone(scope=subscope))


        def estimateTime (self, _session, _context,
                          asynchronous, replaceExisting, ignoreAbort, ignoreErrors,
                          branch, name, *command):
                          
            scratch = DynamicData()
            self.defaultEstimate(_session, _context.clone(estimationResults=scratch),
                                 asynchronous, replaceExisting, ignoreAbort, ignoreErrors,
                                 branch, name, *command)

            if asynchronous:
                synctime  = 0
                asynctime = scratch.pop(SYNCHRONOUS, 0)
                tasktime  = asynctime
            else:
                synctime  = scratch.get(SYNCHRONOUS, 0)
                asynctime = scratch.get(ASYNCHRONOUS, 0)
                tasktime  = synctime + asynctime

            path  = self.parent.getPath(_context.scope, branch, name)
            tasks = _context.estimationData.setdefault('task', DynamicData())
            tasks[path] = _context.estimationResults.get(SYNCHRONOUS, 0) + tasktime
            self.addTime(_context, synctime, asynctime)



    class WAIT (Controlling, Leaf):
        """
        Perform synchronization options on the specified task.
        """

        class TaskTimeout (RunError):
            'Timed out waiting for task to complete after %(time)ss'

#        class DeferredInternal (RunError):
#            'Internal error in task %(name)r: %(error)s'


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignoreMissing',
                          description=
                          'If set, and if the specified task does not exist, '
                          'do not return an error')

            self.setInput('keep', type=bool, named=True, default=False,
                          description='Keep the specified task even if task process completed.')

            self.setInput('abort', type=bool, named=True, default=False,
                          description=
                          'Abort execution of the task.')

            self.setInput('suspend', type=bool, named=True, default=False,
                          description=
                          'Suspend execution of the task.')

            self.setInput('resume', type=bool, named=True, default=False,
                          description=
                          'Continue executing a previously-suspended task.')

            self.setInput('wait',
                          type=float,
                          range=(0.0, None),
                          hidden=True,
                          description=
                          'Deprecated; use "-timeout" instead.')

            self.setInput('timeout',
                          type=float,
                          range=(0.0, None),
                          description=
                          'Maximum time to wait for the command to finish '
                          '(default=forever). '
                          'A wait time of zero can be used to return immediately, '
                          'e.g. in conjunction with "-abort" and "-ignoreTimeout"')

            self.setInput('ignoreTimeout',
                          description=
                          'If the task does not complete withing the specified wait time '
                          'an error is normally raised; this option prevents that error')

            self.setInput('ignoreErrors',
                          description=
                          'Errors raised by the task are normally raised; '
                          'this option ignores the error and instead returns the error message.')

            self.setInput('ignoreAbort',
                          description=
                          'Do not raise an abort exception if the task is aborted; instead, return normally.')

            self.setInput('branch', type=str, default=None,
                          description="Command branch in which to the task exists "
                          "(default is the current command scope)")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('result', type=tuple, repeats=(0, None),
                           description='Reply from the command')
            

        def estimateTime (self, _session, _context, 
                          ignoreMissing, keep, abort, suspend, resume, timeout, wait,
                          ignoreTimeout, ignoreAbort, ignoreErrors, branch, name):

            path = self.parent.getPath(_context.scope, branch, name)
            try:
                synctime = _context.estimationData['task'][path]

            except KeyError:
                if not ignoreMissing:
                    raise self.parent.NoSuchTask(name=name)

            else:
                current   = _context.estimationResults.get(SYNCHRONOUS, 0)
                waittime  = synctime - current

                if (waittime > wait > None) and not ignoreTimeout:
                    raise self.TaskTimeout(time=wait)

                elif wait is not None:
                    waittime = min(waittime, wait)

                self.addTime(_context, max(waittime, 0))
            

        _waitInstance = 0
        def run (self, _session, _context, ignoreMissing=True, keep=False,
                 abort=False, suspend=False, resume=False,
                 timeout=None, wait=None, ignoreTimeout=False,
                 ignoreAbort=False, ignoreErrors=False, branch=None, name=str):

            task = self.parent.getTask(_context.scope, branch, name, ignoreMissing=ignoreMissing)
            if not task:
                return
            
            event, thread, result = task
            
            debug = {}
            if thread:
                if abort:
                    thread.abort()
                    debug.update(aborted=True)

                if suspend:
                    thread.suspend()
                    debug.update(suspended=True)

                if resume:
                    thread.resume()
                    debug.update(resumed=True)

            if timeout is None and wait is not None:
                timeout = wait

            debug.update(timeout=timeout)

            if event.isSet():
                finished = True
            else:
                self._waitInstance += 1
                debug.update(waitInstance=self._waitInstance)
                self.debug("Waiting for task %r"%(name,) + "".join([" -%s=%s"%item for item in debug.items()]))
                finished = event.wait(timeout)
                self.debug("%s task %r"%(("Cancelled", "Completed")[finished], name) +
                           "".join([" -%s=%s"%item for item in debug.items()]))

            result   = task[RESULT]
            if not ignoreTimeout and not finished:
                raise self.TaskTimeout(time=timeout)

            if not keep:
                self.parent.delTask(_context.scope, branch, name, task=task, ignoreMissing=True)

            if not isinstance(result, Exception):
                return result

            elif isinstance(result, Aborted):
                if (abort or ignoreAbort):
                    return (None, type(result).__name__, result)
                else:
                    raise

            elif ignoreErrors or isinstance(result, SessionControl):
                return (None, str(result), result),

            else:
                raise result


    class ID_Enumerate (Observing, Leaf):
        '''
        List all currently pending tasks.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('active', named=True,
                          description='List only tasks that are currently pending')
            self.setInput('branch', type=str, default=None, named=True,
                          description="Command branch in which to the task exists "
                          "(default is the current command scope)")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self, _context, active=False, branch=None):
            try:
                tasks = self.parent.getTasks(_context.scope, branch, active)
            except AttributeError,e:
                pass
            else:
                return tuple(sorted(tasks))



    class ID_Exists (Observing, Leaf):
        '''
        Indicate whether the specified task exists
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('branch', type=str, default=None,
                          description="Command branch in which to the task exists "
                          "(default is the current command scope)")
            
        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('exists', type=bool, default=False)

        def run (self, _context, running=False, branch=None, name=str):
            task = self.parent.getTask(_context.scope, branch, name, ignoreMissing=True)
            return task and (not running or not task[EVENT].isSet())

                

    class STATus_Query (Observing, Leaf):
        '''
        Show the state of the specified task.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            
            self.setInput('ignoreMissing',
                          description=
                          'If set, and if the specified task does not exist, '
                          'do not return an error')

            self.setInput('branch', type=str, default=None, named=True,
                          description="Command branch in which to the task exists "
                          "(default is the current command scope)")

            self.setInput('wait', type=bool, default=False, named=True,
                          description='Wait for the task to complete before returning. '
                          'Optionally, "-timeout" can be specified.')

            self.setInput('timeout',
                          type=float,
                          description=
                          'Maximum time to wait for the task to finish '
                          '(default=forever). ')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('state', type=TaskStates)

        def run (self, _context, ignoreMissing=False, wait=False, timeout=None, branch=None, name=str):
            try:
                task = self.parent.getTask(_context.scope, branch, name)

            except self.parent.NoSuchTask:
                if ignoreMissing:
                    return UNKNOWN
                else:
                    raise

            else:
                if wait:
                    task[EVENT].wait(timeout)

                if not task[EVENT].isSet():
                    return RUNNING

                elif isinstance(task[RESULT], Aborted):
                    return ABORTED

                elif isinstance(task[RESULT], Exception):
                    return FAILED

                else:
                    return FINISHED

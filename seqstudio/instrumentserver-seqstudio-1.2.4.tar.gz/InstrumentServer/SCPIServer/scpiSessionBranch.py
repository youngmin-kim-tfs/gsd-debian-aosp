########################################################################
### FILE:	scpiSessionBranch.py
### PURPOSE:	Commands to manage client sessions
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase          import Hidden
from scpiBranch        import Branch
from scpiMinimalBranch import MinimalBranch
from scpiLeaf          import Administrative, Observing, Public, Leaf, OBSERVER, ASYNC
from scpiExceptions    import RunError, CommandError
from scpiSession       import BaseSession, ClientSession, AccessLevels, Triggers
from threadControl     import invocation
from cStringIO         import StringIO

import inspect, re, base64

class _SessionLeaf (Leaf):
    class NoSuchSession (RunError):
        'There is no such session ID: %(id)s'

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setOptionalInput('all',
                              type=bool,
                              named=True,
                              default=False,
                              description='Also include "nested" sessions, such as '
                              'currently executing macros and modules.')

    def getInstances (self, all=False):
        cls = (ClientSession, BaseSession)[all]
        return BaseSession.getInstances(cls)

    def findSession (self, sessionid, all=True, ignoreMissing=False):
        for s in self.getInstances(all):
            if s.sessionid.lower() == sessionid.lower():
                return s
        else:
            raise self.NoSuchSession(id=sessionid)


class SESSion (MinimalBranch):
    '''
    Commands to access and manage client sessions
    '''

    class CHALlenge_Query (Public, Leaf):
        '''
        Request a challenge string, consisting of 32 hexadecimal digits.
        This can be used together with a shared secret to compute a valid
        authentication string for the "AUTHentication" command.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('challenge', type=str)


        def run (self, _session):
            return _session.generateChallenge()



    class AUTHentication (Public, Leaf):
        '''Provide authentiation credentials to the instrument to allow for
        higher levels of access.  For information about access levels,
        see the "ACCess" command.

        The "hexdigest" argument should be a HMAC digest string consisting
        of 32 hexadecimal digits (0-f), derived from:
           - A shared secret
           - A previously obtained challenge (see "CHALlenge?")
           - The MD5 hashing algorithm

        Based on the secret used to compute the digest, but limited
        according to the communications interface between the client and
        the instrument controller, the client will be authenticated to a
        specific access level (GUEST, OBSERVER, CONTROLLER or FULL). Once
        authenticated, the higher level is not granted by default however;
        the client will have to explicitly request higher access levels
        using the "ACCess" command.

    Example:
        * Request a challenge, then respond to it:
            C: 1 CHALlenge?
            S: OK 1 b9b44327792d884421190d0c03eb9197
            C: 2 AUTHentication 6a8981a54c36a818c85cce3c685cbbad
            S: OK 2

        '''

        class NoChallenge (RunError):
            'You must first obtain a challenge'

        class AuthError (RunError):
            'Authentication failed'


        def declareInputs (self):
            Leaf.declareInputs(self)

            self.setInput('hexdigest',
                          type=str,
                          description=
                          'A 32-character HMAC "hex" digest, derived from a '
                          'shared secret, a previously obtained challenge (see '
                          '"CHALlenge?"), and the MD5 hashing algorithm')


        def run (self, _session, _context, hexdigest=str):
            if not _session.getChallenge():
                raise self.NoChallenge()

            auth = _session.authenticate(hexdigest)
            if not auth:
                raise self.AuthError()

            client, level, limit, preexec, postexec = auth

            if postexec:
                _session.addExitHook(postexec)

            if preexec:
                _session.runBlock(preexec, _context)


    class AUTHentication_Add (Administrative, Leaf):
        '''
        Add an authentication profile, which then allows clients to obtain
        specific access levels by authenticating with one of the specified
        secrets.  Optionally, a command may be executed in the client
        session once authenticated, and/or upon disconnect.

        Note that this command should normally be used only by clients
        connecting from localhost or over a fully trusted SSL connection,
        and that the secret should normally be encapsulated between "$<"
        and ">".

    Example:
        AUTHentication+ MTSS -limit=Administrator -preexec="SESSion:SCOPE= MTSSBranch" $<password>
        '''

        class ProfileExists (RunError):
            '''The authentication profile %(profile)r already exists; use "-replaceExisting" to replace.'''

        class SecretExists (RunError):
            '''The specified secret is already assigned to the authentication profile %(profile)r; use "-replaceExisting" to replace.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('temporary', type=bool, named=True, default=False,
                          description='Do not persist this autentication profile to permanent storage.')
            self.setInput('encoded', type=bool, named=True, default=False,
                          description='The provided secrets are base64-encoded.')
            self.setInput('preexec', type=str, named=True, default=None,
                          description='Command to invoke once a client authenticates.')
            self.setInput('postexec', type=str, named=True, default=None,
                          description='Command to invoke after a client disconnects.')
            self.setInput('level', type=AccessLevels, named=True, default=OBSERVER,
                          description='Default access level granted to the client after authenticating.')
            self.setInput('limit', type=AccessLevels, named=True,
                          description='Maximum access level granted to the client after authenticating.')
            self.setInput('secrets', type=str, repeats=(1, None))

        def run (self, _session, replaceExisting=False, temporary=False, encoded=False, preexec=None, postexec=None,
                 profile=str, level=AccessLevels, limit=AccessLevels, *secrets):

            if _session.authdata.has_key(profile):
                if not replaceExisting:
                    raise self.ProfileExists(profile=profile)

            if not encoded:
                secrets = [base64.b64encode(s) for s in secrets]

            spec = dict(secrets=' '.join(secrets),
                        level=AccessLevels[level],
                        limit=AccessLevels[limit])
            if preexec:
                spec.update(preexec=preexec)
            if postexec:
                spec.update(postexec=postexec)

            _session.addAuthProfile(profile, spec, save=not temporary)


    class AUTHentication_Remove (Administrative, Leaf):
        '''
        Remove an existing authentication profile.
        '''

        class NoSuchProfile (RunError):
            '''The specified authentication secret does not exist; use "-ignoreMissing" to ignore.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('temporary', type=bool, named=True, default=False,
                          description='Do not save changes; keep in memory only.')

        def run (self, _session, ignoreMissing=False, temporary=False, profile=str):
            try:
                _session.removeAuthProfile(profile, save=not temporary)
            except KeyError:
                if not ignoreMissing:
                    raise self.NoSuchProfile()


    class AUTHentication_Query (Administrative, Leaf):
        '''
        Query an existing authentication profile.
        '''

        class NoSuchProfile (RunError):
            '''The specified authentication secret does not exist; use "-ignoreMissing" to ignore.'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('preexec', type=str, named=True, default=None,
                          description='Command to invoke once a client authenticates.')
            self.addOutput('postexec', type=str, named=True, default=None,
                          description='Command to invoke after a client disconnects.')
            self.addOutput('level', type=AccessLevels, named=True, default=None,
                          description='Default access level granted to the client after authenticating.')
            self.addOutput('limit', type=AccessLevels, named=True, default=None,
                          description='Maximum access level granted to the client after authenticating.')


        def run (self, _session, ignoreMissing=False, profile=str):
            try:
                return _session.authdata[profile].copy()
            except KeyError:
                if not ignoreMissing:
                    raise self.NoSuchProfile()
                
                    


    class AUTHentication_Enumerate (Administrative, Leaf):
        '''
        Enumerate  existing authentication profiles
        '''

        class NoSuchProfile (RunError):
            '''The specified authentication secret does not exist; use "-ignoreMissing" to ignore.'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('profile', type=str, repeats=(0, None))

        def run (self, _session):
            return tuple(_session.authdata)


    class AUTHentication_Clear (Administrative, Leaf):
        '''
        Remove all known authentication profiles.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('temporary', type=bool, named=True, default=False,
                          description='Do not save changes; keep in memory only.')

        def run (self, _session, temporary=False):
            _session.clearAuthProfiles(save=not temporary)


    class ACCess (Public, Leaf):
        '''
        Request a specific access level for this session.

        Each instrument controller command is restricted according to
        access level.  Before executing a given command, the client must
        obtain the corresponding access level or higher.

        Once a client connects to the instrument controller via a specific
        communications interface (e.g. a specific ethernet port on the
        instrument), a default access level is granted.  The client may
        then request a lower access level, or - more commonly - a higher
        one.

        To request an access level that is higher than this initial level,
        the client must first authenticate using hte "AUTHenticate"
        command. After this, the client may request access up to the
        lesser of:
          - the level allowed by the authentication credentials used, and
          - the maximum level allowed over the communications interface

        The client may also request exclusive access to the given level.
        This means that the command will fail if any other sesson
        currently holds the given access level or above, and that no other
        clients will be granted access to this level while the original
        client holds the exclusive access.  In effect, this is a "lock"
        that can be used to perform instrument control.

    Examples:
        * Gain exclusive controller access to the instrument, perform
          a run, then relinquish controller access.

            ACCess -exclusive CONTROLLER
            FLAG MyRun RunProtocol MyProtocol ...
            ...
            SYNC MyRun
            ACCess OBSERVER
        '''

        def run (self, _session, stealth=False, exclusive=False, level=AccessLevels):
            _session.setAccessLevel(level, exclusive, stealth)



    class ACCess_Query (Public, Leaf):
        '''
        Return the current access level for this session.
        '''
        Properties = ('level', 'limit', 'exclusive', 'stealth')

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('named', type=bool, named=True, default=False)
            self.setInput('properties', type=self.Properties, repeats=(0, len(self.Properties)))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('values', type=tuple, repeats=(1, None))

        def run (self, _session, named=False, *properties):
            if not properties:
                properties = range(len(self.Properties))
                named = True

            values = (_session.getLevelName(_session.getAccessLevel()),
                      _session.getLevelName(_session.getAccessLimit()),
                      _session.getExclusiveFlag(),
                      _session.getStealthFlag())

            items = [((None, self.Properties[p])[named], values[p]) for p in properties]
            return tuple(items)




    class COUNT_Query (Observing, _SessionLeaf):
        '''
        Return the number of currently active client sessions.
        '''

        def declareOutputs (self):
            _SessionLeaf.declareOutputs (self)
            self.addOutput('count',
                           type=int,
                           description='Number of connected sessions')

        def run (self, _session, all=False):
            return len(self.getInstances(all))

    class ID_Query (Public, Leaf):
        '''
        Return the session ID of requesting client.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('client', type=bool, named=True, default=False,
                          description='Return the top-level session that originated '
                          'this invocation, even if the command itself is called '
                          'from a nested command block like a macro.')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('session',
                           type=str,
                           description='A unique identifier for this client session')

        def run (self, _session, client=False):
            if client:
                _session = _session.top(ClientSession)

            return _session.sessionid

    class ID_Enumerate (Observing, _SessionLeaf):
        '''
        List the session IDs of currently active client sessions.
        '''

        def declareOutputs (self):
            _SessionLeaf.declareOutputs(self)
            self.addOutput('sessions',
                           type=str,
                           repeats=(0, None),
                           description='A unique identifier for each active '
                           'client session')

        def run (self, _session, all=False):
            sessions = [ s.sessionid for s in self.getInstances(all) ]
            return tuple(sessions)

    class ROLe_Set (Observing, _SessionLeaf):
        '''
        Set the role of this session.
        '''

        class InvalidRole (CommandError):
            '''The name %(role)r is not a valid role identifier.'''

        validRoleX = re.compile(r'^[\S]*$')

        def declareInputs (self):
            _SessionLeaf.declareInputs(self)
            self.setInput('session', type=str, default=None, named=True,
                          description="Session ID, if not current session")

        def run (self, _session, session=None, role=str):
            if not self.validRoleX.match(role):
                raise self.InvalidRole(role=role)

            if session is None:
                s = _session

            else:
                s = self.findSession(session, all=False)
                _session.checkAccess(s.accessLimit)

            s.setRole(role)

    class ROLe_Clear (Observing, _SessionLeaf):
        '''
        Set the role of this session.
        '''

        def declareInputs (self):
            _SessionLeaf.declareInputs(self)
            self.setInput('session', type=str, default=None, named=True,
                          description="Session ID, if not current session")

        def run (self, _session, session=None):
            if session is None:
                s = _session

            else:
                s = self.findSession(session, all=False)
                _session.checkAccess(s.accessLevel)

            s.setRole(None)

    class ROLe_Query (Public, _SessionLeaf):
        '''
        Return the role of the requesting client.
        '''

        def declareInputs (self):
            _SessionLeaf.declareInputs(self)
            self.setInput('session', type=str, default=None, named=True,
                          description="Session ID, if not current session")


        def declareOutputs (self):
            _SessionLeaf.declareOutputs(self)
            self.addOutput('role',
                           type=str,
                           default=None,
                           description='The role identifier of this session.')


        def run (self, _session, session=str):
            if session is None:
                s = _session

            else:
                s = self.findSession(session, all=False)
                _session.checkAccess(s.accessLimit)

            return _session.role

    class DESCription_Set (Hidden, ROLe_Set):
        '''
        Deprecated. Please use "ROLe=" instead.
        '''

    class DESCription_Query (Observing, _SessionLeaf):
        '''
        Return the description of the sesson with the specified id,
        or this session if if no id is provided.
        '''

        def declareInputs (self):
            _SessionLeaf.declareInputs(self)
            self.setInput('session', type=str, default=None,
                          description="Session ID to describe, if other than current session")

        def declareOutputs (self):
            _SessionLeaf.declareOutputs(self)
            self.addOutput('description', type=str)

        def run (self, _session, session=None):
            if session is None:
                s = _session
            else:
                s = self.findSession(session, all=True)

            return s.description

    class DESCription_Enumerate (Observing, _SessionLeaf):
        '''
        Return description of all existing sessions
        '''

        def declareOutputs (self):
            _SessionLeaf.declareOutputs(self)
            self.addOutput('description', type=tuple, repeats=(0, None))

        def run (self, _session, all=False, named=False):
            descriptions = [ ((None, s.sessionid)[named], s.description)
                             for s in self.getInstances(all) ]
            return tuple(descriptions)

    class FIND_Query (Observing, _SessionLeaf):
        '''
        Return ID for session matching the provided description
        '''

        class NoMatchingSession (RunError):
            'There is no session with description matching %(description)r'

        def declareOutputs(self):
            _SessionLeaf.declareOutputs(self)
            self.addOutput('id', type=str, default=None)

        def run (self, _session, all=False, ignoreMissing=False, description=str):
            for s in self.getInstances(all):
                if s.description.lower() == description.lower():
                    return s.sessionid
            else:
                if not ignoreMissing:
                    raise self.NoMatchingSession(description=description)

    class HOOK_Add (Administrative, _SessionLeaf):
        '''
        '''

    class JOBS_Enumerate (Observing, _SessionLeaf):
        '''
        Return a list of SCPI commands currently executing.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('id',
                          default=None,
                          type=str,
                          description='Session ID.  If None, list jobs for all sessions')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('command', type=list)

        def run (self, _session, all=False, verbose=False, id=str):
            if id is not None:
                sessions = [self.findSession(id, all=True)]
            else:
                sessions = self.getInstances(all)

            jobs = []
            for s in sessions:
                for index, commandtext, method, args, argv, thread, blocking in s.jobs:
                    name =  commandtext.strip()
                    if '\n' in name:
                        name, rest = name.split('\n', 1)
                        name += ' ...'

                    text = '[%s] %s'%(s.sessionid, name)
                    if verbose:
                        text +=' -- %s'%(invocation(method, args, argv))

                    jobs.append(text)

            return (jobs,)

    class SCOPe_Set (Observing, Leaf):
        '''
        Change the default command scope fort this session.
        '''

        def run (self, _context, branch=str):
            _context.scope = _context.scope.find(branch, Branch)

    class SCOPe_Query (Public, Leaf):
        '''
        Return the default scope of this session
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("short", type=bool, named=True, default=False)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('branch', type=str, default=None)

        def run (self, _scope, short=False):
            return _scope.commandPath(short=short)

    class PROPerties_Query (Observing, _SessionLeaf):
        '''
        Return information about a given client session
        '''

        def declareInputs (self):
            Leaf.declareInputs (self)
            self.setInput('client', type=bool, named=True, default=False,
                          description='Return the top-level session that originated '
                          'this invocation, even if the command itself is called '
                          'from a nested command block like a macro.')

            self.setInput('id',
                          default=None,
                          description='Session identifier (see the "ID*" command)')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('type',
                           type=str,
                           named=True,
                           description=
                           'Session type (e.g. "ClientSession", "MacroSession")')

            self.addOutput('clientAddress',
                           type=str,
                           named=True,
                           default=None,
                           description='Client address (host:port).')

            self.addOutput('serverAddress',
                           type=str,
                           named=True,
                           default=None,
                           description='Interface address (host:port).')

            self.addOutput('interface',
                           type=str,
                           named=True,
                           default=None,
                           description='Interface name (e.g., "lo")')

            self.addOutput('role',
                           type=str,
                           named=True,
                           default=None,
                           description='Client role')

            self.addOutput('accessLevel',
                           type=AccessLevels,
                           named=True,
                           description='Current access level of the given session')

            self.addOutput('exclusive',
                           type=bool,
                           named=True,
                           description='Whether or not the given session has exclusive access')

            self.addOutput('accessLimit',
                           type=AccessLevels,
                           named=True,
                           description='Current maximum access level of the given session')

            self.addOutput('authLimit',
                           type=AccessLevels,
                           named=True,
                           description='Maximum access level granted to this session once authenticated')

            self.addOutput('description',
                           type=str,
                           named=True,
                           description='Textual description of the sesssion')

        def run (self, _session, client=False, id=str):
            if id is not None:
                s = self.findSession(id, all=not client)
            elif client:
                s = _session.top(ClientSession)
            else:
                s = _session

            try:
                client = "%s:%s"%(s.peer)
                server = "%s:%s"%(s.interface)
                ifname = s.ifname
            except AttributeError:
                client = server = ifname = None

            return (s.__class__.__name__,
                    client, server, ifname,
                    s.role,
                    s.getAccessLevel(),
                    s.getExclusiveFlag(),
                    s.getAccessLimit(),
                    getattr(s, 'authLimit', None),
                    s.description)

    class THReads_Enumerate (Observing, Leaf):
        '''
        List all threads running in the specified session, or in this
        session if none is specified.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('session', type=int, default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self, session=None):
            pass

    class WRITe (Administrative, Leaf):
        '''
        Write text to SCPI session
        '''

        def run (self, _session, text=str):
            if not text.endswith("\n"):
                text += "\n"

            _session.top(ClientSession).sendOutput(text)


    class READ_Query (Administrative, Leaf):
        '''
        Read raw input from SCPI Session
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('text', type=str)


        def run (self, _session, prompt=""):
            top = _session.top(ClientSession)
            try:
                ### TelnetHandler class has "setprompt()" method
                top.instream.setprompt(prompt)
                hasprompt = True
            except AttributeError, e:
                ### StreamHandler does not.
                top.sendOutput(prompt)
                hasprompt = False

            try:
                text = top.instream.readline()
            finally:
                if hasprompt:
                    top.instream.setprompt()

            return text.rstrip("\n").rstrip("\r")


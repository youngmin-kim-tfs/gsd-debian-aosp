########################################################################
### FILE:	llacCommandBranch.py
### PURPOSE:	LLAC register branch with command/status/errror interface
### HISTORY:
###  2016-11-21 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from llacBase       import LLACRegisterBranch, _LLACRegisterLeaf, _LLACLeaf
from scpiLeaf       import Leaf, Asynchronous, Observing, Controlling
from scpiExceptions import RunError

class LLACCommandBranch (LLACRegisterBranch):
    '''Abstract commands'''

    LLACCONFIGFILE = "<must-be-defined>.ini"

    (RegSection, CmdSection, StatusSection) = \
                 ("Registers", "Command", "Status")

    Registers = ("COMMand", "LongCOMmand", "STATus?", "ERRor?")
    (R_COMMAND, R_LONGCOMMAND, R_STATUS, R_ERROR) = range(len(Registers))

    Commands = ("Disable", "Enable")
    (C_DISABLE, C_ENABLE) = range(len(Commands))

    Statuses = ("Enabled",)
    (S_ENABLED, ) = range(len(Statuses))


    class NoSuchRegister (RunError):
        '''Register %(name)r does not exist'''

    def __init__ (self, node=None, base=None, llacConfig=None, *args, **kwargs):
        LLACRegisterBranch.__init__(self, *args, **kwargs)
        LLACCommandBranch.init(self, node=node, base=base, llacConfig=llacConfig)

    def init (self, node=None, base=None, llacConfig=None):
        self.regbranch  = None
        self.registers  = None
        self.llacConfig = llacConfig or self.LLACCONFIGFILE
        if node is not None and base is not None:
            self.setBase(node, base)


    def getConfigSection (self, section, options=None, valuetype=int, default=None):
        items = self.getConfigItems(self.llacConfig,
                                    section,
                                    literal=True,
                                    valuetype=valuetype)

        if options:
            valuemap = dict(items)
            values   = [ valuemap.get(option, default) for option in options ]
            return values
        else:
            return items
                       

    def setBase (self, node, base):
        result = LLACRegisterBranch.setBase(self, node, base)
        self.loadRegisters()

    def clearBase (self):
        LLACRegisterBranch.clearBase(self)
        self.clearRegisters()


    def loadRegisters (self):
        base = self.getBase()

        regbranch = LLACRegisterBranch(name="REGisters", parent=self)
        regbranch.setBase(*base)
        regbranch.loadRegDefs(None, self.llacConfig, self.RegSection)

        self.addChild(regbranch)
        self.regbranch = regbranch
        self.registers = [ self.regbranch.getRegisterLeafSpec(regname, _LLACRegisterLeaf, ignoreMissing=True)
                           for regname in self.Registers ]


        self.commands  = self.getConfigSection(self.CmdSection, self.Commands)
        self.statuses  = self.getConfigSection(self.StatusSection, self.Statuses)



    def clearRegisters (self):
        self.delChild(self.regbranch)
        self.regbranch = None
        self.registers = None
        

    def checkConfig (self):
        if not self.regbranch:
            self.loadRegisters()
            return True
        else:
            return False


    def synchronize (self, requests, abortable=True):
        if requests:
            self.waitSync(requests, abortable=abortable)


    def sendValue (self, regindex, value, debug=True, **regspec):
        self.checkConfig()
        try:
            for key, override in self.registers[regindex].items():
                regspec.setdefault(key, override)
        except AttributeError, e:
            raise self.NoSuchRegister(name=self.regbranch.commandPath(self.Registers[regindex]),
                                      operation="write",
                                      value=value)
        else:
            ref = self.sendWrite((value, ), **regspec)
            if debug:
                self.logWrite(regspec, value, ref)
            return ref


    def writeValue (self, regindex, value, synchronize=True, **regsettings):
        ref = self.sendValue(regindex, value, **regsettings)
        pending = self.waitAck((ref,))
        if pending and synchronize:
            self.waitSync(pending)
        else:
            return pending


    def readValue (self, regindex, **regspec):
        self.checkConfig()

        try:
            for key, value in self.registers[regindex].items():
                regspec.setdefault(key, value)
        except AttributeError:
            raise self.NoSuchRegister(name=self.regbranch.commandPath(self.Registers[regindex]),
                                      operation="read")
        else:
            return self.read(**regspec)


    def sendCommand (self, index, longCommand=False, **regsettings):
        self.checkConfig()
        command = self.commands[index]
        if command is None:
            raise self.CommandNotAvailable(command=self.Commands[index],
                                           axis=self.commandPath())
            
        reg = (self.R_COMMAND, self.R_LONGCOMMAND)[longCommand]
        ref = self.sendValue(reg, self.commands[index], debug=False, **regsettings)
        self.debug("Sent command %s (0x%08X), msgid=%s"%
                   (self.Commands[index], self.commands[index], ref))

        return ref


    def command (self, index, longCommand=False, abortable=True, **regsettings):
        ref = self.sendCommand(index, longCommand=longCommand, **regsettings)
        pending = self.waitAck((ref,), abortable=abortable)
        self.waitSync(pending, abortable=abortable)


    def logWrite (self, regspec, value, ref):
        type, format = self.argTypes[regspec['type']]
        name = regspec['name']
        node = regspec['node']
        reg  = regspec['register']
        size = regspec['size']
        self.debug("Writing 0x%02X/0x%04X (%s)=%r; ref=%s"%
                   (node, reg, name, format(size)%value, ref))


    def setMask (self, regindex, mask, enable=True):
        value  = self.readValue(regindex)
        if enable:
            value |= mask
        else:
            value &= ~mask

        self.writeValue(regindex, value)


    def getStatusMap (self):
        return dict(self.getConfigSection(self.StatusSection, valuetype=int))


    def getStatusBits (self, value=None):
        if value is None:
            value  = self.readValue(self.R_STATUS)

        bitmap = [ (mask, key) for (key, mask) in self.getConfigSection(self.StatusSection, valuetype=int) ]
        bitmap.sort()
        output = []

        for mask, key in bitmap:
            output.append((key, value & mask and True or False))

        return output


    def statusBits (self, *bits):
        bitmask = 0
        for bit in bits:
            bitmask |= self.statuses[bit]

        status = self.readValue(self.R_STATUS)
        return (status & bitmask) == bitmask


    def logCurrentState (self, verbose=False):
        try:
            self.checkConfig()
            status = self.readValue(self.R_STATUS)

            if verbose:
                config = self.getConfigInstance(self.llacConfig)
                names  = config.options(self.RegSection)

                regspecs = [ self.regbranch.getRegisterLeafSpec(name, _LLACRegisterLeaf)
                             for name in names
                             if self.regbranch.hasChild(name) ]
                values   = self.readList(regspecs)

        except (ComponentError, self.LLACTimeout), e:
            warning("Unable to read %s extended registers: %s"%(self.commandPath(), e))

        else:
            sb     = self.getStatusBits(status)
            active = [ name for name, value in sb if value ]
            self.debug("Status: -value=0x%08X (Active bits: %s)"%
                       (status, "|".join(active) or "-"))

            if verbose:
                for name, spec, value in zip(names, regspecs, values):
                    type, format = self.argTypes[spec['type']]
                    size = spec['size']
                    self.regbranch.debug("%s = %s"%(name, format(size)%value))




    class StatusBits_Query (_LLACLeaf):
        '''Return status bits'''

        class NoSuchBit (RunError):
            '''There is no such status bit: %(name)s'''

        def __init__ (self, *args, **kwargs):
            self.bitmap   = None
            _LLACLeaf.__init__(self, *args, **kwargs)


        def checkMap (self):
            if self.bitmap is None:
                self.bitmap   = self.parent.getStatusMap()
                self.regindex = self.parent.R_STATUS
            

        def declareInputs (self):
            self.super.declareInputs()
            self.setInput('named', type=bool, named=True, default=None)
            self.setInput('keys', type=str, repeats=(0, None),
                          description='Return specific bits from the status register, '
                          'rather than all bits')


        def declareOutputs (self):
            _LLACLeaf.declareOutputs(self)
            self.addOutput('keys', type=tuple, repeats=(1, None))


        def run (self, named=None, *keys):
            self.checkMap()
            outputKeys = keys or self.bitmap.keys()

            self.parent.checkConfig()

            value  = self.parent.readValue(self.regindex)
            output = []

            for key in outputKeys:
                try:
                    mask = self.bitmap[key]
                except KeyError, e:
                    raise self.NoSuchBit(name=key)
                else:
                    if named or (named is None and not keys):
                        name = key
                    else:
                        name = None

                    bit = (value & mask) and True or False
                    output.append((name, bit))

            return tuple(output)

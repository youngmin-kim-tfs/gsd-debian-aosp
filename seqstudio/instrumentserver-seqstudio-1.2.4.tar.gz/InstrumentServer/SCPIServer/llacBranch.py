########################################################################
### FILE:	llacBranch.py
### PURPOSE:	LLAC low-level commands
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiExceptions     import RunError, NextReply, ReturnCall
from scpiBase           import Hidden
from scpiBranch         import branchTypes
from scpiLeaf           import Leaf, Observing, Controlling, Administrative, Background
from scpiFilesystemBase import FilesystemLeaf
from scpiFileContexts   import P_WRITE, OP_WRITE
from scpiSession        import DetachedSession
from scpiConfigBase     import ConfigBase
from llacController     import MessageTypes
from llacBase           import INT, UINT, HEX, REAL, TEXT, _LLACBase, _LLACLeaf, LLACFullBranch

from cStringIO          import StringIO
from struct             import pack, unpack, error as StructError
from subscription       import info, LogLevels, TRACE
from array              import array
from base64             import encodestring


class _LLACReadValueLeaf (Observing, _LLACLeaf):
    '''
    Read a value from a specified LLAC register.
    '''

    def declareInputs (self):
        _LLACLeaf.declareInputs(self)

        self.setInput('size', type=int, named=True,
                      units='bytes', range=(1, 4), default=4,
                      description='Register size')
    
        self.setInput('node',
                      type=hex,
                      format='0x%02X',
                      range=(0x00, 0xFF),
                      description='Device node address')

        self.setInput('register',
                      type=hex,
                      format='0x%04X',
                      range=(0x0000, 0xFFFF),
                      description='Device register address')


    def declareOutputs (self):
        _LLACLeaf.declareOutputs(self)
        argtype, format = self.argTypes[self.datatype]
        self.addOutput('value', format='%s', type=argtype)


    def run (self, _branch, size, node, register):
        argtype, format = self.argTypes[self.datatype]
        packing         = self.packing(self.datatype, size)
        request         = self.sendRead(node, register, size, packing)
        return format(size)%self.getResponses([request])
    



class _LLACWriteValueLeaf (Controlling, Background, _LLACLeaf):
    '''
    Read a value from a specified LLAC register.
    '''

    def declareInputs (self):
        _LLACLeaf.declareInputs(self)

        argtype, format = self.argTypes[self.datatype]

        self.setInput('sync', type=float, units='seconds',
                      named=True, default=None,
                      description=
                      'When writing a value to this register, request a '
                      'synchronization response from the device, then '
                      'detach and wait for this response to arrive.  If '
                      'more than the specified time elapses, an error is '
                      'returned.')

        self.setInput('size', type=int, named=True,
                      units='bytes', range=(1, 4), default=4,
                      description='Register size')

        self.setInput('node',
                      type=hex,
                      format='0x%02X',
                      range=(0x00, 0xFF),
                      description='Device node address')

        self.setInput('register',
                      type=hex,
                      format='0x%04X',
                      range=(0x0000, 0xFFFF),
                      description='Device register address.')

        
        self.setInput('value', type=argtype, format=format(0),
                      description='Register value')


    def run (self, _branch, sync, size, node, register, value):
        packing  = self.packing(self.datatype, size)
        asynchlist = self.write((value,), node, register, packing, flags=0x00, sync=sync)
        return asynchlist or None

    def next (self, refs):
        return self.waitSync(refs)



class _LLACEventLeaf (_LLACLeaf):
    '''
    Abstract superclass for EVENt_Add, EVENt_Query
    '''

    def declareParams (self, setParam):
        setParam('target',
                 type=int,
                 named=True,
                 range=(0x00, 0xFF),
                 format='0x%02X',
                 default=None,
                 units='node address')

        setParam('targetMask',
                 type=int,
                 named=True,
                 range=(0x00, 0xFF),
                 format='0x%02X',
                 default=None,
                 units='bitmask')

        setParam('source',
                 type=int,
                 named=True,
                 range=(0x00, 0xFF),
                 format='0x%02X',
                 default=None,
                 units='node address')

        setParam('sourceMask',
                 type=int,
                 named=True,
                 range=(0x00, 0xFF),
                 default=None,
                 format='0x%02X',
                 units='bitmask')

        setParam('id',
                 type=int,
                 named=True,
                 range=(0x0000, 0xFFFF),
                 default=None,
                 format='0x%04X',
                 units='register address')

        setParam('idMask',
                 type=int,
                 named=True,
                 range=(0x0000, 0xFFFF),
                 format='0x%04X',
                 default=None,
                 units='bitmask')

        setParam('msgid',
                 type=int,
                 named=True,
                 range=(0x0000, 0xFFFF),
                 default=None,
                 format='0x%04X',
                 units='register address')

        setParam('msgidMask',
                 type=int,
                 named=True,
                 range=(0x0000, 0xFFFF),
                 format='0x%04X',
                 default=None,
                 units='bitmask')

        setParam('control',
                 type=int,
                 named=True,
                 range=(0x00, 0xFF),
                 format='0x%02X',
                 default=None,
                 units='control bits')

        setParam('controlMask',
                 type=int,
                 named=True,
                 range=(0x00, 0xFF),
                 default=None,
                 format='0x%02X',
                 units='bitmask')

        setParam('command',
                 type=str,
                 default=None,
                 repeats=(1, None),
                 description=
                 'Invoked when a matching LLAC event arrives')
        

class _LLACEventTableLeaf (Leaf):
    class NoSuchTable (RunError):
        "No event table has been defined for LLAC node 0x%(node)02X"



class LLAC (LLACFullBranch):
    '''
    Low Level Auxillary Communications Protocol Support.
    '''

    def __init__ (self, *args, **kwargs):
        LLACFullBranch.__init__(self, *args, **kwargs)
        self.addShutDownAction(self.llac.close)
        


    class OPEN (Administrative, _LLACLeaf):
        '''Open LLAC transport'''

        class LLACOpenError (RunError):
            'Could not open LLAC transport: %(message)s'


        def run (self):
            if not self.llac.isopen:
                try:
                    self.llac.open()
                except (EnvironmentError, self.llac.LLACError), e:
                    raise self.LLACOpenError(message=str(e).strip())


    class CLOSE (Administrative, _LLACLeaf):
        '''Close LLAC Transport'''
        def run (self):
            if self.llac.isopen:
                self.llac.close()


    class OPEN_Query (Observing, _LLACLeaf):
        '''Query LLAC Open status'''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('open', type=bool)

        def run (self):
            return self.llac.isopen


    class INTeger (_LLACWriteValueLeaf):
        '''
        Write an integer value to an LLAC register.
        '''
        datatype = INT

    class INTeger_Query (_LLACReadValueLeaf):
        '''
        Read an integer value from an LLAC register.
        '''
        datatype = INT


    class UnsignedINTeger (_LLACWriteValueLeaf):
        '''
        Write an unsigned integer value to an LLAC register.
        '''
        datatype = UINT

    class UnsignedINTeger_Query (_LLACReadValueLeaf):
        '''
        Read an unsigned integer value from an LLAC register.
        '''
        datatype = UINT


    class HEXadecimal (_LLACWriteValueLeaf):
        '''
        Write a hexadecimal value to an LLAC register.
        '''
        datatype = HEX

    class HEXadecimal_Query (_LLACReadValueLeaf):
        '''
        Read a hexadecimal value from an LLAC register.
        '''
        datatype = HEX


    class REAL (_LLACWriteValueLeaf):
        '''
        Write a real (floating point) number to an LLAC register.
        '''
        datatype = REAL

    class REAL_Query (_LLACReadValueLeaf):
        '''
        Read a real (floating point) number from an LLAC register.
        '''
        datatype = REAL


    class TEXT (_LLACWriteValueLeaf):
        '''
        Write text to an LLAC register.
        '''
        datatype = TEXT


    class TEXT_Query (_LLACReadValueLeaf):
        '''
        Read text from an LLAC register.
        '''
        datatype = TEXT

        def declareInputs (self):
            _LLACReadValueLeaf.declareInputs(self)
            self.setInput('nonprint', type=str, named=True, default=".",
                          description="How to represent non-printable characters")

            self.setInput('raw', type=bool, named=True, default=False,
                          description="Return original/filtered string")


        def run (self, _branch, nonprint, raw, size, node, register):
            result = _LLACReadValueLeaf.run(self, _branch, size, node, register)
            if not raw:
                chars = [ [nonprint, c][c.isalnum()]  for c in result ]
                result = ''.join(chars)

            return result


    class READ_Query (Observing, _LLACLeaf):
        '''
        Read up to 8 bytes from a register of an LLAC capable device.

        This is mainly a diagnostic command, used to obtain raw input.
        To read specific data types from a register, use the type-specific
        read commands: :INT?, :UINT?, :HEX?, :REAL?, and :TEXT?.

Examples:
        * Read 8 bytes from node 0x80, starting at register 0x100:
            LLAC:READ? 0x80 0x100 8

        '''

        def declareInputs (self):
            _LLACLeaf.declareInputs(self)

            self.setInput('node',
                          type=int,
                          format='0x%02X',
                          range=(0x00, 0xFF),
                          description='Device node address')

            self.setInput('register',
                          type=int,
                          format='0x%04X',
                          range=(0x0000, 0xFFFF),
                          description='Device register address')

            self.setInput('count',
                          type=int,
                          range=(1,4),
                          default=4)


        def declareOutputs (self):
            _LLACLeaf.declareOutputs(self)
            self.addOutput('byte',
                           type=int,
                           format='0x%02X',
                           range=(0x00, 0xFF),
                           repeats=(1, 8))


        def run (self, node, register, count):
            packing = self.packing(HEX, 1, count)
            return self.read(node, register, count, packing)



    class WRITe (Controlling, _LLACLeaf):
        '''
        Write up to 4 data bytes (d4-d7) to an LLAC device register.

        The first four data bytes of the write request contain
        LLAC information, and will be generated automatically.
        The remaining four bytes may be supplied as hexadecimal
        arguments to this command.

        To set one or more control bits in the write message, use
        "-flags=<bitmask>".  For instance, to request that the device
        sends a synchronization event once it has completed any
        operation that resulted from the write request, use
        "-flags=0x80" to set control bit #7.  (To capture the
        resulting synchronization event, you should also register an
        event handler using LLAC:EVENt).

        This is a low-level command, used to send raw output to the
        device.  To send specific data types, and to automatically
        handle synchronization requests/responses, use the type-specific
        write commands: :INT, :UINT, :HEX, :REAL, :TEXT.

Examples:
        * Set up an event handler for synchronization events, then
          write data bytes 0x45, 0x56, 0x12, 0x23 to register 0x1002
          in node 0x82, requesting that a synchronization event be
          generated once any applicable operation has completed.
          Finally, wait for the synchronization event to arrive:

            EVENt -control=0x80 -controlMask=0x80 PUBLish Sync
            WRITe -flags=0x80 0x82 0x1002 0x45 0x56 0x12 0x23
            MWAit Sync
    
        '''

        def declareInputs (self):
            _LLACLeaf.declareInputs(self)

            self.setInput('flags',
                          type=int,
                          named=True,
                          default=0x00,
                          range=(0x00, 0xFF),
                          format='0x%02X',
                          units="bitmask")

            self.setInput('node',
                          type=int,
                          format='0x%02X',
                          range=(0x00, 0xFF),
                          description='Device node address')

            self.setInput('register',
                          type=int,
                          format='0x%04X',
                          range=(0x0000, 0xFFFF),
                          description='Device register address')

            self.setInput('data',
                          type=int,
                          default=None,
                          range=(0x00, 0xFF),
                          format='0x%02X',
                          repeats=(None, 4))


        def run (self, flags, node, register, *data):
            packing = self.packing(HEX, 1, len(data))
            self.write(data, node, register, packing, flags=flags, sync=None)



    class EVENt_Set (Controlling, _LLACLeaf):
        '''
        Generate an LLAC event message
        '''
        def declareInputs (self):
            _LLACLeaf.declareInputs(self)

            self.setInput('node',
                          type=int,
                          format='0x%02X',
                          range=(0x00, 0xFF),
                          description='Device node address')

            self.setInput('eventid',
                          type=int,
                          format='0x%04X',
                          range=(0x0000, 0xFFFF),
                          description='Event ID')

            self.setInput('data',
                          type=int,
                          default=None,
                          range=(0x00, 0xFF),
                          format='0x%02X',
                          repeats=(None, 4))

            self.setInput('control',
                          type=int,
                          default=None,
                          range=(0x00, 0xF),
                          format='0x%02X',
                          description='Control bits')

        def run (self, node, eventid, control, *data):
            packing = self.packing(HEX, 1, len(data))
            self.sendEvent(data, node, eventid, packing, control*16)



    class EVENt_Add (Observing, _LLACEventLeaf):
        '''
        Add an LLAC event handler.

        The handler will be invoked when an LLAC event message is
        received, under the following conditions:

        * If "target" is specified, it must match the destination node
          address of the event message after applying "targetMask"

        * If "source" is specified, it must match the source node
          address of the event message after applying "sourceMask"

        * If "id" is specified, it must match the event id of the
          message after applying "eventMask"

        * If "control" is specified, it must match the control bits in
          the message after applying "controlMask"

        Unless specified, each of the mask values defaults to its maximum
        value (0xFF or 0xFFFF), meaning that the specified value and the
        actual value from the event message must match exactly for the
        match to succeed, and thus for the handler to be invoked.

        The following substitutions occur in the command text prior
        to invocation:
          $target   = hexadecimal representation of 8-bit target node (ours)
          $id       = hexadecimal representation of 16-bit event ID
          $msgid    = hexadecimal representation of 16-bit message ID
          $source   = hexadecimal representation of 8-bit source node (= $0h)
          $control  = hexadecimal representation of 8-bit control mask (= $3h)
          $severity = textual representation of severity: Info, Warning, Error, Fatal
          $device   = textual representation of device (see DEVice=)
          $text     = textual representation of event (see LoadEVent)
          $Nh       = hexadecimal representation of data byte(s) N
          $Ni       = signed integer representation of data byte(s) N
          $Nu       = unsigned integer representation of data byte(s) N
          $Nf       = floating point representation of (4 or 8) data byte(s) N
          $Ns       = string representation of data byte(s) N

        where N is one or more digits 0-7 representing the corresponding data
        byte from the packet.  For instance, "0" gives the 8-bit value from
        the first data byte of the packet, whereas "45" gives a big endian
        representation of the fifth and sixth byte (#4 and #5).

        To prevent substitution in the command text, insert a backslash
        immediately prior to the dollar sign (e.g. "\\$id").

Examples:
        * Publish Registration messages for devices using LLAC v8 protocol:
            EVENt+ RegHandler8 -control=0x00 -target=0x00 <multiline>
                PUBLish Registration NODE=$0h VERSION=0x0008
            </multiline>

        * Publish a Registration message for devices using LLAC v9.. protocol:
            EVENt+ RegHandler9 -control=0x40 -controlMask=0x40 <multiline>
                PUBLish Registration NODE=$source VERSION=$67h REGMAP=$45h
            </multiline>

        * Publish a message for events 8000-FFFF from nodes 0x80-0x8F:
            EVENt+ Alarms <multiline>
              -source=0x80 -sourceMask=0xF0
              -id=0x8000 -idMask=0x8000
              PUBLish ValveAlarm $45h
            </multiline>
        '''

        class HandlerExists (RunError):
            'There is already an LLAC event handler named %(name)s'

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('replaceExisting',
                          type=bool,
                          named=True,
                          default=False,
                          description=
                          'If an event handler by the specified name already '
                          'exists, replace it.')

            self.setInput('name',
                          type=str,
                          description=
                          'A unique name for this event handler.')

            self.declareParams(self.setInput)


        def run (self, _session, _context, replaceExisting,
                 name, target, targetMask, source,
                 sourceMask, id, idMask, msgid, msgidMask, control, controlMask, *command):

            if self.llac.getEventHandler(name):
                if replaceExisting:
                    self.llac.removeEventHandler(name)
                else:
                    raise self.HandlerExists(name=name)

            command = ' '.join(command)
            session = DetachedSession(parent=_session,
                                      input=None,
                                      description='LLAC Event handler %r'%name)

            self.llac.addEventHandler(name,
                                      self.handleEvent, (session, command),
                                      target, targetMask, source, sourceMask,
                                      id, idMask, msgid, msgidMask, control, controlMask)



        def handleEvent (self, target, source, eventid, msgid, control, data,
                         session, command):

            command = self.formatEventText(command, target, source,
                                           eventid, msgid, control, data)
            session.handleInput(command, scope=self.parent)



    class EVENt_Remove (Observing, _LLACLeaf):
        '''
        Remove an existing LLAC event handler
        '''
        class NoSuchHandler (RunError):
            'There is no event handler named %(name)r.'

        def run (self, ignoreMissing=False, name=str):
            try:
                self.llac.removeEventHandler(name)
            except KeyError:
                if not ignoreMissing:
                    raise self.NoSuchHandler(name=name)




    class EVENt_Query (Observing, _LLACEventLeaf):
        '''
        Show the definiton of the specified LLAC event handler.
        '''

        class NoSuchHandler (RunError):
            'There is no event handler named %(name)s'


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.declareParams(self.addOutput)


        def run (self, name=str):
            handler = self.llac.getEventHandler(name)
            if handler:
                func, args, tspec, sspec, ispec, mspec, cspec = handler
                session, command = args

                props = [ ]
                for spec in tspec, sspec, ispec, mspec, cspec:
                    props.extend(spec)

                props.append(command)
                return tuple(props)

            else:
                raise self.NoSuchHandler(name=name)


    class EVENt_Enumerate (Observing, _LLACLeaf):
        '''
        List all LLAC event handlers
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))


        def run (self):
            return tuple(self.llac.listEventHandlers())


    class DEVice_Set (Controlling, Leaf):
        '''
        Set device name for a given LLAC node.  In event handlers (see
        EVENt+), occurences of the string "$device" will subsequently
        be expanded to this device name.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF))
            self.setInput('name', type=str)

        def run (self, node=hex, name=str):
            self.parent.nodename[node] = name


    class DEVice_Clear (Controlling, Leaf):
        '''
        Clera device name for a given LLAC node.  
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF))

        def run (self, node=hex):
            self.parent.nodename.pop(node, None)


    class DEVice_Query (Observing, Leaf):
        '''
        Return the device name associated with a given LLAC node address.
        '''

        class NoAssociation (RunError):
            '''There is no configured association for the LLAC node 0x%(node)02X'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, default="")

        def run (self, ignoreMissing=False, node=hex):
            try:
                return self.parent.nodename[node]
            except KeyError:
                if not ignoreMissing:
                    raise self.NoAssociation(node=node)


    class DEVice_Enumerate (Observing, Leaf):
        '''
        Return a list of known LLAC devices
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('device', type=str, repeats=(0, None))


        def run (self):
            devices = [ d for (n,d) in sorted(self.parent.nodename.items()) ]
            return tuple(devices)



    class NODe_Query (Observing, Leaf):
        '''
        Return the LLAC node address associated with the given device name
        '''

        class UnknownDeviceName (RunError):
            '''LLAC device %(device)r is not known'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('node', type=hex, format="0x%02X", range=(0x00, 0xFF), default=None)

        def run (self, ignoreMissing=False, device=str):
            for node, candidate in self.parent.nodename.items():
                if candidate.lower() == device.lower():
                    return node
            else:
                if not ignoreMissing:
                    raise self.UnknownDeviceName(device=device)


    class NODe_Enumerate (Observing, Leaf):
        '''
        Return a list of known LLAC nodes
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('node', type=hex, format="0x%02X", range=(0x00, 0xFF), repeats=(0, None))


        def run (self):
            devices = self.parent.nodename.keys()
            devices.sort()
            return tuple(devices)
        
                    
                



    class EventTABle_Load (Controlling, ConfigBase, Leaf):
        '''
        Load a table of event texts for the specified source node
        (device) from the specified configuration file/section.  In
        event handlers (see EVENt+), occurences of the string "$text"
        will subsequently be expanded to the text string associated
        with the reported event ID.
        '''

        class InvalidID (RunError):
            '''Invalid Event ID: %(eventid)r'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF))
            self.setInput('file', type=str)
            self.setInput('section', type=str)
            self.setInput('offset', type=hex)
            self.setInput('prefix', type=str)

        def run (self, literal=True, replace=False, offset=0, prefix="", node=hex, file=str, section=str):
            d = self.parent.eventTable.setdefault(node, {})
            if replace:
                d.clear()
            for eventid, text in self.getConfigItems(file, section, literal=literal):
                try:
                    eventid = int(eventid, 0)
                except ValueError:
                    raise self.InvalidID(eventid=eventid)
                else:
                    d[eventid + offset] = prefix + text



    class EventTABle_Clear (Controlling, Leaf):
        '''
        Clear a table of event texts for the specified source node
        (device).
        '''

        class InvalidID (RunError):
            '''Invalid Event ID: %(eventid)r'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF))

        def run (self, node=hex):
            self.parent.eventTable.pop(node, None)



    class EventTABle_Enumerate (Observing, _LLACEventTableLeaf):
        '''
        If a node address is specified, return event IDs that are
        known for this node.

        Otherwise, return LLAC node addresses for which event tables
        have been loaded.
        '''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF), default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('node', type=hex, format='0x%04X', repeats=(0, None))


        def run (self, node=hex):
            if node is None:
                return tuple(self.parent.eventTable.keys())
            else:
                try:
                    return tuple(self.parent.eventTable[node].keys())
                except KeyError:
                    raise self.NoSuchTable(node=node)


    class EventTABle_Query (Observing, _LLACEventTableLeaf):
        '''
        Return text description of the specified event ID

        '''

        class NoSuchEvent (RunError):
            "No such event ID exist in the event table for node 0x%(node)02X: 0x%(eventid)04X"

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, range=(0x00, 0xFF))
            self.setInput('eventid', type=hex, range=(0x0000, 0xFFFF))


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('text', type=str, default=None)


        def run (self, ignoreMissing=False, node=hex, eventid=hex):
            try:
                table = self.parent.eventTable[node]
            except KeyError:
                raise self.NoSuchTable(node=node)

            try:
                text = table[eventid]
            except KeyError:
                raise self.NoSuchEvent(node=node, eventid=eventid)

            return text


    class PENDing_Enumerate (Observing, _LLACLeaf):
        '''
        List message IDs of all pending LLAC requests.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int, named=True)
            self.addOutput('id',    type=hex, format="0x%04X", repeats=(0, None))

        def run (self):
            return (len(self.llac.responses),) + tuple(self.llac.responses)


    class PENDing_Query (Observing, _LLACLeaf):
        '''
        Return information about a pending LLAC request.
        '''

        class NoSuchMessage (RunError):
            '''There is no pending message with ID 0x%(msgid)04X'''

        def declareInputs (self):
            _LLACLeaf.declareInputs(self)
            self.setInput('msgid', type=hex, range=(0x0000, 0xFFFF))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            mtypes = dict(zip(MessageTypes.itervalues(), MessageTypes.iterkeys()))
            
            self.addOutput('name', type=str, named=True)
            self.addOutput('mt', type=mtypes, named=True)
            self.addOutput('dest', type=hex, format="0x%02X", named=True)
            self.addOutput('source', type=hex, format="0x%02X", named=True)
            self.addOutput('control', type=hex, format="0x%02X", named=True)
            self.addOutput('register', type=hex, format="0x%04X", named=True)
            self.addOutput('data', type=hex, format="0x%02X", repeats=(0, 4))


        def run (self, ignoreMissing=False, msgid=hex):
            try:
                name, request, queue = self.llac.responses[msgid]
            except KeyError, e:
                if not ignoreMissing:
                    raise self.NoSuchMessage(msgid=msgid)
            else:
                mt, dest, source, control, reg, msgid, data = request
                data = [ ord(c) for c in data ]
                return (name, mt, dest, source, control, reg) + tuple(data)


    class IDLE_Query (Observing, _LLACLeaf):
        '''
        Return True if LLAC transport is currently blocked for input, False otherwise.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('idle', type=bool)

        def run (self):
            return self.llac.isIdle()

        
    class RegistrationREQuest (Controlling, _LLACLeaf):
        '''
        Send a LLAC registration request.  By default, the request is
        sent to the broadcast node address 0xFF, which means that
        every device should respond by issuing a registration event,
        as if it were powering on.  If the request is issued to any
        other address, only the device with the corresponding address
        is expected to respond.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('destination', type=hex, range=(0x00, 0xFF), format="0x%02X")

        def run (self, destination=0xFF):
            return self.llac.sendRegistrationRequest(node=destination)


    class FILL (Controlling, _LLACLeaf):
        '''
        Fill up LLAC bulk transfer buffer with simulated data.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('length', type=int, range=(0, 65535),
                          description="How many packets to fill in LLAC buffer")


        def run (self, length=int):
            self.llac.fillDataBuffer(length)
            


    class TRACe_Set (Controlling, _LLACLeaf):
        '''
        Enable or disable logging of LLAC packets
        '''

        def declareInputs (self):
            _LLACLeaf.declareInputs(self)
            self.setInput('level', named=True, type=LogLevels, default=TRACE)

        def run (self, topic="LLAC", level=LogLevels, enabled=bool):
            if enabled:
                self.llac.setLogging(level, topic)
            else:
                self.llac.setLogging(None, topic)
                

    class DUMP_Query (Observing, _LLACLeaf):
        '''
        Return data from LLAC bulk transfer buffer as a base64-encoded string.
        '''

        def declareOutputs (self):
            EncodeLeaf.declareOutputs(self)
            self.addOutput('data', type=str, default="",
                           description="Base64-encoded data from LLAC transfer buffer")


        def run (self, _session):
            data = self.llac.getData()
            return encodestring(data)


    class DUMP (Controlling, _LLACBase, FilesystemLeaf):
        '''
        Save data from LLAC bulk transfer buffer to file.
        '''

        def run (self, _session, skipTriggers=False, filename=str):
            with self.openLocation(filename, _session, P_WRITE, not skipTriggers) as loc:
                data   = self.llac.getData()
                fp = loc.open(mode=OP_WRITE)
                fp.write(data)
                fp.close()


    class DATA_Query (Observing, _LLACLeaf):
        '''
        Return the highest index number of LLAC bulk transfer packets received
        since the last CLEar command, or beginning of time.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('size', type=int, named=True, format="0x%04X",
                           description="The size of the most recent batch of "
                           "data received via LLAC bulk transfer, i.e. one higher "
                           "than the index of the last bulk transfer request.")

            self.addOutput('gaps', type=int, repeats=(0, None), default=None,
                           description="Gaps in the data, "
                           "i.e. indexes that were never present in packets since "
                           "the last clear (DATA~) operation.")


        def run (self):
            response = [ self.llac.getDataIndex() ] + self.llac.getDataGaps()
            return tuple(response)



    class DATA_Clear (Controlling, _LLACLeaf):
        '''
        Clear LLAC bulk transfer buffer
        '''

        def run (self):
            self.llac.clearDataBuffer()


branchTypes['LLAC'] = LLAC

########################################################################
### FILE:	scpiPythonBranch.py
### PURPOSE:	Branch to access underlying Python interpreter
### CREATED:
###  2016-11-08 Tor Slettnes
###             Created.
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from scpiMinimalBranch  import MinimalBranch
from scpiLeaf           import Leaf, Administrative, Controlling, Observing
from scpiFilesystemBase import FilesystemLeaf
from scpiExceptions     import InternalError
from sys                import exc_info
from os.path            import basename, dirname

def execute (code):
    exec code

class PYthon (MinimalBranch):
    '''Branch to access underlying Python interpreter'''

    class PythonError (InternalError):
        pass

    class EXECute (Administrative, Leaf):
        '''Execute a block of Python code.'''

        def run (self, code=str):
            try:
                execute(code)
            except Exception, e:
                raise self.parent.PythonError(e, exc_info())


    class EVALuate_Query (Administrative, Leaf):
        '''
        Perform a numeric evaluation and return the result.
        Operator symbols are those that are available in the Python language.

        Local, global and persistent variable names can be used in the
        expression; they are resolved in that order.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('import', type=str, split=",", named=True, default=["math", "re"],
                          description="Comma-separated list of Python modules "
                          "to import into evaluation namespace")
            self.setInput('expression', type=str, repeats=(1, None))
            

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('result', type=str)

        def run (self, _session, _context, Import='', *expression, **assignments):

            exp = ' '.join(expression)
            imp = filter(None, Import)
            return str(_session._getEvaluationResult(exp, context=_context, assignments=assignments, imports=imp))


########################################################################
### FILE:       serialSCPIDevice.py
### PURPOSE:    Interface to SCPI-based serial device
###
### HISTORY:
###  2016-01-22 Tor Slettnes
###             Created.
###
### Copyrights (C) 2016 ThermoFisher Scientfic.  All rights reserved.
########################################################################

from scpiExceptions     import RunError, CommandError
from scpiBranch         import Branch, branchTypes
from scpiFullBranch     import FullBranch
from scpiLeaf           import Administrative, Controlling, Observing
from scpiDynamicBase    import Dynamic, DynamicCommandLeaf
from locking            import Lock
from commandParser      import parser

import glob, threading, time

try:
    import serial

    parities = dict([ (symbol.split("_", 1)[1], getattr(serial, symbol))
                      for symbol in dir(serial)
                      if symbol.startswith('PARITY_') ])

    gotSerial = True

except ImportError:
    parities  = {'NONE': 'N', 'EVEN': 'E', 'ODD': 'O'}
    gotSerial = False


class LinkedSCPIDeviceBranch (Dynamic, Branch):
    deviceMask     = "/dev/serial/by-id/*"
    newline        = "\r\n"
    serial         = None
    received       = ""

    class NoDevices (RunError):
        '''Could not detect any serial device'''

    class ConnectionError (RunError):
        '''Failed to connect to serial device %(device)r: %(error)s'''

    class NotConnected (RunError):
        '''Serial device is not connected'''

    class CommunicationError (RunError):
        '''Serial communication error: %(error)s'''

    class CommunicationTimeout (RunError):
        '''Timed out after %(timeout)s waiting for response'''

    class DeviceError (RunError):
        '''Device returned error %(errorCode)s'''

    class UnknownResponse (RunError):
        '''Device returned unknown response %(response)r'''


    def __init__ (self, autoCapitalize=False, retries=0, waitTimeout=0, *args, **kwargs):
        Branch.__init__(self, *args, **kwargs)
        self.lock = Lock()
        self.autoCapitalize=autoCapitalize
        self.retries=retries
        self.waitTimeout=waitTimeout


    def listDevices (self, mask=deviceMask):
        return glob.glob(mask)

    def connect (self, device, *args, **kwargs):
        assert gotSerial, 'Python "serial" module is not installed'


        if device is None:
            devices = self.listDevices()
            if not devices:
                raise self.NoDevices()
            device = devices[0]

        try:
            self.serial = serial.Serial(port=device, *args, **kwargs)
            self.serial.flushInput()

        except ValueError, e:
            raise CommandError("Invalid parameter: %s"%(e,))

        except IOError, e:
            raise self.ConnectionError(device=device, error=e)

        except serial.SerialException, e:
            raise self.CommunicationError(error=e)


    def sendCommand (self, command):
        if not self.serial:
            raise self.NotConnected()

        try:
            count = self.serial.write(command + self.newline)
        except serial.SerialException, e:
            raise self.CommunicationError(error=e)


        return count == (len(command) + len(self.newline))


    def receiveLine (self, block=True):
        if not self.serial:
            raise self.NotConnected()

        try:
            self.received += self.serial.read(self.serial.inWaiting())

            while block and not '\n' in self.received:
                c = self.serial.read()
                if not c:
                    raise self.CommunicationTimeout(timeout=self.serial.timeout)
            
                self.received += c + self.serial.read(self.serial.inWaiting())

        except serial.SerialException, e:
            raise self.CommunicationError(error=e)

        try:
            response, self.received = self.received.split('\n', 1)
            response = response.rstrip('\r')
        except ValueError:
            response, self.received = self.received, ""

        self.trace("Received from %s: %r"%(self.serial.port, response))
        return response


    def receiveResponse (self, block=True):
        received = self.receiveLine(block=block)
        response = None

        while not received[:3] in ("", "OK", "ERR"):
            response = received
            received = self.receiveLine(block=block)

        if received.startswith("ERR"):
            errorCode = int(received[3:])
            raise self.DeviceError(errorCode=errorCode)

        return response



    def _locate (self, elements, path, defaults):
        defaults.update(_subcommand=elements)

    def capitalize (self, element):
        intro, fourth, remainder = element[:3], element[3:4], element[4:]
        isvowel = fourth.lower() in "aeiouy"
        return intro.upper() + (fourth.upper(), fourth.lower())[isvowel] + remainder.lower()

    def invoke (self, _parts, _subcommand, **options):
        if self.autoCapitalize:
            _subcommand = [self.capitalize(element) for element in _subcommand]
        cmd = ' '.join(((':'.join(_subcommand), parser.collapseArgs(_parts))))

        try:
            self.lock.acquire()

            err = None
            for _ in range(self.retries + 1):
                self.trace("Sending to %s: %r"%(self.serial.port, cmd))
                self.sendCommand(cmd)
                try:
                    # Retrieve response
                    response = self.receiveResponse()
                except self.CommunicationTimeout as e:
                    # Communication error
                    self.debug("Communication error on %s: %s"%(self.serial.port, e))
                    err = e

                    continue
                else:
                    # Retrieved response
                    return response
            else:
                # All attempts to retrieve response failed
                raise err
        finally:
            if self.waitTimeout:
                def delayRelease():
                    time.sleep(self.waitTimeout / 1000.0)
                    self.lock.release()

                threading.Thread(target=delayRelease).start()
            else:
                self.lock.release()


    def estimate (self, **options):
        pass

    def formatOutputs (self, response, alwaysNamed=False, raw=False):
        return [ response ]



class DeviceLeaf (DynamicCommandLeaf):
    dynamicType = 'Serial SCPI Device'


class SerialSCPIDeviceBranch (FullBranch):

    class SerialSCPI_Add (Administrative, DeviceLeaf):
        '''
        Create a new command branch, and map its namespace to a SCPI device 
        connected via a serial interface.  Any commands delegated to this

    Examples:
        * Create a "DEVice" branch, mapped to a SCPI server listening on a
          device connected via serial device "/dev/ttyACM0" at 38400 baud.

            C: 1 SerialSCPI+ DEVice /dev/ttyACM0 -baudrate=38400
            S: OK 1
            C: 2 DEVice:*IDN?
            S: OK 2 "Coherent, Inc - OBIS LS 505-50 - V1.203 - 20130220"
        '''


        def declareInputs (self):
            DeviceLeaf.declareInputs(self)
            self.setInput('replaceExisting',
                          description=
                          'If another dynamic command by the same name already '
                          'exists, replace it')

            self.setInput('commandIndex',
                          description=
                          'Prefix every command sent to the linked server with '
                          'a unique index.  This increases the reliability of '
                          'communications for asynchronous command execution, '
                          'but is not understood by all SCPI servers')

            self.setInput('commandTimeout',
                          units='seconds',
                          description=
                          'How long to wait for a response to commands '
                          'sent to the linked server')

            self.setInput('retries',
                          type=int,
                          default=0,
                          range=(0, None),
                          description=
                          'How many retries to perform when a command fails to '
                          'get a successful response')

            self.setInput('waitTimeout',
                          type=int,
                          default=0,
                          units='milliseconds',
                          description=
                          'How long to wait after receiving a response before '
                          'allowing the next command to be sent')

            self.setInput('autoCapitalize',
                          description='Automatically capitalize commands sent '
                          'to the device according to standard SCPI conventions: '
                          'The first three letters of each command element are '
                          'capizalized, the fourth if and only if it is a '
                          'consontant, and remaining letters are converted to '
                          'lowercase.')

            self.setInput('device',
                          type=str,
                          description='Serial device name, e.g. "/dev/ttyACM0" or "COM3"')

            self.setInput('baudrate',
                          type=int,
                          description='Speed of serial interface, e.g. 9600, 38400, 115200, etc')

            self.setInput('bytesize',
                          type=int,
                          default=8,
                          description='Data bits per byte')

            self.setInput('parity', type=parities)


        def run (self, _session, _branch,
                 replaceExisting=False,
                 commandIndex=False, autoCapitalize=False,
                 commandTimeout=15.0, retries=0, waitTimeout=0,
                 branch=str, device=str, baudrate=int, bytesize=8, parity='N', stopbits=1):

            obj = self.findModifiableCommand(_session, branch,
                                             allowMissing=True,
                                             allowExisting=replaceExisting,
                                             parent=_branch)
            
            new = self.incarnate(branch, LinkedSCPIDeviceBranch, parent=_branch, autoCapitalize=autoCapitalize, retries=retries, waitTimeout=waitTimeout)

            new.connect(device, baudrate=baudrate, timeout=commandTimeout,
                        bytesize=bytesize, parity=parity, stopbits=stopbits)

            self.addinstance(_session, branch, new,
                             replaceExisting=replaceExisting,
                             parent=_branch)



    class SerialSCPI_Remove (Controlling, DeviceLeaf):
        '''
        Delete a branch that was previously linked to a remote SCPI server.
        '''

        def run (self, _session, _branch, ignoreMissing=False, name=str):
            self.delinstance(_session, name, ignoreMissing, parent=_branch)
        


    class SerialSCPI_Query (Observing, DeviceLeaf):
        """
        If no arguments are provided, return a list of branches currently
        linked to external SCPI servers.

        If the name of a linked branch is provided, return the host name
        and port of the corresonding SCPI server to which it is connected.
        """

        def declareInputs (self):
            DeviceLeaf.declareInputs(self)
            self.setInput('branch',
                          type=str,
                          description='Name of a linked branch')


        def declareOutputs (self):
            DeviceLeaf.declareOutputs(self)
            self.addOutput('device',
                           type=str,
                           description='Serial device name, e.g. "/dev/ttyACM0" or "COM3"')

            self.addOutput('baudrate',
                           type=int,
                           description='Speed of serial interface, e.g. 9600, 38400, 115200, etc')

            self.addOutput('bytesize', type=int, description='Data bits per byte')
            self.addOutput('parity', type=parities, description='Parity checking')
            self.addOutput('stopbits', type=float, format="%g", description='Stop bits')


        def run (self, _branch, branch):
            obj, names, argmap = self.findDynamicCommand(name, parent=_branch)
            return obj.serial.port, obj.serial.baudrate, obj.serial.bytesize, obj.serial.parity, obj.serial.stopbits



    class SerialSCPI_Enumerate (Observing, DeviceLeaf):
        '''
        Return a list of dynamic subbranches in this branch.
        '''

        def declareOutputs (self):
            DeviceLeaf.declareOutputs(self)
            self.addOutput('command', type=str, repeats=(0, None))

        def run (self, _branch):
            return tuple(self.listinstances(parent=_branch))



branchTypes['SerialSCPIDevice'] = SerialSCPIDeviceBranch

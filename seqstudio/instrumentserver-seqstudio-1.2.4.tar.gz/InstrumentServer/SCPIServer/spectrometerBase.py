########################################################################
### FILE:	spectrometerBase.py
### PURPOSE:	Abstract superclass for spectrometers
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2015 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch     import FullBranch
from scpiLeaf           import Leaf, Background, Singleton, \
    Observing, Controlling, Administrative, \
    SYNCHRONOUS, ASYNCHRONOUS
from scpiFileContexts   import OP_READ, OP_WRITE, OP_APPEND, P_WRITE, FileContext

from scpiFilesystemBase import FilesystemLeaf, FilesystemBase
from scpiFileBranch     import FilesystemBranch
from scpiExceptions     import RunError, NextReply, ComponentError, Aborted
from scpiConfigBase     import ConfigBase, ConfigError
from subscription       import publish, addTopic, TRACE, DEBUG
from locking            import Event, Lock
from gzip               import GzipFile

import time
import threading


class SpectrometerBase (ConfigBase, FilesystemBranch):
    '''Abstract Spectrometer branch'''

    class NoDevices (RunError):
        '''No spectrometer devices were found in this system.'''

    class NotFound (RunError):
        '''No matching spectrometer was found in this system'''

    class NotConnected (RunError):
        '''Not connected to spectrometer.'''

    class ChannelExists (RunError):
        '''Data channel %(name)r already exists.'''

    class RegionExists (RunError):
        '''Region %(name)r already exists.'''

    class CoefficientGroupExists (RunError):
        '''Wavelength coefficient group %(name)r already exists.'''

    class NoSuchChannel (RunError):
        '''Data channel %(name)r has not been defined.'''

    class NoRegion (RunError):
        '''No region has been defined for channel %(channel)r'''

    class NoRegion (RunError):
        '''Region %(name)r has not been defined'''

    class NoRegionMapping (RunError):
        '''Channel %(channel)r has not been mapped to any region'''

    class NoCoeffs (RunError):
        '''Wavelength coefficient group %(name)r has not been defined.'''

    class NoChannels (RunError):
        '''No channel regions have been defined'''

    class SpectrometerFailure (RunError):
        '''Operation failed: %(message)s'''


    spectrometers = None

    (ConfigSection, ChannelSection, RegionSection, WLCoeffSection) = \
        ("Configuration", "Channels", "Regions", "Wavelength Coefficients")

    Parameters = (ChannelNames, RegionNames, ExposureTime, Trigger, Signal, OpenShutter,
                  Speed, Gain, Binning, FrameDelay, AlignmentShift,
                  DataBinning, MaxDataBins, MinDataWavelength, MaxDataWavelength,
                  MinCorrectionRatio, MinCorrectionThreshold, Chunk) = \
                  ("channels", "regions", "exposureTime", "trigger", "signal", "openShutter",
                   "speed", "gain", "binning", "framedelay", "alignmentShift",
                   "dataBinning", "maxDataBins", "minDataWavelength", "maxDataWavelength",
                   "minCorrectionRatio", "minCorrectionThreshold", "chunk")


    DEFAULT_TOPIC = 'Data'
    IMAGE, SCAN   = range(2)

    fileLocks     = {}

    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        SpectrometerBase.init(self)


    def init (self):
        addTopic(self.DEFAULT_TOPIC, level=DEBUG)
        self.collecting    = None
        self.params        = {}
        self.framedata     = []
        self.darksignal    = []
        self.customColumns = []


    def listDevices (self, rescan=False):
        raise NotImplementedError


    def connectDevice (self, rescan=False, serial=None, productID=None):
        raise NotImplementedError


    def getConfig (self):
        return self.getConfigInstance('spectrometer.ini', casePreserving=False, literal=True)


    def getConfigValue (self, param, default=None,
                  section=ConfigSection, valuetype=None):

        return self.getConfig().get(section, param, default,
                                    valuetype=valuetype, vars=self.params)


    def setConfigValue (self, param, value, section=ConfigSection, save=True):
        self.getConfig().set(section, param, value, save=save)


    def delConfigValue (self, param, section=ConfigSection, save=True):
        return self.getConfig().remove_option(section, param, save=save)


    def setOrDelConfigValue (self, param, value, section=ConfigSection, save=True):
        if value is None:
            self.delConfigValue(param, section, save)
        else:
            self.setConfigValue(param, value, section, save)


    def saveConfigValues (self):
        self.getConfig().save()


    def checkChannelRegions (self, regions):
        try:
            self.device.CheckChannelRegions(filter(None, regions))
        except ValueError, e:
            raise self.SpectrometerFailure(message=str(e))


    def addChannel (self, name, region, replaceExisting=False, save=True):
        index    = self.getChannelIndex(name, True)
        channels = self.getChannelNames(True)

        if index is None:
            index = len(channels)
            channels += (name,)

        elif replaceExisting:
            channels = tuple(channels[:index]) + (name,) + tuple(channels[index+1:])

        else:
            raise self.ChannelExists(name=name)

        self.getConfiguredRegion(region)

        regions  = list(self.getConfigValue(self.RegionNames, (), valuetype=tuple))
        while len(regions) <= index:
            regions.append(None)

        regions[index] = region

        self.setConfigValue(self.ChannelNames, channels, save=False)
        self.setConfigValue(self.RegionNames, tuple(regions), save=save)


    def removeChannel (self, name, ignoreMissing=False, save=True):
        index    = self.getChannelIndex(name, ignoreMissing)
        channels = self.getChannelNames(allowEmpty=True)
        regions  = self.getConfigValue(self.RegionNames, ())

        if (index  is not None):
            channels = channels[:index] + channels[index+1:]
            self.setConfigValue(self.ChannelNames, channels, save=False)

            regions  = regions[:index] + regions[index+1:]
            self.setConfigValue(self.RegionNames, regions, save=save)


    def clearChannels (self, save=True):
        self.delConfigValue(self.ChannelNames, save=save)
        self.getConfig().remove_section(self.ChannelSection, save=save)


    def getChannelNames (self, allowEmpty=False):
        default  = (self.NoChannels, ())[bool(allowEmpty)]
        return self.getConfigValue(self.ChannelNames, default, valuetype=tuple)


    def getChannelIndex (self, channel, ignoreMissing=False):
        for index, name in enumerate(self.getChannelNames(ignoreMissing)):
            if name.lower() == channel.lower():
                return index
        else:
            if not ignoreMissing:
                raise self.NoSuchChannel(name=channel)


    def getRegionName (self, channel, ignoreMissing=False):
        channelIndex = self.getChannelIndex(channel)
        regionNames  = self.getConfigValue(self.RegionNames, ())

        if channelIndex < len(regionNames) and regionNames[channelIndex] is not None:
            return regionNames[channelIndex]

        elif not ignoreMissing:
            raise self.NoRegionMapping(channel=channel)


    def setRegion (self, name, x1, x2, y1, y2, coeffGroup, replaceExisting=False, save=True):
        if not replaceExisting and self.getConfiguredRegion(name, True):
            raise self.RegionExists(name=name)

        self.getCoefficientGroup(coeffGroup)

        region = (x1, x2, y1, y2, coeffGroup)
        self.setConfigValue(name, region, section=self.RegionSection, save=save)


    def delRegion (self, name, ignoreMissing=False, save=True):
        exists = self.delConfigValue(name, section=self.RegionSection, save=save)
        if not exists and not ignoreMissing:
            raise self.NoRegion(name=name)


    def getRegionNames (self):
        return self.getConfig().options(self.RegionSection)


    def clearRegions (self, save=True):
        self.getConfig().remove_section(self.RegionSection, save=save)


    def getConfiguredRegion (self, name, ignoreMissing=False):
        region = self.getConfigValue(name, default=None,
                               section=self.RegionSection, valuetype=tuple)

        if region is None and not ignoreMissing:
            raise self.NoRegion(name=name)

        return region


    def getConfiguredRegions (self):
        return [ self.getConfiguredRegion(name, True)[:-1]
                 for name in self.getConfigValue(self.RegionNames, (), valuetype=tuple) ]

    def getDeviceRegions (self):
        return self.device.GetDataRegions()

    def getCoefficientsByChannel (self, binning, ignoreMissing=False):
        result = []
        divisor, section = self.bestCoeffSection(binning)

        for channelName, regionName in zip(self.getConfigValue(self.ChannelNames, (), valuetype=tuple),
                                           self.getConfigValue(self.RegionNames, (), valuetype=tuple)):

            try:
                x1, x2, y1, y2, group = self.getConfiguredRegion(regionName, ignoreMissing)
            except (TypeError, ValueError):
                coeffs = None
                group  = None
            else:
                coeffs = self.getConfigValue(group, None, section=section)

            if not coeffs and not ignoreMissing:
                raise self.NoCoeffs(channel=channelName, region=regionName, name=group, binning=binning, divisor=divisor)

            result.append(coeffs or (0,))

        return result, divisor


    def getCoefficientGroup (self, name, divisor=None, ignoreMissing=False):
        section = self.coeffSection(divisor)
        coeffs  = self.getConfigValue(name, default=(), section=section, valuetype=tuple)

        if not coeffs and not ignoreMissing:
            raise self.NoCoeffs(name=name, divisor=divisor)

        return coeffs


    def addCoefficientGroup (self, name, divisor, coefficients, replaceExisting=False, save=True):
        assert isinstance(coefficients, tuple), \
            "addCoefficientGroup(%r, %r, %r): argument 3 must be a tuple."%(name, divisor, coefficients)

        section = self.coeffSection(divisor)

        if not replaceExisting and self.getConfigValue(name, section=section):
            raise self.CoefficientGroupExists(name=name, divisor=divisor)

        self.setConfigValue(name, coefficients, section=section, save=save)


    def delCoefficientGroup (self, name, divisor=0, ignoreMissing=False, save=True):
        section = self.coeffSection(divisor)
        exists  = self.delConfigValue(name, section=self.WLCoeffSection, save=save)
        if not exists and not ignoreMissing:
            raise self.NoCoeffs(name=name, divisor=divisor)


    def clearCoefficientGroups (self, save=True):
        for section in self.allCoeffSections():
            self.getConfig().remove_section(section, save=False)

        if save:
            self.getConfig.save()


    def getCoefficientGroups (self, divisor=0):
        section = self.coeffSection(divisor)
        return self.getConfig().options(section)


    def coeffSection (self, divisor=None):
        section = self.WLCoeffSection
        if divisor:
            section += ":"+str(divisor)
        return section


    def bestCoeffSection (self, binning):
        best, section = 0, None
        for divisor, name in self.allCoeffSections():
            if best <= divisor <= binning:
                best, section = divisor, name

        return best, section


    def allCoeffSections (self):
        sections = [ (0, self.WLCoeffSection) ]
        preamble = self.WLCoeffSection.lower() + ":"

        for section in self.getConfig().sections():
            if section.lower().startswith(preamble):
                try:
                    name, divisor = section.split(":", 1)
                    divisor = int(divisor)
                except ValueError:
                    pass
                else:
                    sections.append((divisor, section))

        return sorted(sections)


    def getWavelengths (self, coeffs, pixels, divisor):
        width, height = self.device.GetChipSize()
        if width:
            pixels = [ int(p%width) for p in pixels ]

        if divisor:
            pixels = [ int(p/divisor) for p in pixels ]

        return [ sum([ c*(pixel**i) for (i, c) in enumerate(coeffs or (0,)) ])
                 for pixel in pixels ]


    def getBinCenters (self, channelIndex):
        x1, x2, y1, y2 = self.device.GetDataRegions()[channelIndex]
#        binning        = self.device.GetPixelBinning(channelIndex)
        binning        = self.device.GetPixelBinning()
        size           = self.device.GetDataSize(channelIndex)
        direction      = (1, -1)[x1 > x2]
        start          = x1 + direction*(binning - 1)/2.0
        return [ start + (direction*binning*i) for i in range(size) ]


    def getDataSlices (self, channelIndex, dataBinning, maxBins, wlMin, wlMax, coeffs, divisor):
        binCenters   = self.getBinCenters(channelIndex)
        wavelengths  = self.getWavelengths(coeffs, binCenters, divisor)

        goodBins     = [ bindex
                         for (bindex, wavelength) in enumerate(wavelengths)
                         if not (None != wlMin > wavelength) and not (None != wlMax < wavelength) ]

        dataSlices   = [ slice(goodBins[index],
                               goodBins[min(index+dataBinning, len(goodBins))-1]+1)
                         for index in range(0, len(goodBins), dataBinning) ]

        if maxBins and len(dataSlices) > maxBins:
            dataSlices = dataSlices[:maxBins]

        dataCenters = [ sum(binCenters[s]) / len(binCenters[s])
                        for s in dataSlices ]

        dataWavelengths  = self.getWavelengths(coeffs, dataCenters, divisor)

        return dataSlices, dataCenters, dataWavelengths



    def getAllDataSlices (self, pixelBinning, dataBinning, maxBins, wlMin, wlMax):
        allCoeffs, divisor = self.getCoefficientsByChannel(pixelBinning)
        allSlices          = []
        allCenters         = []
        allWavelengths     = []

        for channelIndex, coeffs in enumerate(allCoeffs):
            slices, centers, wavelengths = self.getDataSlices(channelIndex,
                                                              dataBinning, maxBins, wlMin, wlMax,
                                                              coeffs, divisor)
            allSlices.append(slices)
            allCenters.append(centers)
            allWavelengths.append(wavelengths)

        return allSlices, allCenters, allWavelengths, divisor



    def publishItem (self, topic, timestamp, *args):
        strings = [ ]
        for arg in args:
            if isinstance(arg, tuple):
                strings.append("-%s=%s"%arg)
            elif isinstance(arg, list):
                strings.extend([ "-%s=%s"%item for item in arg])
            elif isinstance(arg, dict):
                strings.extend([ "-%s=%s"%item for item in arg.items() ])
            else:
                strings.append(str(arg))

        message = " ".join(strings)
        publish(topic, message)

    def formatData (self, data, allslices, frameIndex,
                    minCorrectionRatio, minCorrectionThreshold):
        result       = []
        minRatio     = minCorrectionRatio or 0
        minThreshold = minCorrectionThreshold or 0


        for channelIndex, channelData in enumerate(zip(data, allslices)):
            values, slices = channelData
            items = []
            correctionAllowed = bool(minCorrectionRatio) or bool(minCorrectionThreshold)

            for span in slices:
                try:
                    if correctionAllowed:
                        vs = []
                        for i in range(span.start, span.stop):
                            v        = values[i]
                            inner    = values[i-1:i+2:2]
                            outer    = values[i-2:i+3:4]
                            expected = (4*sum(inner) - sum(outer)) // 6
                            delta    = v - expected

                            if (v > delta > minThreshold) and (delta > minRatio*expected) and (max(inner) < 0xFFFF):
                                self.debug("Corrected: -frame=%d -channel=%d -index=%d -original=%d -corrected=%d -neighborhood=%s"%
                                           (frameIndex+1, channelIndex+1, i+1, v, expected, ",".join([str(p) for p in values[i-2:i+3]])))
                                v = expected
                                correctionAllowed = False

                            vs.append(v)
                    else:
                        vs = values[span]


                    if max(vs) >= 0xFFFF:
                        items.append(max(vs))
                    else:
                        items.append(sum(vs) // len(vs))

                except IndexError:
                    items.append(0)

            result.append(",".join(map(str, items)))

        return result



    def getValue (self, value, parameter, default, valuetype=None):
        if value is not None:
            return value
        else:
            return self.getConfigValue(parameter, default, valuetype=valuetype)


    def startAcquisition (self, count,
                          duration=None,
                          binning=8,
                          exposureTime=None,
                          trigger=None,
                          signal=None,
                          speed=None,
                          gain=None,
                          openShutter=None,
                          alignmentShift=None,
                          mode=0,
                          chunk=None):

        regions = self.getConfiguredRegions()
        #self.checkChannelRegions(regions)

        shutter  = self.getValue(openShutter, self.OpenShutter, None, valuetype=bool)
        if shutter is None:
            shutter = (outputSignal != 0)

        binning         = self.getValue(binning, self.Binning, 1, valuetype=int)
        trigger         = self.getValue(trigger, self.Trigger, 0, valuetype=int)
        signal          = self.getValue(signal, self.Signal, 0, valuetype=int)
        exposure        = self.getValue(exposureTime, self.ExposureTime, 10, valuetype=int)
        speed           = self.getValue(speed, self.Speed, 0, valuetype=int)
        gain            = self.getValue(gain, self.Gain, 0, valuetype=int)
        alignmentShift  = self.getValue(alignmentShift, self.AlignmentShift, 0, valuetype=int)

        self.debug("%s.SetupForAcquisition(mode=%s, openShutter=%s, exposureTime=%s, "
	           "trigger=%s, signal=%s, speed=%s, gain=%s, binning=%s, alignmentShift=%s, %s regions)" %
                   (self.device.__class__.__name__, mode, shutter, exposure,
                    trigger, signal, speed, gain, binning, alignmentShift, len(regions)))

        try:
            self.device.SetupForAcquisition(mode=mode, binning=binning,
                                       openShutter=shutter, exposureTime=exposure,
                                       trigger=trigger, signal=signal,
                                       speed=speed, gain=gain,
                                       regions=regions,
                                       alignmentShift=alignmentShift)
        except ValueError, e:
            raise self.SpectrometerFailure(message=str(e) or e.__class__.__name__.join("[]"))


        if duration and not count:
            count = self.frameCount(duration)

        if not chunk:
            if count:
                chunk = self.getConfigValue(self.Chunk, 50000, valuetype=int)
            else:
                chunk = 1

        self.debug("Starting data acquisition, %s frames in %s frame chunks, trigger=%s (%s), signal=%s (%s)"%
                   (count or "unlimited", chunk,
                    trigger, self.TRIGGER_MODES[trigger],
                    signal, self.SIGNAL_MODES[signal]))

        self.device.StartAcquisition(count=count, chunk=chunk)
        return count


    def frameCount (self, duration, exposure=None):
        if exposure == None:
            exposure = self.device.GetExposureTime()

        readoutTime = self.device.GetReadoutTime()
        count = int(duration / ((exposure/1e3) + (readoutTime/1e6)))
        return count


    def resetDevice (self, resetOptions=None):
        if resetOptions is not None:
            self.device.ResetDevice(resetOptions)
        else:
            self.device.ResetDevice()


    def stopAcquisition (self, abort=False, synchronous=False):
        if abort:
            self.device.AbortAcquisition()
        else:
            self.device.StopAcquisition()

        if self.collecting:
            self.collecting.cancel()


    def saveHeader (self, outputFile, count, exposure, speed, gain, description):
        self.debug("Saving spectrometer data to file %s"%(outputFile.name))

        ltime              = time.localtime()
        channels           = self.getChannelNames()
        binning            = self.device.GetPixelBinning()
        allcoeffs, divisor = self.getCoefficientsByChannel(binning)
        regions            = self.getDeviceRegions()

        speed              = self.getValue(speed, self.Speed, 0, valuetype=int)
        gain               = self.getValue(gain, self.Gain, 0, valuetype=int)
        speeds                = dict(self.device.GetSpeeds())
        gains                 = dict(self.device.GetGains())
        chipWidth, chipHeight = self.device.GetChipSize()
        chipCount             = self.device.GetNumChipsInUse()


        data = [ ("File Version", 1013),
                 ("Camera Info",
                  self.device.SerialNumber, self.device.DeviceType,
                  "Product ID %s"%self.device.ProductID,
                  "Firmware Version %s"%self.device.FirmwareVersion),
                 ("Capture Date", time.strftime("%Y-%m-%d", ltime)),
                 ("Capture Time", time.strftime("%H:%M:%S", ltime)),
                 ("Description", description),
                 ("Exposure(MS)", exposure),
                 ("Gain", gains.get(gain, "Unknown gain %d"%(gain,))),
                 ("Speed", speeds.get(speed, "Unknown speed %d"%(speed,))),
                 ("Chip Dimensions", "width/height/count", chipWidth, chipHeight, chipCount),
                 ("Binning", binning),
                 ("Number of Spectra", count),
                 ("Number of Regions per Spectrum", len(channels)) ]


        data.append(["Number of Points per Region", ""] +
                    [self.device.GetDataSize(c) for c in range(len(channels))])

        for index, channel in enumerate(channels):
            data.append(("Channel Region %d"%(index+1,), channel) + regions[index])

        maxlen = max([len(coeffs) for coeffs in allcoeffs])
        data.append(["Number of Polynomial Coefficients Per Channel", maxlen])

        coefflegend = "%dx"%(max(1, divisor))
        for index, coeffs in enumerate(allcoeffs):
            data.append(("Channel %d Polynomial Coefficients"%(index+1,), coefflegend) +
                        coeffs)

        regiondata = ["Region Number", ""]
        centerdata = ["Center Pixel", ""]
        wldata     = ["Wavelengths", "nm"]
        darkdata   = ["Dark Current", "Subtracted from Data"]


        for index, channel in enumerate(channels):
            centers = self.getBinCenters(index)
            wls     = self.getWavelengths(allcoeffs[index], centers, divisor)

            regiondata.extend([str(index+1)] * len(centers))
            centerdata.extend(centers)
            wldata.extend(wls)
            if len(self.darksignal) == len(centers):
                darkdata.extend(self.darksignal)
            else:
                darkdata.extend([0] * len(centers))

        for r, c, w, d in self.customColumns:
            regiondata.append(r)
            centerdata.append(c)
            wldata.append(w)
            darkdata.append(d)

        data.append(regiondata)
        data.append(centerdata)
        data.append(wldata)
        data.append(darkdata)

        for item in data:
            outputFile.write(','.join(map(str, item)) + '\n')


    def clearDataColumns (self):
        del self.customColumns[:]

    def addDataColumns (self, regionHeader="-", centerHeader="-", wlHeader="-", darkDataHeader="-"):
        self.customColumns.append((regionHeader, centerHeader, wlHeader, darkDataHeader))


    def publishHeader (self, topic, allSlices, allCenters, allWavelengths):
        binning      = self.device.GetPixelBinning()
        regions      = self.device.GetDataRegions()
        channels     = self.getChannelNames()
        allcoeffs, divisor = self.getCoefficientsByChannel(binning)

        pixelCounts  = [ [ binning * (s.stop - s.start) for s in slices ]
                         for slices in allSlices ]

        self.publishItem(topic, None, 'CameraInfo',
                         ("SerialNumber", '"%s"'%(self.device.SerialNumber,)),
                         ("DeviceType", '"%s"'%(self.device.DeviceType,)),
                         ("ProductID", self.device.ProductID))

        self.publishItem(topic, None, 'ChannelRegion',
                         [(channel, ",".join([str(n) for n in region]))
                          for channel, region in zip(channels, regions) ])

        self.publishItem(topic, None, 'Coefficients',
                         [(channel, ",".join([str(c) for c in coeffs]))
                          for (channel, coeffs) in zip(channels, allcoeffs) ])

        self.publishItem(topic, None, 'PixelsPerBin',
                         [(channel, ",".join(map(str, widths)))
                          for (channel, widths) in zip(channels, pixelCounts)])

        self.publishItem(topic, None, 'CenterPixels',
                         [(channel, ",".join(map(str, centers)))
                          for (channel, centers) in zip(channels, allCenters)])

        self.publishItem(topic, None, 'Wavelengths',
                         [(channel, ",".join(map(str, wls)))
                          for (channel, wls) in zip(channels, allWavelengths)])



    def collectData (self, firstFrame, startOffset, count,
                     exposure, speed, gain, dark, minCorrectionRatio, minCorrectionThreshold,
                     pixelBinning, dataBinning, maxDataBins, wlMin, wlMax,
                     loc, outputFile, topic, description):

        channels  = self.getChannelNames()

        pixelBinning = self.getValue(pixelBinning, self.Binning, 1, valuetype=int)
        dataBinning  = self.getValue(dataBinning, self.DataBinning, 1, valuetype=int)
        maxDataBins  = self.getValue(maxDataBins, self.MaxDataBins, 0, valuetype=int)
        wlMin        = self.getValue(wlMin, self.MinDataWavelength, None, valuetype=float)
        wlMax        = self.getValue(wlMax, self.MaxDataWavelength, None, valuetype=float)
        minCorrectionRatio = self.getValue(minCorrectionRatio, self.MinCorrectionRatio, 0.1, valuetype=float)
        minCorrectionThreshold = self.getValue(minCorrectionThreshold, self.MinCorrectionThreshold, 2000, valuetype=int)

        slices, centers, wavelengths, divisor \
            = self.getAllDataSlices(pixelBinning, dataBinning, maxDataBins, wlMin, wlMax)

        if self.collecting:
            collecting = None
        else:
            self.collecting = collecting = Event()
            collecting.set()


        index  = firstFrame or 0
        self.frameDelay      = self.getFrameDelay() / 1000.0
        self.frameDue        = time.time()

        try:
            if topic:
                self.publishHeader(topic, slices, centers, wavelengths)

            if outputFile:
                self.saveHeader(outputFile, count, exposure, speed, gain, description)

            try:
                self.framedata = []
#                while (index < count or not count) and self.waitForData(index):
                while self.waitForData(index):
                    timestamp, data = self.getData(index)
                    self.device.SetCollectedCount(index+1)

                    if outputFile:
                        fields = ["Spectrum %d"%(index+startOffset), "%.3f"%(timestamp*1000,)]

                        for values in data:
                            fields.extend(map(str, values))

                        fields.extend([ str(value) for (key, value) in self.framedata ])

                        outputFile.write(",".join(fields)+"\n")


                    if topic:
                        channelData = self.formatData(data, slices, index, minCorrectionRatio, minCorrectionThreshold)
                        self.publishItem(topic, timestamp, "Signal",
                                         ("Index", index+startOffset),
                                         ("Timestamp", "%.3f"%(timestamp,)),
                                         zip(channels, channelData),
                                         self.framedata)


                    if collecting and not collecting.isSet():
                        self.info("Suspending spectrometer data publication")
                        if outputFile:
                            self.closeFile(loc)
                            outputFile = None

                        resume = collecting.wait()
                        if resume:
                            self.info("Resuming spectrometer data publication")
                            if loc:
                                outputFile = self.openFile(loc, OP_APPEND)
                        else:
                            self.info("Canceling spectrometer data publication after suspend")

                    if self.frameDelay:
                        naptime = max(0, self.frameDue - time.time())
                        if naptime > 0:
                            time.sleep(naptime)
                        self.frameDue += self.frameDelay

                    threading.currentThread().check()

                    del self.framedata[:]

                    index += 1


                return index

            except RuntimeError, e:
                raise self.SpectrometerFailure(message=str(e) or e.__class__.__name__.join("[]"))

        finally:
            self.device.ClearData()
            self.publishItem(topic, None, "End", ("Count", index))
            if collecting:
                collecting.clear()
                self.collecting = None


    def lockFile (self, path):
        try:
            lock = self.fileLocks[path]
        except KeyError:
            lock = self.fileLocks[path] = Lock()

        lock.acquire()


    def unlockFile (self, path):
        try:
            lock = self.fileLocks[path]
        except KeyError:
            pass
        else:
            # Ideally we should remove this lock from self.fileLocks;
            # however that would lead to a race condition if one other
            # thread is waiting, wherein future lockFile() invoations
            # would not be acquiring the same lock.
            # So we keep it, nonwithstanding a small memory leak.
            lock.release()


    _fileops = {
        None      : "rb",
        OP_READ   : "rb",
        OP_WRITE  : "wb",
        OP_APPEND : "ab" }


    def openFile (self, loc, mode=OP_READ):
        path = loc.vfspath()
        self.lockFile(path)

        try:
            loc.__enter__()
            fp = loc.open(mode)

            if loc.path.endswith('.gz'):
                fp = GzipFile(path, self._fileops[mode], 9, fp)
                loc.openFiles.append(fp)

            return fp

        except Exception, e:
            self.closeFile(loc)
            raise


    def closeFile (self, loc):
        try:
            loc.__exit__()
        finally:
            self.unlockFile(loc.vfspath())


    def holdCollection (self):
        if self.collecting:
            self.collecting.clear()


    def continueCollection (self):
        if self.collecting:
            self.collecting.set()


    def setFrameDelay (self, delay):
        self.setConfigValue(self.FrameDelay, delay)
        self.frameDelay = delay / 1000.0

    def clearFrameDelay (self):
        self.delConfigValue(self.FrameDelay)
        self.frameDelay = None

    def getFrameDelay (self):
        return self.getConfigValue(self.FrameDelay, 0)

    def getData (self, index):
        return self.device.GetData(index)

    def waitForData (self, index):
        return self.device.WaitForData(index)

    class COUNT_Query (Observing, Leaf):
        '''Return the number of spectrometers'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self, rescan=False):
            return len(self.parent.listDevices(rescan))

    class SERial_Enumerate (Observing, Leaf):
        '''List serial numbers of each spectrometer that is attached'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('serial', type=str, repeats=(0, None))

        def run (self, rescan=False):
            serials = [ serial
                        for (productID, serial, deviceType) in self.parent.listDevices(rescan) ]
            return tuple(serials)


    class CONNect (Controlling, Leaf):
        '''Connect to the specified spectrometer'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('serial', type=str, default=None,
                          description="Serial string; if not given, "
                          "connect to the first available spectrometer")

            self.setInput('product', type=int, default=None,
                          description="Product ID; if given, connect only"
                          "to spectrometers with a maching ID.")

            self.setInput('rescan', type=bool, default=False,
                          description="Enumerate available spectrometers "
                          "again even if they have already beeen enumerated")

        def run (self, serial=str, product=int, rescan=bool):
            self.parent.connectDevice(rescan, serial, product)



    class RESet (Controlling, Leaf):
        '''
        Stop data acquisition.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('resetOptions', type=int, range=(0, 0xFFFF), default=None)

        def run (self, resetOptions=None):
            self.parent.resetDevice(resetOptions)



    class PROPerties_Query (Observing, Leaf):
        '''Return information about the specified spectrometer'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('productid',  type=int, named=True)
            self.addOutput('serial',     type=str, named=True)
            self.addOutput('devicetype', type=str, named=True)
            self.addOutput('libraryVersion',  type=str, named=True)
            self.addOutput('firmwareVersion', type=float, named=True)

        def run (self):
            device = self.parent.device
            return (device.ProductID, device.GetSerialNumber(), device.DeviceType,
                    device.LibraryVersion, device.FirmwareVersion)


    class SERial_Query (Observing, Leaf):
        '''Return information about the specified spectrometer'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('serial', type=int)

        def run (self):
            return self.parent.device.GetSerialNumber()



    class VERSion_Query (Observing, Leaf):
        '''Return firmware version of connected spectrometer'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('firmwareVersion', type=float)

        def run (self):
            return self.parent.device.FirmwareVersion



    class CHANnel_Add (Controlling, Leaf):
        '''
        Add a new data channel to acquire data from the specified CCD region.
        '''

        def run (self, replaceExisting=False, name=str, region=str):
            self.parent.addChannel(name, region, replaceExisting)



    class CHANnel_Remove (Administrative, Leaf):
        '''
        Remove an existing data channel.
        '''

        def run (self, ignoreMissing=False, name=str):
            self.parent.removeChannel(name, ignoreMissing)


    class CHANnel_Query (Observing, Leaf):
        '''
        Return the region associated with the specified channel.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('region', type=str, default=None)


        def run (self, ignoreMissing=False, name=str):
            return self.parent.getRegionName(name, ignoreMissing)



    class CHANnel_Enumerate (Observing, Leaf):
        '''
        Enumerate existing collection channels
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))


        def run (self):
            return self.parent.getChannelNames(allowEmpty=True)



    class REGion_Add (Administrative, Leaf):
        '''
        Define a CCD region for the specified collection channel.

        If the starting pixel column (x1) is greater than the ending
        column (x2), data values for this channel will be reported in
        reverse order (right-to-left).

        Multiple channel region must not overlap.  Also, while they
        may be be fully vertically aligned (side by side), they may
        not be partially aligned.  This restriction does not apply to
        horizontal alignment (regions may be stacked partically on
        top of each other).
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('name', type=str, description='Region name')
            self.setInput('x1', type=int, description='Starting pixel column on CCD')
            self.setInput('x2', type=int, description='Ending pixel column on CCD')
            self.setInput('y1', type=int, description='Starting pixel row on CCD')
            self.setInput('y2', type=int, description='Ending pixel column on CCD')
            self.setInput('waveLengthConversion', type=str,
                          description='Wavelength Coefficient set to use for this region')


        def run (self, replaceExisting=False, name=str,
                 x1=int, x2=int, y1=int, y2=int, waveLengthConversion=str):

            self.parent.setRegion(name, x1, x2, y1, y2, waveLengthConversion, replaceExisting)



    class REGion_Remove (Controlling, Leaf):
        '''
        Rmove the specified CCD region.  Subsequently, it will not be possible
        to collect data in any channels that are mapped to this region.
        '''

        def run (self, ignoreMissing=False, name=str):
            self.parent.delRegion(name, ignoreMissing)



    class REGion_Query (Observing, Leaf):
        '''
        Return the CCD region associated with the specified collection channel.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('x1', type=int, named=True, default=None)
            self.addOutput('x2', type=int, named=True, default=None)
            self.addOutput('y1', type=int, named=True, default=None)
            self.addOutput('y2', type=int, named=True, default=None)
            self.addOutput('waveLengthConversion', type=str, named=True, default=None)

        def run (self, ignoreMissing=False, name=str):
            return self.parent.getConfiguredRegion(name, ignoreMissing)


    class REGion_Enumerate (Observing, Leaf):
        '''
        Return the CCD region associated with the specified collection channel.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))


        def run (self):
            return tuple(self.parent.getRegionNames())



    class WaveLengthCoefficients_Add (Administrative, Leaf):
        '''
        Define a set of polyomial coefficients for translating horizontal
        pixel coordinates to wavelengths.  This set can later be mapped
        to specific channel regions with the "REGion=" command.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('name', type=str, description='Coefficient set name')
            self.setInput('divisor', type=int, named=True, default=1,
                          description='Divide pixel numbers by this before feeding in to '
                          'polynomial calculation.')
            self.setInput('coeffs', type=float, repeats=(1, 10),
                          description='Polynomial coefficients in increasing order, '
                          'starting with the coefficient for the fixed (order zero) term')


        def run (self, replaceExisting=False, name=str, divisor=0, *coeffs):
            self.parent.addCoefficientGroup(name, divisor, coeffs, replaceExisting)



    class WaveLengthCoefficients_Remove (Administrative, Leaf):
        '''
        Remove a set of polynomial wavelength coefficients used to
        translate pixel coordinates to wavelengths.
        '''

        def run (self, ignoreMissing=False, divisor=0, name=str):
            self.parent.delCoefficientGroup(name, divisor=divisor, ignoreMissing=ignoreMissing)



    class WaveLengthCoefficients_Query (Observing, Leaf):
        '''
        Return the specified polynomial wavelength coefficients set.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('coeffs', type=float, repeats=(0, None))


        def run (self, ignoreMissing=False, divisor=0, name=str):
            return self.parent.getCoefficientGroup(name, divisor=divisor, ignoreMissing=ignoreMissing)


    class WaveLengthCoefficients_Enumerate (Observing, Leaf):
        '''
        Return the specified polynomial wavelength coefficients set.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('group', type=str, repeats=(0, None))


        def run (self, divisor=0):
            return tuple(self.parent.getCoefficientGroups(divisor))



    class EXPosure_Set (Controlling, Leaf):
        '''
        Set default exposure time for subsequent data captures,
        used when not specified in the "ACQuire" command.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('exposure', type=int, range=(1, None), units='milliseconds')

        def run (self, exposure=int):
            self.parent.setConfigValue(self.parent.ExposureTime, exposure)



    class EXPosure_Query (Observing, Leaf):
        '''
        Return default exposure time,
        used when not specified in the "ACQuire" command.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('exposure', type=int, default=None, units='milliseconds')

        def run (self):
            return self.parent.getConfigValue(self.parent.ExposureTime, default=None, valuetype=int)


    class TRIGGer_Set (Controlling, Leaf):
        '''
        Set default input & output trigger behavior,
        used when not specified in the "ACQuire" command.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('inputTrigger', type=self.parent.TRIGGER_MODES)
            self.setInput('outputSignal', type=self.parent.SIGNAL_MODES)

        def run (self, inputTrigger, outputSignal):
            self.parent.setConfigValue(self.parent.Trigger, inputTrigger)
            self.parent.setConfigValue(self.parent.Signal, outputSignal)


    class TRIGGer_Query (Observing, Leaf):
        '''
        Return default input & output trigger behavior,
        used when not specified in the "ACQuire" command.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('inputTrigger', type=self.parent.TRIGGER_MODES, named=True, default=0)
            self.addOutput('outputSignal', type=self.parent.SIGNAL_MODES, named=True, default=0)

        def run (self):
            return (self.parent.getConfigValue(self.parent.Trigger, None, valuetype=int),
                    self.parent.getConfigValue(self.parent.Signal, None, valuetype=int))


    class SPEED_Enumerate (Observing, Leaf):
        '''
        Return available CCD speeds.
        '''
        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('speed', type=tuple, repeats=(0, None))

        def run (self):
            device = self.parent.device
            speeds = [ (str(token), name)
                       for (token, name) in device.GetSpeeds() ]
            return tuple(speeds)


    class SPEED_Set (Controlling, Leaf):
        '''
        Set default CCD speed,
        used when not specified in the "ACQuire" command.
        '''

        class NoSuchSpeed (RunError):
            "Spectrometer %(device)r does not support speed #%(speed)d"

        def run (self, speed=int):
            speeds = dict(self.parent.device.GetSpeeds())
            if not speed in speeds:
                raise self.NoSuchSpeed(device=self.parent.device.DeviceType,
                                       speed=speed)

            self.parent.setConfigValue(self.parent.Speed, speed)



    class SPEED_Query (Observing, Leaf):
        '''
        Return the default CCD speed,
        used when not specified in the "ACQuire" command.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('token', type=int)
            self.addOutput('description', type=str)

        def run (self):
            speeds = dict(self.parent.device.GetSpeeds())
            speed = self.parent.getConfigValue(self.parent.Speed, 0, valuetype=int)
            return (speed, speeds.get(speed, 'Unknown'))


    class GAIN_Enumerate (Observing, Leaf):
        '''
        Return available CCD gains.
        '''
        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('gain', type=tuple, repeats=(0, None))

        def run (self):
            device = self.parent.device
            gains  = [ (str(token), name)
                       for (token, name) in device.GetGains() ]
            return tuple(gains)


    class GAIN_Set (Controlling, Leaf):
        '''
        Set default CCD gain,
        used when not specified in the "ACQuire" command.
        '''

        class NoSuchGain (RunError):
            "Spectrometer %(device)r does not support gain #%(gain)d"


        def run (self, gain=int):
            gains = dict(self.parent.device.GetGains())
            if not gain in gains:
                raise self.NoSuchGain(device=self.parent.device.DeviceType, gain=gain)

            self.parent.setConfigValue(self.parent.Gain, gain)


    class GAIN_Query (Observing, Leaf):
        '''
        Return the default CCD gain,
        used when not specified in the "ACQuire" command.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('token', type=int)
            self.addOutput('description', type=str)

        def run (self):
            gains = dict(self.parent.device.GetGains())
            gain = self.parent.getConfigValue(self.parent.Gain, 0, valuetype=int)
            return (gain, gains.get(gain, 'Unknown'))



    class BINNing_Set (Controlling, Leaf):
        '''
        Configure data binning (a.k.a. software binning) values, to be used when
        not specified in the "START" command.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('analogBinning', type=int, range=(1, None), units='pixels', default=None,
                          description='Pixels per hardware (aka. analog) bin.  Higher values '
                          'means fewer spectral bins, but more signal in each bin.  This '
                          'increases the signal-to-noise ratio, but also the propensity to '
                          'oversaturate the detector.')

            self.setInput('dataBinning', type=int, range=(1, None), default=None,
                          description='Number of analog bins (a.k.a. "software bins") per spectral '
                          'value in the published data. Note that this does NOT affect data saved '
                          'to CSV output file.')

            self.setInput('maxDataBins', type=int, named=True, range=(0, None), default=None,
                          description='Limit the number of values in the published data to this '
                          'number. If the number of available spectral values exceeds this, '
                          'remaining values are truncated.')

            self.setInput('minDataWavelength', type=float, named=True, default=None,
                          description='Minimum wavelength of bins included in published data.')

            self.setInput('maxDataWavelength', type=float, named=True, default=None,
                          description='Maximum wavelength of bins included in published data.')



        def run (self, analogBinning=None, dataBinning=None, maxDataBins=None,
                 minDataWavelength=None, maxDataWavelength=None):

            changed = False

            if analogBinning is not None:
                self.parent.setConfigValue(self.parent.Binning, analogBinning, save=False)
                changed = True

            if dataBinning is not None:
                self.parent.setConfigValue(self.parent.DataBinning, dataBinning, save=False)
                changed = True

            if maxDataBins is not None:
                self.parent.setConfigValue(self.parent.MaxDataBins, maxDataBins, save=False)
                changed = True

            if minDataWavelength is not None:
                self.parent.setConfigValue(self.parent.MinDataWavelength, minDataWavelength, save=False)
                changed = True

            if maxDataWavelength is not None:
                self.parent.setConfigValue(self.parent.MaxDataWavelength, maxDataWavelength, save=False)
                changed = True

            if changed:
                self.parent.saveConfigValues()


    class BINNing_Clear (Controlling, Leaf):
        '''
        Clear data binning (a.k.a. software binning) settings.  Subsequently, no data binning
        is performed by default, unless specifed in the "START" command.
        '''

        def run (self):
            self.parent.delConfigValue(self.parent.Binning, save=False)
            self.parent.delConfigValue(self.parent.DataBinning, save=False)
            self.parent.delConfigValue(self.parent.MaxDataBins, save=False)
            self.parent.delConfigValue(self.parent.MinDataWavelength, save=False)
            self.parent.delConfigValue(self.parent.MaxDataWavelength, save=False)
            self.parent.saveConfigValues()



    class BINNing_Query (Observing, Leaf):
        '''
        Return default number of spectral bands (a.k.a. software bins)
        to be collected, used when not specified in the "ACQuire"
        command.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('analogBinning', type=int, named=True, units='pixels', default="-",
                          description='Pixels per hardware (aka. analog) bin.  Higher values '
                          'means fewer spectral bins, but more signal in each bin.  This '
                          'increases the signal-to-noise ratio, but also the propensity to '
                          'oversaturate the detector.')

            self.addOutput('dataBinning', type=int, named=True, default="-",
                          description='Number of analog bins (a.k.a. "software bins") per spectral '
                          'value in the published data. Note that this does NOT affect data saved '
                          'to CSV output file.')

            self.addOutput('maxDataBins', type=int, named=True, default="-",
                          description='Limit the number of values in the published data to this '
                          'number. If the number of available spectral values exceeds this, '
                          'remaining values are truncated.')

            self.addOutput('minDataWavelength', type=float, named=True, default="-",
                          description='Minimum wavelength of bins included in published data.')

            self.addOutput('maxDataWavelength', type=float, named=True, default="-",
                          description='Maximum wavelength of bins included in published data.')

        def run (self):
            return (self.parent.getConfigValue(self.parent.Binning, valuetype=int),
                    self.parent.getConfigValue(self.parent.DataBinning, valuetype=int),
                    self.parent.getConfigValue(self.parent.MaxDataBins, valuetype=int),
                    self.parent.getConfigValue(self.parent.MinDataWavelength, valuetype=float),
                    self.parent.getConfigValue(self.parent.MaxDataWavelength, valuetype=float))


    class FrameDelay_Set (Controlling, Leaf):
        '''
        If set, timestamps for each data frame from the CSV input file are ignored,
        and data frames are instead published at the specified interval.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('delay', units='milliseconds')

        def run (self, delay=int):
            self.parent.setFrameDelay(delay)



    class FrameDelay_Clear (Controlling, Leaf):
        '''
        Revert to publish data according to timestamps specified in
        the CSV input file.
        '''

        def run (self):
            self.parent.clearFrameDelay()


    class FrameDelay_Query (Observing, Leaf):
        '''
        Return current frameDelay setting, if any.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('delay', type=int, units='milliseconds', default=None)

        def run (self):
            return self.parent.getFrameDelay()


    class FrameCount_Query (Observing, Leaf):
        '''
        Return the number of frames to be collected, given the specified
        total duration & exposure time.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('duration', type=int, units="seconds",
                          description="Duration for which to acquire")
            self.setInput('exposure', type=int, default=None, units="milliseconds",
                          description="Exposure time.  "
                          "If not specified, use exposure time previously set with the \"EXPosure=\" command.")

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self, duration, exposure=None):
            return self.parent.frameCount(duration, exposure)



    class START (Controlling, Singleton, Background, FilesystemLeaf):
        '''
        Start data acquisition.

        Data is grouped into spectral bands as specified with the "-bands" option,
        then published published in real time on the specified message topic.
        The following information is published at the start of the acquisition:

          ChannelRegion -<channelName>=<x1>,<x2>,<y1>,<y2> ...
          Coefficients -<channelName>=<fixed>,<linear>,<quadratic>,<cubic>... ...
          PixelsPerBand -<channelName>=<band0width>,<band1width>,... ...
          CenterPixels -<channelName>=<band0center>,<band1center>,... ...
          Wavelengths -<channelName>=<band0wl>,<band1wl>,... ...
          Signal -index=1 -timestamp=<sec.ms> -<channelName>=<band0average>,<band1average>,... ...
          Signal -index=2 -timestamp=<sec.ms> -<channelName>=<band0average>,<band1average>,... ...
          ...

        Optionally, data is also saved to a file, in a CSV format suitable
        for subsequent use in simulation and/or offline analysis applications.
        Note that this data is not grouped into spectral bands, but includes
        individual data columns for all analog bins.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('count', type=int, default=0,
                          description='The number of frames to acquire. '
                          'If not specified (or if 0), acquire continuously for the '
                          'specified duration, or until stopped')

            self.setInput('duration', type=float, named=True, default=None, units='seconds',
                          description='The duration for which to acquire data. '
                          'If not specified (or if 0), continue until the specified '
                          'number of frames has been acquired, or until stopped')

            self.setInput('synchronous', type=bool, named=True, default=False,
                          description='Run acquisition in foreground')

            self.setInput('exposure', type=int, named=True, default=None, units='milliseconds',
                          description='Exposure time.')

            self.setInput('speed', type=int, named=True, default=None,
                          description='Speed value for spectrometer.')

            self.setInput('gain', type=int, named=True, default=None,
                          description='Gain value for spectrometer.')

            self.setInput('inputTrigger', type=self.parent.TRIGGER_MODES, named=True, default=None,
                          description='Wait for hardware input trigger for each frame.')

            self.setInput('outputSignal', type=self.parent.SIGNAL_MODES, named=True, default=None,
                          description='Issue output signal after acquiring each frame.')

            self.setInput('openShutter', type=bool, named=True, default=None,
                          description='Manually open shutter during acquisition. '
                          'Required for output signals.')

            self.setInput('dark', type=bool, named=True, default=False,
                          description='Save the last frame as a "dark signal" reference frame, '
                          'be included in subsequenct data publications')

            self.setInput('minCorrectionRatio', type=float, named=True, default=None, range=(0.0, None),
                          description='Correct pixel values that deviate by more than the specified ratio '
                          'from its expected value, based on neighboring pixels. ')

            self.setInput('minCorrectionThreshold', type=int, named=True, default=None, range=(0, None),
                          description='Correct pixel values that deviate more than the specified threshold '
                          'away from its expected value, based on neighboring pixels. ')

            self.setInput('alignmentShift', type=int, named=True, default=None,
                          description='Correction to the offset to the data buffer '
                          'from the spectrometer by this count')

            self.setInput('binning', type=int, named=True, range=(1, None), default=None,
                          description='Pixels per hardware (aka. analog) bin.  Higher values '
                          'means fewer spectral bins, but more signal in each bin.  This '
                          'increases the signal-to-noise ratio, but also the propensity to '
                          'oversaturate the detector.  The default value is set by the '
                          '"BINNing=" command.')

            self.setInput('dataBinning', type=int, named=True, range=(0, None), default=None,
                          description='Number of analog bins per spectral value in the published data '
                          '(a.k.a. "software binning").  The default value is set with the "DATA=" '
                          'command. Note that this does NOT affect data saved to CSV output file.')

            self.setInput('maxDataBins', type=int, named=True, range=(0, None), default=None,
                          description='Limit the number of values in the published data to this '
                          'number. If the number of available spectral values exceeds this, '
                          'remaining values are truncated.')

            self.setInput('minDataWavelength', type=float, named=True, default=None,
                          description='Minimum wavelength of bins included in published data.')

            self.setInput('maxDataWavelength', type=float, named=True, default=None,
                          description='Maximum wavelength of bins included in published data.')


            self.setInput('topic', type=str, named=True, default=self.parent.DEFAULT_TOPIC,
                           description='Message topic used for real-time data publication.')

            self.setInput('outputFile', type=str, named=True, default=None,
                          description='Save acquired data to the specified CSV file. '
                          'Unlike data published in real time, the saved data is NOT '
                          'grouped into spectral bands (a.k.a. software bins). '
                          'If the filename ends with ".gz", the file is implicitly '
                          'compressed in GZIP format.')

            self.setInput('description', type=str, named=True, default=None,
                          description='General-purpose description of this acquisition, '
                          'to be included in the output file')


        def run (self, _session, _context,
                 count=int, duration=float, synchronous=False,
                 startIndex=1, exposure=int, speed=int, gain=int,
                 inputTrigger=0, outputSignal=0, openShutter=None, dark=False,
                 minCorrectionRatio=None, minCorrectionThreshold=None,
                 binning=None, dataBinning=None, maxDataBins=None,
                 minDataWavelength=None, maxDataWavelength=None,
                 topic=str, outputFile=None, description=None):

            return self.start(**locals())


        def start (self, _session, _context,
                   count=int, duration=float, startIndex=1,
                   exposure=int, speed=int, gain=int,
                   inputTrigger=0, outputSignal=0, openShutter=None, dark=False,
                   minCorrectionRatio=None, minCorrectionThreshold=None,
                   alignmentShift=None, binning=None, dataBinning=None, maxDataBins=None,
                   minDataWavelength=None, maxDataWavelength=None,
                   topic=str, outputFile=None, description=None):


            if outputFile:
                loc = self.openLocation(outputFile, _session, P_WRITE)
                fp  = self.parent.openFile(loc, OP_WRITE)
            else:
                loc = None
                fp  = None

            try:
                count = self.parent.startAcquisition(count,
                                                     duration,
                                                     binning=binning,
                                                     alignmentShift=alignmentShift,
                                                     exposureTime=exposure,
                                                     openShutter=openShutter,
                                                     trigger=inputTrigger,
                                                     signal=outputSignal,
                                                     speed=speed,
                                                     gain=gain,
                                                     mode=self.parent.SCAN)
            except Exception, e:
                if loc:
                    self.parent.closeFile(loc)
                raise

            return startIndex, count, exposure, speed, gain, dark, \
                minCorrectionRatio, minCorrectionThreshold, \
                binning, dataBinning, maxDataBins, minDataWavelength, maxDataWavelength, \
                loc, fp, topic, description


        def next (self, startIndex, count, exposure, speed, gain, dark,
                  minCorrectionRatio, minCorrectionThreshold,
                  pixelBinning, dataBinning, maxDataBins, wlMin, wlMax,
                  loc, fp, topic, description):

            try:
                self.parent.collectData(0, startIndex, count,
                                        exposure, speed, gain, dark,
                                        minCorrectionRatio, minCorrectionThreshold,
                                        pixelBinning, dataBinning,
                                        maxDataBins, wlMin, wlMax,
                                        loc, fp, topic, description)

            finally:
                if loc:
                    self.parent.closeFile(loc)

        def estimateTime (self, _session, _context,
                          count=int, duration=float, synchronous=False,
                          startIndex=1, exposure=int, speed=int, gain=int,
                          inputTrigger=0, outputSignal=0, openShutter=None, dark=False,
                          minCorrectionRatio=None, minCorrectionThreshold=None,
                          alignmentShift=None,  binning=None, dataBinning=None, maxDataBins=None,
                          minDataWavelength=None, maxDataWavelength=None,
                          topic=str, outputFile=None, description=None):


            if not duration and count:
                exposure = self.parent.getValue(exposure, self.parent.ExposureTime, 0)
                duration = ((exposure+20) / 1000.0) * count

            self.debug("SYNCHRONOUS=%s, duration=%s"%(synchronous, duration))

            if synchronous:
                self.addTime(_context, synchronous=(duration or 0)+3)
            else:
                self.addTime(_context, synchronous=3, asynchronous=duration or 0)



    class STOP (Controlling, Leaf):
        '''
        Stop data acquisition.
        '''

        def run (self, abort=False, synchronous=False):
            self.parent.stopAcquisition(abort, synchronous)



    class HOLD (Controlling, Leaf):
        '''
        Hold publication of spectrometer data until the "CONTinue" or "STOP" command
        is issued.

        Acquisiton continues in the background as long as there is buffer space to
        hold data, then pauses.
        '''


        def run (self):
            self.parent.holdCollection()


    class CONTinue (Controlling, Leaf):
        '''
        Continue publication of spectrometer data after a "HOLD".   Any data frames
        queued up in the meantime are published back-to-back at this time.
        '''

        def run (self):
            self.parent.continueCollection()



    class ACQuiring_Query (Observing, Leaf):
        '''
        Return True if the spectrometer is currently acquiring, False otherwise.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('acquiring', type=bool)


        def run (self):
            return self.parent.device.Acquiring()



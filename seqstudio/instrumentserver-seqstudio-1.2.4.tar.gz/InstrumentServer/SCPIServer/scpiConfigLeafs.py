########################################################################
### FILE:	scpiConfigBranch.py
### PURPOSE:	Configuration support
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006 Applied Biosystems.  All rights reserved.
########################################################################

from scpiExceptions     import RunError
from scpiLeaf           import Leaf, Controlling, Observing
from scpiConfigBase     import ConfigBase
from scpiFilesystemBase import FilesystemLeaf
from scpiFileContexts   import OP_READ, P_READ
from ConfigParser       import NoSectionError, NoOptionError, DuplicateSectionError
from subscription       import debug, warning


class CONFiguration_Enumerate (Observing, ConfigBase, FilesystemLeaf):
    '''
    List sections in the specified configuration file.
    '''

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('item', type=str, repeats=(0, None))


    def run (self, _session, ignoreMissing=False, reread=False, skipTriggers=False, filename=str, section=""):
        if reread:
            self.clearCache()

        c = self.getConfigInstance(filename, reload=reread, session=_session,
                                   skipTriggers=skipTriggers, mustExist=not ignoreMissing)
        try:
            if section:
                l = list(c.options(section, mustExist=not ignoreMissing))
            else:
                l = list(c.sections())

        except NoSectionError:
            if not ignoreMissing:
                raise self.NoSuchSection(filename=filename, section=section)

        else:
            l.sort()
            return tuple(l)

            


class CONFiguration_Exists (Observing, ConfigBase, FilesystemLeaf):
    '''
    Return True if the specified configuration file, section, and/or option exists,
    or False if not.
    '''

    def declareInputs (self):
        FilesystemLeaf.declareInputs(self)
        self.setInput('section', type=str, default=None)

    def declareOutputs (self):
        FilesystemLeaf.declareOutputs(self)
        self.addOutput('exists', type=bool)

    def run (self, _session, reread=False, filename=str, section=str, *options):
        if reread:
            self.clearCache()

        try:
            c = self.getConfigInstance(filename, mustExist=True, session=_session)
        except EnvironmentError, e:
            exists = False
        else:
            if section and options:
                exists = min([ c.has_option(section, o) for o in options ])
            elif section is not None:
                exists = c.has_section(section)
            else:
                exists = True

        return exists


class CONFiguration_Query (Observing, ConfigBase, FilesystemLeaf):
    '''
    Return the value of the specified configuration option.
    If no option is provided, return ALL only a section is provided
    '''
    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('default', type=str, default=None, named=True)
        self.setInput('option', type=str, repeats=(0, None))

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('value', type=tuple, repeats=(0, None))


    def run (self, _session, _context,
             reread=False, ignoreMissing=False, split=False, named=False, default=None, filename=str, section=str, *option):

        if reread:
            self.clearCache()

        if (default is not None) or ignoreMissing:
            default = (default or '',)
        else:
            default = ()

        c = self.getConfigInstance(filename, mustExist=not ignoreMissing, session=_session)
        self.checkConflictingOptions(named=named, split=split)

        try:
            if option and split:
                value = ' '.join([(c.get(section, opt, *default)) for opt in option])
                text, items = _session.expandArgs(value, context=_context)
                items = [ (opt, val or '') for (opt, val, raw) in items ]

            elif option:
                items = [ (named and opt or None, c.get(section, opt, *default))
                          for opt in option ]

            else:
                items = c.items(section, mustExist=not ignoreMissing)

            return tuple(items)

        except NoSectionError, e:
            if not default:
                raise self.NoSuchSection(filename=filename, section=e.section)

        except NoOptionError, e:
            if not default:
                raise self.NoSuchOption(filename=filename, section=e.section, option=e.option)




class CONFiguration_Add (Controlling, ConfigBase, Leaf):
    '''
    Add the specified configuration section or option.
    If an option is specified, the section must already exist.
    '''

    class SectionExists (RunError):
        'Configuration section [%(section)s] already exists'

    class OptionExists (RunError):
        'Configuration option %(option)r in section [%(section)s] already exists'


    def run (self, _session, replaceExisting=False, reread=False, filename=str, section=str, option=''):
        if reread:
            self.clearCache()

        c = self.getConfigInstance(filename, mustExist=False, session=_session)
        try:
            if option:
                if not replaceExisting and c.has_option(section, option):
                    raise self.OptionExists(section=section, option=option)

                c.set(section, option, '', mustHaveSection=True)
            else:
                if replaceExisting and c.has_section(section):
                    c.remove_section(section)

                c.add_section(section)
                c.save()
            self.configCache.pop(filename, None)
        except NoSectionError:
            raise self.NoSuchSection(filename=filename, section=section)
        except DuplicateSectionError:
            raise self.SectionExists(section=section)

    
class CONFiguration_Remove (Controlling, ConfigBase, FilesystemLeaf):
    '''
    Remove the specified configuration section or option.
    '''

    def run (self, _session, ignoreMissing=False, reread=False, filename=str, section=str, option=''):
        if reread:
            self.clearCache()

        c = self.getConfigInstance(filename, mustExist=not ignoreMissing, session=_session)
        if option:
            if not c.remove_option(section, option) and not ignoreMissing:
                raise self.NoSuchOption(filename=filename, section=section, option=option)

        else:
            if not c.remove_section(section) and not ignoreMissing:
                raise self.NoSuchSection(filename=filename, section=section)

        c.save()
                


class CONFiguration_Set (Controlling, ConfigBase, FilesystemLeaf):
    '''
    Set the specified configuration option to the specified value.
    '''

    class Mismatched (RunError):
        'Missing value for option %(option)s'

    def run (self, _session, createMissing=False, reread=False, filename=str, section=str, *items, **options):
        if len(items) % 1:
            raise self.Mismatched(keys=len(items)/2+1, values=len(items)/2,
                                  option=items[-1])


        options.update(zip(items[::2], items[1::2]))

        self.updateConfigValues(filename, section, options,
                                reload=reread, session=_session,
                                mustExist=not createMissing,
                                mustHaveSection=not createMissing,
                                mustHaveOption=not createMissing,
                                save=True)



class CONFiguration_Load (Controlling, ConfigBase, Leaf):
    '''
    Reload the specified configuration file(s).
    If no files are specified, reload all configuration files.
    '''

    class NotLoaded (RunError):
        'No such configuration file is currently loaded'

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput("filenames", type=str, repeats=(0, None))


    def run (self, ignoreMissing=False, *filenames):
        for name in filenames or self.configCache:
            try:
                self.configCache[name].load()
                debug("Reloaded configuration file %r"%(name,))
            except KeyError, e:
                if not ignoreMissing:
                    raise self.NotLoaded(filename=name)

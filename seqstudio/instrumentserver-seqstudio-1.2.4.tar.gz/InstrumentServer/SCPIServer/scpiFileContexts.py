########################################################################
### FILE:       scpiFileContexts.py
### PURPOSE:    Virtual filesystem context defintions
### AUTHOR:     Tor Slettnes <tor.slettnes@thermofisher.com>
###
### Copyrights (C) 2005-2013 Applied Biosystems.
### Copyrights (C) 2013-2018 ThermoFisher Scientific.
### All rights reserved.
########################################################################

from scpiExceptions import RunError, EnvError, ComponentError
from scpiServer     import getStartupOption
from scpiParameter  import Enum, Bool, Missing
from scpiSession    import AccessLevels, OBSERVER, CONTROLLER, ADMINISTRATOR, FULL, NestedSession
from scpiBase       import Base
from subscription   import trace, debug, info, warning
from commandParser  import parser
from ConfigParser   import RawConfigParser, Error as ConfigParserError
from threading      import RLock
from threadControl  import invocation
from scpiClient     import LEVEL_DEBUG
from stat           import S_IMODE, S_IFDIR, S_ISDIR, S_ISREG, S_ISLNK, S_ISCHR, S_ISBLK, \
    ST_SIZE, ST_DEV, ST_MODE, ST_UID, ST_GID, ST_ATIME, ST_MTIME, ST_CTIME
from statvfs        import F_BLOCKS, F_BSIZE, F_FRSIZE, F_BAVAIL, F_BFREE
from StringIO       import StringIO as StringIOClass
from cStringIO      import StringIO

#from base64         import encodestring, decodestring
#from binascii       import Error as B64DecodeError

import re, os, shutil, stat, statvfs, fnmatch, time, errno, urlparse, base64, binascii, collections, tempfile, process, subprocess

try:
    from pwd import getpwuid, getpwnam
    from grp import getgrgid, getgrnam
except ImportError:
    pwd = None

try:
    import pysmbc as smbc
except ImportError, e:
    smbc = None


class NotSupported (RunError):
    pass

AttributeFile = ".attributes"

FileOps = ("read", "write", "append")
(OP_READ, OP_WRITE, OP_APPEND) = range(len(FileOps))

TimeKeys = (T_ACCESS, T_MODIFICATION, T_CREATION) = ("atime", "mtime", "ctime")

FileTypes = 'folder', 'file', 'link', 'device', 'special', 'any'
(FOLDER, FILE, LINK, DEVICE, SPECIAL, ANY) = range(len(FileTypes))

IncludeSpec = ('hidden', 'dot', 'dollar', 'reserved')
INCL_ALL     = (INCL_HIDDEN, INCL_DOT, INCL_DOLLAR, INCL_RESERVED) = range(len(IncludeSpec))
INCL_DEFAULT = (INCL_HIDDEN, INCL_DOT, INCL_DOLLAR)
INCL_VISIBLE = ()



PermissionScopes    = ('uperm', 'gperm', 'wperm')
SCOPES = (PERM_USER, PERM_GROUP, PERM_WORLD) = range(len(PermissionScopes))

FilePermissions     = ('read', 'write', 'execute', 'set')
PERMISSIONS = (P_READ, P_WRITE, P_EXECUTE, P_SET) = range(len(FilePermissions))

FilePermissionMasks = ({P_READ: 0400, P_WRITE: 0200, P_EXECUTE: 0100, P_SET: 04000},
                       {P_READ: 0040, P_WRITE: 0020, P_EXECUTE: 0010, P_SET: 02000},
                       {P_READ: 0004, P_WRITE: 0002, P_EXECUTE: 0001})



########################################################################
### Utility Functions


def splitLocation (location, defaultContext=None):
    try:
        cxtname, relpath = (location or "").split(':', 1)
    except ValueError:
        cxtname, relpath = defaultContext, location
    return cxtname, relpath





########################################################################
### CONTEXT TYPES

class Context (object):
    class NotSupportedInScheme (NotSupported):
        '''Context %(name)r scheme %(scheme)r does not support %(operation)s operation'''

    class NotSupportedOnPlatform (NotSupported):
        '''Host platform %(platform)s does not support %(operation)s operation'''

    class NoSuchUser (RunError):
        '''No such user exists: %(user)r'''

    class NoSuchGroup (RunError):
        '''No such group exists: %(group)r'''

    class NoSuchMode (RunError):
        '''No such file mode exists: %(mode)r'''

    class NotAFile (RunError):
        '''Location %(location)r is not a file, and '-recursive' was not specified'''

    class NoSuchProperty (RunError, AttributeError):
        'Location context %(context)r scheme %(scheme)r has no %(property)r property'

    class MissingProperty (RunError):
        '''Context %(context)r scheme %(scheme)r requires a %(property)r property'''

    class NoSuchAttribute (RunError):
        'Location %(location)r has no such attribute(s): %(id)s'

    class ContextViolation (RunError):
        'Path %(path)r would be outside %(context)r context root %(root)r'

    class CrossDeviceLink (NotSupported):
        'Links are not supported across storage devices'


    #__slots__  = ('name', 'read', 'write', 'preexec', 'postexec', 'localtime')
    #propkeys   = ( P_READ, P_WRITE, P_PREXEC, P_POSTEXEC, P_LOCALTIME ) \
    #           = ('read', 'write', 'preexec', 'postexec', 'localtime')


    TriggerNames = ("preexec", "postexec")
    (PREEXEC, POSTEXEC) = range(len(TriggerNames))

    scheme     = "generic"
    path       = Missing
    read       = OBSERVER
    write      = CONTROLLER
    execute    = CONTROLLER
    replace    = FULL
    preexec    = None
    postexec   = None
    localtime  = False
    separators = ("/", "\\")
    _pathsep   = re.compile(r"[/\\]")
    _conversions = {
        'read'     : Enum(*AccessLevels),
        'write'    : Enum(*AccessLevels),
        'execute'  : Enum(*AccessLevels),
        'replace'  : Enum(*AccessLevels),
        'localtime': Bool()
    }


    StaticAttributes = ('type', 'size', 'atime', 'mtime', 'ctime', 'btime',
                        'mode', 'uid', 'gid', 'owner', 'group', 'uperm', 'gperm', 'wperm', 'comment')


    def __init__ (self, name, **properties):
        self.name        = name
        self._refcount   = 0
        self._mutex      = RLock()
        self._attrmaps   = {}

        for key, value in properties.items():
            if isinstance(value, str) and key in self._conversions:
                setattr(self, key, self._conversions[key].fromString(value))

            elif hasattr(self, key):
                setattr(self, key, value)

            elif value:
                raise self.NoSuchProperty(context=name, scheme=self.scheme, property=key)

        for key in dir(self):
            if getattr(self, key) is Missing:
                raise self.MissingProperty(context=name, scheme=self.scheme, property=key)

#    def __getattr__ (self, attribute):
#        try:
#            return object.__getattr__(attribute)
#       except AttributeError, e:
#           raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation=attribute)


    def enter (self, ignoreErrors=False, runTrigger=True):
        with self._mutex:
            if not self._refcount and runTrigger:
                self.runtrigger(self.PREEXEC, self.preexec, None, ignoreErrors)
            self._refcount += 1

    def exit (self, ignoreErrors=False, runTrigger=True):
        with self._mutex:
            if self._refcount:
                self._refcount -= 1
                if not self._refcount:
                    self.syncAttributes()
                    if runTrigger:
                        self.runtrigger(self.POSTEXEC, self.postexec, None, ignoreErrors)


    def runtrigger (self, index, command, session=None, ignoreErrors=False):
        if command:
            session = NestedSession(parent=session, input=command, access=CONTROLLER,
                                    description='file context %r %s hook'%(self.name, self.TriggerNames[index]))
            try:
                trace("Invoking %s: %s"%(session.description, command.strip()))
                session.handle(scope=Base.top)
                trace("Completed %s"%(session.description,))
            except Exception, e:
                if ignoreErrors:
                    warning("While exiting %r location context: [%s] %s"%
                            (self.name, e.__class__.__name__, e))
                else:
                    raise

    def properties (self, omit={"password"}):
        #properties = dict(uri=self.uri())
        properties = {}

        for key in dir(self.__class__):
            if not key.startswith("_") and not key in (omit or {}):
                value = getattr(self, key)

                if key in self._conversions:
                    value = self._conversions[key].toString(value)

                if isinstance(value, str) and len(value)>0:
                    properties[key] = value

        return properties

    def normpath (self, filepath):
        return self.join(*self.split(filepath))

    def convertpath (self, relpath):
        return self.localpath(relpath)

    def localpath (self, relpath=None):
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='localpath')

    def vfspath (self, relpath, sanitized=True):
        if sanitized:
            relpath = self.join(*self.split(relpath))
        return ':'.join((self.name or '', relpath))

    def uri (self, relpath=None):
        path = self.join(self.path, *self.split(relpath))
        return urlparse.urlunsplit((self.scheme, self.hostname, path, None, None))

    def join (self, *parts):
        joined     = []
        stripchars = "".join(self.separators)

        for part in filter(None, parts):
            if part.startswith(self.separators):
                joined[:] = [""]

            part = part.strip(stripchars)
            if part:
                joined.append(part)

        return "/".join(joined)

    def split (self, *relpaths):
        parts = []
        for relpath in relpaths:
            for part in self._pathsep.split(relpath or ""):
                if part in (os.path.curdir, ""):
                    pass
                elif part == os.path.pardir:
                    try:
                        del parts[-1]
                    except IndexError:
                        raise self.ContextViolation(path=self.join(*relpaths), root=self.convertpath(None), context=self.name)
                else:
                    parts.append(part)
        return parts


    def splitbase (self, path, suffix=None):
        parts = self.split(path)

        dirname  = self.join(*parts[:-1])
        basename = parts and parts[-1] or ""

        if suffix and basename.lower().endswith(suffix.lower()):
            basename = basename[:-len(suffix)]

        return dirname, basename

    def basename (self, path, suffix=None):
        dirname, basename = self.splitbase(path, suffix)
        return basename

    def dirname (self, path):
        dirname, basename = self.splitbase(path)
        return dirname

    def filetype (self, relpath, followLinks=False, stat=None):
        try:
            if stat is None:
                stat = self.stat(relpath, followLinks)
        except EnvironmentError:
            return None
        else:
            if S_ISDIR(stat[ST_MODE]):
                return FOLDER
            elif S_ISREG(stat[ST_MODE]):
                return FILE
            elif S_ISCHR(stat[ST_MODE]) or S_ISBLK(stat[ST_MODE]):
                return DEVICE
            elif not followLinks and S_ISLNK(stat[ST_MODE]):
                return LINK
            else:
                return SPECIAL

    def exists (self, relpath, followLinks=False):
        try:
            self.stat(relpath, followLinks)
            return True
        except EnvironmentError:
            return False

    def isdir (self, relpath, followLinks=False, stat=None):
        try:
            if stat is None:
                stat = self.stat(relpath, followLinks)
        except EnvironmentError:
            return False
        else:
            return S_ISDIR(stat[ST_MODE])

    def isfile (self, relpath, followLinks=False, stat=None):
        try:
            if stat is None:
                stat = self.stat(relpath, followLinks)
        except EnvironmentError:
            return False
        else:
            return S_ISREG(stat[ST_MODE])

    def islink (self, relpath, stat=None):
        try:
            stat = self.stat(relpath, False)
        except EnvironmentError:
            return False
        else:
            return S_ISLNK(stat[ST_MODE])

    def samefile (self, relpath, targetcontext, targetpath):
        return self.vfspath(relpath) == targetcontext.vfspath(targetpath)

    def volsize (self, relpath):
        st = self.statvfs(relpath)
        units = st[F_BSIZE]
        total = units * st[F_BLOCKS]
        avail = units * (st[F_BAVAIL] or st[F_BFREE])
        return (total, avail)

    _accessMode = { P_READ   : os.R_OK,
                    P_WRITE  : os.W_OK,
                    P_EXECUTE: os.X_OK }

    def access (self, relpath, permission, ignoreMissing=False):
        try:
            st = self.stat(relpath)
        except EnvironmentError:
            if not ignoreMissing:
                raise
            else:
                return False
        else:
            if permission == P_SET:
                masks = (04000, 02000, 07777)
            else:
                mode  = self._accessMode[permission]
                masks = (mode << 6, mode << 3, mode)

            if (os.geteuid() == st[ST_UID]):
                required = masks[0]
            elif (st[ST_GID] in os.getgroups()):
                required = masks[1]
            else:
                required = masks[2]

            return (st[ST_MODE] & required) == required


    def walk (self, top, topdown=False, include=INCL_DEFAULT, followLinks=True):
        items = ([], [])
        for name in self.listdir(top, include=include):
            isdir = self.isdir(self.join(top, name), followLinks=followLinks)
            items[isdir].append(name)

        result = (top, items[True], items[False])
        if topdown:
            yield result

        for folder in items[True]:
            for item in self.walk(self.join(top, folder), include=include, topdown=topdown):
                yield item

        if not topdown:
            yield result

    def makedir (self, relpath, createParents=False, owner=None, group=None, uperm=None, gperm=None, wperm=None, followLinks=False):
        options = self.encodePermissions(owner, group, uperm, gperm, wperm)
        mkdir = (self.mkdir, self.mkdirs)[createParents]
        mkdir(relpath, **options)


    def mkdirs (self, relpath, mode=None, uid=None, gid=None):
        parts     = self.split(relpath) or [""]
        newparts  = []

        while parts and not self.isdir(self.join(*parts), followLinks=True):
            newparts.append(parts.pop())

        while newparts:
            parts.append(newparts.pop())
            path = self.join(*parts)
            self.mkdir(path, mode=mode, uid=uid, gid=gid)


    def remove (self, relpath, recursive=False, ignoreMissing=False):
        if not self.isdir(relpath):
            self.removefile(relpath, ignoreMissing)
        elif recursive:
            self.rmtree(relpath, ignoreMissing)
        else:
            raise self.NotAFile(location=self.vfspath(relpath))

    def rmtree (self, relpath, ignoreMissing=False):
        for folder, dirs, files in self.walk(relpath, topdown=False, include=INCL_ALL):
            for f in files:
                self.removefile(self.join(folder, f), ignoreMissing)
            self.removedir(folder, ignoreMissing)

    def removefile (self, relpath, ignoreMissing=False):
        try:
            self.unlink(relpath)
        except EnvironmentError as e:
            if not ignoreMissing or (e.errno != errno.ENOENT):
                raise
        else:
            self.clearAttributes(relpath, ignoreMissing=True)

    def removedir (self, relpath, ignoreMissing=False, followLinks=False):
        try:
            self.rmdir(relpath)
        except EnvironmentError as e:
            if followLinks and self.islink(relpath):
                self.unlink(relpath)
            elif not ignoreMissing or (e.errno != errno.ENOENT):
                raise

        self.clearAttributes(relpath, ignoreMissing=True)


    def call (self, method, fileargs=(), *otherargs, **kwargs):
        if not isinstance(fileargs, tuple):
            fileargs = (fileargs,)

        args = [ self.convertpath(arg) for arg in fileargs ]
        args.extend(otherargs)

        try:
            return method(*args, **kwargs)
        except EnvironmentError as e:
            location = None

            if fileargs:
                location = ",".join([ self.vfspath(arg) for arg in fileargs ])

            if e.filename:
                for relpath in fileargs:
                    if self.convertpath(relpath) == e.filename:
                        location = self.vfspath(relpath)
                        break

#            raise EnvError(e, location=location, invocation=invocation(method, args, kwargs))
            raise EnvError(e, location=location)

    def move (self, source, target):
        attributes = self.getAttributes(source)
        self.rename(source, target)
        self.setAttributes(target, attributes)
        self.clearAttributes(source, ignoreMissing=True)


    def readlink (self, relpath):
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='readlink',
                                        location=self.vfspath(relpath))

    def linkfile (self, relpath, targetcontext, targetpath, symbolic, replaceExisting=False):
        operation = ('link', 'symlink')[symbolic]
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation=operation,
                                        source=self.vfspath(relpath),
                                        target=targetcontext.vfspath(targetpath))

    def ismount (self, relpath):
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='ismount',
                                        location=self.vfspath(relpath))

    def stat (self, relpath, followLinks=False):
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='stat',
                                        location=self.vfspath(relpath))

    def statvfs (self, relpath):
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='statvfs',
                                        location=self.vfspath(relpath))

    def utime (self, relpath, times):
        raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='utime',
                                        location=self.vfspath(relpath))



    ########################################################################
    ### Metadata


    def getDetails (self, relpath, localtime=True, withAttributes=False, followLinks=False, stat=None):
        if not stat:
            stat = self.stat(relpath, followLinks=followLinks)

        uid      = stat[ST_UID]
        gid      = stat[ST_GID]
        mode     = stat[ST_MODE]
        size     = stat[ST_SIZE]
        perm     = S_IMODE(mode)
        filetype = self.filetype(relpath, followLinks, stat)

        data = {}

        if withAttributes:
            data.update(self.getAttributes(relpath))

        data.update(type=FileTypes[filetype], size=size, mode=oct(perm), uid=uid, gid=gid)
        data.update(self.getTimes(relpath, localtime=localtime, stat=stat))
        data.update(self.decodePermissions(perm, uid, gid))

        return data


    def copyprops (self, orgfile, newfile, times=False, permissions=True, attributes=True):
        if permissions:
            perms = self.getOwnershipAndMode(orgfile)
            self.setOwnershipAndMode(newfile, ignoreErrors=True, **perms)

        if times:
            times = self.getTimes(orgfile, localtime=False)
            self.setTimes(newfile, localtime=False, ignoreErrors=True, **times)

        if attributes:
            attributes = self.getAttributes(orgfile)
            self.setAttributes(newfile, attributes)


    ########################################################################
    ### FILE PERMISSIONS

    def getOwnershipAndMode (self, relpath, stat=None):
        if not stat:
            stat = self.stat(relpath)
        return dict(mode=stat[ST_MODE], uid=stat[ST_UID], gid=stat[ST_GID])

    def setOwnershipAndMode (self, relpath, mode=None, uid=None, gid=None, ignoreErrors=False):
        try:
            self.chmod(relpath, mode)
            self.chown(relpath, uid, gid)
        except EnvironmentError as e:
            if not ignoreErrors:
                raise

    def setPermissions (self, relpath, owner=None, group=None, uperm=None, gperm=None, wperm=None, ignoreErrors=False):
        oam = self.encodePermissions(owner, group, uperm, gperm, wperm)
        self.setOwnershipAndMode(relpath, ignoreErrors=ignoreErrors, **oam)


    def getPermissions (self, relpath, stat=None):
        oam = self.getOwnershipAndMode(relpath, stat)
        return self.decodePermissions(**oam)


    def encodePermissions (self, owner=None, group=None, uperm=None, gperm=None, wperm=None):
        mode  = None

        for scope, perms in enumerate((uperm, gperm, wperm)):
            if perms is not None:
                for perm in perms:
                    try:
                        mask = FilePermissionMasks[scope][perm]
                    except KeyError:
                        pass
                    else:
                        mode = (mode or 0) | mask

        uid = gid = None

        if owner is not None:
            if owner.isdigit():
                uid = int(owner)
            else:
                try:
                    pw   = getpwnam(owner)
                except (NameError, KeyError):
                    raise self.NoSuchUser(owner=owner)
                else:
                    uid  = pw.pw_uid
                    gid  = pw.pw_gid

        if group is not None:
            if group.isdigit():
                gid = int(group)
            else:
                try:
                    gr   = getgrnam(group)
                except (NameError, KeyError):
                    raise self.NoSuchGroup(group=group)
                else:
                    gid  = gr.gr_gid

        return dict(mode=mode, uid=uid, gid=gid)


    def decodePermissions (self, mode, uid, gid):
        try:
            pw = getpwuid(uid)
        except (NameError, KeyError):
            owner = str(uid)
        else:
            owner = pw.pw_name

        try:
            gr = getgrgid(gid)
        except (NameError, KeyError):
            group = str(gid)
        else:
            group = gr.gr_name

        props = dict(owner=owner, group=group)
        for scope, who in enumerate(PermissionScopes):
            perms = []
            for perm, what in enumerate(FilePermissions):
                try:
                    mask = FilePermissionMasks[scope][perm]
                except KeyError:
                    pass
                else:
                    if mask & mode != 0:
                        perms.append(perm)
            props[who] = perms

        return props

    def permissionStrings (self, owner=None, group=None, uperm=None, gperm=None, wperm=None, **kwargs):
        spec = {}

        if owner is not None:
            spec.update(owner=owner)

        if group is not None:
            spec.update(group=group)

        for who, permissions in zip(PermissionScopes, (uperm, gperm, wperm)):
            if permissions is not None:
                permstrings = []
                for perm, what in enumerate(FilePermissions):
                    if perm in permissions:
                        permstrings.append(what)
                spec[who] = ",".join(permstrings)

        return spec

    def included (self, filename, spec=INCL_DEFAULT, attributes={}):
#        if not (INCL_DOTONLY in spec) and filename in (os.path.curdir, os.path.pardir):
        if filename in (os.path.curdir, os.path.pardir):
            return False
        if not (INCL_DOT in spec) and filename.startswith("."):
            return False
        elif not (INCL_DOLLAR in spec) and '$' in filename:
            return False
        elif not (INCL_RESERVED in spec) and filename == AttributeFile:
            return False
        elif not (INCL_HIDDEN in spec) and attributes.get('hidden'):
            return False
        else:
            return True


    ########################################################################
    ### FILE TIMES

    def getTimes (self, relpath, localtime=True, stat=None):
        if stat is None:
            stat = self.stat(relpath)

        times = {T_ACCESS:       stat[ST_ATIME],
                 T_MODIFICATION: stat[ST_MTIME],
                 T_CREATION:     stat[ST_CTIME]}

        if localtime and self.localtime:
            self.adjustTimestamps(times, 1)

        return times


    def setTimes (self, relpath, atime=None, mtime=None, ctime=None, localtime=True, ignoreErrors=False):
        now   = time.time()
        times  = {T_ACCESS:       atime,
                  T_MODIFICATION: mtime,
                  T_CREATION:     ctime}

        if localtime and self.localtime:
            self.adjustTimestamps(times, -1)

        times = [ times[key] for key in TimeKeys ]
        try:
            self.utime(relpath, times)
        except EnvironmentError as e:
            if not ignoreErrors:
                raise


    def adjustTimestamps (self, times, direction=1):
        for key, timestamp in times.items():
            if timestamp:
                dst = time.localtime(timestamp).tm_isdst
                adjustment = (time.timezone, time.altzone)[dst]
                times[key] += direction * adjustment
        return times


#    def adjustTimestampsFrom (self, relpath, other):
#        direction = other.localtime - self.localtime
#        if direction:
#            self.adjustTimestamps(relpath, direction)


    def adjustTimes (self, relpath, direction=-1, stat=None):
        if self.localtime:
            if stat is None:
                stat = self.stat(relpath)

            times = self.getTimes(relpath, localtime=False, stat=stat)
            self.adjustTimestamps(times, direction)
            self.setTimes(relpath, localtime=False, **times)

            if S_ISDIR(stat[ST_MODE]):
                for basename in self.listdir(relpath):
                    self.adjustTimes(self.join(relpath, basename), direction)


    ########################################################################
    ### CUSTOM ATTRIBUTES

    def attributeMap (self, relpath, ignoreMissing=False):
        dirname, basename = self.splitbase(relpath)
        if not basename:
            basename = os.path.curdir

        try:
            attrmap  = self._attrmaps[dirname]

        except KeyError, e:
            c = RawConfigParser()
            c.optionxform = str

            debug("Loading file attributes in folder %r"%(dirname,))

            with self._mutex:
                attrpath = self.join(dirname, AttributeFile)
                attrmap  = self._attrmaps[dirname] = {}

                try:
                    fp = self.open(attrpath)
                    try:
                        c.readfp(fp)
                    finally:
                        fp.close()

                except EnvironmentError, e:
                    if not ignoreMissing:
                        self.stat(relpath)

                    trace("No attributes read from %s: [%s] %s"%
                          (self.uri(attrpath), type(e).__name__, e))

                except ConfigParserError, e:
                    notice("Failed to load attributes from file %r: [%s] %s"%
                           (self.vfspath(attrpath), type(e).__name__, e))

                else:
                    for s in c.sections():
                        attrmap[s] = dict(c.items(s))

                # else:
                #     skipped = []
                #     for s in c.sections():
                #         if self.exists(self.join(dirname, s)):
                #             attrmap[s] = dict(c.items(s))
                #         else:
                #             skipped.append(repr(s))

                #     if skipped:
                #         self.info("While loading attributes in folder %r, skipping non-existing path(s) %s"%
                #                   (dirname, ",".join(skipped)))


        attributes = attrmap.setdefault(basename, {})
        return attributes, dirname, basename


    def getAttributes (self, relpath, ignoreMissing=False):
        attrmap, dirname, basename = self.attributeMap(relpath, ignoreMissing)
        return attrmap

    def getAttribute (self, relpath, attribute, ignoreMissing=False):
        try:
            return self.getAttributes(relpath, ignoreMissing=ignoreMissing)[attribute.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchAttribute(location=self.vfspath(), id=attribute)

    def setAttributes (self, relpath, attributes, ignoreMissing=False):
        if attributes:
            attrmap, dirname, basename = self.attributeMap(relpath, ignoreMissing)

            for key, value in attributes.items():
                attrmap[key.lower()] = str(value)

            self.markAttributes(dirname)

    def setAttribute (self, relpath, attribute, value, ignoreMissing=False):
        self.setAttributes(relpath, {attribute: value}, ignoreMissing)

    def removeAttributes (self, relpath, attributes, ignoreMissing=True):
        attrmap, dirname, basename = self.attributeMap(relpath, ignoreMissing)

        remaining = set(attributes)
        modified  = False
        for attr in attributes:
            try:
                del attrmap[attr.lower()]
                remaining.discard(attr)
                modified = True
            except KeyError:
                pass

        if not attrmap:
            self.clearAttributes(relpath)

        if remaining and not ignoreMissing:
            raise self.NoSuchAttribute(location=self.vfspath(relpath),
                                       id=",".join(sorted(remaining)))

        elif modified:
            self.markAttributes(dirname)

    def clearAttributes (self, relpath, ignoreMissing=True):
        attrmap, dirname, basename = self.attributeMap(relpath, ignoreMissing)
        uri = self.uri(dirname)

        try:
            del self._attrmaps[dirname][basename]
        except KeyError:
            if not ignoreMissing:
                raise

        self.markAttributes(dirname)


    _dirtymaps = None ### Initiated per instance, since we use relative paths

    def markAttributes (self, dirname):
        if self._dirtymaps is None:
            self._dirtymaps = set()

        self._dirtymaps.add(dirname)

    def syncAttributes (self):
        while self._dirtymaps:
            self.saveAttributes(self._dirtymaps.pop())

        self._attrmaps.clear()

    def saveAttributes (self, dirname):
        maps = self._attrmaps.get(dirname)
        used = False

        if maps:
            c = RawConfigParser()
            c.optionxform = str

            for filename in self.listdir(dirname):
                try:
                    itemmap = maps[filename]
                except KeyError:
                    pass
                else:
                    used = True
                    c.add_section(filename)
                    for attr, value in itemmap.items():
                        c.set(filename, attr, value)


        attrpath = self.join(dirname, AttributeFile)
        if used:
            with self._mutex:
                tmppath  = attrpath + ".tmp"
                tmpfile  = self.open(tmppath, OP_WRITE)
                try:
                    c.write(tmpfile)
                finally:
                    tmpfile.close()

                try:
                    self.rename(tmppath, attrpath)
                except EnvironmentError, e:
                    ### On Windows, rename() does not overwrite existing files
                    self.unlink(attrpath)
                    self.rename(tmppath, attrpath)

        else:
            if self.exists(attrpath):
                try:
                    self.unlink(attrpath)
                except EnvironmentError:
                    pass

        self._dirtymaps.discard(dirname)


class FileContext (Context):
    scheme    = "file"
    fileop    = {
        None      : "rb",
        OP_READ   : "rb",
        OP_WRITE  : "wb",
        OP_APPEND : "ab" }


    def __init__ (self, name, **props):
        Context.__init__(self, name, **props)
        self.top = os.path.join(getStartupOption("root", os.path.curdir), self.path)

    def localpath (self, relpath=None):
        return os.path.join(self.top, *self.split(relpath))

    def uri (self, relpath=None):
        return "://".join((self.scheme, self.localpath(relpath)))

    def listdir (self, relpath, include=INCL_DEFAULT, showdir=False):
        names = [name for name in self.call(os.listdir, relpath) if self.included(name, include)]

        if showdir:
            names = [(name, None) for name in names]

        return names

    def stat (self, relpath, followLinks=False):
        method = (os.lstat, os.stat)[followLinks]
        return self.call(method, relpath)

    def readlink (self, relpath, localpath=False, ignoreErrors=False):
        try:
            readlink = os.readlink
        except AttributeError:
            raise self.NotSupportedOnPlatform(platform=platform.system(), operation='statvfs')

        linkspec = self.call(readlink, relpath)
        if not localpath:
            parts   = [self.top] + self.split(relpath)[:-1] + [linkspec]
            abslink = os.path.normpath(os.path.join(*parts))
            if (abslink+"/").startswith(self.top+"/"):
                linkspec = abslink[len(self.top):]
            elif ignoreErrors:
                linkspec = None
            else:
                raise self.ContextViolation(path=abslink, root=self.top, context=self.name)

        return linkspec

    def statvfs (self, relpath):
        try:
            statvfs = os.statvfs
        except AttributeError:
            raise self.NotSupportedOnPlatform(platform=platform.system(), operation='statvfs')
        return self.call(statvfs, relpath)

    def open (self, relpath, mode=None):
        return self.call(open, relpath, self.fileop[mode])


    def makedir (self, relpath, createParents=False, owner=None, group=None, uperm=None, gperm=None, wperm=None, followLinks=False):
        oam   = self.encodePermissions(owner, group, uperm, gperm, wperm)
        mkdir = (self.mkdir, self.mkdirs)[createParents]
        try:
            mkdir(relpath, **oam)
        except EnvError, e:
            if followLinks:
                try:
                    linkspec = self.readlink(relpath, localpath=True)
                except (NotSupported, EnvironmentError):
                    raise e
                else:
                    dirname = self.call(os.path.dirname, relpath)
                    normpath = os.path.normpath(os.path.join(dirname, linkspec))
                    mkdir = (os.mkdir, os.makedirs)[createParents]
                    if not os.path.isdir(normpath):
                        try:
                            mkdir(normpath)
                        except EnvironmentError, e:
                            if e.errno != errno.EBUSY:
                                raise

                        self.setOwnershipAndMode(relpath, ignoreErrors=True, **oam)
            else:
                raise e


    def mkdirs (self, relpath, mode=None, **options):
        parent = os.path.dirname(self.localpath(relpath))
        if not os.path.isdir(parent):
            os.makedirs(parent, (mode, 0777)[mode is None])

        return Context.mkdirs(self, relpath, mode=mode, **options)

    def mkdir (self, relpath, mode=None, uid=None, gid=None):
        self.call(os.mkdir, relpath)
        self.chown(relpath, uid, gid)
        self.chmod(relpath, (mode, 0777)[mode is None])

    def rmdir (self, relpath):
        return self.call(os.rmdir, relpath)

    def chmod (self, relpath, mode=None):
        if mode is not None:
            try:
                chmod = os.chmod
            except AttributeError:
                raise self.NotSupportedOnPlatform(platform=platform.system(), operation='chmod')

            return self.call(chmod, relpath, mode)


    def chown (self, relpath, uid=None, gid=None):
        if not uid is gid is None:
            try:
                chown = os.chown
            except AttributeError:
                raise self.NotSupportedOnPlatform(platform=platform.system(), operation='chown')

            return self.call(chown, relpath, (uid, -1)[uid is None], (gid, -1)[gid is None])

    def rename (self, old, new):
        return self.call(os.rename, (old, new))

    def unlink (self, relpath):
        return self.call(os.unlink, relpath)

    def deviceid (self, relpath):
        return self.stat(self.dirname(relpath), True)[ST_DEV]

    def linkfile (self, relpath, targetcontext, targetpath, symbolic, replaceExisting=False, attributes=True):
        if (not isinstance(targetcontext, FileContext) or
            (not symbolic and self.deviceid(relpath) != targetcontext.deviceid(targetpath))):
            raise self.CrossDeviceLink(source=self.vfspath(relpath), target=targetcontext.vfspath(targetpath))

        try:
            link = (os.link, os.symlink)[symbolic]
        except AttributeError:
            raise self.NotSupportedOnPlatform(platform=platform.system(), operation='link')
        else:
            if attributes:
                attr = self.getAttributes(relpath)

            try:
                target = targetcontext.convertpath(targetpath)
                self.call(link, relpath, target)
            except EnvironmentError, e:
                if replaceExisting and (e.errno == errno.EEXIST):
                    targetcontext.unlink(targetpath)
                    self.call(link, relpath, target)
                else:
                    raise

            if attributes:
                targetcontext.setAttributes(targetpath, attr)


    def copyfile (self, orgfile, newfile, times=False, permissions=True, attributes=True, update=False):
        self.call(shutil.copyfile, (orgfile, newfile))
        self.copyprops(orgfile, newfile, times, permissions, attributes)

    def utime (self, relpath, times):
        return self.call(os.utime, relpath, tuple(times[:2]))

    def access (self, relpath, mode, ignoreMissing=False):
        if not ignoreMissing:
            self.stat(relpath)

        return self.call(os.access, relpath, mode)

    def samefile (self, relpath, targetcontext, targetpath):
        if not isinstance(targetcontext, FileContext):
            return False

        target = targetcontext.convertpath(targetpath)
        try:
            return self.call(os.path.samefile, relpath, target)
        except EnvironmentError:
            return False
        except AttributeError:
            return self.call(os.path.normcase, source) == os.path.normcase(target)

#    def walk (self, top, topdown=False):
#        return self.call(os.walk, top, topdown=topdown)

    def ismount (self, relpath):
        return self.call(os.path.ismount, relpath)



class BaseSMBContext (Context):
    class NoSMBSupport (RunError):
        '''SMB client features are not supported on this system'''

    class NoSMBShare (RunError):
        '''This operation requires a valid SMB share'''

    class NoSMBPath (RunError):
        '''This operation requires a subpath'''

    _domainsplit = re.compile(r"[/\\]")
    scheme       = "smb"
    hostname     = Missing
    domain       = ""
    username     = ""
    password     = ""

    ATTRIBUTES = (A_READONLY, A_HIDDEN, A_SYSTEM, A_VOLUME,
                  A_DIRECTORY, A_ARCHIVE, A_DEVICE, A_NORMAL,
                  A_TEMP, A_SPARSE, A_RPP, A_COMPRESSED,
                  A_OFFLINE, A_NONINDEXED, A_ENCRYPTED) = range(15)

    AttributeFlags = ('R', 'H', 'S', 'V',
                      'D', 'A', 'd', 'N',
                      't', 's', 'r', 'c',
                      'o', 'n', 'e')

    AttributeNames = {
        A_HIDDEN : 'hidden',
        A_SYSTEM : 'system',
        A_ARCHIVE : 'archive',
        A_READONLY : 'readonly' }

    StaticAttributes = Context.StaticAttributes + tuple(AttributeNames.values())

    def __init__ (self, name, username=None, domain=None, **properties):
        if username and not domain:
            try:
                domain, username = self._domainsplit.split(username, 1)
            except ValueError:
                pass

        Context.__init__ (self, name, username=username or "", domain=domain or "", **properties)
        self._directory = {}

    def convertpath (self, relpath):
        return self.uri(relpath)

    def listdir (self, relpath, include=INCL_DEFAULT, showdir=False):
        try:
            items = self._directory[relpath]
            trace("Cache hit for directory %r information: %r"%(relpath, items))

        except KeyError:
            trace("Cache miss for directory %r information"%(relpath,))
            path = self.join(self.path, relpath)

            if not path:
                items = self.listshares()

            else:
                items = self.listfolder(relpath)

                trace("Caching information for directory %r: %r"%(relpath, items))
                self._directory[relpath] = items

            # Slight optimization: if we did not see the ".attributes" file in this listing,
            # do not bother to to look for it when obtaining details later.
            if not AttributeFile in items:
                self._attrmaps.setdefault(relpath, {})

        names = []
        for name, props in items.iteritems():
            if self.included(name, include, props):
                if showdir:
                    names.append((name, props.get('type') == FOLDER))
                else:
                    names.append(name)

        return names


    def getFileInfo (self, relpath, allowquery=True):
        dirname, basename = self.splitbase(relpath)

        try:
            fileinfo = self._directory[dirname][basename or os.path.curdir]
        except KeyError:
            share, path = self.splitcifs(relpath)
            if path:
                fileinfo = self.readfileinfo(relpath)
            else:
                self.listdir(relpath)
                fileinfo = self._directory[relpath].get(os.path.curdir, {})
                fileinfo.update(type=FOLDER)
                self._directory.setdefault("", {}).setdefault(relpath, {}).update(fileinfo)

        return fileinfo


    def statFromInfo (self, info, attributes):
        mode = (0666, 0444)[self.hasdosattribute(attributes, self.A_READONLY)]
        if info.get('type') == FOLDER:
            mode |= (S_IFDIR|0111)

        stat = [ mode, 0, 0, 1 ]  # Mode, Ino, Device, Links
        for key in 'uid', 'gid', 'size', 'atime', 'mtime', 'ctime':
            stat.append(info.get(key, 0))

        return stat

    def getDetails (self, relpath, localtime=True, withAttributes=False, followLinks=False, stat=None):
        data = {}
        fileinfo = self.getFileInfo(relpath)

        for key in self.StaticAttributes:
            try:
                data[key] = fileinfo[key]
            except KeyError:
                pass

        if withAttributes:
            data.update(self.getAttributes(relpath))

        try:
            data.update(type=FileTypes[fileinfo['type']])
        except KeyError:
            pass

        return data

    def getAttributes (self, relpath, ignoreMissing=False):
        path = self.split(self.path, relpath)
        if len(path) > 1:
            return Context.getAttributes(self, relpath, ignoreMissing)
        if len(path) > 0:
            return Context.getAttributes(self, self.join(relpath, os.path.curdir), ignoreMissing)
        else:
            return {}


    def syncAttributes (self):
        Context.syncAttributes(self)
        self._directory.clear()



class PySMBContext (BaseSMBContext):
    _opmap = {
        None      : 0,
        OP_READ   : os.O_RDONLY,
        OP_WRITE  : os.O_WRONLY | os.O_CREAT,
        OP_APPEND : os.O_WRONLY | os.O_CREAT | os.O_APPEND }

    scheme       = "smb"

    @property
    def smbc (self):
        if not self._smbc:
            if smbc:
                self._smbc = smbc.Context(auth_fn = self.auth)
            else:
                raise self.NoSMBSupport()
        return self._smbc
    _smbc  = None

    def auth (self, server, share, workgroup, username, password):
        return self.domain, self.username, self.password

    def listshares (self):
        dirmap = { smbc.FILE_SHARE:True, smbc.DIR:True, smbc.FILE:False }
        shares = {}

        for entry in self.call(self.smbc.opendir, "").getdents():
            try:
                isdir = dirmap[entry.smbc_type]
            except KeyError:
                isdir  = False
                filetype = SPECIAL
            else:
                filetype = (FILE, FOLDER)[isdir]

            props = dict(type=filetype)
            if entry.comment:
                props.update(comment=entry.comment)

            shares[entry.name] = props

        return shares


    def listfolder (self, relpath):
        entries  = self.call(self.smbc.opendir, relpath).getdentsplus()
        items    = {}

        for name, props in entries.items():
            attributes = props.get('attrs', 0)
            if self.hasdosattribute(attributes, self.A_DIRECTORY, self.A_VOLUME):
                filetype = FOLDER
            elif self.hasdosattribute(attributes, self.A_DEVICE):
                filetype = DEVICE
            else:
                filetype = FILE

            props.update(type=filetype)

            for flag, label in self.AttributeNames.items():
                props[label] = self.hasdosattribute(attributes, flag)

            items[name] = props

        return items

    def readfileinfo (self, relpath):
        dirname, basename = self.splitbase(relpath)
        self.listdir(dirname)
        try:
            return self._directory[dirname][basename]
        except KeyError:
            raise IOError(errno.ENOENT, os.strerror(errno.ENOENT), self.convertpath(relpath))


    def stat (self, relpath, followLinks=False):
        dirname  = self.dirname(relpath)
        basename = self.basename(relpath)

        try:
            fileinfo = self._directory[dirname][basename]
        except KeyError:
            return self.call(self.smbc.stat, relpath)
        else:
            return self.statFromInfo(fileinfo, fileinfo.get('attrs', 0))


    def statvfs (self, relpath):
        return self.call(self.smbc.statvfs, relpath)

    def volsize (self, relpath, ignoreErrors=False):
        try:
            vst = self.statvfs(relpath)
        except EnvironmentError, e:
            if ignoreErrors:
                return (0, 0)
            else:
                raise
        else:
            units = vst[F_BSIZE] * vst[F_FRSIZE]
            total = units * vst[F_BLOCKS]
            avail = units * (vst[F_BAVAIL] or vst[F_BFREE])
            return (total, avail)


    def open (self, relpath, mode=None):
        return self.call(self.smbc.open, relpath, self._opmap[mode])

    def mkdir (self, relpath, mode=None, uid=None, gid=None):
        self.call(self.smbc.mkdir, relpath, (mode, 0777)[mode is None])
        self.chown(relpath, uid, gid)

    def rmdir (self, relpath):
        return self.call(self.smbc.rmdir, relpath)

    def chmod (self, relpath, mode):
        if mode is not None:
            return self.call(self.smbc.chmod, relpath, mode)

    def chown (self, relpath, uid, gid):
        if not uid == gid == None:
            try:
                method = self.smbc.chown
            except AttributeError:
                raise self.NotSupportedInScheme(name=self.name, scheme=self.scheme, operation='chown', location=self.vfspath(relpath))

            return self.call(method, relpath, (uid, -1)[uid is None], (gid, -1)[gid is None])

    def rename (self, old, new):
        return self.call(self.smbc.rename, (old, new))

    def unlink (self, relpath):
        return self.call(self.smbc.unlink, relpath)

    def utime (self, relpath, times):
        return self.call(self.smbc.utime, relpath, tuple(times[:2]))

    def hasdosattribute (self, attributes, *flags):
        attrs = props.get('attrs', 0)

        mask  = 0
        for flag in flags:
            mask |= (1<<flag)

        return (attrs & mask) != 0



class SMBClientContext (BaseSMBContext):
    class NoSMBSupport (RunError):
        '''SMB client features are not supported on this system'''

    _SMBCLIENT = '/usr/bin/smbclient'

    _NTSTATUSMAP = {
        'NT_STATUS_OBJECT_NAME_NOT_FOUND'  : errno.ENOENT,
        'NT_STATUS_OBJECT_PATH_NOT_FOUND'  : errno.ENOENT,
        'NT_STATUS_NOT_FOUND'              : errno.ENOENT,
        'NT_STATUS_NO_SUCH_FILE'           : errno.ENOENT,
        'NT_STATUS_BAD_NETWORK_NAME'       : errno.ENOENT,
        'NT_STATUS_ACCESS_DENIED'          : errno.EPERM,
        'NT_STATUS_LOGON_FAILURE'          : errno.EPERM,
        'NT_STATUS_CONNECTION_DISCONNECTED': errno.ECONNRESET,
        'NT_STATUS_NOT_A_DIRECTORY'        : errno.ENOTDIR,
        'NT_STATUS_DIRECTORY_NOT_EMPTY'    : errno.ENOTEMPTY,
        'NT_STATUS_FILE_IS_A_DIRECTORY'    : errno.EISDIR,
        'NT_STATUS_OBJECT_NAME_COLLISION'  : errno.EEXIST,
    }

    scheme = "smb"

    class ProcessProxy (object):
        def __init__ (self, instance, onclose, *args, **kwargs):
            self.instance   = instance
            self.closed     = False
            self.invocation = (onclose, args, kwargs)

        def __del__ (self):
            self.close()

        def __enter__ (self):
            return self

        def __exit__ (self, exc_type=None, exc_value=None, exc_tb=None):
            self.close()
            return False

        def read (self, chunksize=None):
            return self.instance.stdout.read(chunksize)

        def write (self, data):
            self.instance.stdin.write(data)

        def close (self):
            if not self.closed:
                self.closed = True
                method, args, kwargs = self.invocation
                method(self.instance, *args, **kwargs)


    def __init__ (self, *args, **kwargs):
        BaseSMBContext.__init__(self, *args, **kwargs)
        self._volumeinfo = {}

    def smblaunch (self, *args, **kwargs):
        kwargs.setdefault('env', {})
        kwargs.setdefault('log', debug)

        fd, tempname = tempfile.mkstemp()
        try:
            os.write(fd, 'username=%s\npassword=%s\ndomain=%s\n'%(self.username, self.password, self.domain))
            os.close(fd)
            instance = process.launch((self._SMBCLIENT, "-N", "-A", tempname) + args, **kwargs)
            return instance, tempname
        except Exception:
            os.remove(tempname)
            raise

    _rx_capture_smb = re.compile(r'.*(NT_STATUS_\w+)\s+(.*)$', re.S)
    def smbcapture (self, instance, credfile, input=None, ignoreExit=False, ignoreStatus=False, log=debug, relpath=None):
        try:
            out, err = process.communicate(instance, input=input, log=log)
            try:
                process.waitInstance(instance, out=out, err=err, ignoreExit=ignoreExit)
                exitstatus = None
            except process.ExitStatus, e:
                exitstatus = e

            if (exitstatus or not ignoreStatus):
                match = self._rx_capture_smb.match(out) or self._rx_capture_smb.match(err)
            else:
                match = None

            if match:
                ntstatus = match.group(1)
                message  = " ".join((match.group(1), match.group(2)))
                errno    = self._NTSTATUSMAP.get(ntstatus, -1)
                error    = IOError(errno, message, self.uri(relpath))
                raise EnvError(error, location=self.vfspath(relpath))

            elif exitstatus:
                exitstatus.filename = self.uri(relpath)
                raise EnvError(e, location=self.vfspath(relpath))

            else:
                return out, err

        finally:
            os.remove(credfile)

    def smbrun (self, *args, **kwargs):
        input        = kwargs.get('input', None)
        ignoreExit   = kwargs.pop('ignoreExit', False)
        ignoreStatus = kwargs.pop('ignoreStatus', False)
        log          = kwargs.get('log', debug)
        relpath      = kwargs.pop('relpath', None)

        instance, credfile   = self.smblaunch(*args, **kwargs)
        return self.smbcapture(instance, credfile,
                               input=input, ignoreExit=ignoreExit, ignoreStatus=ignoreStatus, log=log, relpath=relpath)


    def splitcifs (self, relpath, needpath=False):
        parts = self.split(self.path, relpath)
        try:
            share = '\\\\%s\\%s'%(self.hostname, parts[0])
            path = '\\'.join(parts[1:])

        except IndexError:
            if needpath:
                raise self.NoSMBShare(uri=self.uri(relpath))
            share = '\\\\%s'%(self.hostname,)
            path =  ''

        else:
            if needpath and not path:
                raise self.NoSMBPath(uri=self.uri(relpath))

        return share, path


    def listshares (self):
        out, err = self.smbrun('-gL', self.hostname, ignoreStatus=True)
        shares = {}
        for line in out.splitlines():
            try:
                kind, name, comment = line.split("|", 2)
            except ValueError:
                pass
            else:
                props = {}

                if kind == "Disk":
                    filetype  = FOLDER
                else:
                    filetype  = SPECIAL

                props.update(type=filetype)
                if comment:
                    props.update(comment=comment)

                shares[name] = props

        return shares


    def listfolder (self, relpath, command="ls", suffix=r'\*'):
        return self.listpath(relpath, command, suffix)


    _rx_file  = re.compile(r'^\s+(.*?)\s+([%s]+)\s+(\d+)\s+(\w+\s+\w+\s+\d+\s+\d+:\d+:\d+\s+\d+)$' %
                           (''.join(BaseSMBContext.AttributeFlags),))
    _rx_total = re.compile(r'\s*(\d+) blocks of size (\d+)\.\s+(\d+) blocks available')

    def listpath (self, relpath, command="ls", suffix=''):
        share, path  = self.splitcifs(relpath)
        out, err = self.smbrun(share, '-c', '%s "%s%s"'%(command, path, suffix), relpath=relpath)
        items = {}

        for line in out.splitlines():
            filematch = self._rx_file.match(line)
            if filematch:
                name, attributes, size, timestring = filematch.groups()
                items[name] = self.getprops(name, size, attributes, mtime=timestring)

            else:
                sizematch = self._rx_total.match(line)
                if sizematch:
                    blocks, blocksize, available = [int(n) for n in sizematch.groups()]
                    self._volumeinfo[relpath] = (blocks*blocksize, available*blocksize)

        return items


    def hasdosattribute (self, flags, *attributes):
        for a in attributes:
            if self.AttributeFlags[a] in flags:
                return True
        else:
            return False

    # def updatefileinfo (self, relpath):
    #     share, path = self.splitcifs(relpath, needpath=False)
    #     out, err = self.smbrun(share, '-c', 'allinfo "%s"'%(path,))
    #     info = {}
    #     for line in out.splitlines():
    #         try:
    #             key, value = line.split(":", 1)
    #         except ValueError:
    #             pass
    #         else:
    #             info.setdefault(key, value.strip())

    #     dirname  = self.dirname(relpath)
    #     dirkey   = self.convertpath(dirname)
    #     basename = self.basename(relpath) or "."


    #     props = self.getprops(basename,
    #                           info.get('size', ''), info.get('attributes', ''),
    #                           atime=info.get('access_time', ''),
    #                           mtime=info.get('change_time', ''),
    #                           ctime=info.get('create_time', ''))

    #     self.fileinfo.setdefault(self.convertpath(dirname), {})[basename] = props

    def readfileinfo (self, relpath):
        items = self.listpath(relpath)
        self._directory.setdefault(self.dirname(relpath), {}).update(items)
        path, props = items.popitem()
        return props

    def stat (self, relpath, followLinks=False):
        fileinfo = self.getFileInfo(relpath)
        return self.statFromInfo(fileinfo, fileinfo.get('attributes', ''))

    def volsize (self, relpath, ignoreErrors=False):
        try:
            return self._volumeinfo[relpath]
        except KeyError:
            self.listfolder(relpath, command="du")
            return self._volumeinfo.get(relpath, (0,0))


    _rx_date = re.compile(r'\s*(\w+\s+\w+\s+\d+\s+\d+:\d+:\d+\s+\d+).*')
    _rx_size = re.compile(r'[^\d]*(\d+).*')
    _rx_attr = re.compile(r'\s*(\w+).*')

    def getprops (self, name, sizestring, attributestring, **dates):
        m = self._rx_attr.match(attributestring)
        if m:
            attributes = m.group(1)
        else:
            attributes = ""

        if self.hasdosattribute(attributes, self.A_DIRECTORY, self.A_VOLUME):
            filetype = FOLDER
        elif self.hasdosattribute(attributes, self.A_DEVICE):
            filetype = DEVICE
        else:
            filetype = FILE

        props = dict(type=filetype, attributes=attributes)

        for i, v in self.AttributeNames.items():
            props[v] = self.hasdosattribute(attributes, i)

        m = self._rx_size.match(sizestring)
        if m:
            props.update(size=m.group(1))

        for key, string in dates.items():
            m = self._rx_date.match(string)
            if m:
                props[key] = int(time.mktime(time.strptime(m.group(1))))

        return props


    def mkdir (self, relpath, mode=None, uid=None, gid=None):
        share, path = self.splitcifs(relpath, needpath=True)
        self.smbrun(share, '-c', 'mkdir "%s"'%(path,), relpath=relpath)
        self.chmod(relpath, mode)
        self.chown(relpath, uid, gid)

    def rmdir (self, relpath):
        share, path = self.splitcifs(relpath, needpath=True)
        self.smbrun(share, '-c', 'rmdir "%s"'%(path,), relpath=relpath)

    def chmod (self, relpath, mode, ignoreErrors=True):
        if mode is not None:
            share, path = self.splitcifs(relpath, needpath=True)
            self.smbrun(share, '-c', 'chmod "%s" %o'%(path, mode), ignoreExit=ignoreErrors, relpath=relpath)

    def chown (self, relpath, uid, gid, ignoreErrors=True):
        if not uid == gid == None:
            share, path = self.splitcifs(relpath, needpath=True)
            self.smbrun(share, '-c', 'chown "%s" %d %d'%(path, (uid, -1)[uid is None], (gid, -1)[gid is None]),
                        ignoreExit=ignoreErrors, relpath=relpath)

    def copyfile (self, orgfile, newfile, times=False, permissions=True, attributes=True, update=False):
        share, srcpath = self.splitcifs(orgfile)
        share, dstpath = self.splitcifs(newfile)
        self.smbrun(share, '-c', 'scopy "%s" "%s"'%(srcpath, dstpath), relpath=srcpath)
        self.copyprops(orgfile, newfile, times, permissions, attributes)


    def rename (self, old, new):
        share, oldpath = self.splitcifs(old, needpath=True)
        share, newpath = self.splitcifs(new, needpath=True)
        self.smbrun(share, '-c', 'rename "%s" "%s"'%(oldpath, newpath), relpath=oldpath)

    def unlink (self, relpath):
        share, path = self.splitcifs(relpath, needpath=True)
        self.smbrun(share, '-c', 'rm "%s"'%(path,), relpath=relpath)

    def utime (self, relpath, times):
        share, path = self.splitcifs(relpath, needpath=True)
        self.smbrun(share, '-c', 'utimes "%s" %d %d %d %d'%
                    (path, times[T_CREATION], times[T_ACCESS], times[T_MODIFICATION], times[T_MODIFICATION]),
                    relpath=relpath)


    def syncAttributes (self):
        BaseSMBContext.syncAttributes(self)
        self._volumeinfo.clear()

    def open (self, relpath, mode=None):
        share, path = self.splitcifs(relpath, needpath=True)
        if mode in (None, OP_READ):
            return self._openread(relpath, share, path)
        else:
            return self._openwrite(relpath, share, path)

    def _openread (self, relpath, share, path, tempmax=1024*1024):
        instance, credfile = self.smblaunch(share, '-E', '-c', 'get "%s" -'%(path,))
        tmp = tempfile.SpooledTemporaryFile(tempmax)
        shutil.copyfileobj(instance.stdout, tmp)
        tmp.seek(0)
        self.smbcapture(instance, credfile, relpath=relpath)
        return tmp

    def _openwrite (self, relpath, share, path):
        instance, credfile = self.smblaunch(share, '-c', 'put - "%s"'%(path,), inputFile=subprocess.PIPE)
        return self.ProcessProxy(instance, self._onclose, credfile, relpath)

    def _onclose (self, instance, credfile, relpath):
        if instance.stdin:
            instance.stdin.close()
            instance.stdin = None

        self.smbcapture(instance, credfile, relpath=relpath)



#class SearchFileContext (FileContext):
#    scheme = None
#    path   = None
#    searchpath = Missing
#
#    def localpath (self, relpath):
#        parts   = self.split(relpath)
#        path    = None
#        default = None
#        for folder in self.searchpath:
#            candidate = self.join(self.cwd, folder, *parts)
#            if os.path.exists(candiate):
#                return candidate
#            elif path is None:
#                default = candidate
#        return default


class HTTPContext (Context):
    scheme = 'http'

class HTTPSContext (HTTPContext):
    scheme = 'https'

class SCPIContext (Context):
    scheme      = 'scpi'
    hostname    = None
    connection  = None
    _branchname = 'SCPI'

    class EnvironmentError (ComponentError, EnvironmentError):
        def __init__ (self, _errno, _text, _filename=None, _location=None, **kwargs):
            EnvironmentError.__init__(self, _errno, _text, _filename)
            errcode = errno.errorcode.get(_errno, '%d'%(_errno,))
            ComponentError.__init__(self, SCPIContext._branchname, errcode, _text)


    class WritableProxyFile (StringIOClass):
        def __init__ (self, onclose, *args, **kwargs):
            StringIOClass.__init__(self)
            self.invocation = (onclose, args, kwargs)
            self.closed = False

        def __del__ (self):
            if not self.closed:
                self.close()

        def __enter__ (self):
            return self

        def __exit__ (self, exc_type=None, exc_value=None, exc_tb=None):
            self.close()
            return False

        def close (self):
            if not self.closed:
                method, args, kwargs = self.invocation
                self.seek(0)
                args += (self.read(),)
                #args += (self.buf,)
                method(*args, **kwargs)
                self.closed = True
                return StringIOClass.close(self)


    def __init__ (self, name, *args, **kwargs):
        Context.__init__(self, name, *args, **kwargs)
        if not self.connection:
            if self.hostname:
                self.connection = hostname
            else:
                try:
                    self.connection, self.path = self.path.split(":", 1)
                except ValueError:
                    self.connection, self.path = self.path, ""

        self.branch = Base.top.find(self._branchname)
        self.scpi = self.branch.getConnection(self.connection)
        self.scpi.LOG_SEND = LEVEL_DEBUG
        self.attributes = {}


    def convertpath (self, relpath):
        return self.join(self.path, relpath)

    def sendReceive (self, command, fileargs=(), *otherargs, **kwargs):
        if not isinstance(fileargs, tuple):
            fileargs = (fileargs,)

        parts = [ command ]
        parts.extend([(key, value) for (key, value) in kwargs.items() if value is not None])
        parts.extend([self.convertpath(arg) for arg in fileargs])
        parts.extend(otherargs)

        return self.branch.clientWrapper(self.scpi.sendReceive, parts, decompose=True, ignoreNext=True)

    def fileCommand (self, command, *args, **kwargs):
        status, args, kwargs = self.sendReceive("FILe:"+command, *args, **kwargs)
        return args, kwargs

    def listdir (self, relpath, include=INCL_DEFAULT, descend=True, showdir=False):
        args, kwargs = self.fileCommand("LIST?", relpath, verbose=True, all=True, directory=not descend)
        filelist = []
        for arg in args:
            for line in arg.splitlines():
                text, parts = self.scpi.expandArgs(line)
                attributes = collections.OrderedDict()
                lastopt = None
                isfolder = False
                filename = None
                for opt, arg, raw in parts:
                    if opt is None and lastopt is None:
                        filename = arg
                    elif opt:
                        attributes[opt] = arg
                        lastopt = opt
                        if (opt, arg) == ("type", "folder"):
                            isfolder = True
                    elif lastopt:
                        attributes[lastopt] += " "+arg

                if filename is not None and self.included(filename, include, attributes):
                    if descend:
                        cxt, filepath = splitLocation(filename)
                        basename = self.basename(filepath)
                        path = self.join(relpath, basename)
                    else:
                        path = relpath
                        basename = self.basename(path)

                    filelist.append((basename, (basename, isfolder))[showdir])
                    self.attributes[path] = attributes

        return filelist


    def listattributes (self, relpath):
        try:
            return self.attributes[relpath]
        except KeyError:
            self.listdir(relpath, descend=False)
            return self.attributes[relpath]


    def getDetails (self, relpath, localtime=True, withAttributes=False, followLinks=False, stat=None):
        attributes = self.listattributes(relpath)

        try:
            if not withAttributes:
                items = [(key, value) for (key, value) in attributes if key in self.StaticAttributes]
                attributes = dict(items)
        except:
            return attributes

        return attributes


    def stat (self, relpath, followLinks=False):
        attributes = self.listattributes(relpath)

        try:
            mode = int(attributes['mode'], 0)
        except (KeyError, ValueError):
            mode = 0666

        if attributes.get('type') == 'folder':
            mode |= S_IFDIR

        stat = [ mode, 0, 0, 1 ]  # Mode, INO, Device, LInks

        for key in 'uid', 'gid', 'size':
            stat.append(int(attributes.get(key, 0)))

        for key in 'atime', 'mtime', 'ctime':
            stat.append(int(float(attributes.get(key, 0))))

        return stat

    def volsize (self, relpath, ignoreErrors=False):
        args, kwargs = self.fileCommand("VolumeSIZe?", relpath)
        total = int(kwargs.get('total', 0))
        avail = int(kwargs.get('available', 0))
        return (total, avail)

    def open (self, relpath, mode=None):
        if mode in (None, OP_READ):
            return self._openread(relpath)
        elif mode in (OP_WRITE, OP_APPEND):
            return self._openwrite(relpath, append=(mode==OP_APPEND))

    def _openread (self, relpath):
        args, kwargs = self.fileCommand("READ?", relpath, encoding='base64')
        return StringIO(base64.decodestring(args[0]))

    def _openwrite (self, relpath, append):
        return self.WritableProxyFile(self._onclose, relpath, append)

    def _onclose (self, relpath, append, contents):
        self.fileCommand("WRITE", relpath, base64.encodestring(contents), encoding='base64', append=append)

    def remove (self, relpath, recursive=False, ignoreMissing=False):
        self.fileCommand("REMOVE", relpath, recursive=recursive, ignoreMissing=ignoreMissing)

    def makedir (self, relpath, createParents=False, owner=None, group=None, uperm=None, gperm=None, wperm=None, followLinks=False):
        options = self.permissionStrings(owner=owner, group=group, uperm=uperm, gperm=gperm, wperm=wperm)
        if followLinks:
            options.update(followLinks=followLinks)
        if createParents:
            options.update(createParents=createParents)
        self.fileCommand("MKDIR", relpath, **options)

    def removedir (self, relpath, ignoreMissing=False, followLinks=False):
        options = dict(ignoreMissing=ignoreMissing)
        if followLinks:
            options.update(followLinks=followLinks)
        self.fileCommand("RMDIR", relpath, **options)

    def rename (self, old, new):
        self.fileCommand("MOVe", (old, new))

    def copyfile (self, orgfile, newfile, times=None, permissions=None, attributes=None, update=None):
        self.fileCommand("COPy", (orgfile, newfile),
                         times=times, permissions=permissions, attributes=attributes, update=update)

    def getPermissions (self, relpath, stat=None):
        attributes = self.listattributes(relpath)

        spec = {}
        for key in 'owner', 'group':
            if attributes.get(key) is not None:
                spec[key] = attributes[key]

        for who, key in enumerate(PermissionScopes):
            mask = None
            try:
                permstrings = attributes[key].split(",")
            except KeyError:
                pass
            else:
                perms = []
                for what in perms:
                    try:
                        perms.append(FilePermissions.index(what.lower()))
                    except ValueError:
                        pass
                spec[key] = perms

        return spec

    def setPermissions (self, relpath, owner=None, group=None, uperm=None, gperm=None, wperm=None, ignoreErrors=False):
        permspec = self.permissionStrings(owner=owner, group=group, uperm=uperm, gperm=gperm, wperm=wperm)

        if permspec:
            try:
                self.fileCommand("PERMission=", relpath, **permspec)
            except ComponentError, e:
                if not ignoreErrors:
                    raise

    def utime (self, relpath, times):
        access, modification = times[:2]
        self.fileCommand("TIME=", relpath, access=access, modification=modification)

    def getAttributes (self, relpath, ignoreMissing=False):
        attributes = {}

        try:
            attributes.update(self.listattributes(relpath))
        except EnvironmentError, e:
            if not ignoreMissing or e.errno != errno.ENOENT:
                raise
        else:
            for key in self.StaticAttributes:
                attributes.pop(key, None)

        return attributes

    def setAttributes (self, relpath, attributes, ignoreMissing=False, createMissing=True, ignoreErrors=True):
        try:
            for key, value in attributes.items():
                self.fileCommand("ATTRibute=", relpath, key, value, create=createMissing)
        except EnvironmentError, e:
            if not ignoreMissing or e.errno != errno.ENOENT or not ignoreErrors:
                raise

    def removeAttributes (self, relpath, attributes, ignoreMissing=False, ignoreErrors=True):
        try:
            self.fileCommand("ATTRibute-", relpath, *attributes, ignoreMissing=ignoreMissing)
        except Exception, e:
            if not ignoreErrors:
                raise

    def clearAttributes (self, relpath, ignoreMissing=False, ignoreErrors=True):
        try:
            self.fileCommand("ATTRibute~", relpath, ignoreMissing=ignoreMissing)
        except Exception, e:
            if not ignoreErrors:
                raise

    def syncAttributes (self):
        self.attributes.clear()



ContextSchemes = {}
for ContextClass in (FileContext, SMBClientContext, SCPIContext, HTTPContext, HTTPSContext):
    ContextSchemes[ContextClass.scheme] = ContextClass


class Location (object):
    class NoSuchLocation (RunError):
        '''Location %(location)r does not exist'''

    class TargetExists (RunError):
        '''Target location %(location)r already exists'''

    __slots__ = ('context', 'parts', 'path', 'runTriggers', 'openFiles', '_stat', '_exc', '_isdir')

    def __init__ (self, context, path, runTriggers=None, isdir=None):
        self.context     = context
        self.parts       = context.split(path)
        self.path        = context.join(*self.parts)
        self.openFiles   = []
        self.runTriggers = runTriggers
        self._stat       = {}
        self._exc        = {}
        self._isdir      = isdir

    def __enter__ (self):
        self.context.enter(runTrigger=self.runTriggers)
        return self

    def __exit__ (self, exc_type=None, exc_value=None, exc_tb=None):
        try:
            while self.openFiles:
                self.openFiles.pop().close()
        finally:
            self.context.exit(runTrigger=self.runTriggers, ignoreErrors=(exc_type is not None))

        if isinstance(exc_value, EnvironmentError):
            if hasattr(exc_value, 'location'):
                raise
            else:
                raise EnvError(exc_value, location=getattr(exc_value, 'location', self.vfspath()))
            #exc_value.location = self.vfspath()

        return False

#    def __getattr__ (self, name):
#        try:
#            return getattr(super(Location, self), name)
#        except AttributeError, e:
#            context = self.context
#            if hasattr(context, name):
#                return getattr(context, name)
#            else:
#                raise

    def filepath (self, *parts):
        return self.context.join("/", self.path, *parts)

    def filetype (self, followLinks=False, ignoreMissing=False):
        return self.context.filetype(self.path, followLinks, self.stat(followLinks, ignoreMissing=ignoreMissing))

    def stat (self, followLinks=False, ignoreMissing=False):
        try:
            return self._stat[followLinks]
        except KeyError:
            try:
                try:
                    raise self._exc[followLinks]
                except KeyError:
                    st = self._stat[followLinks] = self.context.stat(self.path, followLinks)
                    return st
            except EnvironmentError, e:
                self._exc.setdefault(followLinks, e)
                if not ignoreMissing:
                    raise


    def exists (self, followLinks=False):
        if self._isdir is not None and not followLinks:
            return True

        try:
            self.stat(followLinks)
            return True
        except EnvironmentError:
            return False

    def isdir (self, followLinks=False):
        if self._isdir is not None and not followLinks:
            return self._isdir

        try:
            st = self.stat(followLinks)
        except EnvironmentError:
            return False
        else:
            return S_ISDIR(st[ST_MODE])

    def isreg (self, followLinks=False):
        if self._isdir and not followLinks:
            return False

        try:
            st = self.stat(followLinks)
        except EnvironmentError:
            return False
        else:
            return S_ISREG(st[ST_MODE])

    def islink (self):
        if self._isdir and not followLinks:
            return False

        try:
            st = self.stat(False)
        except EnvironmentError:
            return False
        else:
            return S_ISLNK(st[ST_MODE])

    def readlink (self, *args, **kwargs):
        return self.context.readlink(self.path, *args, **kwargs)

    def ismount (self):
        return self.context.ismount(self.path)

    def access (self, *args, **kwargs):
        return self.context.access(self.path, *args, **kwargs)

    def basename (self, suffix=None):
        return self.context.basename(self.path, suffix)

    def dirname (self):
        return self.context.dirname(self.path)

    def localpath (self):
        return self.context.localpath(self.path)

    def vfspath (self, *args, **kwargs):
        return self.context.vfspath(self.path, *args, **kwargs)

    def uri (self):
        return self.context.uri(self.path)

    def open (self, *args, **kwargs):
        fp = self.context.open(self.path, *args, **kwargs)
        self.openFiles.append(fp)
        return fp

    def makedir (self, *args, **kwargs):
        return self.context.makedir(self.path, *args, **kwargs)

    def removedir (self, *args, **kwargs):
        return self.context.removedir(self.path, *args, **kwargs)

    def remove (self, recursive=False, ignoreMissing=False):
        return self.context.remove(self.path, recursive, ignoreMissing)

    def listdir (self, *args, **kwargs):
        return self.context.listdir(self.path, *args, **kwargs)

    def statvfs (self):
        return self.context.statvfs(self.path)

    def volsize (self, *args, **kwargs):
        return self.context.volsize(self.path, *args, **kwargs)

    def getPermissions (self):
        return self.context.getPermissions(self.path, stat=self.stat())

    def setPermissions (self, *args, **kwargs):
        return self.context.setPermissions(self.path, *args, **kwargs)

    def getTimes (self, localtime=True):
        return self.context.getTimes(self.path, localtime=localtime, stat=self.stat())

    def setTimes (self, *args, **kwargs):
        return self.context.setTimes(self.path, *args, **kwargs)

    def adjustTimes (self, direction=-1):
        return self.context.adjustTimes(self.path, direction, stat=self.stat())

    def getAttributes (self, ignoreMissing=False):
        return self.context.getAttributes(self.path, ignoreMissing)

    def getAttribute (self, attribute, ignoreMissing=False):
        return self.context.getAttributes(self.path, attribute, ignoreMissing)

    def setAttributes (self, attributes, ignoreMissing=False):
        return self.context.setAttributes(self.path, attributes, ignoreMissing)

    def setAttribute (self, attribute, value, ignoreMissing=False):
        return self.context.setAttribute(self.path, attribute, value, ignoreMissing)

    def removeAttributes (self, attributes, ignoreMissing=True):
        return self.context.removeAttributes(self.path, attributes, ignoreMissing)

    def clearAttributes (self, ignoreMissing=True):
        return self.context.clearAttributes(self.path)

    def getDetails (self, localtime=True, withAttributes=False, followLinks=False):
        return self.context.getDetails(self.path,
                                       localtime=localtime,
                                       withAttributes=withAttributes,
                                       followLinks=followLinks,
                                       stat=self.stat(followLinks=followLinks))


    ########################################################################
    ### PATTERN MATCHING

    def attributeMatch (self, attributes, patterns):
        match   = True
        if patterns:
            for attr, candidates in patterns.items():
                provided = attributes.get(attr.lower(), '').lower()
                for candidate in candidates:
                    if fnmatch.fnmatchcase(provided, candidate.lower()):

                        ### Match, no need to look for more
                        break
                else:
                    ### No match, don't add this file.
                    match = False
                    break

        return match

    _magic = re.compile('[*?[]')

    def glob (self, pattern, include=INCL_DEFAULT, descend=False, verify=True, ignoreMissing=False):
        return self.globparts(self.context.split(pattern), include, descend, verify=verify, ignoreMissing=ignoreMissing)

    def globparts (self, parts, include=INCL_DEFAULT, descend=False, verify=True, ignoreMissing=False, _specific=False):
        part = parts and parts[0] or ""
        glob = []

        try:
            if descend and not parts:
                items = self.context.listdir(self.path, include=include, showdir=True)

            elif self._magic.search(part) is not None:
                ### We have a name with wildcards. Use pattern matching.
                items = [item
                         for item in self.context.listdir(self.path, include=include, showdir=True)
                         if fnmatch.fnmatchcase(item[0], part)]

            else:
                items = [(part, None)]
                _specific = True

            for (name, isdir) in items:
                loc = Location(self.context, self.filepath(name), isdir=isdir)
                if (len(parts) > 1) or (len(parts) == 1 and descend and loc.isdir()):
                    glob.extend(loc.globparts(parts[1:], include, descend, verify, ignoreMissing, _specific=_specific))

                else:
                    if verify and _specific:
                        loc.stat()
                    glob.append(loc)

        except EnvironmentError:
            if not ignoreMissing:
                raise

        return glob

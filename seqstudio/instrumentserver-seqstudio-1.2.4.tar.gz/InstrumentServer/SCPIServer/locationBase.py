########################################################################
### FILE:	locationBase.py
### PURPOSE:	Base classes for location aware branches
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2012 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf        import Leaf, Background, Controlling, Observing
from scpiBase        import Hidden
from scpiExceptions  import RunError, Error, NextReply
from scpiConfigBase  import ConfigBase, NoSectionError
from motionBase      import MotionBase, MotionControlLeaf, MotionQueryLeaf
from re              import compile as rxcomp
from subscription    import info



class LocationLeaf (Leaf):
    '''
    Abstract leaf for commands that take a location input
    '''

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('context', type=str, default=None, named=True,
                      description='Location context, e.g. "FlowChip1".  If given, '
                      'the specified location name is first looked up within a '
                      'matching context, then with no context.')
        try:
            self.setInput('location', type=str,
                          description='Location name.')
        except KeyError:
            pass



class LocationSystem (ConfigBase):
    '''
    Subsystem with support for named contexts and locations
    '''
    class NoSuchLocation (RunError):
        'No such location exists: %(location)r'

    def __init__ (self, *args, **kwargs):
        LocationSystem.init(self)

    def init (self):
        self.parkLocations   = {}
        self.mapLocations()
        
    def locationFileName (self):
        return self.name.lower() + '-locations.ini'

    def getLocationConfig(self):
        return self.getConfigInstance(self.locationFileName(), literal=True)

    def getConfigObject(self, attribute):
        return self.getLocationConfig()

    def getSectionName (self, context, location):
        return ":".join(("LOC", (context or ""), location))


    def getLocationSection (self, context, location, ignoreMissing=False):
        locmap = None

        if context and location:
            locmap = self.locations.get(context.lower(), {}).get((location or "").lower())

        if not locmap:
            locmap = self.locations[None].get((location or "").lower())

        if locmap:
            return locmap

        elif not ignoreMissing:
            raise self.NoSuchLocation(location=self.locationName(context, location))

    def mapLocations (self):
        self.locations = { None: {} }

        for section in self.getLocationConfig().sections():
            try:
                prefix, context, names = section.split(":", 2)
            except ValueError:
                pass
            else:
                if prefix.upper() == "LOC":
                    for name in names.split(","):
                        cxtmap  = self.locations.setdefault(context.lower() or None, {})
                        cxtmap[name.lower()] = section

    def addLocation (self, context, location, save=True):
        section = self.getSectionName(context, location)
        config  = self.getLocationConfig()
        config.remove_section(section, save=False)
        config.add_section(section)
        if save:
            config.save()

        self.mapLocations()


    def delLocation (self, context, location, ignoreMissing=False, save=True):
        section = self.getSectionName(context, location)
        config  = self.getLocationConfig()

        if config.remove_section(section, save=save):
            self.mapLocations()
            return True

        elif ignoreMissing:
            return False

        else:
            raise self.NoSuchLocation(location=self.locationName(context, location))

    def setLocation (self, context, location, attributes, replace=False, save=True):
        if not self.hasLocation(context, location):
            self.addLocation(context, location, save=False)

        config  = self.getLocationConfig()
        section = self.getLocationSection(context, location)

        if replace:
            existed = config.remove_section(section, save=False)
        else:
            existed = config.has_section(section)

        self.debug("%s %s location %s (save=%s): %s"%
                   ((existed and (replace and "Replacing" or "Updating") or "Adding"),
                    self.commandPath(),
                    self.locationName(context, location),
                    save,
                    " ".join(sorted([ "-%s=%s"%item for item in attributes.items() ]))))
        
        for attribute, value in attributes.items():
            config.setliteral(section, attribute, value, save=False)

        if save:
            config.save()


    def listLocations (self, context=None):
        locmap = {}
        locmap.update(self.locations.get(None, {}))

        if context:
            locmap.update(self.locations.get(context.lower(), {}))

        locations = locmap.keys()

        locs = []
        for location in locations:
            pfx, cxt, loc = locmap[location].split(":", 2)
            locs.append(loc)

        return locs

    def hasLocation (self, context, location):
        section = self.getLocationSection(context, location, ignoreMissing=True)
        return (section is not None)

    digitSortX = rxcomp(r'^(.*\D+)(\d+)$')

    def sortedLocations (self, context, locations=None):
        if locations is None:
            locations = self.listLocations(context)

        locationmap = {}

        for l in locations:
            match = self.digitSortX.match(l)

            if match:
                prefix, index = match.groups()
                locationmap[len(prefix), prefix, int(index)] = l
            else:
                locationmap[l, None] = l

        locations = []
        for key, value in sorted(locationmap.items()):
            locations.append(value)

        return locations

    def locationName (self, context, location):
        if context and location and location.lower() in self.locations.get(context.lower(), {}):
            return "%s:%s"%(context, location)
        else:
            return location

    def getValue (self, context, location, attribute, default=None, valuetype=None):
        config  = self.getConfigObject(attribute)
        section = self.getLocationSection(context, location)
        value   = config.getliteral(section, attribute, valuetype, None)
        if value is None:
            return default
        else:
            return value

    def setValue (self, context, location, attribute, value, save=True):
        config  = self.getConfigObject(attribute)
        section = self.getLocationSection(context, location)
        current = self.getValue(context, location, attribute)

        if value != current:
            change = ('Updating location %s value "%s" from %r to %r'%
                      (self.locationName(context, location),
                       attribute, current, value))

            if isinstance(value, (int, float)) and isinstance(current, (int, float)):
                delta   = value - (current or 0)
                change += " (%s%s)"%(("", "+")[delta >= 0], delta)

            self.debug(change)
            config.setliteral(section, attribute, value, save=save)



    def clearValue (self, context, location, attribute, save=True):
        config  = self.getConfigObject(attribute)
        section = self.getLocationSection(context, location)
        config.remove_option(section, attribute, save=save)


    class LOCation_Add (Controlling, LocationLeaf):
        '''
        Define a new fluidics location.
        '''

        class LocationExists (RunError):
            '''This location is already defined within context %(context)r: %(location)s'''

        def declareInputs (self):
            LocationLeaf.declareInputs(self)
            self.setInput("context", description=
                          "Location context.  If specified, this location will only be "
                          "available for operations with a matching context; otherwise, "
                          "it is available in all contexts.  For instance, 'FlowChip1' "
                          "and 'FlowChip2' contexts can be used to limit the scope of "
                          "the location")

        def run (self, replaceExisting=False, context=None, location=str):
            if not replaceExisting and self.parent.hasLocation(context, location):
                raise self.LocationExists(context=context, location=location)

            self.parent.addLocation(context, location)

    class LOCation_Remove (Controlling, LocationLeaf):
        '''
        Remove a fluidics location.
        '''

        def run (self, ignoreMissing=False, context=None, location=str):
            self.parent.delLocation(context, location, ignoreMissing=ignoreMissing)

    class LOCation_Set (Controlling, Leaf):
        '''
        Define values for a given location.  The location must already exist.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('replace', type=bool, named=True, default=False,
                          description='Fully replace this location; remove any existing values not specified')
            self.setInput('save', type=bool, named=True, default=True,
                          description='Save location')
            self.setInput('context', type=str, named=True, default=None)
            self.setInput('location', type=str)
            self.setInput('attributes', repeats=(1, None), type=str)

        def run (self, replace=False, save=True, context=None, location=str, **attributes):
            self.parent.setLocation(context, location, attributes, replace=replace, save=save)


    class LOCation_Query (Observing, LocationLeaf):
        '''
        Return specific information about this location
        '''


        def run (self, context="", location=str):
            reply = [ self.parent.getValue(context, location, p.name)
                      for p in self.getOutputs() ]
            return tuple(reply)


    class LOCation_Enumerate (Observing, LocationLeaf):
        '''
        List available location
        '''

        def declareOutputs (self):
            LocationLeaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))


        def run (self, context=None):
            locations = self.parent.sortedLocations(context)
            return tuple(locations)





class LocationAwareMotionBase (LocationSystem, MotionBase):
    '''Motion control system with support for named locations'''

    class NoCoordinates (RunError):
        'No %(branch)s coordinates exist for location %(location)r'


    def __init__ (self, *args, **kwargs):
        MotionBase.__init__(self, *args, **kwargs)
        LocationSystem.init(self)


    def getLocationCoordinates (self, context, location, coordinates=None, axes=None, ignoreMissing=False):
        config  = self.getLocationConfig()
        section = self.getLocationSection(context, location, ignoreMissing=ignoreMissing)

        if coordinates is None:
            coordinates = {}

        if section and config.has_section(section):
            items  = config.items(section, literal=True)
            target = self.unflattenedTarget(dict(items))

            for axis in axes or self.axes:
                if not axis in coordinates and axis in target:
                    coordinates[axis] = target[axis]

        elif not ignoreMissing:
            raise self.NoCoordinates(branch=self.commandPath(),
                                     context=context,
                                     location=self.locationName(context, location))

        return coordinates


    def getLocationsOfCoordinates (self, coordinates, axes=None):
        config = self.getLocationConfig()

        for section in config.sections():
            items = config.items(section, literal=True, valuetype=int)
            
        locations = []
        for context, names in self.locations.iteritems():
            for name, section in names.items():
                targets   = self.getLocationCoordinates(context, name, axes=axes, ignoreMissing=True)
                rawtarget = self.effectiveTarget(targets)

                for axis, target in rawtarget.items():
                    slack = axis.slack
                    if not axis in coordinates or abs(coordinates.get(axis, 0) - target) > slack:
                        break
                else:
                    locations.append((context, name))

        return locations


    def moveToLocation (self, context, location, target=None, reserve=True, axes=None, force=False):
        logitems = []

        if location:
            target = self.getLocationCoordinates(context, location, target, axes, False)
            logitems.append(("location", self.locationName(context, location)))

        return self.sendMoves(target, logitems=logitems, reserve=reserve, force=force)


    def addReservation (self, name, acquire, axes, parkLocation):
        MotionBase.addReservation(self, name, acquire, axes)
        self.parkLocations[name.lower()] = parkLocation

    def delReservation (self, name, ignoreMissing=False):
        MotionBase.delReservation(self, name, ignoreMissing)
        self.parkLocations.pop(name.lower(), None)

    def relinquishReservation (self, name, requestor):
        message = ('Reservation "%s" release to %s'%(name, requestor.commandPath()))

        try:
            if self.motionLock.acquire(0):
                ### No motion was in progress at the time we were asked
                ### to hand over our reservation, so it is still valid.
                needToPark = True

            else:
                self.debug('%s -- waiting for motion...'%message)

                try:
                    self.occupationMutex.release()
                except Exception, e:
                    info("%s failed to release occupationModex relinquishing reservation %r to %s"%
                         (self.commandPath(), name, requestor.commandPath()))
                    raise

                self.motionLock.acquire()
                self.occupationMutex.acquire()

                ### We moved since it it was determined that we hold the
                ### reservation.  If we still do, we need to park first.
                needToPark = self.occupiesReservation(name)

            if needToPark:
                location = self.parkLocations.get(name, None)
                if location:
                    ref = self.moveToLocation(None, location, reserve=False)
                    self.completeMoves(*ref)

                del self.occupations[name]

        finally:
            self.debug("%s -- completed."%(message,))
            self.motionLock.release()



    class LOCation_Set (MotionControlLeaf):
        '''
        Specify coordinates for a given location.  
        '''
        
        class EmptyLocation (RunError):
            "Cowardly refusing to update location %(location)r with no values.  Use '-allowEmpty' to override."


        def declareInputs (self):
            self.startInputs()
            self.addInput('allowEmpty', type=bool, named=True, default=False,
                          description="Create location even if there are no axis coordinates specified.")
            self.addInput('replace', type=bool, named=True, default=False,
                          description='Fully replace coordinates for this location; '
                          'remove any existing coordinates for axes that are not specified')
            self.addInput('save', type=bool, named=True, default=True,
                          description='Save location')
            self.addInput('context', type=str, named=True, default=None)
            self.addInput('location', type=str)


        def run (self, allowEmpty=False, replace=False, save=True, context=None, location=str, *values):
            if replace and not allowEmpty and not self.unflattenedInputs(values):
                raise self.EmptyLocation(location=self.parent.locationName(context, location))

            attributes = []
            for p, value in zip(self.getInputs()[self.commonInputIndex:], values):
                if value is not None:
                    if isinstance(value, float) and value == int(value):
                        value = int(value)

                    attributes.append((p.name, value))

            self.parent.setLocation(context, location, dict(attributes), replace=replace, save=save)


    class LOCation_Query (MotionQueryLeaf, LocationLeaf):
        '''
        Show a location mapping
        '''


        def run (self, ignoreMissing=False, context=None, location=str, *axes):
            axes    = self.parent.getAxisSelection(axes) or self.getSupportedAxes()
            coords  = self.parent.getLocationCoordinates(context, location, None, axes, ignoreMissing=ignoreMissing)

            return dict(self.parent.flattenedTarget(coords))


    class MOVe (Background, MotionControlLeaf, LocationLeaf):
        '''
        Move to the specified target location and/or the specified target coordinates.

        If a predefined location name is given, its coordinates are used as default;
        however:
          - If specific axes names are given via the "-axis" option, only the
            corresponding location coordinates are used.
          - Any specific axis coordinates given will override the location defaults.
        '''

        def declareInputs (self):
            self.startInputs()
            self.addInput('ignorePause', type=bool, default=False, named=True,
                          description="Move even this motion subsystem is paused, "
                          "do not wait for it to be resumed.")

            self.addInput('force', type=bool, named=True, default=False,
                          description='Force move, even if already at position')

            self.addInput('context', type=str, default=None, named=True,
                          description='Location context, e.g. "FlowChip1".  If given, '
                          'the specified location name is first looked up within a '
                          'matching context, then with no context.')

            self.addInput('location', type=str, default=None, named=False,
                          description='Predefined target location.')

            self.addInput('axes', type=str, default=None, named=True,
                          description="In Comma-separated list of axes to move; "
                          "if not specified, all applicable axes are moved. ")

        def prerun (self, ignorePause=False, *args):
            self.parent.clearToMove(ignorePause=ignorePause)

        def postrun (self, *args):
            self.parent.endMove()

        def run (self, ignorePause=False, force=False, context=None, location=str, axes=None, *position):
            if axes:
                axes = self.motionBranch.getAxisSelection(axes.split(","))

            target = self.unflattenedInputs(position)
            return self.motionBranch.moveToLocation(context, location, target=dict(target), axes=axes, force=force)

        def next (self, *args):
            self.motionBranch.completeMoves(*args)


    class LOCation (Hidden, MOVe):
        '''
        Depricated.  Please use "MOVe" instead.
        '''


    class POSition_Query (MotionQueryLeaf, LocationLeaf):
        '''
        Return the effective position of the specified coordinate.
        If a location is defined at that position, its name is returned as well.
        '''

        def declareOutputs (self):
            MotionQueryLeaf.declareOutputs(self)
            self.addOutput('locations', type=str, named=True, default=None,
                           description="Comma-separated list of locations mapped to this position, if any")

        def run (self, steps=False, cached=False, location=False, *axes):
            axes = self.parent.getAxisSelection(axes) or self.getSupportedAxes()

            rawposition = self.parent.getRawPosition(axes=axes, cached=cached)
            position    = [ (axis.name, axis.fromRawPosition(pos, steps=steps))
                            for (axis, pos) in rawposition.items() ]

            if location:
                locations = self.parent.getLocationsOfCoordinates(rawposition, axes=axes)
                names = ','.join( [ self.parent.locationName(context, location)
                                    for (context, location) in locations ])

                poslist.append(('locations', names))

            return dict(poslist)



    class EffectivePOSition_Query (MotionControlLeaf, MotionQueryLeaf, LocationLeaf):
        '''
        Return the effective position of the specified coordinate.
        '''

        def __init__ (self, *args, **kwargs):
            MotionControlLeaf.__init__(self, *args, **kwargs)
            MotionQueryLeaf.init(self)

        def declareInputs (self):
            self.startInputs()
            self.addInput('ignoreMissing', type=bool, default=False, named=True)
            
            self.addInput('steps', type=bool, default=False, named=True)

            self.addInput('context', type=str, default=None, named=True,
                          description='Location context, e.g. "FlowChip1".  If given, '
                          'the specified location name is first looked up within a '
                          'matching context, then with no context.')
            
            self.addInput('location', type=str, default=None, 
                          description='Location name.')
            

        def addAxisOutputs (self, axis):
            self.addOutput(axis.name, type=int, default=None, named=True,
                           description='Axis %s step position'%(axis.name,))

        def removeAxisOutputs (self, axis):
            self.removeOutput(axis.name)


        def run (self, ignoreMissing=False, steps=False, context=None, location=None, *position):
            target = self.unflattenedInputs(position, steps=steps)

            if location:
                target = self.parent.getLocationCoordinates(context, location, target, ignoreMissing=ignoreMissing)
                
            return  dict([ (axis.name, pos)
                           for (axis, pos) in self.parent.effectiveTarget(target).iteritems() ])

        

    class REServation_Add (MotionBase.REServation_Add):
        '''
        Add a reservation spec where this motion subsystem requires exclusive access.
        If a reservation by the same name is defined in another motion subsystem,
        only one of these will be able to move within these respective zones at one time.

        This can be used to prevent robotic arms from crashing into each other,
        syringes from being bent while inserted into a movable stage underneath, etc.

    Example:
        STAGe:REServation+ Stage -X -Y
        FLUidics:ARM:REServation+ Stage -StageX -StageY

        FLUidics:ARM1:REServation+ Reagents -X -Theta
        FLUidics:ARM2:REServation+ Reagents -X -Theta
        '''

        def declareInputs (self):
            MotionBase.REServation_Add.declareInputs(self)
            self.addInput('parkLocation', type=str, default=None, named=True)

        def run (self, name, acquire, axes, parkLocation):
            self.parent.addReservation(name, acquire, axes, parkLocation)


    class REServation_Query (MotionBase.REServation_Query):
        '''
        Return axis coordinates associated with the specified reservation zone.
        '''

        def declareOutputs (self):
            MotionBase.REServation_Query.declareOutputs(self)
            self.addOutput('parkLocation', type=str, default=None, named=True)


        def run (self, ignoreMissing=False, name=str):
            active, names = MotionBase.REServation_Query.run(self, ignoreMissing, name)
            parkLocation = self.parent.parkLocations.get(name.lower(), None)
            return (active, names, parkLocation)


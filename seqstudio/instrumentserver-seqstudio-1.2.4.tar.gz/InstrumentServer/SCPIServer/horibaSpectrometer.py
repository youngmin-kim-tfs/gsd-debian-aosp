########################################################################
### FILE:	horibaSpectrometer.py
### PURPOSE:	IS interface to Horiba Spectrometers
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2015 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf             import Leaf, Observing, Administrative
from scpiExceptions       import NextReply
from scpiBranch           import branchTypes
from scanningSpectrometer import ScanningSpectrometer
from HoribaSpectrometer   import Spectrometer, \
    SCAN, IMAGE, TriggerModes, SignalModes, NUM_FITPARAMS, NUM_IFITPARAMS
    
import time

class HoribaSpectrometer (ScanningSpectrometer):
    '''Horiba Spectrometer branch'''

    SCAN          = SCAN
    IMAGE         = IMAGE
    TRIGGER_MODES = TriggerModes
    SIGNAL_MODES  = SignalModes
    PARAM_CLASSES = (P_FIT, P_IFIT, P_FLOAT) = ("fit", "ifit", "float")

    def __init__ (self, *args, **kwargs):
        ScanningSpectrometer.__init__(self, *args, **kwargs)
        self.device = Spectrometer()

    def getConfig (self):
        files  = ('spectrometer.ini', 'horibaspectrometer-product%d.ini'%(self.device.ProductID,))
        return self.getConfigInstance(files, casePreserving=False, literal=True)


    def listDevices (self, rescan=False):
        if not self.spectrometers or rescan:
            self.spectrometers = self.device.ListDevices()

        return self.spectrometers


    def waitForRestart (self, serial, timeout=15.0):
        time.sleep(timeout)
        self.connectDevice(rescan=True, serial=serial)


    def connectDevice (self, rescan=False, serial=None, productID=None):
        devices = self.listDevices(rescan)
        if not devices:
            raise self.NoDevices()

        for deviceinfo in devices:
            p, s, d = deviceinfo
            if s != serial != None:
                continue
            elif p != productID != None:
                continue
            else:
                break
        else:
            raise self.NotFound(serial=serial, product=product)

        try:
            self.device.ConnectToDevice(deviceinfo)
        except RuntimeError, e:
            raise self.SpectrometerFailure(message=str(e))

        self.loadParams()


    def loadParams (self):
        self.params.update([(self.P_FIT+str(i), v) for (i, v) in enumerate(self.device.GetFitParams())])
        self.params.update([(self.P_IFIT+str(i), v) for (i, v) in enumerate(self.device.GetIntensityFitParams())])
        self.params.update([(self.P_FLOAT+str(i), v) for (i, v) in enumerate(self.device.GetFloatSlots())])


    def saveParams (self):
        params = self.getParams(self.P_FIT)
        self.debug("Writing to Fit Parameters: %s"%(params,))
        self.device.SetFitParams(params)

        params = self.getParams(self.P_IFIT)
        self.debug("Writing to Intensity Fit Parameters: %s"%(params,))
        self.device.SetIntensityFitParams(params)

        params = self.getParams(self.P_FLOAT)
        self.debug("Writing to Float Slots: %s"%(params,))
        self.device.SetFloatSlots(params)


    def getParams (self, pclass):
        values = []
        while True:
            try:
                values.append(self.params[pclass+str(len(values))])
            except KeyError:
                break

        return tuple(values)


    class PARameter_Query (Observing, Leaf):
        '''
        Return the contents of the specified memory slot(s) of the spectrometer;
        if unspecified, all memory slots are assumed.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            names = []
            for pclass in self.parent.PARAM_CLASSES:
                names.extend([ pclass+str(i) for i in range(len(self.parent.getParams(pclass))) ])
            self.enums = tuple(names)

            self.setInput('class', type=self.parent.PARAM_CLASSES, default=None, named=True)
            self.setInput('slots', type=self.enums, repeats=(0, None))


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            for slot in self.enums:
                self.addOutput(slot, type=float, default=None)


        def run (self, Class=None, *slots):
            if slots:
                params = [ self.parent.params[self.enums[s]] for s in slots ]
            else:
                if Class is not None:
                    classes = [ self.parent.PARAM_CLASSES[Class] ]
                else:
                    classes = self.parent.PARAM_CLASSES

                params = []
                for pclass in classes:
                    params.extend(self.parent.getParams(pclass))

            return tuple(params)
        


    class PARameter_Set (Administrative, Leaf):
        '''
        Modify the contents of the specified memory slot(s) in the spectrometer.
        WARNING: This should normally only be done in manufacturing.
        '''


        def declareInputs (self):
            self.startInputs()

            names = []
            for pclass in self.parent.PARAM_CLASSES:
                names.extend([ pclass+str(i) for i in range(len(self.parent.getParams(pclass))) ])
            self.enums = tuple(names)

            for slot in self.enums:
                self.addInput(slot, type=float, named=True, default=None)


        def run (self, *slots):
            if slots:
                for name, value in zip(self.enums, slots):
                    if value is not None:
                        self.parent.params[name] = value

                self.parent.saveParams()



branchTypes['DataAcquisition'] = HoribaSpectrometer
branchTypes['HoribaSpectrometer'] = HoribaSpectrometer


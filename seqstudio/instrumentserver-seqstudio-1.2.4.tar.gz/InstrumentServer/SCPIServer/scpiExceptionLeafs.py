########################################################################
### FILE:	scpiExceptionLeafs.py
### PUPROSE:	TRY command
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBranch     import Branch
from scpiLeaf       import Leaf, Controlling, Observing, Public, CommandWrapper
from scpiExceptions import Exc, Abort, Error, RunError, UserError, InternalError, NextReply, SessionControl, scpiException
from scpiSession    import SYNC, ASYNC
from threading      import currentThread, enumerate as enumerateThreads
from threadControl  import ControllableThread
from subscription   import debug, info, warning
from sys            import exc_info



class ExceptionLeaf (Leaf):
    class NoError (RunError):
        '''No error was previously captured in this excution context'''

    def setLastError (self, context, error):
        context.lastError = error

    def clearLastError (self, context):
        try:
            del context.lastError
        except AttributeError:
            pass

    def getLastError (self, context, ignoreMissing=False):
        try:
            return context.lastError
        except AttributeError:
            if not ignoreMissing:
                raise self.NoError()

    def raiseLastError (self, context, ignoreMissing=False):
        try:
            e = context.lastError
        except AttributeError:
            if not ignoreMissing:
                raise self.NoError()
        else:
            e.throw()



class TRY (Observing, CommandWrapper, ExceptionLeaf):
    '''
    Try executing each command block (list of commands) in order,
    until one succeeds, or every command block has been tried.
    Any exception that still occurs in the last command block will
    propagate out to the caller, unless the "-keepError" option is given.

    The following substitutions take place within each command block
    but the first prior to execution, based on the exception that
    occured in while executing the previous command list:

       $aborted$   is True if command block was aborted
       $internal$  is True if this was an internal error
       $transient$ is True if this is a transient exception
       $error$     is set to the error name (id)
       $arguments$ is set to a sequence keys/values associated with the error
       $context$   is the "call path" resulting in the error
       $message$   is a human readable message indicating the nature of the error

       $text$      is equivalent to:
                   [$error$] $arguments$ -> $message$

       $fulltext$  is the full representation of the error, usually equivalent to:
                   [$error$] $arguments$ -> $context$ $message$

    For backwards compatibility to earlier IS releases, corresponding
    local variables are also set; for instance, "${error}" is
    equivalent to "$error$".  Note that these are cleared once the
    "TRY" command ends.

Example:
  * Handle errors that occur during execution of a file operation:

       TRY \\
          <<<FILE:READ? myfile>>> \\
          <<<WARNING "Could not read 'myfile': [$error$] [$message$]">>>

See also:
   * ERRor   - Raise an error, or re-raise the previous error.

    '''

    delegateEstimation = True


    def declareInputs (self):
        Leaf.declareInputs(self)

        self.setInput('inline', type=bool, named=True, default=False,
                      description='Run within the parent execution context '
                      '(i.e., command scope, exception space, etc), '
                      'even if invoked within a different branch.')
        self.setInput('catchAbort', type=bool, default=False, named=True,
                      description="Normally 'Aborted' exceptions are allowed through; this option "
                      "catches even those")
        self.setInput('keepError', type=bool, default=False, named=True,
                      description="Keep any error that may occur, so that it may be re-raised "
                      "later in the sesssion, outside the TRY statement.")
        self.setInput('commandlist', type=tuple, repeats=(1, None))


    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('reply', type=tuple, repeats=(0, None))

    def setError (self, _context, error, substitutions):
        context  = error.format(showID=False, showArgs=False, showContext=True, showText=False)
        message  = error.format(showID=False, showArgs=False, showContext=False)
        errtext  = error.format(showID=True, showArgs=True, showContext=False)
        fulltext = error.format(showID=True, showArgs=True, showContext=True)
        name     = error.name

        substitutions.update(aborted=isinstance(error, Abort),
                             internal=isinstance(error, InternalError),
                             transient=error.transient,
                             error=name,
                             arguments=error.args,
                             context=context,
                             message=message,
                             text=errtext,
                             fulltext=fulltext)

        self.setLastError(_context, error)
        return error

    def run (self, _session, _context, inline=False, catchAbort=False, keepError=False, *commandlist):
        substitutions = {}

        if inline:
            subcontext = _context
        else:
            subcontext = _context.clone(scope=self.parent)

        try:
            for option, text, raw in commandlist:
                try:
                    for k, v in substitutions.iteritems():
                        text = text.replace(k.join("$$"), str(v))
                        
                    subcontext.data.update(substitutions)
                    return _session.runBlock(text, subcontext)

                except Abort, e:
                    if catchAbort:
                        currentThread().clearAbort()
                        self.setError(subcontext, e, substitutions)
                    else:
                        raise

                except SessionControl:
                    raise

                except Exc, e:
                    self.setError(subcontext, e, substitutions)
            else:
                if not keepError:
                    self.raiseLastError(subcontext)
        finally:
            if keepError:
                error = self.getLastError(subcontext, ignoreMissing=True)
                if error:
                    self.setLastError(_context, error)
                else:
                    self.clearLastError(_context)


class InternalERRor (Observing, Leaf):
    '''
    Generate an internal Python error.  Useful only for testing.
    '''

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('asynchronous', type=bool, named=True, default=False,
                      description='Raise error asynchronously')

    def run (self, asynchronous=False, text=""):
        if asynchronous:
            raise NextReply(self, self.run, (False, text), {})
        else:
            raise Exception(text)


class ERRor (Observing, ExceptionLeaf):
    '''
    Generate an error message.  Useful in macros.

    This command can be used without any arguments within a TRY statement,
    starting at the 2nd clause, to re-raise any previous errors that occured
    in the previous clause.
    '''

    def run (self, _context, ignoreMissing=False, id='', *message, **options):
        if id or message:
            message = list(message)
            if not id and message and (message[0][0:1] + message[0][-1:] == "[]"):
                id = message.pop(0)[1:-1]

            while message and message[0] == Error.contextSeparator:
                del message[0]

            if id.lower() == "aborted":
                raise Abort()
            else:
                raise UserError(id or "UndeclaredError", ' '.join(message), **options)
        else:
            self.raiseLastError(_context, ignoreMissing)



class ERRor_Query (Observing, ExceptionLeaf):
    '''
    Return any error captured in a previous TRY clause.
    '''

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('withArgs', type=bool, named=True, default=False)
        self.setInput('withContext', type=bool, named=True, default=False)

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('id', type=str, named=True, default=None)
        self.addOutput('arguments', type=tuple, repeats=(0, None))


    def run (self, _context, withArgs=False, withContext=False):
        e = self.getLastError(_context, ignoreMissing=True)
        if e:
            outputs = [ e.name ]
            if withArgs:
                outputs.extend(e.getArgs())
            outputs.append(('message',
                            e.format(showID=False, showArgs=False, showContext=withContext)))
            return tuple(outputs)


class ERRor_Clear (Observing, ExceptionLeaf):
    '''
    Clear any captured error from this session.
    '''

    def run (self, _context):
        self.clearLastError(_context)


class ERRor_Exists (Observing, ExceptionLeaf):
    '''
    Return True if an error has been previously captured in this session
    '''

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('exists', type=bool)

    def run (self, _context):
        return bool(self.getLastError(_context))


# class ERRor_List (Observing, Leaf):
#     '''
#     Return a list of error IDs and text
#     '''
#
#     def declareOutputs (self):
#         Leaf.declareOutputs(self)
#         self.addOutput("errors", type=list)
#
#
#     def run (self, _session):
#         classmap = self.getErrors(_session)
#         self.addErrors(classmap, self.parent)
#         errlist = classmap.values()
#         errlist.sort()
#         return errlist
#
#
#     def addErrors (self, classmap, scope):
#         classmap.update(self.getErrors(scope))
#
#         if scope.istype(Branch):
#             for subbranch in scope.listChildren():
#                 child = scope.getChild(subbranch, allowMissing=True)
#                 if child:
#                     self.addErrors(classmap, child)
#
#
#     def getErrors (self, obj):
#         d   = {}
#
#         for name in dir(obj):
#             cls = getattr(obj, name)
#             try:
#                 if issubclass(cls, RunError):
#                     d[cls] = '[%s] %s'%(cls.__name__, cls.__doc__)
#             except TypeError:
#                 pass
#
#         return d


    ########################################################################
    ### Get list of error classes

#    def getErrors (self):
#        d = {}
#        for name, cls in (self.__class__.__dict__ or {}).iteritems():
#            if isinstance(cls, type) and issubclass(cls, RunError):
#                d[name] = cls
#
#        return d




class ABORt (Controlling, Leaf):
    '''
    Abort this thread and optionally its subthreads.
    '''
    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('recursive', type=bool, named=True, default=False,
                      description="Recursively abort threads started from this thread")


    def run (self, recursive=False):
        currentThread().abort(recursive=recursive)



class SUSPend (Controlling, Leaf):
    '''
    Suspend this thread and optionally its subthreads.
    '''

    def run (self, recursive=False):
        currentThread().suspend(recursive=recursive)



class PASS (Public, Leaf):
    '''
    Do nothing, but do it well.

    Useful as the last argument of a "TRY" statement, to
    prevent any errors from prior statements from being raised.
    '''

    def run (self):
        pass

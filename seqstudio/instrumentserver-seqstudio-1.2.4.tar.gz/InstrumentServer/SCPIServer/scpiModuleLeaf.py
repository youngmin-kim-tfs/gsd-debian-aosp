########################################################################
### FILE:	scpiModuleLeaf.py
### PURPOSE:	Run a command module
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiExceptions     import RunError, NextReply
from scpiLeaf           import Leaf, CommandWrapper, Observing
from scpiSession        import MacroSession, ModuleSession, ASYNC, SYNC
from scpiFilesystemBase import FilesystemLeaf
from scpiFileContexts   import OP_READ, P_READ
from os                 import getenv, pathsep
from os.path            import isfile, abspath, splitext, sep
from cStringIO          import StringIO
from subscription       import warning, info
from threadControl      import invocation


class MODule (Observing, FilesystemLeaf):
    '''Execute commands from a module file.

    The supplied filename must either contain a valid location context
    and/or folder name, or exist in one of the directories specified
    in the module search path.  At startup, this search path is
    initialized from the MODULEPATH environment variable, or if that
    variable does not exist, is set to "." (i.e. the working directory
    from which the server was started).
    '''
    delegateEstimation = True


    def declareOutputs (self):
        FilesystemLeaf.declareOutputs(self)
        self.addOutput('reply', type=tuple, repeats=(0, None))

    def run (self, _session, _context, skipTriggers=False, asynchronous=False, filename=str):
        cxtname, path = self.splitLocation(filename, None)
        contexts = set()

        if cxtname is not None or sep in path:
            ### Open module file from within location context
            cxt = self.openContext(cxtname, _session, P_READ)
            contexts.update(self.enterContexts((cxt,), not skipTriggers))
            try:
                module = cxt.open(path, mode=OP_READ)
            except Exception, e:
                self.exitContexts(contexts)
                raise
        else:
            ### Allow ModuleSession to search for filename in MODULEPATH
            module = filename

        try:
            moduleSession = ModuleSession(module=module, 
                                          description='module %r'%filename,
                                          parent=_session)
        except Exception, e:
            self.exitContexts(contexts, not skipTriggers)
            raise

        if asynchronous:
            raise NextReply(self,
                            self.next,
                            (moduleSession, _context, contexts, skipTriggers),
                            {})
        else:
            return self.next(moduleSession, _context, contexts, skipTriggers)


    def next (self, session, _context, contexts, skipTriggers):
        try:
            return session.handle(self.parent, _context.invocation)
        finally:
            self.exitContexts(contexts, not skipTriggers)



class MODule_Query (Observing, FilesystemLeaf):
    '''
    Search folders in MODULEPATH for the specified filename, and return its absolute path.
    '''
    def declareOutputs (self):
        FilesystemLeaf.declareOutputs(self)
        self.addOutput('pathname', type=str, default=None)


    def run (self, _session, skipTriggers=False, ignoreMissing=False, filename=str):
        cxtname, path = self.splitLocation(filename, None)

        if cxtname is not None or sep in path:
            try:
                with self.openLocation(filename, _session, P_READ, not skipTriggers) as loc:
                    loc.stat()
                    return loc.localpath()
            except EnvironmentError, e:
                if not ignoreMissing:
                    raise
        else:
            return ModuleSession.filepath(filename, ignoreMissing)


class RUN (Observing, CommandWrapper, Leaf):
    '''
    Run an inline (unnamed) macro.  Essentially, run a sequence of
    commands until completion, or until an error occurs.

    This may be useful to encapsulate a list of commands in a single
    statement - for instance, as argument for the REPeat and/or FLAG
    commands:

        REPeat -counter=MyCounter 50 RUN <multiline>
            VAR? MyCounter
            PUBLish Count $@
            COMMand ...
        </multiline>
    '''

    def declareInputs (self):
        Leaf.declareInputs(self)

        self.setInput('inline', type=bool, named=True, default=False,
                      description='Run within the parent execution context '
                      '(i.e., command scope, exception space, etc), '
                      'even if invoked within a different branch.')

        self.setInput('synchronous', type=bool, named=True,  default=False)
        self.setInput('asynchronous', type=bool, named=True,  default=False)
        self.setInput('commands',     type=str,  named=False, default=None)

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('reply', type=tuple, repeats=(0, None))

    def run (self, _session, _context, inline, synchronous, asynchronous, commands):
        if commands:
            runmode  = (ASYNC, SYNC)[synchronous]

            if not inline:
                _context = _context.clone(scope=self.parent)

            options = dict(input=commands, context=_context,
                           nextReply=runmode,
                           nextCommand=runmode,
                           catchReturn=inline)

            if asynchronous:
                raise NextReply(self, _session.runBlock, (), options)
            else:
                return _session.runBlock(**options) 

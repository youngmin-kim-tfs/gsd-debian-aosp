########################################################################
### FILE:	scpiTop.py
### PURPOSE:	Implementation of a top level branch (trunk).
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch import FullBranch
from scpiTracker    import TrackerBranch
from scpiBase       import Base

import schedule

class Top (FullBranch):
    def __init__ (self):
        Base.top = self
        FullBranch.__init__(self, name='Top', parent=None)
        self.addShutDownAction(schedule.shutdown)
        self.debugTopic = 'TOP'

        schedule.start()

    def shutdown (self):
        for (method, args, kwargs) in self.shutdownHook:
            method(*args, **kwargs)

        self.persistentData.commit()


    from scpiHelpTopics import \
         OVERVIEW, COMMANDS, REPLIES, \
         ARGUMENTS, SUBSTITUTIONS, \
         QUOTATIONS, MACROS, BOOLEANS, \
         FILESYSTEM, STATES

    from scpiSystemBranch    import SYSTem
    from scpiPythonBranch    import PYthon
    from scpiStringBranch    import STRing
    from scpiSessionBranch   import SESSion
    from scpiMTSSBranch      import MTSS
    from scpiLoggerBranch    import LOGGer
    from scpiTaskBranch      import TASK
    from scpiStateBranch     import State
    from scpiIdleBranch      import IDLE
    from scpiFileBranch      import FILe
    from scpiMessageBranch   import MESSage
    from scpiPollingBase     import POLL
    from scpiProfilingLeafs  import RunTime_Query
    from scpiQuitLeaf        import QUIT, SHUTdown
    from scpiWaitLeaf        import WAIT_Set, WAIT_Query, SPEED_Set, SPEED_Query
    from scpiQueueBranch     import QUEue
    from scpiLinking         import SCPI
    from scpiResourceBranch  import LOCK
    from scpiExceptionLeafs  import InternalERRor, ERRor, ERRor_Clear, ERRor_Query, ERRor_Exists

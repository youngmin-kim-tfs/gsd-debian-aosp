########################################################################
### FILE:	scpiRepeatLeaf.py
### PURPOSE:	Repeat a scpi command
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf         import Asynchronous, Leaf, CommandWrapper, \
    Administrative, Controlling, Observing
from scpiExceptions   import RunError, NextReply, Break
from scpiSession      import SYNC, ASYNC, NestedSession
from scpiVariableLeaf import VariableLeaf
from schedule         import sleep, scheduleList, schedule, unschedule, \
    getUptime, getTask, isStarted, TaskAlignment, A_NONE
from data             import DynamicData



class RepeatLeaf (CommandWrapper, Leaf):
    '''
    Abstract superclass for REPeat and SCHedule.
    '''
    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('counter',
                      description='Name of a variable that will be used to'
                      ' hold the current repeat index')

        self.setInput('start',
                      description='Initial value of the optional counter')

        self.setInput('step',
                      description='Increment that will be added to the counter'
                      ' at each command invocation')

        self.setInput('count',
                      range=(0, None),
                      type=int,
                      description=
                      'Number of times to invoke the specfied command.')

        self.setInput('commands', type=str, repeats=(1, None),
                      description='commands to invoke')


    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('reply', type=tuple, repeats=(0, None))



class REPeat (Observing, RepeatLeaf):
    '''
    Repeat the specified command the specified number of times.

    If "counter" is specified, a global variable by that name will be
    created to hold the current iteration index.  At first invocation,
    the this variable is set to the value of the "start" argument;
    thereafter, it increments by "step" at each iteration.  Once the
    repeat loop ends, the counter variable is deleted.

    Each iteration will not start until the prior iteration has
    completed, even in the case of an asynchronous command.
    '''

    def declareInputs (self):
        RepeatLeaf.declareInputs(self)
        self.setInput('inline', type=bool, named=True, default=False,
                      description='Run within the parent execution context '
                      '(i.e., command scope, exception space, etc), '
                      'even if invoked within a different branch.')

        self.setInput('synchronous', type=bool, named=True, default=False,
                      description='Wait for completion of all commands')

        self.setInput('interval',
                      range=(0.0, None),
                      units='seconds',
                      format='%.1f',
                      description='Number of seconds to elapse between '
                      'each invocation of "command" (start to start).')

    def run (self, _session, _context,
             inline=False, synchronous=False, counter="",
             start=0, step=1, interval=0.0, count=int, *commands):
             

        response = None
        runmode  = (ASYNC, SYNC)[synchronous]

        starttime = getUptime()
        if not inline:
            _context = _context.clone(scope=self.parent)

        try:
            for iteration in range(count):
                if iteration and interval:
                    sleep(max(0, starttime + interval*iteration - getUptime()))

                if counter:
                    index = start + iteration*step
                    _context.data[counter] = str(index)

                _session.runBlock(commands, _context, nextReply=runmode, nextCommand=runmode)
        except Break, e:
            remaining = e.args[0]-1
            if remaining:
                raise Break(remaining)

        finally:
            if counter:
                _context.data.pop(counter, None)


    def defaultEstimate (self, _session, _context,
                         inline, synchronous, counter,
                         start, step, interval, count, *commands):

        try:
            for index in xrange(start, start+(count*step), step):
                if counter:
                    _context.data[counter] = str(index)

                _session.runBlock(commands, context)
        finally:
            if counter:
                _context.data.pop(counter, None)


class SCHedule_Add (Controlling, RepeatLeaf):
    '''
    Schedule the specified command for execution at the given interval.

    If "count" is specified, the command is repeated that number of times.
    Otherwise, the command repeats forever, or until unscheduled using
    "SCHedule-".  The specified handle can be used for this purpose.

    If "counter" is specified, a global variable by that name will be
    created to hold the current iteration index.  At first invocation,
    the this variable is set to the value of the "start" argument;
    thereafter, it increments by "step" at each iteration.  Once the
    repeat loop ends, the counter variable is deleted.

    Each iteration will not start until the prior iteration has
    completed, even in the case of an asynchronous command.
    '''

    class ScheduledTaskExists (RunError):
        'A task named %(name)s is already scheduled'

    def declareInputs (self):
        RepeatLeaf.declareInputs(self)

        self.setInput('count',
                      range=(0, None),
                      type=int,
                      description=
                      'Number of times to invoke the specfied command. '
                      'If not specified, the scheduler will run forever, or '
                      'until cancelled with "SCHedule-".')

        self.setInput('delay', type=float, units='seconds',
                      description='Delay before the first invocation. '
                      'If "align" is also set, the actual delay may be larger.')

        self.setInput('align', type=TaskAlignment, default=A_NONE, named=True,
                      description="Align scheduling of this task according to "
                      "local time or UTC")

        self.setInput('waitStart', type=bool, named=True, default=False,
                      decription='Wait for the first invocation of the scheduled task '
                      'before returning')

        self.setInput('interval',
                      range=(0.0, None),
                      units='seconds',
                      format='%.1f',
                      description=
                      'Number of seconds to elapse between each invocation'
                      ' of "command" (start to start).')

        self.setInput('commands', type=str, repeats=(1, None))


    def run (self, _session, _context, 
             synchronous=False, replaceExisting=False,
             counter="", start=0, step=1, count=None,
             retries=0, align=A_NONE, delay=0.0, suspendable=False,
             waitStart=False, handle=str, interval=float, *commands):

        if not replaceExisting and handle in scheduleList():
            raise self.ScheduledTaskExists(name=handle)

        if counter and start is not None:
            counters = { counter: start }
        else:
            counters = None

        session = NestedSession(parent=_session,
                                input=commands,
                                description="Scheduler %r"%(handle,))

        context = _context.clone(session=session, scope=self.parent)

        schedule(handle, interval,
                 self.runTask,
                 (context, commands, counters, step),
                 align=align, delay=delay, count=count, retries=retries,
                 synchronous=synchronous, suspendable=suspendable, waitstart=waitStart)


    def runTask (self, context, commands, counters, step):
        if counters is not None:
            counter, index = counters.popitem()
            context.data[counter] = str(index)

        context.session.runBlock(commands, context,
                                  nextReply=ASYNC, nextCommand=ASYNC, catchReturn=True)

        if counters is not None:
            context.data.pop(counter, None)
            counters[counter] = index + step



class SCHedule_Query (Observing, Leaf):
    '''
    Return information about a repeat task
    '''

    class NoSuchTask (RunError):
        'There is no scheduled task named %(name)r.'

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('counter', type=str, named=True, default=None)
        self.addOutput('index', type=int, named=True, default=None)
        self.addOutput('step', type=int, named=True, default=None)
        self.addOutput('count', type=int, named=True, default=None)
        self.addOutput('retries', type=int, named=True)
        self.addOutput('align', type=TaskAlignment, named=True)
        self.addOutput('delay', type=float, named=True, default=0.0)
        self.addOutput('suspendable', type=bool, named=True)
        self.addOutput('started', type=bool, named=True)
        self.addOutput('interval', type=float, named=True)
        self.addOutput('commands', type=str, split=' ')

    def run (self, ignoreMissing=False, handle=str):
        try:
            (handle, interval, method, args, kwargs,
             count, retries, align, delay, suspendable) = getTask(handle)
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchTask(name=handle)
        else:
            started = isStarted(handle)
            (context, commands, counters, step) = args

            if counters:
                counterspec, = counters.items()
                counter, index =  counterspec
            else:
                counter, index = None, None

            return (counter, index, step, count, retries, align, delay,
                    suspendable, started, interval, commands)



class SCHedule_Remove (Controlling, RepeatLeaf):
    '''
    Unschedule a command that has previously been scheduled using
    "SCHedule+".
    '''
    class NoSuchTask (RunError):
        'There is no scheduler by the name %(name)s'

    def declareInputs (self):
        Leaf.declareInputs(self)

    def run (self, wait=False, ignoreMissing=False, handle=str):
        try:
            unschedule(handle, wait=wait)
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchTask(name=handle)



class SCHedule_Enumerate (Observing, RepeatLeaf):
    '''
    List schedulers that are currently running
    '''
    def declareInputs (self):
        Leaf.declareInputs(self)

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('handle', type=str, repeats=(0, None))

    def run (self):
        handles = [ key for key in scheduleList() if isinstance(key, str) ]
        handles.sort()
        return tuple(handles)


class SCHedule_Exists (Observing, Leaf):
    '''
    List schedulers that are currently running
    '''
    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('handle', type=str)

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('exists', type=bool)

    def run (self, handle=str):
        return handle.lower() in [ key.lower() for key in scheduleList() ]


class ITERate (Observing, CommandWrapper, VariableLeaf):
    '''
    Run the specified commands for each argument in "sequence" list.
    '''

    delegateEstimation = True

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('inline', type=bool, named=True, default=False,
                      description='Run within the parent execution context '
                      '(i.e., command scope, exception space, etc), '
                      'even if invoked within a different branch.')

        self.setInput('counter',
                      type=str, 
                      description='Name of a variable that will'
                      ' hold the current repeat index')

        self.setInput('start',
                      type=int, 
                      description='Initial value of the optional counter')

        self.setInput('step',
                      type=int, 
                      description='Increment that will be added to the counter'
                      ' at each command invocation')

        self.setInput('key',
                      type=str, 
                      description='Name of a variable that will hold'
                      ' each keyword from the sequence as it is traversed')

        self.setInput('value',
                      type=str, 
                      description='In conjunction with "-dictionary", this'
                      ' specifies the name of a variable that will hold'
                      ' the value of each item of the given dictionary'
                      ' as it is traversed.')

        self.setInput('delimiter',
                      type=str, 
                      default=None,
                      description='Separator between each item in the sequence. '
                      'If unset, the sequence will split similar to command arguments. '
                      'If set to an empty string, the sequence will be traversed '
                      'one character at a time.')

        self.setInput('includeEmpty',
                      type=bool,
                      default=False,
                      description='Iterate over every item in the list, '
                      'even empty ones')

        self.setInput('synchronous', type=bool, named=True, default=False,
                      description='Wait for completion of all commands')

        self.setInput('variable', type=bool, named=True, default=False,
                      description='The sequence is supplied as the name of '
                      'a variable containing a list of items over which to '
                      'iterate.')

        self.setInput('dictionary', type=bool, named=True, default=False,
                      description='The sequence is supplied as the name of '
                      'a dictionary containing a list of items over which '
                      'to iterate.  The "-key" and "-value" options can '
                      'be used to specify a variable that will contain the '
                      'dictionary key and value, respectively.')

        self.setInput('sequence',
                      type=str,
                      description='List of items over which to iterate')

        self.setInput('commands', type=str, repeats=(1, None),
                      description='Commands to invoke for each item in sequence')


    def run (self, _session, _context,
             inline=False, counter=None, start=0, step=1,
             key=None, value=None, delimiter=None,
             includeEmpty=False, synchronous=False,
             variable=False, dictionary=False,
             sequence=str, *commands):
             

        self.checkConflictingOptions(dictionary=dictionary, variable=variable, delimiter=delimiter is not None)
        self.checkConflictingOptions(dictionary=dictionary, counter=counter is not None)
        self.checkConflictingOptions(variable=variable, value=value is not None)

        runmode = (ASYNC, SYNC)[synchronous]

        if not inline:
            _context = _context.clone(scope=self.parent)

        if dictionary:
            scope, data, d = self.dataProxy(None, _context.data, sequence, dict, branch=_context.scope)
            sequence = d.items()

        else:
            if variable:
                scope, data, values = self.dataProxy(None, _context.data, sequence, list, branch=_context.scope)
            elif delimiter is None:
                text, args = _context.session.expandArgs(sequence, context=_context)
                values = [v for o, v, r in args]
            elif delimiter == "":
                values = list(sequence)
            else:
                values = sequence.split(delimiter)

            sequence = [(v,v) for v in values]

        if not includeEmpty:
            sequence = [(k,v) for (k,v) in sequence if v]

        try:
            for index, item in enumerate(sequence):
                k, v = item
                if counter:
                    _context.data[counter] = str(start + (step * index))
                if key:
                    _context.data[key] = k
                if value:
                    _context.data[value] = v
                    
                _session.runBlock(commands, _context, nextReply=runmode, nextCommand=runmode)

        except Break, e:
            remaining = e.args[0]-1
            if remaining:
                raise Break(remaining)

        finally:
            if counter:
                _context.data.pop(counter, None)
            if key:
                _context.data.pop(key, None)
            if value:
                _context.data.pop(value, None)

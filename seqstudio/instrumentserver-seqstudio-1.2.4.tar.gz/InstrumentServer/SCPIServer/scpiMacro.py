########################################################################
### FILE:	scpiMacro.py
### PURPOSE:	Macro support
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase        import Base, addCommandType
from scpiLeaf        import Leaf, Asynchronous, Singleton, \
    Controlling, Observing, Public, FULL, CommandWrapper, EstimationCriteria
from scpiParameter   import Missing, ArgTuple, autoType
from scpiDynamicBase import Dynamic, DynamicCommandLeaf
from scpiExceptions  import CommandError, RunError
from scpiSession     import MacroSession, AccessLevels, \
     OBSERVER, CONTROLLER, SYNC, ASYNC, RAISE
from cStringIO       import StringIO
from commandParser   import parser, QUOTE_NEVER, QUOTE_ALWAYS, QUOTE_AUTO, CookedValue
from subscription    import warning, info, debug
from data            import DynamicData


class Macro (Dynamic, CommandWrapper, Leaf):
    ''

#    '''
#    This is an undocumented macro.
#    '''

    class RepeatSuffixBeforeLast (CommandError):
        "Macro argument %(arg)r cannot come after repeated %(type)s argument %(previous)r"

    class MissingArgumentName (CommandError):
        'Missing argument name'

    class NonNumericEstimation (RunError):
        'Macro %(macro)r custom estimation routine returned non-numeric result for key %(key)r: %(value)r'

    TypeName = 'macro'
    requiredAccess = FULL

    def __init__ (self, *args, **kwargs):
        Leaf.__init__(self, *args, **kwargs)
        self.estimationRoutines = {}


    def declareInputs (self):
        self.startInputs()
        self.addInput('_session')
        self.addInput('_context')
        self.addInput('_command')


    def declareMacroInputs (self):
        optionals = []
        repeated  = [None, None]
        repeatSuffix = {"*":(0, None), "+":(1, None)}

        for arg in self.arguments:
            try:
                name, value = arg.split('=', 1)
                default = (name, value, arg)
            except ValueError:
                name, default = arg, Missing

            suffix = name[-1:]
            try:
                repeats = repeatSuffix[suffix]
            except KeyError:
                repeats = None
                named   = False
                if not name.strip("$@"):
                    raise self.MissingArgumentName()
            else:
                named = (name[-2:] == suffix*2)
                if not name[:1] in ("$@"):
                    name = name.rstrip(suffix)

            if repeats or default is Missing:
                ### If this is a required argument, all prior
                ### optional arguments automatically become 'named'
                while optionals:
                    self.setInput(optionals.pop(), named=True)

            else:
                ### Keep track of this optional argument, in case we later
                ### need to convert it to a 'named' argument as well.
                optionals.append(name)


            #form = (str, basestring)[name.startswith('@')]
            if repeated[named]:
                raise self.RepeatSuffixBeforeLast(arg=name, previous=repeated[named].name,
                                                  type=('positional', 'named')[named])

            argtype = (tuple,str)[named]
            param = self.addInput(name, type=argtype, form=None, named=named, default=default, repeats=repeats)
            if repeats:
                repeated[named] = param

        self.varParam, self.varOptParam = repeated



    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('reply', type=tuple, repeats=(0, None))

    def substituteArgs (self, args, kwargs, text=None):
        if text is None:
            text = self.text or ""

        variables = DynamicData()
        varindex  = None

        for index, param in enumerate(self.getInputs()):

            if not param.repeats:
                name, value, raw = args[index]

                if name is not None and value is None:
                    value = str(True)

            else:
                if varindex is None:
                    varindex = index

                if param.name[0] == '@':
                    value = parser.collapseArgs(args[varindex:], tag='argument')

                elif param.name[0] == '$':
                    value = ' '.join([ value for (opt, value, raw) in args[varindex:] ])

                elif param.named:
                    ## Named variable inputs
                    value = DynamicData([(k,v) for (k,v,r) in args[varindex:] if k])
                    value.update(kwargs)

                elif self.varOptParam:
                    ## Positional variable inputs, in a macro that also takes named variable inputs
                    value = [v for (k,v,r) in args[varindex:] if not k]

                else:
                    ## Since this macro does not take named variable inputs, pass on the arguments
                    ## including initial option name ("[-option[=]][value]").
                    value = parser.collapseParts(args[varindex:], tag=None, quoting=QUOTE_NEVER)

            if param.name[0] in '$@':
                text = text.replace(param.name, value)
            else:
                variables[param.name] = value

        return text, variables

    def estimate (self, _session, _context, _parts, **options):
        methodname = _context.estimationMethod
        try:
            routine = self.estimationRoutines[methodname]
        except KeyError:
            return Leaf.estimate(self, _session=_session, _parts=_parts, _context=_context, **options)
        else:
            _session.checkAccess(self.requiredAccess)
            args, kwargs, argmap = self.parseInputs(_parts, _session=_session, _context=_context, **options)
            self.customEstimate(routine, *args)


    def customEstimate (self, routine, _session, _context, _command, *args, **kwargs):
        text, parameters = self.substituteArgs(args, kwargs, routine)

        context=_context.clone(scope=self.parent, invocation=None, data=DynamicData(parameters))
        outputs = _session.runBlock(text, context, nextReply=SYNC, nextCommand=SYNC, catchReturn=True)

        for item in outputs or ():
            try:
                key, cooked, value = item
            except ValueError:
                key, cooked = item

            value = autoType(cooked)

            if isinstance(value, (int, float)):
                _context.estimationResults[key] = _context.estimationResults.get(key, 0)  + value

            elif key and value:
                raise self.NonNumericEstimation(macro=self.commandPath(), key=key, value=cooked)


    def defaultEstimate (self, _session, _context, _command, *args, **kwargs):
        text, parameters = self.substituteArgs(args, kwargs)
        context = _context.clone(data=DynamicData(parameters), scope=self.parent)
        return _session.runBlock(text, context)


    def run (self, _session, _context, _command, *args, **kwargs):
        text, parameters = self.substituteArgs(args, kwargs)
        return self.runMacro(_session, _context, _command,
                             text=text,
                             scope=self.parent,
                             parameters=parameters)


    def runMacro (self, _session, _context, _command, text, scope, parameters):
        session = MacroSession(input=text, parent=_session, access=self.access, 
                               description='macro %r'%_command)
        context = _context.clone(data=DynamicData(parameters), scope=scope)
        return session.handleInput(text, context, nextReply=self.async)

    def getSyntax (self, margin, columns, defaults=None):
        syntax      = Base.getSyntax(self, margin, columns, defaults=defaults)
        stxmargin   = len(syntax[-1]) + 1

        for param in self.getInputs():
            self.wrapText(syntax,
                          self.argSyntax(param, param.name.strip('$@+*'), defaults=defaults),
                          stxmargin,
                          columns)

        return syntax


    def argSyntax (self, param, name=None, defaults=None):
        if name is None:
            name = param.name

        if defaults is None:
            defaults = self.defaults

        named   = param.named or (name in self.defaults)
        default = defaults.get(name, param.default)

        if not default in (None, Missing):
            if isinstance(param.type, ArgTuple):
                default = default[CookedValue]

            if default:
                default = parser.protectString(default, tag='', quoting=QUOTE_AUTO)

        if named:
            if not default or default is Missing:
                value = name.join("<>")
            else:
                value = default

            if param.repeats:
                argsyntax = "-<%s>=%s"%(name, value)
            else:
                argsyntax = "-%s=%s"%(name, value)

        else:
            if not default or default is Missing:
                argsyntax = name.join("<>")
            else:
                argsyntax = "<%s=%s>"%(name, default)

        if param.repeats:
            rmin, rmax = param.repeatRange()
            if not rmin:
                default = None

        if default is not Missing:
            argsyntax = '[%s]'%(argsyntax,)

        if param.repeats:
            argsyntax += " ..."

        return argsyntax


    def getProperties (self):
        props = Leaf.getProperties(self)
        props.append(('Access',       AccessLevels[self.access]))
        props.append(('ModifyAccess', AccessLevels[self.modifyAccess]))
        return props


    def formatOutputs (self, outputs, alwaysNamed=False, raw=False):
        return outputs


class InlineMacro (Macro):
    def runMacro (self, _session, _context, _command, text, scope, parameters):
        #context = _context.clone(data=DynamicData(parameters), scope=scope)
        _context.data.update(parameters)
        return _session.runBlock(text, _context, nextReply=self.async, catchReturn=True)


class MacroLeaf (DynamicCommandLeaf):
    _dynamicCommandType = Macro


class MACRo_Add (Controlling, MacroLeaf):
    '''
    Create or redefine a macro command.  The macro will remain until
    either deleted, redefined, or the instrument is restarted.

    See also the MACROS help topic ("HELP? MACROS") for information
    about macro parameters/substitutions and inline macros.
    '''

    class TooMuchAccess (RunError):
        'You cannot create macro with a higher access level than your own.'

    class InvalidEstimationCriterion (RunError):
        'No such estimation criterion exists: %(criterion)r'


    AsyncOptions = { "BLOCK"      : SYNC,
                     "BACKGROUND" : ASYNC,
                     "NEXT"       : RAISE }

    def declareInputs (self):
        MacroLeaf.declareInputs(self)

        self.setInput('replaceExisting',
                      description=
                      'If another dynamic command by the same name already '
                      'exists, replace it')

        self.setInput('asynchronous', hidden=True,
                      description='Deprecated; please use "background" instead.')

        self.setInput('background', type=bool, named=True, default=None,
                      description=
                      'Execute the macro in the background, allowing further '
                      'commands to be issued while it is running.')

        self.setInput('async', type=self.AsyncOptions, named=True, default=ASYNC,
                      description=
                      'Determines how asynchronous commands invoked in this macro '
                      'are handled. The default is to run them in the background '
                      'while moving on to the subsequent commands in the macro. '
                      'NEXT does the same, but also issues a NEXT response from '
                      'the macro itself to allow the caller to move on to the next '
                      'command.  BLOCK causes all commands to run until completion '
                      'before moving on.')

        self.setInput('inline', type=bool, named=True, default=False,
                      description='Run within the parent execution context '
                      '(i.e., command scope, exception space, etc), '
                      'even if invoked within a different branch.')

        self.setInput('hidden',
                      description=
                      'Hide the macro from the list of commands presented '
                      'in the HELP? and XMLHelp? outputs')

        self.setInput('singleton',
                      description=
                      'Allow only one instance of this command to run at '
                      'any given time.')

        self.setInput('access', type=AccessLevels,
                      description=
                      'Access level granted to the macro upon invocation. '
                      'By default, the macro will run with the access '
                      'level of the session that created it.')

        self.setInput('requiredAccess', type=AccessLevels,
                      description=
                      'Access level required to run the macro.  By default, '
                      'macros whose name ends with a "?" or "*", typically '
                      'indicating a query, require Observer access, wheras '
                      'other macros require the lesser of "Controller" '
                      'access and the access level of the session in '
                      'which the macro is defined.')

        self.setInput('modifyAccess', type=AccessLevels,
                      description=
                      'Access level required to delete or replace the macro.'
                      'By default, this is copied from the current access level '
                      'of the session in which the macro is defined.')

        self.setInput('name',
                      description='Name of the macro.')

        self.setInput('arguments',
                      description=
                      'Macro arguments; the last argument is the macro text '
                      '(i.e. the commands that are executed when then macro '
                      'is invoked)')


    def run (self, _session, 
             asynchronous=False,
             background=False,
             async=AsyncOptions,
             inline=False,
             hidden=False,
             singleton=False,
             replaceExisting=False,
             access=None,
             requiredAccess=None,
             modifyAccess=None,
             name=str, *arguments):

        try:
            text = arguments[-1]

            if text.startswith('\r'):
                text = text[1:]
            if text.startswith('\n'):
                text = text[1:]

            if not text.endswith('\n'):
                text += '\n'

        except IndexError:
            text = '\n'

        arguments     = arguments[:-1]
        currentAccess = _session.getAccessLevel()
        defaultAccess = self.defaultAccess(name)
        defaultAccess = min(defaultAccess, currentAccess)

        if access > currentAccess:
            raise self.TooMuchAccess(requestedAccess=access, currentAccess=currrentAccess)
        elif access is None:
            access = currentAccess

        if requiredAccess is None:
            requiredAccess = defaultAccess

        classes = []
        if background or (background is None and asynchronous):
            classes.append(Asynchronous)
        if singleton:
            classes.append(Singleton)
        classes.append((Macro, InlineMacro)[inline])
        obj = self.incarnate(name, tuple(classes), parent=self.parent)

        obj.arguments       = arguments
        obj.text            = text
        obj.requiredAccess  = requiredAccess
        obj.access          = access
        obj.async           = async
        obj.declareMacroInputs()

        debug("Adding macro %s"%(name,))

        self.addinstance(_session, name, obj,
                         replaceExisting=replaceExisting,
                         modifyAccess=modifyAccess,
                         hidden=hidden,
                         singleton=singleton,
                         parent=self.parent)




class MACRo_Remove (Controlling, MacroLeaf):
    '''
    Delete a macro branch previously created within this scope.
    '''

    def run (self, _session, ignoreMissing=False, name=str):
        self.delinstance(_session, name, ignoreMissing, parent=self.parent)




class MACRo_Query (Observing, MacroLeaf):
    '''
    Show the definition of the given macro.
    '''
    def declareOutputs (self):
        MacroLeaf.declareOutputs(self)
        self.addOutput('argument', type=str, repeats=(0, None))


    def run (self, name=str):
        obj = self.findDynamicCommand(name, parent=self.parent, searchType=Macro)
        return obj.arguments + ("\n%s"%obj.text,)


class MACRo_Enumerate (Observing, MacroLeaf):
    '''
    Return a list of dynamic subbranches in this branch.
    '''

    def declareOutputs (self):
        MacroLeaf.declareOutputs(self)
        self.addOutput('command', type=str, repeats=(0, None))

    def run (self):
        return tuple(self.listinstances(parent=self.parent))


addCommandType(Macro)

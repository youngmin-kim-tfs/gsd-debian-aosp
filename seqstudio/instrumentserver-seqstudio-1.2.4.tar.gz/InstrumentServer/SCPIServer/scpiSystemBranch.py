########################################################################
### FILE:       scpiSystemBranch.py
### PURPOSE:    Product and version commands
### AUTHOR:     Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################


from scpiLeaf            import Administrative, Controlling, Observing, Public, Background, Leaf
from scpiFilesystemBase  import FilesystemLeaf, OP_READ, P_READ
from scpiFullBranch      import FullBranch
from scpiExceptions      import RunError, CommandError
from scpiServer          import getStartupOption, getStartupOptions, listeners, addListener, \
    RequestHandlerClasses, SSLRequestHandler
from scpiProcessBranch   import ProcessBranch
from scpiSysConfigBranch import SysConfigBranch, SysConfigLeaf, NetConfigLeaf, \
    SysConfigSetting, SysConfigQuery, WifiConfigLeaf
from SysConfig           import sysconfig, netconfig, SysConfigError
from SysConfig.wpasupplicant import WLAN_AUTHENTICATION
from commandParser       import parser, QUOTE_ALWAYS
from timeformat          import Time
from os                  import getenv, getpid, environ
from schedule            import getUptime, sleep
from socket              import gethostname
from config              import setConfigPath, getConfigPath, Config
import platform
import subscription

import time


_default_mdns_service_type = "_abi-instrument._tcp"


class SYSTem (FullBranch):
    '''
    Server implementation and version commands.
    '''

    class PROCess (ProcessBranch):
        '''Subprocess support'''

    class CONFiguration (SysConfigBranch):
        '''SysConfig interface'''


    class CpuUTILization_Query (Observing, Leaf):
        'Return CPU utilization as a percent'

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('utilization', type=long)

        def run (self):
            try:
                import psutil
                utilization = psutil.cpu_percent()
            except ImportError:
                raise ImportError('Unable to import required module psutil')

            return utilization


    class MemorySIZe_Query (Observing, Leaf):
        'Return Memory size information in Bytes'

        TYPE = ("total", "used", "available")
        (TOTAL, USED, AVAILABLE) = range(len(TYPE))

        UNITS = ("B", "KB", "MB", "GB", "TB")
        (BYTES, KB, MB, GB, TB) = range(len(UNITS))

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("types", type=self.TYPE, named=True, split=",", default=())
            self.setInput("units", type=self.UNITS, named=True)
            self.setInput("named", type=bool, named=True, default=False,
                          description="Return named outputs. By default outputs unnamed "
                          "when specific types are specified.")

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('space', type=tuple, repeats=(0, None))

        def run (self, types=None, units=BYTES, named=False):
            try:
                import psutil
                total = psutil.virtual_memory().total
                free  = psutil.virtual_memory().available
                used = total - free
            except ImportError:
                raise ImportError('Unable to import required module psutil')

            sizes  = [ total, used, free ]
            scaled = [ s/(1024**units) for s in sizes ]

            if not types:
                types = range(len(self.TYPE))
                named = True

            items = [ ((None, self.TYPE[t])[named], str(scaled[t])) for t in types ]
            return tuple(items)


    class HDD_Query (Observing, FilesystemLeaf):
        'Return Hard Disk Drive Available space in MB'

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('context', type=str, default=None, description='Path mount point')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('size', type=long, description='HDD Available space')

        def run (self, context=str):
            try:
                from os import statvfs
                _posix = True
            except ImportError:
                _posix = False

            if _posix:
                if context is None:
                    filepath = '/'
                else:
                    filepath = self.getContextLocation(context)
                f = statvfs(filepath)
                return ((f.f_bsize * f.f_bavail)/(1024 * 1024))
            else:
                return (100000000)


    class OperatingSystem_Query (Observing, Leaf):
        'Return OS Name, Release, and Version information'

        TYPE = ("os", "release", "version")
        (OS, RELEASE, VERSION) = range(len(TYPE))

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("types", type=self.TYPE, named=True, split=",", default=(self.OS,))
            self.setInput("named", type=bool, named=True, default=False,
                          description="Return named outputs. By default outputs unnamed "
                          "when specific attributes are specified.")

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('attribute', type=tuple, repeats=(0, None), description='Operating System Information')

        def run (self, types=TYPE, named=False):
            name    = platform.system()
            release = platform.release()
            version = platform.version()

            information = [ name, release, version ]
            items = [ ((None, self.TYPE[t])[named], str(information[t])) for t in types ]
            return tuple(items)


    class TimeZONe_Query (Observing, SysConfigLeaf):
        '''
        Return the system time zone.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('current', type=bool, named=True, default=False,
                          description='Return current effective timezone, e.g. "PDT" or "PST". '
                          'Otherwise return configured timezone, e.g. "US/Pacific".')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('timezone', type=str, default="", description='Time zone')


        def run (self, current=False):
            return sysconfig.get(self.getOutputNames(), current=current)


    class TimeZoneLIST_Query (Observing, SysConfigLeaf):
        '''
        Return timezones wtih detailed informtion.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('areaName', type=str, default=None, named=True,
                          description = "Limit output to zones in the specified area, e.g. 'Europe'")

            self.setInput('countryCode', type=str, default=None, named=True,
                          description = "Limit output to zones limited to specified country code, e.g. 'US'")

            self.setInput('countryName', type=str, default=None, named=True,
                          description = "Limit output to zones limited to the specified country name, e.g. 'United States'")


        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('zonelist', type=list)


        def run (self, areaName=None, countryCode=None, countryName=None):
            zones = sysconfig.listValues('timezone', verbose=True,
                                         areaName=areaName, countryCode=countryCode, countryName=countryName)

            items = []
            for zone in zones:
                item = [ '"%s"'%zone["zoneName"] ]
                item.extend([ '-%s="%s"'%(key, zone[key])
                              for key in ("areaName", "countryCode", "countryName", "description") ])
                items.append(" ".join(item))

            return (items,)




    class TimeZoneINFO_Query (Observing, SysConfigLeaf):
        '''
        Return information about the specified timezone.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('zone', type=str)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('areaName', type=str, named=True, default=None, description="Area name, e.g. 'Americas'")
            self.addOutput('countryCode', type=str, named=True, default=None, description="Country code, e.g. 'US'")
            self.addOutput('countryName', type=str, named=True, default=None, description="Country name, e.g. 'United States'")
            self.addOutput('description', type=str, named=True, default=None, description="Display name, e.g. 'Pacific'")

        def run (self, ignoreMissing=False, zone=str):
            zones = sysconfig.listValues('timezone', verbose=True)

            for candidate in zones:
                if candidate["zoneName"] == zone:
                    return candidate
            else:
                if not ignoreMissing:
                    provider  = sysconfig.getProvider('timezone')
                    raise provider.NoSuchZone(zone=zone)


    class TimeZONe_Enumerate (Observing, SysConfigLeaf):
        '''
        Return the supported time zones.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('timezone', type=str, repeats=(0, None), description='Zones')

        def run (self):
            return tuple(sysconfig.listValues(*self.getOutputNames()))


    class TimeZONe_Set (Administrative, SysConfigLeaf):
        '''
        Set the system time zone.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('timezone', type=str, description='Instrument time zone, e.g. "US/Pacific"')

        def run (self, timezone):
            sysconfig.set(dict(timezone=timezone))



    class TIMe_Query (Observing, Leaf):
        '''
        Return the system time, as seconds since epoch.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('decimals', type=int, default=3, range=(0, None))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('seconds', type=float, format='%s',
                           description='Number of seconds since midnight, '
                           'January 1, 1970 (UTC).')

        def run (self, decimals=3):
            return "%.*f"%(decimals, time.time())


    class TIMe_Set (Administrative, SysConfigLeaf):
        '''
        Set the system time.
        '''

        class OSError (RunError):
            'Unable to set time: %(reason)s'


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('seconds', type=float,
                          description='Number of seconds since midnight, '
                          'January 1, 1970 (UTC).')

        def run (self, seconds=float):
            sysconfig.set(dict(time=seconds))



    class HttpTimeProtocol_Set (Administrative, Background, SysConfigLeaf):
        '''
        Configure a HTTP Time Protocol server for this system
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('enabled', type=bool, named=True, default=None,
                          description='Enable or disable time updates via HTP')
            self.setInput('server', type=str, named=True, default=None,
                          description='HTTP Time Protocol Server (e.g. "pool.ntp.org")')
            self.setInput('proxy', type=str, named=True, default=None,
                          description='HTTP Proxy Server')

        def run (self, apply=False, enabled=bool, server=str, proxy=str):
            update = {}
            if enabled is not None:
                update['htp'] = enabled
            if server:
                update['htpserver'] = server
            if proxy is not None:
                update['htpproxy'] = proxy

            return (update, apply)

        def next (self, update, apply):
            sysconfig.set(update, apply=apply)


    class HttpTimeProtocol_Query (Observing, SysConfigLeaf):
        '''
        Return any HTTP Time Protocol server configured on this system
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('enabled', type=str, named=True, default=False, description='HTTP time updates enabled')
            self.addOutput('server', type=str, named=True, default="", description='HTTP server')
            self.addOutput('proxy', type=str, named=True, default="", description='HTTP proxy server')


        def run (self):
            return sysconfig.get(('htp', 'htpserver', 'htpproxy'))



    class NetworkTimeProtocol_Set (Administrative, Background, SysConfigLeaf):
        '''
        Configure a Network Time Protocol server for this system
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('enabled', type=bool, named=True, default=None,
                          description='Enable or disable time updates via NTP')
            self.setInput('server', type=str, named=True, default=None,
                          description='Network Time Protocol Server (e.g. "pool.ntp.org")')

        def run (self, apply=False, enabled=bool, server=str):
            update = {}
            if enabled is not None:
                update['ntp'] = enabled
            if server:
                update['ntpserver'] = server

            return (update, apply)

        def next (self, update, apply):
            sysconfig.set(update, apply=apply)


    class NetworkTimeProtocol_Query (Observing, SysConfigLeaf):
        '''
        Return any Network Time Protocol server configured on this system
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('enabled', type=str, named=True, default=False, description='NTP time updates enabled')
            self.addOutput('server', type=str, named=True, default="", description='NTP server')


        def run (self):
            return sysconfig.get(('ntp', 'ntpserver'))


    class LocalTIMe_Set (Administrative, SysConfigLeaf):
        '''
        Set the system time, specified as local time in ISO 8601 format: YYYY-MM-DD HH:MM:SS.
        Optionally, an alternate time zone offset may be appended as {+|-}hh[:mm].
        '''

        class ConversionError (RunError):
            'Date/Time cannot not be represented'

        class OSError (RunError):
            'Unable to set time: %(reason)s'

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('datetime', type=str, repeats=(1, 3),
                          desription='Date and time in ISO 8601 format: YYYY-MM-DD HH:MM:SS[.SSS] [+hh[[:]mm]]')

        def run (self, *datetime):
            try:
                tm = Time().fromiso(' '.join(datetime), local=True)
            except (OverflowError, ValueError), e:
                raise self.ConversionError(date=date, time=time, reason=e)

            sysconfig.set(dict(time=tm.timestamp))



    class LocalTIMe_Query (Observing, Leaf):
        '''
        Without arguments, return the current local date and time in
        relaxed ISO 8601 format:
           yyyy-mm-dd hh:mm:ss [+-]hh:mm

        Use "-format=iso" to obtain a strict ISO format:
           yyyy-mm-ddThh:mm:ss[+-]hhmm

        Alternatively a different output format may be explicilty
        specified, similar to the GNU "date" command but with the
        addition of ".n" in front of "s" or "S" to represent seconds
        with n decimal points, e.g. "%.3S" to obtain millisecond
        precision (0.000 through 59.999).
        '''

        _defaultFormat = "%F %T %:z"
        _isoFormat = "%FT%T%z"

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('format', type=str, named=True, default=self._defaultFormat,
                          description='Output format, similar to the GNU "date" command. '
                          'Use "iso" for strict ISO representation.')
            self.setInput('timestamp', type=float, default=None,
                          description='Epoch time in seconds, if not current time.')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('time', type=str, repeats=(1, None))

        def run (self, format, timestamp):
            if format.lower() in ('iso', 'iso8601'):
                format = self._isoFormat

            tm = Time(timestamp)
            s = [tm.format(fmt, local=True) for fmt in format.split()]
            return tuple(s)

    class UniversalTIMe_Set (Administrative, SysConfigLeaf):
        '''
        Set the system time, specified as UTC time in ISO 8601 format: YYYY-MM-DD HH:MM:SS.
        '''

        class ConversionError (RunError):
            'Date/Time cannot not be represented'

        class OSError (RunError):
            'Unable to set time: %(reason)s'

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('datetime', type=str, repeats=(1, 3),
                          desription='UTC date and time in ISO 8601 format: YYYY-MM-DD HH:MM:SS[.SSS] [+hh[[:]mm]]')

        def run (self, *datetime):
            try:
                tm = Time().fromiso(' '.join(datetime), local=False)
            except (OverflowError, ValueError), e:
                raise self.ConversionError(date=date, time=time, reason=e)

            sysconfig.set(dict(time=tm.timestamp))

    class UniversalTIMe_Query (Observing, Leaf):
        '''
        Without arguments, return the current UTC date and time in
        relaxed ISO 8601 format:
           yyyy-mm-dd hh:mm:ss +00:00

        Use "-format=iso" to obtain a strict ISO format:
           yyyy-mm-ddThh:mm:ssZ

        Alternatively a different output format may be explicilty
        specified, similar to the GNU "date" command but with the
        addition of ".n" in front of "s" or "S" to represent seconds
        with n decimal points, e.g. "%.3S" to obtain millisecond
        precision (0.000 through 59.999).
        '''

        _defaultFormat = "%F %T %:z"
        _isoFormat = "%FT%TZ"

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('format', type=str, named=True, default=self._defaultFormat,
                          description='Output format, similar to the GNU "date" command. '
                          'Use "iso" for strict ISO representation.')
            self.setInput('timestamp', type=float, default=None,
                          description='Epoch time in seconds, if not current time.')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('time', type=str, repeats=(1, None))

        def run (self, format, timestamp):
            if format.lower() in ('iso', 'iso8601'):
                format = self._isoFormat

            tm = Time(timestamp)
            s = [tm.format(fmt, local=False) for fmt in format.split()]
            return tuple(s)

    class HOSTname_Set (Administrative, SysConfigLeaf):
        '''
        Set the instrument host name.
        '''

        def run (self, apply=False, hostname=str):
            sysconfig.set(dict(hostname=hostname),
                          apply=apply)



    class HOSTname_Query (Observing, SysConfigLeaf):
        '''
        Get the current instrument host name
        '''
        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('hostname', type=str, default='')


        def run (self, current=False):
            if current:
                return gethostname().split('.')[0]
            else:
                return sysconfig.get(self.getOutputNames())


    class InterFace_Enumerate (Observing, SysConfigLeaf):
        '''
        Return a list of supported network interfaces
        '''
        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False,
                          description='Return an empty sequence instead of failing on unsupported platforms')


        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('interface',
                           type=str,
                           repeats=(0, None))

        def run (self, ignoreMissing=False):
            try:
                return tuple(netconfig.listValues(*self.getOutputNames()))
            except netconfig.NoProvider:
                if not ignoreMissing:
                    raise


    class InterFace_Query (Observing, SysConfigLeaf):
        '''
        Return information about the specified interface.
        '''

        connectionType = { 'Ethernet' : False,
                           'WiFi'     : True }

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('enabled', type=bool, named=True, default=None)
            self.addOutput('carrier', type=bool, named=True, default=None)
            self.addOutput('mac', type=str, named=True, default=None, description='MAC address')
            self.addOutput('connection', type=self.connectionType, named=True, default=None)
#            self.addOutput('ssid', type=str, named=True, default=None)


        def run (self, ignoreMissing=False, interface=str):
            try:
                return netconfig.get(('enabled', 'carrier', 'mac', 'wireless'),
                                     interface=interface)
            except EnvironmentError, e:
                if not ignoreMissing:
                    raise



    class InterFace_Set (Administrative, SysConfigLeaf):
        '''
        Enable or disable the specified interface
        '''

        def run (self, interface=str, enabled=bool):
            netconfig.set(dict(enabled=enabled), interface=interface)



    class WirelessLocalAreaNetwork (FullBranch):
        '''
        Wireless Network Support
        '''

        class AUTHentication_Enumerate (Observing, WifiConfigLeaf):
            '''
            Enumerate available authentication schemes.
            '''

            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('scheme', type=str, repeats=(0, None))


            def run (self):
                return WLAN_AUTHENTICATION



        class WPA (Administrative, WifiConfigLeaf):
            '''
            Send a command directly to the WPA_Supplicant socket
            '''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)
                self.setInput('interface', type=str, default=None, named=True)


            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('response', type=str, default=None)


            def run (self, interface=None, command=str, *arguments):
                provider = self.getWifiProvider()
                if not interface:
                    interface = self.getWifiInterface()

                return provider.wpa_cli(interface, command, *arguments)




        class SCAN_Enumerate (Observing, Background, WifiConfigLeaf):
            '''
            Return list of available wireless network names (SSIDs)
            '''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)

                self.setInput('uptime', type=float, default=1.0, named=True, hidden=True,
                              description='Obsolete')
#                              description='If wireless network interface is not active, '
#                              'enable it for the specified duration prior to collecting SSIDs, then shut down again.')

                self.setInput('interface', type=str, default=None, named=True)
                self.setInput('ssid', type=str, default=None,
                              description='Return information about a single SSID')


            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('ssid', type=str, repeats=(0, None))


            def run (self, uptime=1.0, interface="", ssid=None):
                if not interface:
                    interface = self.getWifiInterface()

                return (interface, ssid)

            def next (self, interface, ssid):
                scanmap = netconfig.get('ssidscan', interface=interface)
                return tuple(scanmap)



        class SCAN_Query (Observing, Background, WifiConfigLeaf):
            '''
            Return list of available wireless network names (SSIDs)
            '''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)
                self.setInput('verbose', type=bool, default=False, named=True,
                              description='Return detailed information about'
                              'each wireless access point (SSID)')

                self.setInput('uptime', type=float, default=0.0, named=True, hidden=True,
                              description='Obsolete.')
#                              description='If wireless network interface is not active, '
#                              'enable it for the specified duration prior to collecting SSIDs, then shut down again.')

                self.setInput('interface', type=str, default=None, named=True)
                self.setInput('ssid', type=str, default=None,
                              description='Return information about a single SSID')


            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('list', type=list,
                               description='List of available SSIDs')


            def run (self, verbose=False, uptime=float, interface=None, ssid=str):
                if not interface:
                    interface = self.getWifiInterface()

                return (verbose, interface, ssid)

            def next (self, verbose, interface, ssid):
                scanmap = netconfig.get('ssidscan', interface=interface)
                names = []
                for name, props in scanmap.iteritems():
                    if not ssid or name == ssid:
                        fields = [ '"%s"'%name ]
                        if verbose:
                            fields.extend(parser.collapseParts(props, None))

                        names.append(' '.join(fields))

                return (names,)



        class SSID_Enumerate (Observing, WifiConfigLeaf):
            '''
            Return a list of configured wireless networks (SSIDs)
            '''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)
                self.setInput('ignoreMissing', type=bool, default=False,
                              description='Do not complain about missing wireless interface')

            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('ssid',
                               type=str,
                               repeats=(0, None))


            def run (self, ignoreMissing=False, interface=""):
                if not interface:
                    interface = self.getWifiInterface(required=not ignoreMissing)

                if interface:
                    ssidlist = netconfig.listValues('ssid', interface)
                    return tuple(ssidlist)



        class SSID_Query (Observing, WifiConfigLeaf):
            '''
            Return detailed information about the specified wireless network configuration.
            '''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)
                self.setInput('interface', type=str, default=None, named=True)
                self.setInput('ssid', type=str, named=False)


            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('authentication', type=str, named=True, default=None)
                self.addOutput('identity', type=str, named=True, default=None)
                self.addOutput('key', type=str, named=True, default=None)
                self.addOutput('keyindex', type=int, named=True, default=None)


            def run (self, ignoreMissing=False, interface=str, ssid=str):
                if not interface:
                    interface = self.getWifiInterface()

                return netconfig.getdict(self.getOutputNames(),
                                         interface, ssid, required=not ignoreMissing)



        class SSID_Add (Administrative, Background, WifiConfigLeaf):
            '''
            Add a new wireless network configuration
            '''

            class SSIDExists (RunError):
                '''The SSID %(ssid)r already exists'''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)

                self.setInput('save', type=bool, named=True, default=True,
                              description="Save this SSID for future use")
                self.setInput('ssid', type=str)
                self.setInput('hidden', type=bool, default=False, named=True)
                self.setInput('authentication', type=WLAN_AUTHENTICATION, named=True)
                self.setInput('identity', type=str, named=True, default=None)
                self.setInput('key', type=str, named=True, default=None, secret=True)
                self.setInput('keyindex', type=int, named=True, default=0)


            def run (self, replaceExisting=False, select=False, hidden=False, ignoreAssociationFailure=False, save=True,
                     interface="", ssid=str, authentication=str, identity=None, key=None, keyindex=0):

                if not interface:
                    interface = self.getWifiInterface()

                if not replaceExisting and netconfig.get('ssid',
                                                         interface=interface,
                                                         ssid=ssid,
                                                         required=False):
                    raise self.SSIDExists(ssid=ssid)


                if authentication is not None:
                    authentication = WLAN_AUTHENTICATION[authentication]

                values = dict(ssid=ssid,
                              scan_ssid=hidden,
                              authentication=authentication,
                              identity=identity,
                              key=key,
                              keyindex=keyindex)

                return (interface, ssid, values, select, save, ignoreAssociationFailure)

            def next (self, interface, ssid, values, select, save, ignoreAssociationFailure):
                try:
                    netconfig.set(values, apply=select, interface=interface, save=save)
                except SysConfigError, e:
                    if not ignoreAssociationFailure:
                        provider = self.getWifiProvider()
                        provider.removeNetwork(interface, ssid, required=False, save=save)
                    raise


        class SSID_Remove (Administrative, WifiConfigLeaf):
            '''
            Remove an existing wireless network configuration (SSID).
            If the specified SSID is "*", remove ALL existing wireless networks.

            '''

            def run (self, ignoreMissing=False, interface="", ssid=str):
                if not interface:
                    interface = self.getWifiInterface(required=not ignoreMissing)

                if interface:
                    provider = self.getWifiProvider()

                    if ssid == '*':
                        provider.clearNetworks(interface)

                    else:
                        provider.removeNetwork(interface, ssid, required=not ignoreMissing)



        class AccessPoint_Query (Observing, WifiConfigLeaf):
            '''
            Return the SSID of currently selected access point, if any.
            '''

            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)
                self.setInput('pending', type=bool, default=False,
                              description='Show association even if not completed yet.')

                self.setInput('verbose', type=bool, default=False,
                              description='Show additional information about association.  '
                              'Implies "-pending".')

                self.setInput('interface', type=str, default=None)

            def declareOutputs (self):
                WifiConfigLeaf.declareOutputs(self)
                self.addOutput('ssid', type=str, default="-")
                self.addOutput('mode', type=str, named=True, default=None)
                self.addOutput('state', type=str, named=True, default=None)
                self.addOutput('access', type=str, named=True, default=None)


            def run (self, verbose=False, pending=False, interface=str):
                if not interface:
                    interface = self.getWifiInterface()

                provider = self.getWifiProvider()

                if verbose:
                    status   = provider.getStatus(interface)

                    return (status.get('ssid'),
                            status.get('mode'),
                            status.get('wpa_state'),
                            status.get('suppPortStatus'))

                else:
                    status = provider.getStatus(interface, pending=pending)
                    return status.get('ssid')



        class AccessPoint_Set (Administrative, Background, WifiConfigLeaf):
            '''
            Associate the specified wireless interface with an access point.
            '''


            def declareInputs (self):
                WifiConfigLeaf.declareInputs(self)
                self.setInput('interface', type=str, default=None)
                self.setInput('timeout', type=float, units="seconds", range=(0.0, None),
                              description='Wait up to the specified duration; if still not associated, return an error.')
                self.setInput('keep', type=bool, default=False,
                              description='Keep SSID selection even if association cannot be completed, rather than reverting '
                              'to currently associated SSID')


            def run (self, interface='', timeout=30.0, keep=False, ssid=str):
                provider = self.getWifiProvider()
                if not interface:
                    interface = self.getWifiInterface()

                return (provider, interface, timeout, keep, ssid)


            def next (self, provider, interface, timeout, keep, ssid):
                ### Enable network interface
                enabled  = netconfig.get('enabled', interface=interface)

                if not enabled:
                    netconfig.set({'enabled':True}, interface=interface)

                else:
                    previous = provider.getStatus(interface)

                try:
                    provider.selectNetwork(interface, ssid, timeout=timeout)
                except self.SysConfigError, e:
                    if not enabled:
                        self.debug('Association with SSID "%s" failed; disabling network interface %s'%
                                   (ssid, interface))
                        netconfig.set({'enabled':False}, interface=interface)

                    elif not keep and 'ssid' in previous and previous['ssid'] != ssid:
                        self.debug('Association with new SSID "%s" failed; reverting to previous SSID "%s"'%
                                   (ssid, previous['ssid']))
                        provider.selectNetwork(interface, previous['ssid'])

                    raise self.AssociationFailure(ssid=ssid,
                                                  timeout=timeout,
                                                  wpastate=wpastate,
                                                  authstate=authstate)


        class AccessPoint_Clear (Administrative, WifiConfigLeaf):
            '''
            Disconnect/disassociate the specified wireless interface
            '''

            def run (self, interface=""):
                provider = self.getWifiProvider()
                if not interface:
                    interface = self.getWifiInterface()

                provider.disconnect(interface)



    class IP_Set (Administrative, Background, NetConfigLeaf):
        '''
        Configure IP settings for the specified network interface.
        '''


        def declareInputs (self):
            Leaf.declareInputs(self)

            self.setInput('apply',
                          type=bool,
                          named=True,
                          default=False,
                          description='Restart network interface with new settings.')

            self.setInput('restart',
                          type=bool,
                          named=True,
                          default=False,
                          hidden=True,
                          description='Depricated - please use "-apply" instead.')

            self.setInput('interface',
                          type=str,
                          description='Network interface name (OS dependent).')

            self.setInput('state',
                          type=self.STATES,
                          default=None,
                          description='Interface state at OS boot')

            self.setInput('mode',
                          type=self.METHODS,
                          default=None,
                          description=
                          'Network configuration strategy')

            self.setInput('address',
                          type=str,
                          named=True,
                          default=None,
                          description='The IP address that should be '
                          'assigned to the interface.  This is required '
                          'in "static" mode, ignored otherwise.')

            self.setInput('netmask',
                          type=str,
                          named=True,
                          default=None,
                          description='The IP netmask that should be '
                          'applied to the interface, in "dotted quad" '
                          'notation (e.g. "255.255.255.0"). '
                          'This is only used in "static" mode.')

            self.setInput('gateway',
                          type=str,
                          named=True,
                          default=None,
                          description='The IP address of a  gateway '
                          'through which to route traffic to outside '
                          'networks.  Optional, and only used in "static" '
                          'mode.  If supplied, it must be "reachable" '
                          'given the address and netmask discussed above. ')

            self.setInput('dnsservers',
                          type=str,
                          named=True,
                          default=None,
                          split=",",
                          description='IP addresses of domain name servers '
                          'for this interface. Optional, and only used in '
                          '"static" mode.')

            self.setInput('dnssearch',
                          type=str,
                          named=True,
                          default=None,
                          split=",",
                          description='DNS domains under which '
                          'to search for unqualified host names.'
                          'Optional, and only used in "static" mode.')

        def run (self, apply=False, restart=False,
                 interface=str, state=None, mode=None,
                 address=None, netmask=None, gateway=None,
                 dnsservers=None, dnssearch=None):

            if not apply:
                apply = restart

            valuemap = {}
            if state is not None:
                valuemap.update(state=self.STATES[state])

            if mode is not None:
                valuemap.update(mode=self.METHODS[mode],
                                address=address,
                                netmask=netmask,
                                gateway=gateway,
                                dnsservers=dnsservers,
                                dnssearch=dnssearch)

            return (valuemap, interface, apply)


        def next (self, valuemap, interface, apply):
            netconfig.set(valuemap, interface=interface, apply=apply)



    class IP_Query (Observing, NetConfigLeaf):
        '''
        Read current IP settings of the specified interface.
        '''

        class NoActiveInterface (RunError):
            '''No interface name provided, and no active interfaces detected.'''


        def declareInputs (self):
            NetConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, default=False,
                          description='Do not complain about missing wireless interface')

            self.setInput('current',
                          type=bool,
                          named=True,
                          default=False,
                          description=
                          'Return only the current and not the configured state of the interface')

            self.setInput('configured',
                          type=bool,
                          named=True,
                          default=False,
                          description=
                          'Return only the configured and not the current state of the interface')

            self.setInput('interface',
                          type=str,
                          default=None,
                          description='Network interface name (OS Dependent).'
                          'If not provided, use the first active interface.')


        def declareOutputs (self):
            NetConfigLeaf.declareOutputs(self)
            self.addOutput('interface',
                           named=True,
                           type=str,
                           default=None,
                           description=
                           'Network interface name')

            self.addOutput('state',
                           named=True,
                           type=str,
                           default=None,
                           description=
                           'Network Interface State')

            self.addOutput('mode',
                           named=True,
                           type=str,
                           default=None,
                           description=
                           'Configuration strategy used for the device')

            self.addOutput('address',
                           named=True,
                           type=str,
                           default=None,
                           description=
                           'IP address assigned to the interface')

            self.addOutput('netmask',
                           named=True,
                           type=str,
                           default=None,
                           description=
                           'IP netmask applied to the interface')

            self.addOutput('gateway',
                           named=True,
                           type=str,
                           default=None,
                           description=
                           'IP gateway used to route traffic to other '
                           'networks/subnets')

            self.addOutput('dnsservers',
                           named=True,
                           type=str,
                           default=None,
                           split=",",
                           description='IP addresses of domain name servers '
                           'for this interface.')

            self.addOutput('dnssearch',
                           named=True,
                           type=str,
                           default=None,
                           split=",",
                           description='DNS domains under which '
                           'to search for unqualified host names.')


        def run (self, ignoreMissing=False, configured=False, current=False, interface=str):
            self.checkConflictingOptions(configured=configured, current=current)

            outputs = {}
            if not interface:
                interface = self.getDefaultInterface(ignoreMissing=ignoreMissing)

            if interface:
                withCurrent = []
                if not current:
                    withCurrent.append(False)
                if not configured:
                    withCurrent.append(True)

                for current in withCurrent:
                    d = netconfig.getdict(self.getOutputNames()[1:], interface=interface, current=current)
                    outputs.update([(k,v) for (k,v) in d.items() if v is not None])

            return outputs


    class MAC_Set (Administrative, NetConfigLeaf):
        '''
        Configure the MAC (Media Access Control, a.k.a. hardware)
        address for the specified network interface.
        '''
        def run (self, interface=str, address=str):
            netconfig.set(dict(mac=address),
                          interface=interface)


    class MAC_Query (Observing, NetConfigLeaf):
        '''
        Return the MAC (Media Access Control, a.k.a. hardware)
        address of the specified interface.
        '''

        def declareOutputs (self):
            NetConfigLeaf.declareOutputs(self)
            self.addOutput('mac', type=str, description='MAC address')

        def run (self, interface=str):
            return netconfig.get(self.getOutputNames(), interface=interface)


    class CARRier_Query (Observing, NetConfigLeaf):
        '''
        Return link/carrier state of the specified interface.
        '''

        def declareInputs (self):
            NetConfigLeaf.declareInputs(self)
            self.setInput('enable',
                          description='If interface is not currently enabled, '
                          'temporarily enable it in order to check the link status.')

        def declareOutputs (self):
            NetConfigLeaf.declareOutputs(self)
            self.addOutput('carrier', type=bool, description='Link status')

        def run (self, enable=False, interface=str):
            return netconfig.get(self.getOutputNames(), interface=interface, enable=enable)



    class DomainNameService_Set (Administrative, NetConfigLeaf):
        '''
        Configure Domain Name Service settings
        '''

        def declareInputs (self):
            NetConfigLeaf.declareInputs(self)
            self.setInput('interface',
                          type=str,
                          named=True,
                          default=None,
                          description="Network interface. If ommited, the default interface is used.")

            self.setInput('suffix',
                          type=str,
                          hidden=True,
                          named=True,
                          default=None,
                          description="Depricated.  Use '-search' instead.")

            self.setInput('search',
                          type=str,
                          named=True,
                          default=None,
                          split=",",
                          description="DNS search domains for looking up unqualified names")

            self.setInput('servers',
                          type=str,
                          repeats=(0, None),
                          description="DNS Server address for name lookups")


        def run (self, apply=False, interface=None, suffix=None, search=[], *servers):
            if not interface:
                interface = self.getDefaultInterface()

            valuemap = {}
            if servers:
                valuemap.update(dnsservers=servers)

            if suffix is not None:
                valuemap.setdefault('dnssearch', []).append(suffix)

            if search:
                valuemap.setdefault('dnssearch', []).extend(search)


            netconfig.set(valuemap, apply=apply, interface=interface)


    class DomainNameService_Clear (Administrative, NetConfigLeaf):
        '''
        Clear any Domain Name Service settings
        '''

        def declareInputs (self):
            NetConfigLeaf.declareInputs(self)
            self.setInput('interface',
                          type=str,
                          named=True,
                          default=None,
                          description="Network interface. If ommited, the default interface is used.")

            self.setInput('apply', type=bool, named=True,
                          description='Apply setings immediately')

        def run (self, apply=False, interface=None):
            if not interface:
                interface = self.getDefaultInterface()

            valuemap = dict(dnsservers=(), dnssearch="")
            netconfig.set(valuemap, apply=apply, interface=interface)



    class DomainNameService_Query (Observing, NetConfigLeaf):
        '''
        Return Domain Name Service configuration
        '''

        def declareInputs(self):
            NetConfigLeaf.declareInputs(self)
            self.setInput('interface',
                          type=str,
                          named=True,
                          default=None,
                          description="Network interface. If ommited, the default interface is used.")

        def declareOutputs (self):
            NetConfigLeaf.declareOutputs(self)
            self.addOutput('suffix',
                           type=str,
                           named=True,
                           split=",",
                           default=None,
                           description="DNS Suffix (domain) for looking up unqualified names")

            self.addOutput('servers',
                           type=str,
                           named=False,
                           repeats=(0, None),
                           description="DNS Server address used for name lookups")

        def run (self, interface=str):
            if not interface:
                interface = self.getDefaultInterface()

            suffix, servers = netconfig.get(('dnssearch', 'dnsservers'), interface=interface)
            return (suffix,) + tuple(servers or ())




    class WIndowsNameService_Set (Administrative, SysConfigLeaf):
        '''
        Configure Windows Name Service settings
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('workgroup',
                          type=str,
                          named=True,
                          default=None,
                          description="Windows workgroup/domain")

            self.setInput('servers',
                          type=str,
                          repeats=(0, None),
                          description="WINS Server address for name lookups")


        def run (self, workgroup=None, *servers):
            valuemap = {}
            if workgroup is not None:
                valuemap.update(workgroup=workgroup)

            if servers:
                valuemap.update(winsservers=servers)

            sysconfig.set(valuemap)



    class WIndowsNameService_Query (Observing, SysConfigLeaf):
        '''
        Read  Windows Name Service settings
        '''

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('workgroup',
                           type=str,
                           named=True,
                           default=None,
                           description="Windows workgroup/domain")

            self.addOutput('servers',
                           type=str,
                           repeats=(0, None),
                           description="WINS Server address for name lookups")


        def run (self, workgroup=None, *winsservers):
            workgroup, servers = sysconfig.get(('workgroup', 'winsservers'))
            return (workgroup,) + tuple(servers or ())


    class BIND_Add (Administrative, NetConfigLeaf):
        '''
        Bind a listener to the specified interface address/port.
        '''

        class InterfaceNotConfigured (RunError):
            '''Interface %(interface)s is currently not configured.'''

        class NotSuchOption (RunError):
            '''Option %(option)r is not valid for the %(handler)r request handler'''

        def declareInputs (self):
            NetConfigLeaf.declareInputs(self)
            self.setInput('preexec', type=str, named=True, default=None,
                          description='Command to invoke once a client connects.')
            self.setInput('postexec', type=str, named=True, default=None,
                          description='Command to invoke after a client disconnects.')
            self.setInput('certfile', type=str, named=True, default=None,
                          description='SSL certificate for the "ssl" handler.')
            self.setInput('keyfile', type=str, named=True, default=None,
                          description='SSL key for the "ssl" handler. If empty, the certificate file must also contain the key.')

        def run (self, _session, preexec=None, postexec=None, certfile=None, keyfile=None,
                 interface="", address="", port=int, handler=RequestHandlerClasses):
            self.checkConflictingOptions(interface=interface, address=address)
            if interface:
                address = netconfig.get('address', interface=interface, current=True)
                if not address:
                    raise self.NotConfigured(interface=interface)

            options = dict(preexec=preexec, postexec=postexec)
            if certfile:
                with self.openLocation(certfile, _session, runTriggers=False) as loc:
                    options.update(certfile=loc.localpath())
                    loc.stat()

            if keyfile:
                with self.openLocation(keyfile, _session, runTriggers=False) as loc:
                    options.update(keyfile=loc.localpath())
                    loc.stat()

            for option in options:
                if not option in handler.OptionNames:
                    raise self.NoSuchOption(option=option, handler=handler.TypeName)

            addListener((address, port), handler, **options)


    class BIND_Remove (Administrative, NetConfigLeaf):
        '''
        Unbind an existing listener from the specified interface address/port.
        '''

        class NotBound (RunError):
            '''Not currently listening on %(address)s:%(port)s'''


        def run (self, ignoreMissing=False, interface="", address="", port=int):
            self.checkConflictingOptions(interface=interface, address=address)
            if interface:
                address = netconfig.get('address', interface=interface, current=True) or ""

            try:
                listener = listeners.pop((address, port))
            except KeyError:
                if not ignoreMissing:
                    raise self.NotBound(address=address, port=port)
            else:
                listener.server_close()


    class BIND_Enumerate (Observing, Leaf):
        '''
        Enumerate listeners
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('address', type=str, split=":", repeats=(0, None))

        def run (self):
            return tuple(sorted(listeners))

    class BIND_Query (Observing, Leaf):
        '''
        Return the type of listener bound to the specified address.
        '''

        class NotBound (RunError):
            '''Not currently listening on %(address)s:%(port)s'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('handler', type=RequestHandlerClasses, default=None)

        def run (self, ignoreMissing=False, interface="", address="", port=int):
            self.checkConflictingOptions(interface=interface, address=address)
            if interface:
                address = netconfig.get('address', interface=interface, current=True) or ""

            try:
                listener = listeners[address, port]
            except KeyError:
                if not ignoreMissing:
                    raise self.NotBound(address=address, port=port)
            else:
                return listener.RequestHandlerClass


    class BIND_Exists (Observing, Leaf):
        '''
        Indicate whether the any listener is bound to the specified address.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('bound', type=bool)

        def run (self, interface="", address="", port=int):
            self.checkConflictingOptions(interface=interface, address=address)
            if interface:
                address = netconfig.get('address', interface=interface, current=True) or ""

            return (address, port) in listeners

    class MulticastDomainNameService_Add (Administrative, SysConfigLeaf):
        '''
        Enable mDNS instrument service discovery.  Usually invoked at startup.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('servicetype', type=str, named=True, default=_default_mdns_service_type)
            self.setInput('servicename', type=str, named=True, default='%h')

            listener = listeners.get(None)
            if listener:
                addr, port = listener.server_address
            else:
                port = None

            # Try and see if there was a preference set in the mdns.ini
            try:
                mdnsdefaultconfig = Config("mdns.ini")
                port = mdnsdefaultconfig.get("service", "port", default=port)
            except:
                port = port


            self.setInput('serviceport', type=int, named=True, default=port)


        def run (self, apply=False, servicetype=_default_mdns_service_type, servicename=str, serviceport=int, **items):
            provider  = sysconfig.getProvider('servicetype')
            items.update(servicetype=servicetype, servicename=servicename, serviceport=serviceport)
            generic   = set(provider.KEYS) - set(items)
            items.update(sysconfig.getdict(generic))

            provider.validate(items)
            provider.configure(items)
            if apply:
                provider.apply(items)



    class MulticastDomainNameService_Set (Administrative, SysConfigLeaf):
        '''
        Update the specified items in published mDNS record.
        '''

        class MismatchedItems (RunError):
            '''Key/value mismatch; need value for key %(lastkey)r'''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('apply',
                          type=bool,
                          named=True,
                          default=False,
                          description='Reload mDNS daemon with new settings.')


        def run (self, apply=False, *pairs, **items):
            if len(pairs) % 2:
                raise self.MismatchedItems(keys=len(pairs)/2+1, values=len(pairs)/2, lastkey=pairs[-1])

            valuemap = dict(zip(pairs[0::2], pairs[1::2]))
            valuemap.update(items)

            provider = sysconfig.getProvider('servicetype')
            provider.validate(valuemap)
            provider.configure(valuemap)
            if apply:
                provider.apply(valuemap)



    class MulticastDomainNameService_Remove (Administrative, SysConfigLeaf):
        '''
        Remove the specified keys from mDNS publication.
        Use "*" to remove ALL information.

        If no keys are provided, remove only "servicename", which has
        the effect of removing this instrument from publication, but
        to leave information intact for next restart.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('apply',
                          type=bool,
                          named=True,
                          default=False,
                          description='Reload mDNS daemon with new settings.')


        def run (self, apply=False, *keys):
            provider = sysconfig.getProvider('servicetype')

            if not keys:
                keys = ('servicename',)

            elif '*' in keys:
                keys = provider.get()

            valuemap = {}.fromkeys(keys)

            provider.validate(valuemap)
            provider.configure(valuemap)
            if apply:
                provider.apply(valuemap)


    class MulticastDomainNameService_Query (Observing, Background, SysConfigLeaf):
        '''
        Return information currently published via mDNS.
        '''

        class NoSuchMDNSName (RunError):
            '''No mDNS records is availble for %(hostname)r'''


        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('hostname', type=str, default=None)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('type', type=str, named=True)
            self.addOutput('name', type=str, named=True)
            self.addOutput('port', type=str, named=True)
            self.addOutput('text', type=tuple, named=True, repeats=(0, None))

        def run (self, ignoreMissing=False, servicetype=_default_mdns_service_type, hostname=str):
            return (ignoreMissing, servicetype, hostname)

        def next (self, ignoreMissing, servicetype, hostname):
            if hostname:
                hosts = sysconfig.get("mdnsbrowse", servicetype=servicetype)
                try:
                    valuemap = hosts[hostname.lower()]
                except KeyError:
                    if not ignoreMissing:
                        raise self.NoSuchMDNSName(hostname=hostname)
                    valuemap = {}

            else:
                provider = sysconfig.getProvider('servicetype')
                valuemap = provider.get()

            args = (valuemap.pop('servicetype', None),
                    valuemap.pop('servicename', None),
                    valuemap.pop('serviceport', None))

            return args + tuple(valuemap.items())


    class MulticastDomainNameService_Enumerate (Observing, Background, SysConfigLeaf):
        '''
        Return names currently published via mDNS.
        '''

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self, servicetype=_default_mdns_service_type):
            return (servicetype,)

        def next (self, servicetype):
            names = sysconfig.get('mdnsbrowse', servicetype=servicetype)
            return tuple(names.keys())


    class MulticastDomainNameService_List (Observing, Background, SysConfigLeaf):
        '''
        Return information currently published via mDNS
        '''

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('information', type=list)

        def run (self, servicetype=_default_mdns_service_type):
            return (servicetype,)

        def next (self, servicetype):
            mdnsinfo = sysconfig.get('mdnsbrowse', servicetype=servicetype)
            output   = []

            for name in sorted(mdnsinfo):
                parts = [ (None, name) ] + mdnsinfo[name].items()
                output.append(parser.collapseArgs(parts, tag=None, quoting=QUOTE_ALWAYS))

            return (output,)


    class PROXy_Exists (Observing, SysConfigLeaf):
        '''
        Return any proxy servers currently configured.
        '''

        def run (self):
            try:
                proxy = sysconfig.getvalue('proxy')
                return bool(proxy and proxy[0])
            except self.SysConfigError, e:
                return False


    class PROXy_Query (Observing, SysConfigLeaf):
        '''
        Return any proxy servers currently configured.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)

            self.addOutput('type', type=str, named=True, default=None)
            self.addOutput('server', type=str, named=True, default=None)
            self.addOutput('port', type=int, named=True, default=None)
            self.addOutput('username', type=str, named=True, default=None)
            self.addOutput('password', type=str, named=True, default=None, secret=True)
            self.addOutput('dnsproxy', type=bool, named=True, default=None)

        def run (self, ignoreMissing=False):
            try:
                return sysconfig.getvalue('proxy')
            except self.SysConfigError, e:
                if not ignoreMissing:
                    raise


    class PROXy_Set (Administrative, Background, SysConfigLeaf):
        '''
        Set proxy server for subprocesses
        '''

        def run (self, dns=False, type="http", server=str, port=str, username='', password=''):
            return {'proxy': (type, server, port, username, password, dns)}

        def next (self, valuemap):
            sysconfig.set(valuemap)


    class PROXy_Clear (Administrative, SysConfigLeaf):
        '''
        Clear proxy setting.
        '''

        def run (self):
            sysconfig.set({'proxy':()})


    class PRODuct_Set (Administrative, SysConfigLeaf):
        '''
        Set the product name.  This is subsequently returned in response
        to "SYSTem:PRODuct?" queries, and published via mDNS.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('save', type=str, named=True, default=True)
            self.setInput('product', type=str, default=None)
            self.setInput('model', type=str, default=None)
            self.setInput('description', type=str, default=None)

        def run (self, save=True, product=None, model=None, description=None):
            valuemap = {}
            if product:
                valuemap.update(product=product)
            if model:
                valuemap.update(model=model)
            if description:
                valuemap.update(description=description)

            sysconfig.set(valuemap, save=save)


    class PRODuct_Query (Public, Leaf):
        'Return the product string.'

        TYPE = ("product", "model", "description")
        (PRODUCT, MODEL, DESCRIPTION) = range(len(TYPE))

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("default", type=str, named=True, default='',
                          description="Return default if undefined.")
            self.setInput("types", type=self.TYPE, named=True, split=",", default=(0,))
            self.setInput("named", type=bool, named=True, default=False,
                          description="Return named outputs.")

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('attribute', type=tuple, repeats=(0, None),
                            description="Attribute(s) queried.")

        def run (self, default='', types=None, named=False):
            if not types:
                types = (0,)

            items = [ ((None, self.TYPE[t])[named], sysconfig.get(self.TYPE[t]) or default) for t in types ]
            return tuple(items)


    class SERial_Set (SysConfigSetting):
        '''
        Set the serial number.  This is subsequently returned in response
        to "SYSTem:SERial?" queries, and published via mDNS.
        '''
        KEY = 'serialnumber'

        def run(self, value):
            self.super.run(value)
            subscription.publish("sysconfig", "Setting " + self.KEY + ": " + value, level=subscription.DEBUG)


    class SERial_Query (Public, SysConfigQuery):
        'Return the instrument serial number.'
        KEY = 'serialnumber'

        def run (self, numeric=False, default=None):
            serial = sysconfig.get(self.KEY)
            if numeric and serial:
                serial = "".join([ c for c in serial if c.isdigit() ])
            return serial or default

    class NICKname_Set (SysConfigSetting):
        '''
        Set a nick name for this instrument.  This is subsequently
        returned in response to "SYSTem:NICKname?" queries, and
        published via mDNS.
        '''
        KEY = 'nickname'


    class NICKname_Query (Public, SysConfigQuery):
        'Return the version string.'
        KEY = 'nickname'


    class VERSion_Query (Public, SysConfigQuery):
        'Return the version string.'
        KEY = 'version'


    class BUILD_Query (Public, SysConfigQuery):
        'Return the build number, or "-" if not an official build.'
        KEY = 'build'

    class FLAVor_Query (Public, Leaf):
        'Return the product flavor, if any.'

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('flavor', type=str, default=None)

        def run (self):
            return getStartupOption("flavor")


    class OPTion_Enumerate (Observing, Leaf):
        'Return the value of the specified startup option'

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self):
            return tuple(getStartupOptions())


    class OPTion_Query (Observing, Leaf):
        'Return the value of the specified startup option'

        class NoSuchOption (CommandError):
            "No such startup option exists: %(option)r"

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=str, repeats=(0, None))

        def run (self, ignoreMissing=False, option=str):
            try:
                value = getStartupOption(option)
            except AttributeError:
                if not ignoreMissing:
                    raise self.NoSuchOption(option=option)
            else:
                if isinstance(value, (list, tuple)):
                    return tuple(value)
                elif value is not None:
                    return str(value),

    class ENVironment_Enumerate (Observing, Leaf):
        '''
        Enumerate all environment variables in the current process.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('variable', type=str, repeats=(0, None))

        def run (self):
            return tuple(sorted(environ))

    class ENVironment_Query (Observing, Leaf):
        '''
        Return the contents of the specified environment variable.
        If the variable does not exist, an empty string is returned.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=tuple, repeats=(0, None))

        def run (self, named=False, default="", *variables):
            if not variables:
                variables = sorted(environ)
                named = True

            env = [((None, var)[named], environ.get(var, default))
                   for var in variables]

            return tuple(env)


    class ENVironment_Set (Administrative, Leaf):
        '''
        Return the contents of the specified environment variable.
        If the variable does not exist, an empty string is returned.
        '''

        class MismatchedItems (RunError):
            '''Key/value mismatch; need value for key %(lastkey)r'''

        def run (self, *pairs, **items):
            if len(pairs) % 2:
                raise self.MismatchedItems(keys=len(pairs)/2+1, values=len(pairs)/2, lastkey=pairs[-1])

            environ.update(items)
            environ.update(zip(pairs[0::2], pairs[1::2]))


    class ProcessID_Query (Observing, Leaf):
        '''
        Returns the process ID of the server.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('pid', type=int)

        def run (self):
            return getpid()


    class TeleTYpe_Query (Leaf):
        """
        Return the path to the server's input terminal, if any.
        """

        try:
            from os import ttyname
            gotTTY = True
        except ImportError:
            gotTTY = False

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('path', type=str, default="")

        def run (self):
            if self.gotTTY:
                return self.ttyname(0)
            else:
                return "(Not supported)"



    class UPTime_Query (Observing, Leaf):
        '''
        Indicate how long the Instrument Server has been running.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('days', type=int, default=0, named=True)
            self.addOutput('hours', type=int, default=0, named=True)
            self.addOutput('minutes', type=int, default=0, named=True)
            self.addOutput('seconds', type=int, default=0, named=True)

        def run (self):
            seconds = int(getUptime())
            minutes = seconds / 60
            hours   = minutes / 60
            days    = hours / 24
            return (days, hours % 24, minutes % 60, seconds % 60)

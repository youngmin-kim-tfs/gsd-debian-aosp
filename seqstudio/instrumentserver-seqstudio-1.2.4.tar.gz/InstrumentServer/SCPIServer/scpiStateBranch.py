########################################################################
### FILE:	scpiStateBranch.py
### PURPOSE:	Instrument State Framework
###
### Copyrights (C) 2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch import FullBranch
from scpiLeaf       import Controlling, Observing, Leaf, CommandWrapper
from scpiExceptions import RunError, Error, UserError, Aborted, scpiException
from scpiSession    import SYNC, ASYNC, NextReply, NestedSession
from subscription   import addTopic, deleteTopic, topicExists, INFO, \
    publish, trace, debug, info, notice, warning
from commandParser  import parser
from threadControl  import ControllableThread, safeInvoke, Aborted, IGNORE, ALLOW, DEFER
from locking        import Lock, Event, Condition, currentThread
from schedule       import getUptime
from data           import Container, DynamicData
from sys            import exc_info

import time


StateStrings  = ("False", "True", "Failed", "Pending")
StateValues   = (OFF, ON, FAILED, PENDING) = range(len(StateStrings))
EdgeStrings   = ("Off", "On", "Failed")

Phases = ("early", "normal", "late")
(PH_EARLY, PH_NORMAL, PH_LATE) = range(len(Phases))

ExceptionHandling = ("cancel", "revert", "continue", "raise", "fail")
(EH_CANCEL, EH_REVERT, EH_CONTINUE, EH_RAISE, EH_FAIL) = range(len(ExceptionHandling))

CancelStrategy = ("none", "cancelable", "remaining", "all")
(C_NONE, C_CANCELABLE, C_REMAINING, C_ALL) = range(len(CancelStrategy))

class _State (object):
    notifyTopics = set()
    deferred     = []
    deferring    = False

    class UnsatisfiedDependencies (Exception):
        def __init__ (self, dependencies):
            self.dependencies = dependencies


    def __init__ (self, name, value=OFF, shutdownValue=None, primary=False, queueSize=None):
        self.name           = name
        self.value          = PENDING
        self.previousValue  = OFF
        self.publishedValue = None
        self.pendingValue   = None
        self.pendingError   = None
        self.pendingOwner   = None
        self.pendingTask    = None
        self.runningHook    = None
        self.shutdownValue  = shutdownValue
        self.queueSize      = queueSize
        self.error          = None
        self.reasons        = {}
        self.actions        = {}
        self.ancestors      = {True:[], False:[]}
        self.descendants    = []
        self.conflicts      = []
        self.hooks          = {}
        self.primary        = primary
        self.changeLock     = Lock()
        self.changeWatch    = Condition()
        self.changeEvent    = Event()
        self.changeEvent.set()
        self.changeIndex    = 1
        self.refcount       = 0
        self._mutex         = Lock()

        if value is not None:
            self.updateValue(value, None)
            self.publishValue(value)


    def clearValue (self):
        self.setValue(OFF)


    def setValue (self, value, error=None, raiseExceptions=True,
                  cancelPending=None, cancelStrategy=C_REMAINING,
                  runHooks=True, descendants=True, descendantHooks=True, 
                  allHooks=False, waitDescendants=True, indirect=False,
                  onCancel=EH_CANCEL, onAbort=EH_RAISE, onError=EH_FAIL,
                  keepErrors=False, enqueue=False, dequeue=False):


        currentTarget = self.getValue(pending=True)
        change       = (value != currentTarget)

        if change:
            if dequeue and self.refcount:
                self.refcount -= 1
                trace('State %r decreased reference count to %s, still %s (would have been %s)'%
                      (self.name, self.refcount,
                       self.getValueString(currentTarget),
                       self.getValueString(value)))
                value = None

            elif currentTarget != FAILED or not keepErrors:
                self.refcount = 0

            else:
                value = None

        else:
            if enqueue:
                if self.queueSize is not None and (self.refcount >= self.queueSize):
                    trace("State %r reference count is at maximum %s while %s"%
                          (self.name, self.refcount, self.getValueString(value)))
                else:
                    self.refcount = max(self.refcount+1, self.queueSize)
                    trace('State %r increased reference count to %s while %s'%
                          (self.name, self.refcount, self.getValueString(value)))
                value = None

            elif indirect:
                value = None


        if value is not None:
            if (cancelPending == False) or (cancelPending == None and not change):
                cancelStrategy = C_NONE

            try:
                self.update(value, error,
                            runHooks=runHooks,
                            cancelStrategy=cancelStrategy,
                            onCancel=onCancel,
                            onAbort=onAbort,
                            onError=onError,
                            descendants=descendants,
                            descendantHooks=descendantHooks,
                            waitDescendants=waitDescendants,
                            indirect=indirect,
                            change=change,
                            allHooks=allHooks,
                            raiseExceptions=raiseExceptions)
            except Exception, e:
                if raiseExceptions:
                    raise
                    

    def update (self, value, error=None, runHooks=True,
                onCancel=EH_CANCEL, onAbort=EH_RAISE, onError=EH_FAIL,
                cancelStrategy=C_CANCELABLE,
                descendants=True, descendantHooks=True,
                waitDescendants=True, indirect=False,
                change=False, allHooks=False, raiseExceptions=True):

        message = ('State %r update #%d from %s to %s'%
                   (self.name, self.changeIndex,
                    self.getValueString(self.value),
                    self.getValueString(value)))
        self.changeIndex   += 1

        acquiredLock = self.acquireLock(message, value, cancelStrategy)
        if acquiredLock:
            self.startUpdate()

        try:
            self.pendingValue   = value
            self.pendingError   = error

            if runHooks:
                isrerun = not change and not allHooks
                self.runValueHooks(value, indirect, isrerun, onCancel, onAbort, onError, message)
            else:
                debug("%s; skipping hooks"%(message,))

        finally:
            previousValue, previousError         = self.value, self.error
            value, error                         = self.pendingValue, self.pendingError
            self.updateValue(value, error)

            if value is None or not descendants or not len(self.descendants):
                self.publishValue()
                self.releaseLock(acquiredLock)
                self.completeUpdate()

            else:
                self.releaseLock(acquiredLock)
                if not waitDescendants and not error:
                    raise NextReply(None, self.updateDescendants,
                                    (value, descendantHooks, cancelStrategy, message), {})
                else:
                    self.updateDescendants(value, descendantHooks, cancelStrategy, message)

        if waitDescendants:
            self.waitDescendants()


    def updateDescendants (self, ownValue, runHooks, cancelStrategy, message):
        debug("%s starting descendant updates: %s"%
              (message, ", ".join([s.name for s in self.descendants])))

        threads = []
        updated = []
        for descendant in self.descendants:
            thread = self.updateDescendantThread(descendant, ownValue, runHooks, cancelStrategy, message)
            if thread:
                threads.append(thread)
                updated.append(descendant)

        self.publishValue()

        for thread in threads:
            thread.start()

        for thread in threads:
            thread.join()

        debug("%s finished descendant updates: %s"%
              (message, ", ".join([s.name for s in updated])))

        self.completeUpdate()


    def updateDescendantThread (self, descendant, ownValue, runHooks, cancelStrategy, message):
        satisfied = self in descendant.getAncestors(ownValue)
        thread    = None
        descendantValue = descendant.getValue(pending=True)

        if ownValue == FAILED:
            wantupdate = (descendantValue != FAILED)
        else:
            wantupdate = (descendantValue != satisfied)

        if not wantupdate:
            trace("%s reinforces descendant %s value to %s"%
                  (message, descendant.name, self.getValueString(descendantValue)))

        elif not self.doAutoUpdate(descendant, ownValue):
            trace("%s does not cause automatic change in %s, keeping at %s"%
                  (message, descendant.name, self.getValueString(descendantValue)))

        else:
            autoValue = descendant.filteredValue()
            if autoValue == descendantValue:
                trace("%s does not alter %s from %s due other dependencies"%
                      (message, descendant.name, self.getValueString(descendantValue)))

            else:
                message = '%s causes descendant %s change to %s'%\
                          (message, descendant.name, self.getValueString(autoValue))

                if runHooks:
                    debug("%s in new thread"%message)

                    descendant.publishPending(autoValue, indirect=True)

                    name = "|".join((currentThread().name, descendant.name))
                    thread = ControllableThread(None, descendant.setValue, name,
                                                (autoValue,),
                                                dict(raiseExceptions=False,
                                                     indirect=True,
                                                     cancelStrategy=cancelStrategy))
                    thread.setDaemon(True)
                else:
                    debug("%s in main thread"%message)
                    descendant.setValue(autoValue,
                                        runHooks=False,
                                        descendantHooks=False,
                                        indirect=True,
                                        cancelStrategy=cancelStrategy)

        return thread


    def runValueHooks (self, value, indirect, rerunOnly, onCancel, onAbort, onError, message):
        hooks = self.getHooks(value, indirect=indirect, rerunOnly=rerunOnly)
        if hooks:
            debug("%s; running hooks: %s"%
                  (message, " ".join([hook.name for hook in hooks])))
            self.publishPending(value, hooks=hooks)
            self.runHooks(hooks, value, indirect, task=message,
                          onCancel=onCancel, onAbort=onAbort, onError=onError)



    def runHooks (self, hooks, value, indirect=False, task=None, onCancel=EH_CANCEL, onAbort=EH_RAISE, onError=EH_FAIL):
        try:
            thread = currentThread()
            self.canceled   = C_NONE
            self.keepErrors = False

            if task is None:
                task = 'State %r'%(self.name,)

            for hook in hooks:
                if (self.canceled == C_NONE) or ((self.canceled == C_CANCELABLE) and not hook.cancelable):
                    try:
                        debug('%s invoking hook %r'%(task, hook.name))
                        self.runningHook = hook
                        thread.setAbortable((ALLOW, DEFER)[hook.unabortable])

                        result = hook.method(self, value, not indirect, *hook.args, **hook.kwargs)
                        trace('%s completed hook %r: %r'%(task, hook.name, result))

                    except Exception, e:
                        exception = scpiException(e, exc_info())

                        if self.keepErrors and self.pendingValue == FAILED:
                            action = EH_CONTINUE

                        elif isinstance(e, Aborted):
                            action = (onAbort, onCancel)[self.canceled == C_ALL]
                            thread.clearAbort()

                        else:
                            action = onError

                        if action == EH_FAIL and (hook.transient or exception.transient):
                            action = EH_RAISE

                        if action != EH_CANCEL:
                            message = exception.format(showContext=True, showTraceback=True)
                            text = ('%s encountered exception in hook %r, will %s: %s'%
                                    (task, hook.name, ExceptionHandling[action], message))
                            info(text)


                        if action == EH_CANCEL:
                            self.pendingValue, self.pendingError = None, None
                            break

                        elif (action == EH_REVERT) and (value != self.value):
                            self.pendingValue, self.pendingError = self.value, self.error
                            self.runValueHooks(self.value, False, False, onCancel, onAbort, onError, ExceptionHandling[action])
                            raise

                        elif action == EH_CONTINUE:
                            pass

                        elif action == EH_RAISE:
                            self.pendingValue, self.pendingError = None, None
                            self.runValueHooks(FAILED, False, False, onCancel, onAbort, onError, ExceptionHandling[action])
                            raise

                        elif (action == EH_FAIL) and (value != FAILED):
                            self.update(FAILED, exception, onCancel=onCancel, onAbort=onAbort, onError=onError,
                                        cancelStrategy=C_CANCELABLE, descendants=False, indirect=indirect,
                                        change=False)
                            raise

        finally:
            self.runningHook = None


    def updateValue (self, value, error):
        if value is not None:
            if self.value not in (value, FAILED):
                self.previousValue = self.value

            self.value, self.error = value, error

        self.pendingValue, self.pendingError = None, None
        #self.publishValue(self.value)

        self.changeWatch.acquire()
        try:
            self.changeWatch.notifyAll()
        finally:
            self.changeWatch.release()


    def publishPending (self, value, hooks=None, indirect=False):
        if hooks is None:
            hooks = self.getHooks(value, indirect=indirect)

        for hook in hooks:
            if not hook.quiet:
                self.publishValue(PENDING)
                break


    def publishValue (self, value=None):
        with self._mutex:
            if value is None:
                value = self.value

            if self.__class__.deferring:
                self.__class__.deferred = [ (s, v)
                                            for (s, v) in self.__class__.deferred
                                            if s is not self ]
                self.__class__.deferred.append((self, value))

            elif value != self.publishedValue:
                topics = set(self.notifyTopics)
                parts  = [ (self.name, self.getValueString(value)) ]
                for topic in topics:
                    publish(topic, parts)

                self.publishedValue = value


    @classmethod
    def setDeferred (cls, defer):
        cls.deferring = defer
        if not defer:
            for state, value in cls.deferred:
                state.publishValue(value)

            del cls.deferred[:]


    def acquireLock (self, task, value=None, cancelStrategy=C_REMAINING):
        thread = currentThread()
        
        if self.changeLock.acquire(0):
            ### There are no pending transitions; acquire lock.
            lock = self.changeLock

        elif self.pendingOwner == thread:
            ### Lock is already acquired to this thread.
            ### We are running from within a transition hook.
            lock = None
            debug('%s retained lock'%task)
            

        else:
            ptask = self.pendingTask or "operation"

            if (cancelStrategy is not C_NONE):
                self.cancelPending(strategy=cancelStrategy, task=task)

            debug('%s waiting for pending %c%s to complete'%(task, ptask[:1], ptask[1:]))

            self.changeLock.acquire()
            lock = self.changeLock

        if lock:
            self.pendingOwner = currentThread()
            self.pendingTask  = task
        
        return lock


    def releaseLock (self, lock):
        if lock:
            self.pendingOwner = None
            self.pendingTask  = None
            lock.release()


    def wait (self, value=None, timeout=None, ignoreErrors=True, pending=False, mustChange=False):
        
        debug("Waiting %s for state %r update%s"%
              (("indefinitely", "up to %ss"%timeout)[timeout is not None],
               self.name,
               (value is not None and " to "+StateStrings[value] or "")))

        currentValue = self.value
        self.changeWatch.acquire()

        try:
            if value == currentValue:
                return True

            elif (value is None) and pending and not self.pendingOwner:
                return True

            else:
                start = getUptime()
                remaining = timeout
                while self.changeWatch.wait(remaining):
                    if self.value == value:
                        return True

                    elif (value != FAILED) and (self.value == FAILED) and not ignoreErrors:
                        return False

                    elif (value is None) and (self.value != currentValue or not mustChange):
                        return True

                    if timeout is not None:
                        remaining = start + timeout - getUptime()

                else:
                    return False
        finally:
            self.changeWatch.release()


    def startUpdate (self):
        self.changeEvent.clear()

    def completeUpdate (self):
        self.changeEvent.set()

    def waitDescendants (self, timeout=None, cancelable=True):
        return self.changeEvent.wait(timeout, cancelable=cancelable)


    def doAutoUpdate (self, descendant, ownValue):
        for relationship, ancestors in descendant.ancestors.items():
            for ancestor, manual, hard in ancestors:
                if ancestor is self and not manual:
                    return True

        return False

    def filteredValue (self, attemptedValue=None, usePending=False, ignoreManual=False, boolean=False):
        dibs = { OFF: [], ON: [], FAILED: [], PENDING: [] }

        currentValue = self.getValue(settled=True)
        gotAncestors = False

        for relationship, ancestors in self.ancestors.items():
            for ancestor, manual, hard in ancestors:
                gotAncestors = True
                if (hard and attemptedValue == ON) or (attemptedValue is None):
                    aCurrentValue, aPendingValue = ancestor.value, ancestor.pendingValue

                    if (aPendingValue is not None) and not usePending:
                        dibs[PENDING].append(ancestor)

                    elif (aCurrentValue == FAILED):
                        dibs[FAILED].append(ancestor)

                    elif (((aCurrentValue != relationship) and (aPendingValue is None or not usePending)) or
                          ((aPendingValue not in (relationship, None)) and (currentValue == OFF or usePending))):
                        dibs[OFF].append(ancestor)

                    elif (attemptedValue is None) and (ignoreManual or not manual):
                        dibs[ON].append(ancestor)

        for candidate in (FAILED, PENDING, OFF, ON):
            if dibs[candidate]:
                if not attemptedValue in (None, candidate):
                    raise self.UnsatisfiedDependencies(dibs[candidate])

                if candidate == PENDING:
                    value = self.value

                elif boolean and (candidate == FAILED):
                    value = self.previousValue

                else:
                    value = candidate


                trace("State %r filteredValue(%s, usePending=%s, ignoreManual=%s, boolean=%s) = %s; dibs: %s"%
                      (self.name, self.getValueString(attemptedValue), usePending, ignoreManual, boolean,
                       (value, self.getValueString(value))[value is not None],
                       ",".join([s.name for s in dibs[candidate]])))

                return value
        else:
            if attemptedValue is not None:
                return attemptedValue
            elif not gotAncestors:
                return True
            else:
                return self.getValue(pending=True, boolean=boolean)



    def addDescendant (self, other, edge=True, manual=False, hard=False, front=False):
        if front:
            self.descendants.insert(0, other)
        else:
            self.descendants.append(other)

        other.ancestors[edge].append((self, manual, hard))

    def removeDescendant (self, other, autoUpdate=True):
        myvalue    = self.value
        removed    = 0

        #compatible = self in other.getAncestorMap()[myvalue]

        for relationship, ancestors in other.ancestors.items():
            for index, item in enumerate(ancestors):
                obj, manual, hard = item
                if obj is self:
                    del ancestors[index]
                    removed += 1
                    break
        
        self.descendants.remove(other)
        debug("Removed descendant %r from %r, removed %d ancestor(s) from %r"%
              (other.name, self.name, removed, other.name))

        if autoUpdate:
            autoValue = other.filteredValue()
            if autoValue != other.getValue(pending=True):
                other.setValue(autoValue, raiseExceptions=False, indirect=True)

    def getDescendants (self, edge=None, recursive=False):
        if edge is None:
            result = set(self.descendants)
        else:
            result = set([ d for d in self.descendants if self in d.getAncestorMap()[edge] ])

        if recursive:
            for descendant in result.copy():
                result.update(descendant.getDescendants(edge=edge,
                                                        recursive=True))

        return result


    def clearDescendants (self, edge=None, autoUpdate=True):
        for descendant in self.getDescendants(edge):
            self.removeDescendant(descendant, autoUpdate=True)

    def getAncestors (self, edge=None, recursive=False):
        result = []

        for direction, ancestors in self.getAncestorMap(recursive=recursive).items():
            if edge in (None, direction):
                result.extend(ancestors)

        return result

    def getAncestorMap (self, recursive=False, manual=None, hard=None):
        result = { False: set(), True: set() }

        for edge, items in self.ancestors.items():
            ancestors = [ obj
                          for obj, m, h in items
                          if manual in (None, m) and hard in (None, h) ]
            result[edge].update(ancestors)

            if recursive:
                for ancestor in ancestors:
                    for direction, recursed in ancestor.getAncestorMap(True).items():
                        result[edge == direction].update(recursed)

        return result


    def clearAncestors (self):
        for edge, ancestors in self.ancestors.items():
            for ancestor, manual, hard in ancestors:
                ancestor.descendants.remove(self)

            del ancestors[:]


    def cancelPending (self, strategy, descendants=True, recursive=True, keepErrors=False, task=None):
        states = [ (self, self.pendingOwner, self.runningHook) ]
        if descendants:
            states += [ (s, s.pendingOwner, s.runningHook)
                        for s in self.getDescendants(recursive=recursive)
                        if s.runningHook ]

        ptask = self.pendingTask or "operation"
        debug('%s execution of %s hooks in pending %c%s'
              %(task and "%s canceling"%task or "Canceling",
                CancelStrategy[strategy],
                ptask[:1].lower(), ptask[1:]))

        for state, thread, runningHook in states:
            state.canceled   = strategy
            state.keepErrors = keepErrors

            if not keepErrors or not state.pendingValue == FAILED:
                state.pendingValue = None
                state.pendingError = None


            if thread:
                if strategy == C_ALL:
                    debug("Canceling state %r hook %r"%(state.name, runningHook.name))
                    thread.abort()
                    return True

                elif (strategy != C_NONE) and runningHook:
                    hooks = state.getHooks()
                    for hook in hooks:
                        if (hook == runningHook):
                            if hook.cancelable:
                                debug("Cancelling state %r hook %r"%(state.name, hook.name))
                                thread.abort()
                            else:
                                debug("Leaving state %r hook %r running"%(state.name, hook.name))
                            return True
                    else:
                        notice("Cannot cancel state %r hook %r: Unable to find hook"%(state.name, runningHook.name))

            return False



    def cancelHook (self, hook):
        thread, runningHook = self.pendingOwner, self.runningHook
        self.pendingValue, self.pendingError = None, None

        if thread and (runningHook == hook):
            debug("Canceling state %r hook %r"%(self.name, hook.name))
            thread.abort()
            return True
        else:
            debug("State %r hook %r is not running, cannot cancel."%(self.name, hook.name))
            return False


    def getCulprits (self, expected=True, actual=None, manual=None, hard=None):
        if actual is None:
            actual = self.getValue()

        culprits = {}
        if actual != expected:
            if not self.primary:
                for relationship, ancestors in self.getAncestorMap(manual=manual, hard=hard).items():
                    expectedAncestorValue = relationship == expected
                    for ancestor in ancestors:
                        ancestorValue = ancestor.value

                        if (ancestor.pendingValue is not None):
                            culprits[ancestor] = PENDING

                        elif (((actual != FAILED) and (ancestorValue != ON) and (expectedAncestorValue == ON)) or
                              ((actual == ancestorValue == FAILED) and (self.error is None))):
                            culprits.update(ancestor.getCulprits(expectedAncestorValue, ancestorValue))

                        elif (ancestorValue == ON) and (expectedAncestorValue == OFF) and (actual != FAILED):
                            culprits[ancestor] = ancestorValue

            if not culprits:
                if self.pendingValue is not None:
                    culprits[self] = PENDING
                else:
                    culprits[self] = actual

        return culprits


    def getCulpritNames (self, expected=True, manual=None, hard=None):
        culprits = [ (c.name, c.getValueString(v))
                     for (c, v) in self.getCulprits(expected=expected, manual=manual, hard=hard).items() ]
        culprits.sort()
        return culprits


    def getCulpritMessage (self, expected=True, culprits=None, manual=None, hard=None):
        values, reasons = self.getCulpritReasons(expected, culprits, manual, hard)
        return (",".join([state for (state, value) in values]),
                ", ".join(reasons))


    def getCulpritReasons (self, expected=True, culprits=None, manual=None, hard=None):
        if culprits is None:
            culprits = self.getCulprits(expected, None, manual, hard)
            
        values      = []
        reasons     = []
        reason = None

        for c, v in culprits.items():
            values.append((c.name, c.getValueString(v)))
            reasons.append(c.getReason(v))

        return values, reasons


    def setError (self, errorid, message, **options):
        error = UserError(errorid, message, **options)
        self.setValue(FAILED, error, raiseExceptions=True)


    def getErrors (self, withAncestors=True, pending=False):
        states = [ self ]
        if withAncestors:
            states.extend(self.getAncestors(recursive=True))

        errors = []
        for s in states:
            if (pending and s.pendingError is not None):
                errors.append(s.pendingError)

            elif s.error is not None:
                errors.append(s.error)

        return errors


    def unlink (self):
        self.clearDescendants()
        self.clearAncestors()


    def setHook (self, name, hook, phase=None, immediate=False):
        lock    = self.acquireLock('state %r hook %r addition'%(self.name, name,))
        try:
            self.clearHook(name)
            self.hooks.setdefault(phase, []).append(hook)
            if immediate:
                if self.value in hook.edges:
                    self.runHooks([hook], self.value)
        finally:
            self.releaseLock(lock)


    def getHookAndPhase (self, name):
        for phase in range(len(Phases)):
            for candidate in self.hooks.get(phase, ()):
                if candidate.name.lower() == name.lower():
                    return candidate, phase
        return None, None

    def getHook (self, name):
        hook, phase = self.getHookAndPhase(name)
        return hook


    def clearHook (self, name):
        for phase, hooks in self.hooks.items():
            for index, hook in enumerate(hooks):
                if hook.name.lower() == name.lower():
                    del hooks[index]
                    if not hooks:
                        del self.hooks[phase]
                    return True
        else:
            return False


    def clearHooks (self):
        self.hooks.clear()


    def getHooks (self, edge=None, phase=None, indirect=False, rerunOnly=False):
        if edge is not None:
            edges = {edge}
        else:
            edges = set(range(len(EdgeStrings)))

        if phase is None:
            hooks = []
            for phase in range(len(Phases)):
                hooks.extend(self.hooks.get(phase, []))
        else:
            hooks = self.hooks.get(phase, [])

        return [ hook for hook in hooks
                 if ((edges & hook.edges)
                     and not (indirect and hook.noindirect)
                     and (hook.rerun or not rerunOnly)) ]

    def getHookNames (self, edge, phase=None, indirect=False, rerunOnly=False):
        return [ hook.name for hook in self.getHooks(edge, phase, indirect, rerunOnly) ]

    def getValue (self, boolean=False, pending=False, settled=False):
        value, pendingValue, previousValue = self.value, self.pendingValue, self.previousValue

        if (pending and pendingValue is not None) and not (boolean and pendingValue == FAILED):
            value = pendingValue
            
        elif pendingValue is not None and not boolean and not settled:
            value = PENDING

        elif value == FAILED:
            value = (FAILED, previousValue)[boolean]

        return value

        

    def getValueString (self, value=None, boolean=False, pending=False, default="initial"):
        if value is None:
            value = self.getValue(boolean=boolean, pending=pending)

        try:
            return StateStrings[value]
        except TypeError:
            return default


    def setActionText (self, value, text):
        self.actions[value] = text


    def clearActionTexts (self):
        self.actions.clear()


    def getActionText (self, value):
        if value in self.actions:
            return self.actions[value]

        else:
            return "change %r state to %s"%(self.name, self.getValueString(value))


    def setReason (self, value, reason):
        self.reasons[value] = reason


    def clearReasons (self):
        self.reasons.clear()


    def getReason (self, value=None, explicit=False):
        if value is None:
            value = self.getValue()

        if value in self.reasons:
            return self.reasons[value]

        elif explicit:
            return ""

        elif value is FAILED:
            errors = self.getErrors()
            if errors:
                return errors[0].format()
            else:
                return "%s failed"%(self.name,)

        else:
            return "%s is %s"%(self.name, self.getValueString(value))


class State (CommandWrapper, FullBranch):
    '''
    State subsystem
    '''

    class StateExists (RunError):
        'The state %(name)r already exists'

    class NoSuchState (RunError):
        'No such state exists: %(name)r'

    class HookExists (RunError):
        'State %(state)r already has a hook named %(hook)r'

    class NoSuchHook (RunError):
        'No such hook exists in state(s) %(states)s: %(hook)r'

    class NotADescendant (RunError):
        'The state %(descendant)r is not a descendant of %(ancestor)r'

    class StateWithDescendants (RunError):
        'The state %(name)r cannot be removed, because it is ancestor for other state(s).'

    class UnsatisfiedRequirement (RunError):
        'Cannot %(action)s because %(reason)s'
        transient = True

    class CircularStateDependency (RunError):
        'The state %(descendant)r cannot depend on %(ancestor)r, because it would create a circular dependency.'
        
    class ConflictingDependency (RunError):
        'The state %(descendant)r cannot depend on %(ancestor)r, due to confliciting dependencies: %(conflicts)s'

    class DuplicateDependency (RunError):
        'The state %(descendant)r already depends on %(ancestor)r'

    class InvalidEdge (RunError):
        'Edge must be one of %(validEdges)s, not %(edge)r'



    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        State.init(self, *args, **kwargs)

    def init (self, *args, **kwargs):
        self.states = {}
        self.addShutDownAction(self.shutdownStates)


    def shutdownStates (self):
        states = [ state for state in self.states.itervalues()
                   if state.shutdownValue is not None ]

        if states:
            debug("Bringing down states: %s"%(", ".join([ s.name for s in states ])))
            for state in states:
                state.setValue(state.shutdownValue, raiseExceptions=False, indirect=True, cancelPending=C_ALL)
                


    def newState (self, name, value, replaceExisting=False, shutdownValue=None, primary=False, queueSize=None, aliases=()):
        try:
            obj = self.states[name.lower()]
        except KeyError:
            pass
        else:
            if not replaceExisting:
                raise self.StateExists(name=obj.name)
            else:
                self.delState(name)

        self.states[name.lower()] = obj = _State(name, value, shutdownValue=shutdownValue, primary=primary, queueSize=queueSize)
        for alias in aliases:
            self.states[alias.lower()] = obj
        return obj


    def getStates (self, names):
        return [ self.getState(name)
                 for name in filter(None, names) ]


    def getEdges (self, names):
        try:
            edgemap = dict([ (s.lower(), i) for (i, s) in enumerate(EdgeStrings) ])
            return set([ edgemap[name.lower()] for name in names ])

        except KeyError, e:
            name, = e.args
            raise self.InvalidEdge(edge=name, validEdges="/".join(EdgeStrings))


    def getState (self, name, ignoreMissing=False):
        try:
            return self.states[name.lower()]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchState(name=name)


    def delState (self, name, ignoreMissing=False, force=False):
        state = self.getState(name, ignoreMissing)

        if state:
            if not force:
                descendants = state.getDescendants()
                if descendants:
                    raise self.StateWithDescendants(name=state.name,
                                                    descendant=descendants[0].name)

            state.unlink()
            for n, s in self.states.items():
                if s is state:
                    del self.states[n]


    def addAliases (self, name, aliases=()):
        state = self.getState(name)

        for alias in aliases:
            self.states[alias.lower()] = state


    def delAliases (self, name, aliases=()):
        state = self.getState(name)
        n = state.name.lower()

        for alias in aliases:
            a = alias.lower()
            if a != n and a in self.states:
                del self.states[a]

    def getAliases (self, name):
        state = self.getState(name)
        n = state.name.lower()

        aliases = [ a for a, s in self.states.items() if s is state and a != n ]
        aliases.sort()
        return aliases


    def clearAliases (self, name):
        aliases = self.getAliases(name)
        for a in aliases:
            del self.states[a]
    

    def addDependencies (self, state, positive, negative, keepExisting=False, replaceExisting=False, autoUpdate=True,
                         manual=False, hard=False, front=False):

        myAncestors   = set(state.getAncestors())
        myDescendants = set(state.getDescendants(recursive=True))
        myDescendants.add(state)

        for wrongEdge, ancestors in ((True, negative), (False, positive)):
            conflictingAncestors = state.getAncestors(edge=wrongEdge, recursive=False)

            for ancestor in ancestors:
                if ancestor in myDescendants:
                    circulars = ",".join([ a.name
                                           for a in ancestor.getAncestors(recursive=True)
                                           if a in myDescendants ])
                    raise self.CircularStateDependency(descendant=state.name,
                                                       ancestor=ancestor.name,
                                                       circulars=circulars)
                if ancestor in conflictingAncestors:
                    conflicts = ",".join([ a.name
                                           for a in ancestor.getAncestors(recursive=False)
                                           if a in conflictingAncestors ])
                    raise self.ConflictingDependency(descendant=state.name,
                                                     ancestor=ancestor.name,
                                                     conflicts=conflicts)


                if ancestor in myAncestors and not keepExisting and not replaceExisting:
                    raise self.DuplicateDependency(descendant=state.name,
                                                   ancestor=ancestor.name)

        modified = False
        for edge, ancestors in ((True, positive), (False, negative)):
            for ancestor in ancestors:
                if not ancestor in myAncestors:
                    ancestor.addDescendant(state, edge, manual, hard, front)
                    modified = True


        if modified and not keepExisting:
            attemptedValue = (state.getValue(pending=True), None)[autoUpdate]
            try:
                value = state.filteredValue(attemptedValue)
            except state.UnsatisfiedDependencies, e:
                value = state.getValueString(attemptedValue)
                action = state.getActionText(attemptedValue)
                culprits, reason = state.getCulpritMessage(attemptedValue, hard=True)

                error = self.UnsatisfiedRequirement(name=state.name, value=value, culprits=culprits, action=action, reason=reason)
                state.setError(error.name, str(error), **error.kwargs)
                raise error

            if value != state.getValue(pending=True):
                state.setValue(value, indirect=True)


    def removeDependencies (self, state, ancestors, ignoreMissing=False, autoUpdate=True):
        if not ignoreMissing:
            myAncestors = state.getAncestors()
            for ancestor in ancestors:
                if not ancestor in myAncestors:
                    raise self.NotADescendant(descendant=state.name,
                                              ancestor=ancestor.name)


        for ancestor in ancestors:
            try:
                ancestor.removeDescendant(state, autoUpdate=autoUpdate)
            except ValueError:
                pass


    def clearDependencies (self, state, autoUpdate=True):
        self.removeDependencies(state, self.states, ignoreMissing=True, autoUpdate=autoUpdate)


    def getDependencies (self, state, edge=None, recursive=False,
                         ancestors=True, descendants=False):
        deps = set()

        if ancestors:
            deps.update(state.getAncestors(edge=edge, recursive=recursive))

        if descendants:
            deps.update(state.getDescendants(edge=edge, recursive=recursive))

        return deps



    def setValue (self, state, value=None, **opts):
        try:
            value = state.filteredValue(value)
        except state.UnsatisfiedDependencies, e:
            culprits, reason = state.getCulpritMessage(value, hard=True)
            valuestring      = state.getValueString(value)
            action           = state.getActionText(value)

            raise self.UnsatisfiedRequirement(name=state.name, value=valuestring,
                                              culprits=culprits, action=action, reason=reason)

        else:
            state.setValue(value, **opts)
        


    def runHook (self, state, value, direct, command, accessLevel, hookName, scope):
        oldValueString = state.getValueString(state.value)
        newValueString = state.getValueString(value)

        substitutions  = dict(name=state.name, value=newValueString, previousValue=oldValueString, direct=direct)
        stream         = self.commandStream(command, **substitutions)
        session        = NestedSession(parent=None, input=stream, access=accessLevel,
                                       description='state %r hook %r'%(state.name, hookName))

        session.handle(scope or self.parent, localdata=DynamicData(substitutions))
        
    class NEW (Controlling, Leaf):
        '''
        Create a new state.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("nick", type=str, split=",", default=(), named=True,
                          description="Comma-separated list of nicknames for this state")
            self.setInput("requires", type=str, split=",", default=(), named=True,
                          description="Comma-separated list of ancestor states that must "
                          "all be set to True before the descendant state may be set.")
            self.setInput("conflicts", type=str, split=",", default=(), named=True,
                          description="Comma-separated list of ancestor states that must "
                          "all be cleared (set to False) before the dependant state may be set.")
            self.setInput("primary", type=bool, named=True, default=False,
                          description="When searching for culprits, include this state rather than "
                          "considering its ancestors")
            self.setInput("queueSize", type=int, named=True, range=(0, None), default=None,
                          description="Maximum reference count for '-enqueue' option (see SETTing). "
                          "A size of 0 disables queueing.")
            self.setInput("hard", type=bool, default=False, named=True,
                          description="This dependency is absolute; if attempting to change the state value "
                          "not in accordance with the values of its ancestors, an error is returned.")
            self.setInput("manual", type=bool, default=False, named=True,
                          description="Do not automatically hook value changes as a result of this dependeny.")
            self.setInput("shutdown", type=bool, default=False,
                          description="Reset state to initial value when shutting down")
            self.setInput("name", type=str,
                          description="Name of state")
            self.setInput("value", type=bool, default=None, 
                          description="Initial value")

        def run (self, _session, replaceExisting=False, nick="", requires="", conflicts="", primary=False,
                 hard=False, manual=False, queueSize=None, shutdown=False, name=str, value=None):

            
            shutdownValue = (None, int(value or False))[shutdown]
            state = self.parent.newState(name, int(value or OFF), replaceExisting, 
                                         primary=primary, queueSize=queueSize, shutdownValue=shutdownValue)

            if nick:
                self.parent.addAliases(name, nick)

            positive   = self.parent.getStates(requires)
            negative   = self.parent.getStates(conflicts)

            pre = state.getValueString()
            self.parent.addDependencies(state, positive, negative, autoUpdate=(value is None), hard=hard, manual=manual)
            post = state.getValueString()
#            self.parent.setValue(state, int(value or False))



    class DELete (Controlling, Leaf):
        '''
        Remove a state
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, default=False, named=True,
                          description="Do not complain if state does not exist")
            self.setInput('force', type=bool, default=False, named=True,
                          description="Remove the state even if it has descendants")

        def run (self, ignoreMissing=False, force=False, name=str):
            self.parent.delState(name, ignoreMissing=ignoreMissing, force=force)




    class SETTing (Controlling, Leaf):
        '''
        Set or clear the specified state.  If the state changes
        as a result, run associated hooks. 

        If the state has any descendants (i.e. states whose value depend
        on this state), the value of those states may be altered as well.
        Normally this happens asynchronously, unless the "-synchronous"
        option is given.
        '''

        class NoChange (RunError):
            '''State %(name)r is already %(value)r'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('skipHooks', type=bool, default=False,
                          description='Just set the value; do not run hooks '
                          'associated with this state change.  Hooks in descendant '
                          'states are still run')

            self.setInput('skipTriggers', type=bool, default=False, hidden=True,
                          description='Deprecated; use "-skipHooks".')

            self.setInput('skipAllHooks', type=bool, default=False,
                          description='Just set the value; do not run hooks '
                          'associated with this state change, or descendant state '
                          'changes.')

            self.setInput('skipAllTriggers', type=bool, default=False,
                          description='Deprecated; use "-skipAllHooks".')

            self.setInput('skipDescendants', type=bool, default=False,
                          description='Update this state only, not its descendants')

            self.setInput('rerun', type=bool, default=False,
                          description='Run hooks for this transition, even if the value does not change.')

            self.setInput('enqueue', type=bool, default=False,
                          description='If state is already set/unset, increment its reference count. '
                          'The reference count is cleared (set to zero) each time the value changes. '
                          'See also "-dequeue"')

            self.setInput('dequeue', type=bool, default=False,
                          description='If the state has a non-zero reference count, '
                          'decrement this count rather than changing the value')

            self.setInput('cancelPending', type=bool, named=True, default=None,
                          description='Cancel any state change currently in progress. '
                          'By default, a pending state change is cancelled if the new and pending values are different.')

            self.setInput('cancelPendingHooks', type=CancelStrategy, named=True, default=C_REMAINING,
                          description='Specify what hooks to cancel for a state change already in progress: '
                          'Complete without interruption, only cancelable hooks, '
                          'currently executing hook if cancelable then all remaining hooks, or '
                          'currently executing hook and remaining hooks regardless of cancelable status.')

            self.setInput('onCancel', type=ExceptionHandling, named=True, default=EH_CANCEL,
                          description='Specify what to do if the state change is canceled.')

            self.setInput('onAbort', type=ExceptionHandling, named=True, default=EH_RAISE,
                          description='Specify what to do if the state change is aborted.')

            self.setInput('onError', type=ExceptionHandling, named=True, default=EH_FAIL,
                          description='Specify what to do if the state change counters an error')

            self.setInput('keepErrors', type=bool, default=False,
                          description='Do not change this state if it is currently failed')

            self.setInput('mustChange', type=bool, default=False,
                          description='Raise an error if no change would occur, ie. if the current and new values are the same.')

            self.setInput('ifChange', type=bool, default=False,
                          description='Do nothing if no change would occur, ie. if the current/pending and new values are the same.')

            self.setInput('synchronous', type=bool, default=False,
                          description='Wait until all descendant states have been updated prior to returning')
            
            self.setInput('asynchronous', type=bool, default=False,
                          description='Set state asynchronously')


        def run (self, _session, createMissing=False,
                 skipHooks=False, skipAllHooks=False, skipTriggers=False, skipAllTriggers=False, skipDescendants=False,
                 rerun=False, enqueue=False, dequeue=False, cancelPending=None, cancelPendingHooks=CancelStrategy,
                 onCancel=ExceptionHandling, onAbort=ExceptionHandling, onError=ExceptionHandling,
                 keepErrors=False, mustChange=False, ifChange=False, 
                 synchronous=False, asynchronous=False,
                 state=str, setting=bool):

            self.checkConflictingOptions(synchronous=synchronous,
                                         asynchronous=asynchronous)
            self.checkConflictingOptions(rerun=rerun,
                                         skipTriggers=skipTriggers,
                                         skipHooks=skipHooks,
                                         skipAllHooks=skipAllHooks,
                                         skipAllTriggers=skipAllTriggers)

            if skipTriggers:
                skipHooks = True

            if skipAllTriggers:
                skipAllHooks = True

            obj     = self.parent.getState(state, ignoreMissing=createMissing)
            setting = int(setting)

            if not obj:
                self.parent.newState(state, setting)

            elif mustChange and obj.getValue(pending=True) == setting:
                raise self.NoChange(name=obj.name, value=StateStrings[setting])

            elif not ifChange or obj.getValue(pending=True) != setting:
                argmap = dict(state=obj, value=setting,
                              cancelPending=cancelPending,
                              cancelStrategy=cancelPendingHooks,
                              runHooks=not skipHooks and not skipAllHooks,
                              descendants=not skipDescendants,
                              descendantHooks=not skipAllHooks,
                              allHooks=rerun,
                              raiseExceptions=True,
                              waitDescendants=synchronous or asynchronous,
                              onCancel=onCancel,
                              onAbort=onAbort,
                              onError=onError,
                              keepErrors=keepErrors,
                              enqueue=enqueue,
                              dequeue=dequeue)

                if asynchronous:
                    raise NextReply(self, self.parent.setValue, (), argmap)
                else:
                    self.parent.setValue(**argmap)



    class AutoSetting (Controlling, Leaf):
        '''
        Automatically set or clear a state value, depending on its ancestor values.

        If the state has any descendants (i.e. states whose value depend
        on this state), the value of those states may be altered as well.
        Normally this happens asynchronously, unless the "-synchronous"
        option is given.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)

            self.setInput('pending', type=bool, named=True, default=False,
                          description='Filter based on pending values of ancestor states')

            self.setInput('skipHooks', type=bool, default=False,
                          description='Just set the value; do not run hooks '
                          'associated with this state change.  Hooks in descendant '
                          'states are still run')

            self.setInput('skipAllHooks', type=bool, default=False,
                          description='Just set the value; do not run hooks '
                          'associated with this state change, or descendant state '
                          'changes.')

            self.setInput('rerun', type=bool, default=False,
                          description='Run all hooks for this transition, even if the value does not change.')

            self.setInput('skipDescendants', type=bool, default=False,
                          description='Update this state only, not its descendants')

            self.setInput('cancelPending', type=bool, named=True, default=None,
                          description='Cancel any state change currently in progress. '
                          'By default, a pending state change is cancelled if the new and pending values are different.')

            self.setInput('cancelPendingHooks', type=CancelStrategy, named=True, default=C_REMAINING,
                          description='Specify what hooks to cancel for a state change already in progress: '
                          'Complete without interruption, only cancelable hooks, '
                          'currently executing hook if cancelable then all remaining hooks, or '
                          'currently executing hook and remaining hooks regardless of cancelable status.')

            self.setInput('onCancel', type=ExceptionHandling, named=True, default=EH_CANCEL,
                          description='Specify what to do if the state change is canceled.')

            self.setInput('onAbort', type=ExceptionHandling, named=True, default=EH_RAISE,
                          description='Specify what to do if the state change is aborted.')

            self.setInput('onError', type=ExceptionHandling, named=True, default=EH_FAIL,
                          description='Specify what to do if the state change counters an error')

            self.setInput('keepErrors', type=bool, default=False,
                          description='Do not change this state if it is currently in error')

            self.setInput('ifChange', type=bool, default=False,
                          description='Do nothing if no change would occur, ie. if the current/pending and new values are the same.')

            self.setInput('synchronous', type=bool, default=False,
                          description='Wait until all descendant states have been updated prior to returning')
            
            self.setInput('asynchronous', type=bool, default=False,
                          description='Set state asynchronously')

            self.setInput('setting', type=bool, default=None,
                          description='Only set to the specified value')


        def run (self, _session, pending=False, skipHooks=False, rerun=False, 
                 skipAllHooks=False, skipDescendants=False,  cancelPending=None, cancelPendingHooks=CancelStrategy,
                 onCancel=ExceptionHandling, onAbort=ExceptionHandling, onError=ExceptionHandling,
                 keepErrors=False, ifChange=False, synchronous=False, asynchronous=False, state=str, setting=None):
                 

            self.checkConflictingOptions(synchronous=synchronous,
                                        asynchronous=asynchronous)
            self.checkConflictingOptions(rerun=rerun,
                                         skipHooks=skipHooks,
                                         skipAllHooks=skipAllHooks)
            
            obj = self.parent.getState(state)
            autoValue = obj.filteredValue(usePending=pending, ignoreManual=True)

            if setting in (None, autoValue) and (not ifChange or autoValue != obj.getValue(pending=True)):
                argmap = dict(value=autoValue,
                              allHooks=rerun,
                              runHooks=not skipHooks and not skipAllHooks,
                              descendants=not skipDescendants,
                              descendantHooks=not skipAllHooks,
                              raiseExceptions=True,
                              waitDescendants=synchronous or asynchronous,
                              cancelPending=cancelPending,
                              cancelStrategy=cancelPendingHooks,
                              onCancel=onCancel, onAbort=onAbort, onError=onError,
                              keepErrors=keepErrors)

                if asynchronous:
                    raise NextReply(self, obj.setValue, (), argmap)
                else:
                    obj.setValue(**argmap)



    class AutoValue_Query (Observing, Leaf):
        '''Return the "automatic" value of the specified state, derived from its depenencies on ancestors.'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('pending', type=bool, named=True, default=False,
                          description='Filter based on pending values of ancestor states')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=StateStrings)


        def run (self, _session, pending=False, boolean=False, state=str):
            obj = self.parent.getState(state)
            return obj.filteredValue(usePending=pending, ignoreManual=True, boolean=boolean)

            

    class CANCel (Controlling, Leaf):
        '''
        Cancel any pending state transition, or a specific hook.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('hooks', type=CancelStrategy, named=True, default=C_REMAINING)
            self.setInput('descendants', type=bool, named=True, default=False,
                          description='Also cancel any pending hooks in descendant states.')
            self.setInput('keepErrors', type=bool, named=True, default=False,
                          description='If state is failed or failing, keep it that way')
            self.setInput('state', type=str)
            self.setInput('hook', type=str, default=None)


        def run (self,  ignoreMissing=False, hooks=CancelStrategy, keepErrors=False, descendants=False, state=str, hook=None):
            s = self.parent.getState(state)

            if not hook:
                s.cancelPending(descendants=descendants, strategy=hooks, keepErrors=keepErrors)

            else:
                hook = s.getHook(hook)
                if hook:
                    s.cancelHook(hook)

                elif not ignoreMissing:
                    raise self.parent.NoSuchHook(states=s.name, hook=hook)
                    
        


    class PENDing_Enumerate (Observing, Leaf):
        '''
        Enumerate states that are currently being updated among the specified state and its ancestors.
        If no state is given, enumerate all states that are currently being updated.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('state', type=str, default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('state', type=str, repeats=(0, None))

        def run (self, state=str):
            if state:
                s = self.parent.getState(state)
                states = [s]
                states.extend(s.getAncestors(recursive=True))
            else:
                states = self.parent.states.values()

            return tuple(sorted([ s.name
                                  for s in states
                                  if s.pendingValue is not None ]))
            

    class PENDing_List (Observing, Leaf):
        '''
        List states that are currently being updated among the specified state and its ancestors.
        If no state is given, list all states that are currently being updated.

        One state is listed on each line, as follows:

            <stateName> -edge={Set|Clear|Failed} -hook=<hookName>

        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('state', type=str, default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('states', type=list, repeats=(0, None), default=None)

        def run (self, state):
            if state:
                s = self.parent.getState(state)
                states = [s]
                states.extend(s.getAncestors(recursive=True))
            else:
                states = self.parent.states.values()

            pendingStates = []
            for s in states:
                pendingValue  = s.pendingValue
                runningHook  = s.runningHook
                if pendingValue is not None and runningHook is not None:
                    parts = [ (None,      s.name),
                              ('edge',    EdgeStrings[pendingValue]),
                              ('hook',    runningHook.name) ]
                    pendingStates.append(parser.collapseArgs(parts))

            return (sorted(pendingStates) or None,)
            

    class PENDing_Query (Observing, Leaf):
        '''
        Indicate if a state is currently in transition.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('descendants', type=bool, default=False,
                          description='Return True only after the state change '
                          'has cascaded through all its descendants')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('pending', type=bool)
            self.addOutput('hook', type=str, named=True, default=None)

        def run (self, descendants=False, hook=False, state=str):
            obj = self.parent.getState(state)

            runningHook = obj.runningHook
            if hook and runningHook:
                hname = runingHook.name
            else:
                hname = None

            return (runningHook is not None, hname)


    class SETTing_Query (Observing, Leaf):
        '''
        Return the value of the specified state.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('named', type=bool, default=False,
                          description='Return state names along with their values ("-state=value")')

            self.setInput('boolean', type=bool, default=False,
                          description="Always return True or False, never Failed or Pending.")

            self.setInput('pending', type=bool, default=False,
                          description='Return expected state value after completion of any hooks '
                          'currently in progress.  Useful within these hooks.')

            self.setInput('ancestors', type=bool, default=False,
                          description="Also list ancestor states, i.e. "
                          "other states on which this state depends.  Implies '-named'.")
            
            self.setInput('descendants', type=bool, default=False,
                          description="Also list descendant states, i.e. "
                          "other states that depend on this state. Implies '-named'")

            self.setInput('recursive', type=bool, default=False,
                          description="If set in concjunction with 'ancestors' or "
                          "'descendants', recursively list all ancestors or descendants")

            self.setInput('names', type=str, repeats=(1, None))


        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('states', type=tuple, repeats=(1, None))


        def run (self, ignoreMissing=False, named=False, boolean=False, pending=False, ancestors=False, descendants=False, recursive=False, *names):

            outputs = []
            for name in names:
                obj = self.parent.getState(name, ignoreMissing=ignoreMissing)

                if obj is None:
                    outputs.append((named and name or None, False, None))
                    

                elif ancestors or descendants:
                    states = [ obj ]
                    states += self.parent.getDependencies(obj, recursive=recursive,
                                                          ancestors=ancestors,
                                                          descendants=descendants)

                    outputs.extend([ (obj.name,
                                      obj.getValueString(boolean=boolean, pending=pending),
                                      None)
                                     for obj in states ])
                else:
                    outputs.append((named and obj.name or None, obj.getValueString(boolean=boolean, pending=pending), None))
                             

            return tuple(outputs)
        

    class SETTing_Enumerate (Observing, Leaf):
        '''
        Return a list of all known states
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('names', type=str, repeats=(0, None))

        def run (self):
            states = set(self.parent.states.values())
            names = [ s.name for s in states ]
            names.sort()
            return tuple(names)


    class EXISTS_Query (Observing, Leaf):
        '''
        Return True if the specified state exists, False otherwise
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('exists', type=bool)

        def run (self, name=str):
            return (self.parent.getState(name, ignoreMissing=True) is not None)


    class NICK_Add (Controlling, Leaf):
        '''
        Add one or more nick names to the specified state.
        '''

        def run (self, state=str, *nick):
            self.parent.addAliases(state, nick)


    class NICK_Remove (Controlling, Leaf):
        '''
        Remove one or more nick names from the specified state
        '''

        def run (self, state=str, *nick):
            self.parent.delAliases(state, nick)


    class NICK_Clear (Controlling, Leaf):
        '''
        Clear all aliases associated with the specified state
        '''

        def run (self, state):
            self.parent.clearAliases(name)


    class NICK_Enumerate (Observing, Leaf):
        '''
        List all nicknames associated with the specified state
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('nickname', type=str, repeats=(0, None))

        def run (self, state=str):
            return tuple(self.parent.getAliases(state))


    class NAME_Query (Observing, Leaf):
        '''
        Return the official name of the specified state, which may be given as a nickname.
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('name', type=str, default=None)

        def run (self, ignoreMissing=False, nickname=str):
            s = self.parent.getState(nickname, ignoreMissing)
            if s:
                return s.name

    class DEPendency_Add (Controlling, Leaf):
        '''
        Add dependencies (ancestors) to the specified state (descendant).
        The descendant state will be set only after all dependencies are met.

    Examples:
      * Make "initialized" state depend on specific hardware:
        > State:DEPendency+ initialized -requires=tbc,mcb

      * Add "initialized" as a positive dependency and "error" as a negative
        for dependency for "runnable":
        > State:DEPendency+ runnable -requires=initialized -conflicts=error
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("front", type=bool, default=False, named=True,
                          description="Insert this in front of existing dependencies.  This can be used to prevent "
                          "temporary changes as a result of complex dependencies.")
            self.setInput("keepValue", type=bool, default=False, named=True,
                          description="Do not change current state value as a result of the dependency, if possible")
            self.setInput("hard", type=bool, default=False, named=True,
                          description="This dependency is absolute; if attempting to change the state value "
                          "not in accordance with the values of its ancestors, an error is returned.")
            self.setInput("manual", type=bool, default=False, named=True,
                          description="Do not automatically hook value changes as a result of this dependeny.")
            self.setInput("name", type=str,
                          description="Name of (descendant) state")
            self.setInput("requires", type=str, default=[], split=",",
                          description="Comma-separated list of ancestor states that must "
                          "be set to True before the descendant state may be set.")
            self.setInput("conflicts", type=str, default=[], split=",",
                          description="Comma-separated list of ancestor states that must "
                          "be cleared (set to False) before the dependant state may be set.")

        def run (self, keepExisting=False, replaceExisting=False, hard=False, manual=False,
                 front=False, keepValue=False, name=str, requires=str, conflicts=str):
            obj = self.parent.getState(name)
            positive = self.parent.getStates(requires)
            negative = self.parent.getStates(conflicts)
            self.parent.addDependencies(obj, positive, negative,
                                        keepExisting=keepExisting,
                                        replaceExisting=replaceExisting,
                                        autoUpdate=not keepValue,
                                        manual=manual,
                                        hard=hard,
                                        front=front)


    class DEPendency_Remove (Controlling, Leaf):
        '''
        Remove dependencies (ancestors) from the specified state (descendant).
        If all other dependencies are fulfilled, the descendant state will be set.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("name", type=str,
                          description="Name of (descendant) state")
            self.setInput("dependencies", type=str, split=",",
                          description="Comma-separated list of states that "
                          "should no longer be ancestors for this state")

        def run (self, keepValue=False, ignoreMissing=False, name=str, dependencies=str):
            obj = self.parent.getState(name)
            ancestors = self.parent.getStates(dependencies)
            self.parent.removeDependencies(obj, ancestors, ignoreMissing=ignoreMissing, autoUpdate=not keepValue)
            


    class DEPendency_Clear (Controlling, Leaf):
        '''
        Remove all dependencies (ancestors) from the specified state.
        The state will be set (set to True).
        '''

        def run (self, name=str):
            obj = self.parent.getState(name)
            self.parent.clearDependencies(obj)


    class DEPendency_Enumerate (Observing, Leaf):
        '''
        List all dependencies (ancestors) and/or descendants for the
        specified state.  If neither "required" not "conflicts" is
        set, list all ancestors/descendants
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ancestors', type=bool, default=None, named=True,
                          description="If set, list ancestor states")

            self.setInput('descendants', type=bool, default=None, named=True,
                          description="If set, list descendant states states")

            self.setInput('required', type=bool, default=None, named=True,
                          description="List required dependencies (default)")

            self.setInput('conflicts', type=bool, default=None, named=True,
                          description="List conflicting dependencies")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("state", type=str, repeats=(0, None))


        def run (self, ancestors=None, descendants=None, required=None, conflicts=None, recursive=False, name=str):
            obj = self.parent.getState(name)

            if required and not conflicts:
                direction = True
            elif conflicts and not required:
                direction = False
            else:
                direction = None

            if not descendants and ancestors is None:
                ancestors = True

            deps = self.parent.getDependencies(obj,
                                               edge=direction,
                                               ancestors=ancestors,
                                               descendants=descendants,
                                               recursive=recursive)
            names = [ dep.name for dep in deps ]
            return tuple(names)



    class NOTify_Add (Controlling, Leaf):
        '''
        Start publishing information about changes in the specified
        state(s) to the specified topic.

        If no states are specified, add the specified topic to the
        default list of notification topics.
        '''

        class NoSuchTopic (RunError):
            '''No match for topic %(topic)r'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('states', type=str, named=True, default=None, split=",",
                          description="Comma-separated list of states for which this "
                          "notification topic should be added.")
            self.setInput('createMissing', type=bool, named=True, default=False,
                          description='If the specified topic does not exist, '
                          'add it instead of complaining.')
            self.setInput('topics', type=str, named=False, repeats=(1, None),
                          description='Topics on which the notification will be published')


        def run (self, states=None, createMissing=False, *topics):
            if not createMissing:
                for topic in topics:
                    if not topicExists(topic):
                        raise self.NoSuchTopic(topic=topic)
            else:
                for topic in topics:
                    if not topicExists(topic):
                        addTopic(topic, level=INFO)


            if not states:
                cs = (_State,)
            else:
                cs = self.parent.getStates(states)

            for c in cs:
                lowercaseTopics = [ t.lower() for t in c.notifyTopics ]
                for topic in topics:
                    if not topic.lower() in lowercaseTopics:
                        if isinstance(c, _State) and c.notifyTopics is _State.notifyTopics:
                            c.notifyTopics = _State.notifyTopics.copy()

                        c.notifyTopics.add(topic)




    class NOTify_Remove (Controlling, Leaf):
        '''
        Stop publishing information about changes in the specified
        state(s) to the specified topic.  If no state is
        specified, remove the topic from the default list of
        notification topics.
        '''

        class NoSuchTopic (RunError):
            '''State %(state)r does not notify on topic %(topic)r'''

        class NoSuchDefaultTopic (RunError):
            '''No notifications are published on topic %(topic)r'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('states', type=str, named=True, default=None, split=",",
                          description="Comma-separated list of states for which this "
                          "notification topic should be added.  If not specified, "
                          "it is added to the default list of notification topic.")
            self.setInput('topics', type=str, named=False, repeats=(1, None),
                          description='Topics on which the notification will be published')


        def run (self, states=None, ignoreMissing=False, *topics):
            if not states:
                cs = (_State,)
            else:
                cs = self.parent.getStates(states)


            for c in cs:
                lowerCaseTopics = dict((t.lower(), t) for t in c.notifyTopics)

                for topic in topics:
                    try:
                        topic = lowerCaseTopics[topic.lower()]
                    except KeyError, e:
                        if not ignoreMissing:
                            if isinstance(c, _State):
                                raise self.NoSuchTopic(state=c.name, topic=topic)
                            else:
                                raise self.NoSuchDefaultTopic(topic=topic)
                    else:
                        if isinstance(c, _State) and c.notifyTopics is _State.notifyTopics:
                            c.notifyTopics = _State.notifyTopics.copy()

                        c.notifyTopics.remove(topic)


    class NOTify_Clear (Controlling, Leaf):
        '''
        Remove any notifications specific to the specified state(s).
        If no states are specified, remove all default notification topics.
        '''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('reset', type=bool, named=True, default=False,
                          description='Remove any overridden notification topics for the specified state(s) '
                          'back to the default notification topics for all states.')

            self.setInput('states', type=str, default=None, repeats=(0, None),
                          description="Comma-separated list of states from which "
                          "notification topics should be cleared")

        def run (self, ignoreMissing=False, reset=False, *states):
            if not states:
                cs = (_State,)
            else:
                cs = self.parent.getStates(states)

            for c in cs:
                if isinstance(c, _State) and c.notifyTopics is not _State.notifyTopics and reset:
                    del c.notifyTopics

                elif isinstance(c, _State) and c.notifyTopics is _State.notifyTopics:
                    c.notifyTopics = set()

                else:
                   c.notifyTopics.clear()



    class NOTify_Query (Observing, Leaf):
        '''
        Return notification topics for the specified state.  If no
        notification topic exists for this state, or if no state is
        specified, return the default notification topic, or "-" if
        none exists.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('state', type=str, default=None)


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('topic', type=str, repeats=(0, None))
        
        def run (self, state=None):
            if not state:
                return tuple(sorted(_State.notifyTopics))
            else:
                return tuple(sorted(self.parent.getState(state).notifyTopics))



    class NOTify_Set (Controlling, Leaf):
        '''
        Specify whether to publish state changes (default is True).
        If set to False, change notifications are deferred until 
        re-enabled.  This can be used to prevent clients from taking
        specific actions during self tests, etc.'''

        def run (self, enabled=bool):
            _State.setDeferred(not enabled)

        

    class HOOK_Add (Controlling, Leaf):
        '''
        Add a command to be executed once the specified state(s) are altered.
        Prior to execution, the following substitutions occur in the command text:

           $name$          = Name of the changed state
           $value$         = New value of the state ("True", "False" or "Error")
           $previousValue$ = Old value of the state ("True", "False" or "Error")
           $direct$        = True if this state was invoked explititly, False otherwise.

        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('edge', type=EdgeStrings, default=range(len(EdgeStrings)), named=True, split=",",
                          description="List of state transitions for "
                          "which the hook should be executed")
            self.setInput('phase', type=Phases, default=PH_NORMAL, named=True,
                          description="Order preference")
            self.setInput('noindirect', named=True, default=False,
                          description='Only run this hook if the specified state '
                          'is modified directly, not by a change in ancestor states')
            self.setInput('rerun', named=True, default=False,
                          description='Always run hook when state value is updated, '
                          'even if the new value is identical to the old one')
            self.setInput('immediate', type=bool, default=False,
                          description="Run hook immediately if state is already satisfied.")
            self.setInput('cancelable', type=bool, default=False, named=True,
                          description='Allow this hook to be aborted in order '
                          'to cancel a pending state change')
            self.setInput('quiet', type=bool, default=False, named=True,
                          description='Do not bother to notify about "Pending" state transition')
            self.setInput('transient', type=bool, default=False, named=True,
                          description='Do not set the state to failed if an exception occurs '
                          'while executing this hook.')
            self.setInput('unabortable', type=bool, default=False, named=True,
                          description='Ignore attempts to abort this hook')
            self.setInput('states', type=str, split=",", default=[],
                          description="states for which this hook should be executed")
            self.setInput('branch', type=str, default=None,
                          description="Command branch in which to run the hook "
                          "(default is the current command scope)")
            self.setInput('name', type=str,
                          description="Hook name; used to remove/list hooks")
            self.setInput('command', type=str,
                          description="Command block to invoke when the specified "
                          "transition takes place.")


        def run (self, _session, _scope,
                 edge=None, phase=Phases, noindirect=False, rerun=False, immediate=False, quiet=False,
                 cancelable=False, transient=False, unabortable=False, replaceExisting=False,
                 states="", branch=None, name=str, command=str):
                 
            states = self.parent.getStates(states)
            edges  = set(edge)

            if branch:
                scope  = _scope.find(branch)
            else:
                scope  = _scope

            if not replaceExisting:
                for obj in states:
                    hook = obj.getHook(name)
                    if hook:
                        raise self.parent.HookExists(state=obj.name, hook=hook.name)
            
            hook = Container(name=name, edges=edges, noindirect=noindirect, rerun=rerun,
                             quiet=quiet, cancelable=cancelable, transient=transient,
                             unabortable=unabortable,
                             method=self.parent.runHook,
                             args=(command, _session.accessLevel, name, scope),
                             kwargs={})

            for obj in states:
                obj.setHook(name, hook, phase=phase, immediate=immediate)



    class HOOK_Remove (Controlling, Leaf):
        '''
        Remove an existing hook from the specified state(s).
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('states', type=str, split=",",
                          description="Comma-separated list of states for which this hook "
                          "should be executed.")
            self.setInput('name', type=str,
                          description="Hook name; used to remove/list hooks")

        def run (self, _session, ignoreMissing=False, states=str, name=str):
            missing = []
            for obj in self.parent.getStates(states):
                if not obj.clearHook(name) and not missing:
                    missing.append(obj.name)

            if missing and not ignoreMissing:
                raise self.parent.NoSuchHook(states=",".join(missing), hook=name)


    class HOOK_Clear (Controlling, Leaf):
        '''
        Clear all hooks for the specified state
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('states', type=str, split=",",
                          description="Comma-separated list of states for which this hook "
                          "should be removed.")

        def run (self, _session, states=str):
            for obj in self.parent.getStates(states):
                obj.clearHooks()



    class HOOK_Query (Observing, Leaf):
        '''
        List hooks associated with the specified state.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('edges', type=str, named=True)
            self.addOutput('phase',  type=Phases, named=True)
            self.addOutput('noindirect', type=bool, named=True)
            self.addOutput('rerun', type=bool, named=True)
            self.addOutput('quiet', type=bool, named=True)
            self.addOutput('cancelable', type=bool, named=True)
            self.addOutput('transient', type=bool, named=True)
            self.addOutput('unabortable', type=bool, named=True)
            self.addOutput('commands', type=str)

        def run (self, _session, ignoreMissing=False, state=str, hook=str):
            obj = self.parent.getState(state)
            h, phase = obj.getHookAndPhase(hook)
            result  = None

            if h:
                if h.method == self.parent.runHook:
                    command, accessLevel, hookName, scope = h.args
                    edgeNames = [ EdgeStrings[edge] for edge in h.edges ]
                    result = (",".join(edgeNames), phase,
                              h.noindirect, h.rerun, h.quiet,
                              h.cancelable, h.transient, h.unabortable,
                              command)

            if not result and not ignoreMissing:
                raise self.parent.NoSuchHook(states=state, hook=hook)

            return result


    class HOOK_Enumerate (Observing, Leaf):
        '''
        List hooks associated with the specified state.
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('edge', type=EdgeStrings, named=True, default=None)
            self.setInput('phase', type=Phases, named=True, default=None)
            self.setInput('state', type=str)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self, _session, edge=EdgeStrings, phase=Phases, state=str):
            obj   = self.parent.getState(state)
            names = obj.getHookNames(edge, phase)
            return tuple(names)



    class EXECute (Controlling, Leaf):
        '''
        Run the specified hook(s), as if during a state transition
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('value', type=StateStrings, default=None, named=True,
                          description="State value for which hooks will be executed.  "
                          "If omitted, use the current state value")
            self.setInput('onCancel', type=ExceptionHandling, named=True, default=EH_CONTINUE,
                          description='Specify what to do if the state change is canceled.')
            self.setInput('onAbort', type=ExceptionHandling, named=True, default=EH_RAISE,
                          description='Specify what to do if the state change is aborted.')
            self.setInput('onError', type=ExceptionHandling, named=True, default=EH_FAIL,
                          description='Specify what to do if the state change counters an error')
            self.setInput('state', type=str)
            self.setInput('hooks', type=str, repeats=(0, None),
                          description="Hooks to execute; "
                          "if not specified, execute all hooks")

        def run (self, _session, value=None,
                 onCancel=ExceptionHandling, onAbort=ExceptionHandling, onError=ExceptionHandling,
                 state=str, *hooks):

            obj    = self.parent.getState(state)

            if hooks:
                try:
                    hlist = [ obj.getHook(name) for name in hooks ]
                except TypeError:
                    raise self.parent.NoSuchHook(states=state, hook=name)

            else:
                if value is None:
                    value = obj.getValue(pending=True)

                hlist = obj.getHooks(value)

            obj.runHooks(hlist, value, False, onCancel=onCancel, onAbort=onAbort, onError=onError)
            



    class ERRor_Count (Observing, Leaf):
        '''
        Return the number of errors that prevented the specified
        state from being set or cleared.   If the state is not
        in an error state, return 0.
        '''
        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('original', type=bool, named=True, default=False,
                          description='Only return error that originated in the specified state, '
                          'not its ancestors')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self, original=False, pending=False, state=str):
            obj = self.parent.getState(state)
            return len(obj.getErrors(withAncestors=not original, pending=pending))


    class ERRor_Set (Controlling, Leaf):
        '''
        Assign an error to the specified state.  This can be used,
        for instance, to capture error states that are encountered
        outside of the standard hook mechanism.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)

        def run (self, state=str, id=str, *message, **options):
            obj = self.parent.getState(state)

            if id and id[0] + id[-1] == '[]':
                id = id[1:-1]

            message = list(message)
            while message and message[0] == Error.contextSeparator:
                del message[0]

            obj.setError(id, ' '.join(message), **options)



    class ERRor_Query (Observing, Leaf):
        '''
        Return any errors encountered while executing state transition hooks
        within the specified state and its ancestors, with outputs formatted
        as parsable key/value pairs.
        '''

        class NoSuchError (RunError):
            '''The error index %(index)i is out of range; there are only %(count)i errors'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('withArgs', type=bool, named=True, default=True)
            self.setInput('withContext', type=bool, named=True, default=False)
            self.setInput('original', type=bool, named=True, default=False,
                          description='Only return error that originated in the specified state, '
                          'not its ancestors')
            self.setInput('index', type=int, range=(1, None))

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('id', type=str, format="%s", named=True, default=None)
            self.addOutput('arguments', type=tuple, repeats=(0, None))

        def run (self, _session, ignoreMissing=False, withArgs=True, withContext=False, original=False, pending=False, state=str, index=None):
            obj = self.parent.getState(state)
            errors = obj.getErrors(withAncestors=not original, pending=pending)
            error = None

            if index is None:
                if errors:
                    error = errors[0]

            else:
                try:
                    error = errors[index-1]
                except IndexError:
                    if not ignoreMissing:
                        raise self.NoSuchError(index=index, count=len(errors))

            if error:
                outputs = [ error.name ]
                            
                if withArgs:
                    outputs.extend(error.getArgs())

                outputs.append(('message', error.format(showID=False, showArgs=False, showContext=withContext)))
                return tuple(outputs)




    class ERRor (Observing, Leaf):
        '''
        Re-raise any errors encountered while executing state transition hooks
        within the specified state and its ancestors.
        '''

        class NoSuchError (RunError):
            '''The error index %(index)i is out of range; there are only %(count)i errors'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('string', type=str, format="%s", named=False, repeats=(0, None))


        def run (self, _session, ignoreMissing=False, original=False, state=str, index=None):
            obj = self.parent.getState(state)
            errors = obj.getErrors(withAncestors=not original)
            error = None

            if index is None:
                if errors:
                    error = errors[0]

            else:
                try:
                    error = errors[index-1]
                except IndexError:
                    if not ignoreMissing:
                        raise self.NoSuchError(index=index, count=len(errors))

            if error:
                raise error


    
    class REASon_Set (Controlling, Leaf):
        '''
        Provide human readable explanation for a given state value.
        This will be returned in response to future "REASon?" or
        "CULPrits? -verbose" queries.
        '''

        def run (self, state=str, false="", true="", failed="", pending=""):
            obj = self.parent.getState(state)
            for level, text in ((OFF, false), (ON, true), (FAILED, failed), (PENDING, pending)):
                if text:
                    obj.setReason(level, text)


    class REASon_Clear (Controlling, Leaf):
        '''
        Clear human readable explanations associated with the specified state.
        '''


        def run (self, state=str):
            obj = self.parent.getState(state)
            obj.clearReasons()


    class REASon_Query (Observing, Leaf):
        '''
        Return human readable explanations for each specified state value and/or transition.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('state', type=str, description='State name')
            self.setInput('value', type=StateStrings, default=None,
                          description='State Value.  If omitted, use the current value of the specified state.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("explanation", type=str)

        def run (self, explicit=False, state=str, value=None):
            obj = self.parent.getState(state)
            return obj.getReason(value, explicit=explicit)


            

    class ACTion_Set (Controlling, Leaf):
        '''
        Provide human readable explanation for a given state transition.
        This will be returned in response to future "REASon?" or
        "CULPrits? -verbose" queries.
        '''

        def run (self, state=str, off="", on="", failed=""):
            obj = self.parent.getState(state)
            for edge, text in ((OFF, off), (ON, on), (FAILED, failed)):
                if text:
                    obj.setActionText(edge, text)


    class ACTion_Clear (Controlling, Leaf):
        '''
        Clear human readable explanations associated with transitions in the specified state.
        '''


        def run (self, state=str):
            obj = self.parent.getState(state)
            obj.clearActionTexts()


    class ACTion_Query (Observing, Leaf):
        '''
        Return human readable explanations for each specified state transition.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('state', type=str, description='State name')
            self.setInput('value', type=EdgeStrings, default=None,
                          description='State Value.  If omitted, use the current value of the specified state.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("explanation", type=str)

        def run (self, state=str, value=None):
            obj = self.parent.getState(state)
            return obj.getActionText(value)



    class REQuire (Observing, Leaf):
        '''
        Raise an explanatory error message if the specified state does not have the specified value.
        This is similar to the "CULPrits@" query, except that an error is raised if there are culprits.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('pending', type=bool, named=True)
            self.setInput('states', type=str, split=",",
                          description="Comma-separated list of states that are required")
            self.setInput('expected', type=bool, default=True)
            self.setInput('action', type=str,
                          description='Description of attempted operation, e.g. "start run".')
            

        def run (self, pending=False, states=str, expected=True, action=None):
            objects = [ self.parent.getState(state) for state in states ]


            for state in objects:
                value = state.getValue(pending=pending)
                if value != expected:
                    culprits, reasons = state.getCulpritMessage(expected=expected)

                    if culprits:
                        if action is None:
                            action = state.getActionText(expected)

                        raise self.parent.UnsatisfiedRequirement(action=action,
                                                                 culprits=culprits,
                                                                 reason=reasons)


#                value = state.getValue(pending=pending)
#                if value != expected:
#                    culprits.append(state.name)
#                    reasons.append(state.getReason(value))


    class ALLowed_Query (Observing, Leaf):
        '''Indicate whether the specified state value is possible.
        For more details about conflicting states, see "State:CULPrits?"'''

        def declareOutputs (self):
            Leaf.declareOutputs (self)
            self.addOutput('allowed', type=bool)


        def run (self, state=str, setting=True):
            obj = self.parent.getState(state)
            try:
                obj.filteredValue(setting)
            except obj.UnsatisfiedDependencies, e:
                return False
            else:
                return True


    class CULPrits_Query (Observing, Leaf):
        '''
        Return dependencies (ancestor states) whose values prevent the
        specified state from being set, along with their values.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('states', type=tuple, named=True, repeats=(0, None))


        def run (self, expected=True, hard=False, state=str):
            obj = self.parent.getState(state)
            states = obj.getCulpritNames(expected, hard=hard or None)
            return tuple(states)
        


    class CULPrits_Enumerate  (Observing, Leaf):
        '''
        Return dependencies (ancestor states) whose values
        prevent the specified state from being set.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('states', type=str, repeats=(0, None))


        def run (self, expected=True, hard=False, explanations=False, state=str):
            obj = self.parent.getState(state)
            items, reasons = obj.getCulpritReasons(expected, hard=hard or None)
            
            if explanations:
                culprits = reasons
            else:
                culprits = [ name for (name, value) in items ]

            return tuple(culprits)


    class WAIT (Observing, Leaf):
        '''
        Wait until a given state has the specified value.
        '''

        class StateChangeTimeout (RunError):
            'Timed out after %(timeout)s seconds waiting for state %(state)r change to %(value)s'


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('timeout', type=float, default=None)
            self.setInput('pending', type=bool, default=False)
            self.setInput('mustChange', type=bool, default=False)
            self.setInput('descendants', type=bool, default=False)
            self.setInput('ignoreTimeout', type=bool, default=False)
            self.setInput('ignoreAbort', type=bool, default=False)
            self.setInput('ignoreErrors', type=bool, default=False)
            self.setInput('value', type=bool, named=False, default=None)

        def run (self, timeout=None, descendants=False, pending=False, mustChange=False,
                 ignoreTimeout=False, ignoreAbort=False, ignoreErrors=False, state=str, value=None):

            obj = self.parent.getState(state)

            try:
                if not obj.wait(value, timeout, ignoreErrors=ignoreErrors, pending=pending, mustChange=mustChange):
                    errors = obj.getErrors(withAncestors=True)
                    if errors and not ignoreErrors:
                        raise errors[0]

                    elif not errors and not ignoreTimeout:
                        raise self.StateChangeTimeout(timeout=timeout, state=state,
                                                      value=obj.getValueString(value, default=value))

                elif descendants:
                    obj.waitDescendants(timeout)

            except Aborted:
                if not ignoreAbort:
                    raise

    class QueueSize_Set (Controlling, Leaf):
        '''
        Set maximum reference count for enqueuing values of the specified state.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('size', type=int, range=(0, None),
                          description='Maximum reference count. If 0, no queuing is allowed.')

        def run (self, state=str, size=int):
            obj = self.parent.getState(state)
            obj.queueSize = size
            obj.refcount  = min(obj.refcount, size)


    class QueueSize_Clear (Controlling, Leaf):
        '''
        Remove restrictions on the queue size of the specified state.
        '''

        def run (self, state=str):
            obj = self.parent.getState(state)
            obj.queueSize = None


    class QueueSize_Query (Observing, Leaf):
        '''
        Return the maximum queue size of the specified state.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('size', type=int, default=None)


        def run (self, state=str):
            obj = self.parent.getState(state)
            return obj.queueSize


    class REFerence_Count (Observing, Leaf):
        '''
        Return the current reference count of the specified state.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int, default=None)


        def run (self, state=str):
            obj = self.parent.getState(state)
            return obj.refcount

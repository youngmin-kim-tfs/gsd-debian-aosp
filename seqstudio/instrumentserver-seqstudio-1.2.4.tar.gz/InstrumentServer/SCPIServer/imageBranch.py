########################################################################
### FILE:	imageBranch.py
### PURPOSE:	Image manipulation commands
########################################################################

from scpiLeaf           import Controlling, Observing, Leaf
from scpiMinimalBranch  import MinimalBranch
from scpiFilesystemBase import FilesystemLeaf
from scpiExceptions     import RunError

try:
    import Image
    gotPIL = True
except ImportError, e:
    gotPIL = False

class IMAGe (MinimalBranch):
    '''Image manipulation commands'''

    class _ImageLeaf (Controlling, FilesystemLeaf):
        'Abstract superclass for image commands'

        class NoPIL (RunError):
            'This operation requires the Python Imaging Library, which is not available'


        def op (self, origLocation, newLocation, method, *args, **kwargs):
            if not gotPIL:
                raise self.NoPIL()

            origPath = self.getPath(origLocation)
            newPath  = self.getPath(newLocation)

            triggers = self.openPathContexts(False, origPath, newPath)
            try:
                image = Image.open(origPath)
                image = method(image, *args, **kwargs)
                image.save(newPath)
            finally:
                self.closeContexts(triggers)


    class SHRink (Observing, _ImageLeaf):
        '''
        Shrink an image by the specified factor
        '''

        def declareInputs (self):
            IMAGe._ImageLeaf.declareInputs(self)
            self.setInput("factor", type=int, range=(1, None))

        def run (self, originalImage=str, resizedImage=str, factor=int):
            self.op(originalImage, resizedImage, self.resize, factor)

        def resize (self, image, factor):
            w, h = image.size
            return image.resize((w/factor, h/factor))



    class RESize (Observing, _ImageLeaf):
        '''
        Shrink an image by the specified factor
        '''

        def run (self, originalImage=str, resizedImage=str, width=int, height=int):
            self.op(originalImage, resizedImage, self.resize, width, height)

        def resize (self, image, width, height):
            return image.resize(width, height)



    class CROP (Observing, _ImageLeaf):
        '''
        Crop a region of interest from an image
        '''
        
        def run (self, originalImage=str, croppedImage=str, left=int, upper=int, right=int, lower=int):
            self.op(originalImage, croppedImage, image.crop, (left, upper, right, lower))

        def crop (self, image, box):
            return image.crop(box)

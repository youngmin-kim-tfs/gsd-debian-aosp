########################################################################
### FILE:       scpiSession.py
### PURPOSE:    Container for external/internal SCPI client sessions
### AUTHOR:     Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All righs reserved.
########################################################################

from sys              import exc_info
from os               import getenv, pathsep, sep
from os.path          import isfile, join, splitext
from re               import compile as rxcomp, sub
from socket           import error as SocketError
from config           import Config, ConfigError
from random           import randint
from cStringIO        import StringIO
from array            import array
from socket           import gethostname
from SysConfig        import sysconfig, netconfig

from data             import Container, DynamicData, DataProxy
from locking          import Queue, Empty, Lock
from threadControl    import Aborted, ControllableThread, currentThread, invoke, invocation, IGNORE

from commandParser    import \
    parser, CommandParser, ParseError, OptionName, CookedValue, RawValue, \
    QUOTE_NEVER, QUOTE_ATTRIBUTES, QUOTE_AUTO

from scpiExceptions   import scpiException, \
    Exc, Abort, Error, RunError, CommandError, InternalError, ExternalError, \
    SessionControl, NextControl, NextReply, NextCommand, Break, ReturnValue, ReturnCall

from scpiParameter    import boolean, integer, real

try:
    from hashlib import md5
except ImportError:
    import md5

import hmac
import base64
import math
import time
import datetime
import traceback
import re, fnmatch
import weakref
import copy
import subscription

### Response words
statuswords = READY, OK, NEXT, WARNING, ERROR, MESSAGE = \
              "READy", "OK", "NEXT", "WARNing", "ERRor", "MESSage"

### Handling of NextReply exception
NextOp = ('sync', 'async', 'raise', 'passthrough')
(SYNC, ASYNC, RAISE, PASSTHROUGH) = range(len(NextOp))

### Access levels
AccessLevels = ('Guest', 'Observer', 'Controller', 'Administrator', 'Full')
(GUEST, OBSERVER, CONTROLLER, ADMINISTRATOR, FULL) = range(len(AccessLevels))

### Path for module files
_modpath = [ ]

def getModulePath ():
    return _modpath

def setModulePath (path):
    global _modpath
    _modpath = path


########################################################################
### Context

class Context (object):
    DefaultInvocation = ('invoke', ())

    def __init__ (self, session, scope, invocation=None, data=None,
                  text=None, leaf=None, response=None, exception=None, **opts):
        if data is None:
            data = DynamicData()

        self.update(session=session, scope=scope,
                    invocation=invocation, data=data, text=text,
                    leaf=leaf, response=response, exception=exception, **opts)

    def clone (self, **updates):
        return copy.copy(self).update(**updates)

    def update (self, **updates):
        for k, v in updates.items():
            setattr(self, k, v)
        return self

    def getOutputs (self, alwaysNamed=False, raw=False):
        if self._outputs is not None:
            return self._outputs
        elif self.leaf and self._invocation in (None, self.DefaultInvocation):
            return self.leaf.formatOutputs(self.response, alwaysNamed=alwaysNamed, raw=raw)
        else:
            return []
    def setOutputs (self, outputs):
        self._outputs = outputs
    outputs = property(getOutputs, setOutputs)


    def _getInvocation (self):
        return self._invocation or self.DefaultInvocation
    def _setInvocation (self, invocation):
        self._invocation = invocation
    invocation = property(_getInvocation, _setInvocation)



########################################################################
### BaseSession class definition.
###
### An instance of this class is created for each external and
### internal client session.  It is an abstract parent class for
### InitSession, ClientSession, and NestedSession.

class BaseSession (CommandParser):
    '''
    Abstract superclass for SCPI sessions
    '''

    class InsufficientAccess (RunError):
        'This operation requires %(requiredAccess)s access or higher; current level is %(currentAccess)s'

    class AccessLevelExceeded (RunError):
        'This level exceeds your access limit (%(accessLimit)s)'

    class InvalidAccessLevel (CommandError):
        'Access level %(accessLevel)r does not exist'

    class IncorrectSessionType (RunError):
        'Top-level session is a %(found)s, expeted a %(expected)s'


    class ParseError (CommandError):
        def __init__ (self, expression, pos, reason, subexpression, exception):
            CommandError.__init__(self, None, reason, expression=subexpression)
            self.expression = expression
            self.pos        = pos
            self.reason     = reason
            self.exception  = exception
            if subexpression:
                self.insertContext(subexpression)
            self.insertContext(expression.strip())

        def __str__ (self):
            if self.exception:
                return str(self.exception)
            else:
                return str(self.reason)

        def format (self, *args, **kwargs):
            if self.exception:
                return self.exception.format(*args, **kwargs)
            else:
                return CommandError.format(self, *args, **kwargs)

    class PythonError (CommandError):
        def __init__ (self, name, text, **argmap):
            CommandError.__init__(self, name, text, **argmap)

    class VariableSyntax (CommandError):
        '%(expression)s <-- Invalid variable syntax'

    accessinfo    = None
    accessLevel   = None
    accessLimit   = None
    authLimit     = None
    exclusive     = None
    stealthAccess = False
    challenge     = None
    authdata      = None
    instances     = []
    sessionIndex  = 0
    mutex         = Lock()
    __slots__     = ('accessinfo', 'accessLevel', 'accessLimit', 'authLimit',
                     'exclusive', 'stealthAcces', 'challenge', 'authdata',
                     'instream', 'description', 'variables', 'jobs',
                     'sessionid', 'role')

    def __init__ (self, instream, description, id_prefix=None):
        self.instream       = instream
        self.description    = description
        self.variables      = {}
        self.jobs           = []

        with self.mutex:
            self.sessionid  = self.nextSessionID(id_prefix)
            self.setRole(None)

            if self.accessinfo is None:
                BaseSession.accessconfig = Config('access.ini')
                BaseSession.accessinfo   = self.importConfig(self.accessconfig)

            if self.authdata is None:
                BaseSession.authconfig   = Config('authentication.ini')
                BaseSession.authdata     = self.importConfig(self.authconfig)

            self.addInstance()

    @classmethod
    def nextSessionID (cls, prefix):
        if prefix == None:
            prefix = cls.__name__[0]

        cls.sessionIndex += 1
        return prefix+str(cls.sessionIndex)

    def setRole (self, role):
        self.role       = role
        self.debugTopic = "-".join(filter(None, ("Session", role, self.sessionid)))

    @classmethod
    def getInstances (cls, instanceClass):
        return [ s() for s in cls.instances if isinstance(s(), instanceClass) ]

    def addInstance (self):
        self.instances[:] = [ s for s in self.instances if s() is not None ] + [weakref.ref(self)]


    def top (self, cls=None):
        session = self
        while session.parent:
            session = session.parent
        if cls and not isinstance(session, cls):
            raise IncorrectSessionType(expected=cls.__name__, found=type(session).__name__)
        return session


    def importConfig (self, config):
        data = DynamicData()
        for section in config.sections():
            data[section] = config[section]
        return data



    ########################################################################
    ### Methods to support command and variable expansions
    ### (used in "CommandParser()")

    def _getInputArgument (self, arg, context):
        self.checkAccess(OBSERVER)
        try:
            index = int(arg, 0)
        except ValueError:
            index = 0

        if index:
            try:
                return context.outputs[index-1][CookedValue]
            except (IndexError, TypeError, AttributeError):
                return
        else:
            if arg == '0':
                sep, tag, quoting = ' ', None, QUOTE_NEVER
            elif arg == '@':
                sep, tag, quoting = ' ', 'arg', QUOTE_AUTO
            else:
                sep, tag, quoting = arg, 'arg', QUOTE_AUTO

            return parser.collapseArgs(context.outputs, tag=tag, quoting=quoting, separator=sep)

    def _getCommandOutput (self, command, context):
        commandtext, index, command, args = self.expandParts(command, context)

        if command:
            subcontext = context.clone(invocation=None)
            subcontext = self.runParts(subcontext, command, args, nextReply=SYNC, catchReturn=True)
            return parser.collapseArgs(subcontext.outputs, tag=None, quoting=QUOTE_NEVER)


    _vx = re.compile(r'^(#)?\s*(?:(\d+|@)|(\w[\w-]*)\s*(?:\[(\w*)\])?)\s*'
                     r'(?:/(/?)([^/]+)(?:/(.*))?|'
                     r':((?:\s+[\+\-]|\s*)?\d+)\s*:?\s*([+-]?\d*)\s*:?\s*([+-]?\d*)\s*|'
                     r':([+-])(.*)|'
                     r'\?([+-])(.*)?|'
                     r'(\?)([^:]*):?(.*)'
                     r')?$')

    def _getVariable (self, name, context):
        self.checkAccess(OBSERVER)
        portion   = None
        handling  = None
        search    = None

        match = self._vx.match(name)
        if not match:
            raise self.VariableSyntax(expression=name.strip())

        (hashmark, argindex, key, subkey,
         isregex, search, replace,
         offset, length, step,
         check, alternate,
         vassert, vtext,
         ifelse, iftext, elsetext) = match.groups()

        proxy = DataProxy((context.data,
                           context.scope.branchData,
                           context.scope.globalData,
                           context.scope.persistentData))

        if argindex:
            value = self._getInputArgument(argindex, context)

        else:
            try:
                varscope, data, value = proxy.getScopeDataValue(None, key)
                value = proxy.getValue(value, subkey)
            except (KeyError, TypeError, IndexError):
                value = ''

        if search:
            string = proxy.toString(value)
            if isregex:
                value = sub(search, replace or '', string)
            else:
                value = string.replace(search, replace or '')

        elif offset:
            start, end, step = int(offset), None, None
            if length:
                end = start + int(length)
            if step:
                step = int(step)

            value = value[start:end:step]

        if hashmark is not None:
            value = len(value)
        else:
            value = proxy.toString(value)

        if vassert:
            value = ("", vtext)[boolean(value) == (vassert == '+')]

        elif ifelse:
            value = (elsetext, iftext)[boolean(value)]

        elif alternate and (bool(value) == (check == '+')):
            value = alternate


        return value


    def _getEvaluationResult (self, expression, context,
                              assignments=None, imports=("math", "re")):
        '''
        Evaluate "expression" natively in Python, and return the result.
        '''
        localmap = { 'session':self,
                     'scope':context.scope, 'find':context.scope.find,
                     'BOOL':boolean, 'INT':integer, 'REAL':real }

        self.checkAccess(ADMINISTRATOR)

        try:
            for modulename in imports:
                m = __import__(modulename)
                localmap.update(m.__dict__)

            varscopes = (context.scope.persistentData,
                         context.scope.globalData,
                         context.scope.branchData,
                         context.data,
                         assignments)

            for idx, varscope in enumerate(varscopes):
                localmap.update((varscope or {}).items())

            return eval(expression, globals(), localmap)

        except Exc:
            raise

        except Exception, e:
            raise self.PythonError(type(e).__name__,
                                   str(e).strip(),
                                   expression=expression.strip())


    ########################################################################
    ### Parse client input

    def expandParts (self, instream, context):
        text, parts = self.expandArgs(instream, context=context)
        args = list(parts)
        index = None

        try:
            option, command, rawtext = args.pop(0)

            if not option and command[:1].isdigit():
                index = command
                option, command, rawtext = args.pop(0)

        except IndexError, e:
            return text, index, None, None

        else:
            if option:
                command = self.collapsePart((option, command), raw=True)

            return text, index, command.strip(), args


    def getCommand (self, instream, context):
        try:
            return self.expandParts(instream, context=context)
        except ParseError, e:
            if isinstance(e.exception, Aborted):
                raise Abort()
            else:
                raise self.ParseError(e.expression, e.pos, e.reason, e.subexpression, scpiException(e.exception, e.exc_info))


    ########################################################################
    ### Handle client input

    def handle (self, scope, invocation=None, localdata=None, **kwargs):
        context = Context(self, scope, invocation=invocation, data=localdata)
        cleanupargs = self.setup(context)
        try:
            if not context.exception:
                return self.handleInput(self.instream, context, **kwargs)
        finally:
            self.cleanup(context, *cleanupargs)

    def setup (self, context):
        #subscription.addTopic(self.debugTopic)
        return ()

    def cleanup (self, context):
        if BaseSession.exclusive == self:
            BaseSession.exclusive = None

        subscription.deleteTopic(self.debugTopic, ignoreMissing=True)

    def close (self):
        ### Prevent further reads from the input stream
        self.instream.close()

    def handleExceptions (self, context, func, args=(), argmap={}, notify=subscription.info, asynchronous=False):
        job   = context, currentThread(), func, args, argmap, asynchronous

        self.addJob(job)
        try:
            func(*args, **argmap)

        except NextReply, e:
            self.startThread(context, e.leaf, e.method, e.methodArgs, e.methodKwargs, notify)

        except (Break, ReturnValue), e:
            pass

        except Exception, e:
            exception = scpiException(e, exc_info(), (func, args, argmap))
            if context.text:
                exception.insertContext(context.text.strip())

            self.logException(exception, context.text)
        finally:
            self.finishJob(job)

    def handleInput (self, instream, context):
        raise NotImplemented

    ####################################################################
    ### The following are used to invoke commands

    def runBlock (self, input, context, nextReply=ASYNC, nextCommand=ASYNC, catchReturn=False, where=None):
        if isinstance(input, str):
            instream = StringIO(input)
        elif isinstance(input, (list, tuple)):
            # Collapse and protect individual strings if more than one argument
            instream = StringIO(self.collapseArgs(input) if len(input) > 1 else input[0])
        elif hasattr(input, 'seek'):
            instream = input
            instream.seek(0)
        else:
            assert False, \
                "Session %s runBlock() received unsupported data type %s in input %s"%\
                (self.description, type(input).__name__, input)

        return self.runStream(instream, context,
                              nextReply=nextReply,
                              nextCommand=nextCommand,
                              catchReturn=catchReturn,
                              where=where)

    def runStream (self, instream, context,
                   nextReply=ASYNC, nextCommand=ASYNC,
                   catchReturn=False, seek=None, where=None):

        assert not isinstance(instream, (str, list, tuple))

        while True:
            try:
                text, index, command, args = self.getCommand(instream, context)
                if command is None:
                    continue
            except EOFError:
                return ()
            except Exc, e:
                context.update(response=None, exception=e)
                raise
            else:
                context.update(text=text, index=index)

            try:
                context = self.runParts(context, command, args, nextReply=nextReply, catchReturn=False)

            except Break, e:
                if catchReturn:
                    return
                else:
                    raise

            except ReturnValue, e:
                if catchReturn:
                    return e.args
                else:
                    raise

            except NextControl, e:
                if isinstance(e, NextCommand) and not e.method:
                    e.method       = self.runStream
                    e.methodArgs   = (instream, context)
                    e.methodKwargs = dict(nextReply=ASYNC, nextCommand=SYNC, catchReturn=False)

                asyncArgs = (instream, context, e.method, e.methodArgs, e.methodKwargs)
                action    = (nextReply, nextCommand)[isinstance(e, NextCommand)]

                if action == PASSTHROUGH:
                    raise

                elif action == RAISE:
                    raise NextReply(e.leaf, self.runAsynchronousStream, asyncArgs, {})

                elif action == SYNC:
                    if e.method:
                        context.response = e.method(*e.methodArgs, **e.methodKwargs)

                elif action == ASYNC:
                    self.startThread(context, e.leaf, self.runAsynchronousStream, asyncArgs, {})
                    break

                else:
                    assert False, \
                       'Session.runStream() invoked with invalid "nextCommand" action %s in command: %s'\
                       %(nextCommand, text)

            except Error, e:
                text = self.extractContext(instream, nlines=8)
                e.insertContext(text.strip())
                if where:
                    e.insertContext(where)
                e.throw()



    def runAsynchronousStream (self, instream, context, method, args, kwargs):
        if method:
            method(*args, **kwargs)
        return self.runStream(instream, context, nextReply=ASYNC, nextCommand=SYNC, catchReturn=True)


    def runParts (self, context, command, args, scope=None, nextReply=ASYNC, catchReturn=False):
        try:
            context = self._run(context, command, args, scope)

        except NextReply, e:
            leaf, method, args, argmap = e.args

            if nextReply in (RAISE, PASSTHROUGH):
                raise
            elif nextReply == SYNC:
                context.response = method(*args, **argmap)
            elif nextReply == ASYNC:
                self.startThread(context, leaf, method, args, argmap)

        except Break, e:
            if not catchReturn:
                raise

        except ReturnValue, e:
            if not catchReturn:
                raise

        except ReturnCall, e:
            leaf, method, args, argmap = e.args
            outstream = StringIO()
            method(outstream, *args, **argmap)
            outstream.seek(0)
            text = outstream.read()
            context.leaf    = None
            context.outputs = [(None, text, text)]

        except Error, e:
            parts = [command]
            parts.extend(args)
            cmd = self.collapseArgs(parts)
            e.insertContext(cmd)
            raise

        return context


    def _run (self, context, command, args, scope=None):
        #assert context or scope, \
        #"Neither context nor scope was provided while running command %r with parts %s"%(command, args)

        if not scope:
            scope = context.scope
#        elif not context:
#            context = Context(self, scope)

        path, opts = scope.locate(command)

        try:
            branch, leaf = path[-2:]
        except ValueError:
            branch, leaf = scope, path[-1]

        iname, iargs = context.invocation
        method = getattr(leaf, iname)

        opts.update(_session=self,
                    _context=context,
                    _scope=scope,
                    _command=command,
                    _parts=args,
                    _branch=branch,
                    _callpath=path)

        response = outputs = exception = None
        try:
            response = method(*iargs, **opts)

        except ReturnValue, e:
            exception = e
            outputs   = e.args

        except Exc, e:
            exception = e

        except Aborted, e:
            exception = Abort()

        except Exception, e:
            exception = scpiException(e, exc_info(), (method, iargs, opts))

        finally:
            context.leaf      = leaf
            context.invoked   = method, iargs, opts
            context.response  = response
            context.outputs   = outputs
            context.exception = exception
            if exception:
                exception.throw()

        return context


    def _next (self, context, method, args, kwargs):
        context.response = method(*args, **kwargs)
        return context

    ####################################################################
    ### Asynchronous execution

    def startThread (self, context, leaf, method, args, argmap, notify=subscription.info):
        basename    = leaf and leaf.commandPath(short=True) or method.__name__
        name        = ">".join((currentThread().name, basename))
        nextcontext = context.clone()
        #nextcontext = context
        nextargs    = (nextcontext, method, args, argmap)
        handleargs  = (nextcontext, self._next, nextargs, {}, notify, True)
        thread      = ControllableThread(None, self.handleExceptions, name, handleargs)
        nextcontext.update(thread=thread)
        self.trace("Starting thread %r in %s"%(thread.name, self.description))
        thread.setDaemon(True)
        thread.start()
        return thread

    def extractContext (self, instream, nlines=8):
        position = instream.tell()
        instream.seek(0)
        lines   = []
        readpos = 0
        for line in instream:
            lines.append(line)
            readpos += len(line)
            if readpos >= position:
                break

        if len(lines) > nlines:
            lines[nlines/2:len(lines)-nlines/2] = [" ...\n"]

        return ''.join(lines)



    ########################################################################
    ### Command output processing

    #def formatOutputs (self, response, alwaysNamed=False, raw=False):
    #    try:
    #        leaf, outputs = response
    #    except TypeError:
    #        outputs = ()
    #    else:
    #        if leaf:
    #            outputs = leaf.formatOutputs(outputs, alwaysNamed=alwaysNamed, raw=raw)
    #
    #    return outputs



    ########################################################################
    ### Job control/watch support

    def addJob (self, job):
        self.jobs.append(job)

    def finishJob (self, job):
        try:
            self.jobs.remove(job)
        except ValueError:
            pass

    ####################################################################
    ### Debug method

    def publish (self, topic, message, level, quoting=QUOTE_NEVER, literaltag=None):
        subscription.publish(topic, message, level=level, quoting=quoting, literaltag=literaltag)

    def trace (self, message):
        self.publish(self.debugTopic, message, level=subscription.TRACE)

    def debug (self, message):
        self.publish(self.debugTopic, message, level=subscription.DEBUG)

    def info (self, message):
        self.publish(self.debugTopic, message, level=subscription.INFO)

    def notice (self, message):
        self.publish(self.debugTopic, message, level=subscription.NOTICE)

    def warning (self, message):
        self.publish(self.debugTopic, message, level=subscription.WARNING)

    def logException (self, exc, circumstance=None):
        if isinstance(exc, SessionControl):
            intro     = "Session control:"
            logmethod = self.debug
            parts     = exc.parts(withContext=False)

        elif isinstance(exc, InternalError):
            intro     = "Internal error:"
            logmethod = self.notice
            parts     = exc.parts(withContext=True, withTraceback=True)

        elif isinstance(exc, Error):
            intro     = "Error:"
            logmethod = (self.info, self.debug)[exc.transient]
            parts     = exc.parts(withContext=not exc.transient)

        else:
            intro     = 'Exception:'
            logmethod = self.info
            parts     = exc.parts(withContext=True)

        message = [intro]
        if circumstance:
           message.append(circumstance.strip())
        message.extend(parts)
        logmethod(message)


    ########################################################################
    ### Access control and authentication

    def checkAccessByName (self, requiredAccessName):
        self.checkAccess(self.accessLevelIndex(requiredAccessName, CONTROLLER))

    def checkAccess (self, requiredAccess):
        if self.accessLevel < requiredAccess:
            raise self.InsufficientAccess(requiredAccess=self.getLevelName(requiredAccess),
                                          currentAccess=self.getLevelName(self.accessLevel))

    def setAccessLevel (self, level, exclusive=False, stealth=False):
        if level > self.accessLimit:
            raise self.AccessLevelExceeded(accessLimit=self.getLevelName(self.accessLimit))

        self.accessLevel   = level
        self.stealthAccess = stealth

        if exclusive and not stealth:
            BaseSession.exclusive = self
        elif BaseSession.exclusive == self:
            BaseSession.exclusive = None

    def getStealthFlag (self):
        return self.stealthAccess

    def getExclusiveFlag (self):
        return False

    def getAccessLevel (self):
        return self.accessLevel

    def getAccessLimit (self):
        return self.accessLimit

    def getLevelName (self, index=None):
        return AccessLevels[index or self.accessLevel]

    def accessLevelIndex (self, name, *default):
        try:
            return list(AccessLevels).index(name and name.capitalize())
        except ValueError:
            if not default:
                raise self.InvalidAccessLevel(accessLevel=name)
            else:
                return default[0]

    def generateChallenge (self):
        self.challenge = "%032x"%randint(0, 2L**128-1)
        return self.challenge

    def getChallenge (self):
        return self.challenge


    def isValidAuthentication (self, hexdigest, secret):
        if self.challenge:
            key = hmac.new(secret, self.challenge, md5).hexdigest()
            return (key.lower() == hexdigest.lower())


    def authenticatedLevel (self, spec, key, current, limit):
        try:
            level = self.accessLevelIndex(spec[key])
        except KeyError:
            level = current

        if limit is not None and level > limit:
            level = limit

        return level


    def authenticate (self, response):
        for profile, spec in self.authdata.items():
            try:
                secrets = [base64.b64decode(secret) for secret in spec['secrets'].split()]
            except (TypeError, KeyError):
                pass
            else:
                for secret in secrets:
                    if self.isValidAuthentication(response, secret):
                        return self.authorize(profile, spec)


    def authorize (self, profile, spec):
        limit = self.authenticatedLevel(spec, 'limit', self.accessLimit, self.authLimit)
        level = self.authenticatedLevel(spec, 'level', self.accessLevel, limit)

        oldsession = self.sessionid
        self.setRole(profile)

        self.notify(subscription.DEBUG, T_AUTH,
                    role=self.role,
                    session=self.sessionid,
                    accessLevel=AccessLevels[level],
                    accessLimit=AccessLevels[limit],
                    oldLimit=AccessLevels[self.accessLimit])

        self.accessLevel, self.accessLimit = level, limit
        return (profile, level, limit, spec.get('preexec'), spec.get('postexec'))


    def addAuthProfile (self, name, spec, save=False):
        self.authdata[name] = spec
        if save:
            self.authconfig[name] = spec
            self.authconfig.save()

    def removeAuthProfile (self, name, save=False):
        del self.authdata[name]
        if save:
            self.authconfig.remove_section(name, save=True)

    def clearAuthPRofiles (self, save=False):
        self.authdata.clear()
        if save:
            for section in self.authconfig.sections():
                self.authconfig.remove_section(section)



### Notification triggers
Triggers = ('Connect', 'Disconnect',  # An external client connects or disconnects
            'Access', 'Authenticate', # An external client changes access level or authenticates
            'Error')                  # A command returns an error.

(T_CONNECT, T_DISCONNECT, T_ACCESS, T_AUTH, T_ERROR) = range(len(Triggers))

class ClientSession (BaseSession):
    '''
    Handle network connections
    '''
    class ExclusiveAccessGiven (RunError):
        '''Exclusive %(level)s access is already given to %(client)s'''

    class AccessGiven (RunError):
        '''%(level)s access is already given to %(client)s'''

    enterHooks = []
    exitHooks  = []

    def __init__ (self, connection, outstream, preexec=None, postexec=None, **argmap):
        BaseSession.__init__(self, **argmap)

        self.outstream   = outstream
        self.connection  = connection
        self.peer        = connection.getpeername()
        self.interface   = connection.getsockname()

        self.ifname      = self.maptoif(self.interface[0])
        self.parent      = None

        self.authLimit   = self.interfaceLimit('authLimits')
        self.accessLimit = self.interfaceLimit('accessLimits')
        self.accessLevel = min(self.interfaceLimit('defaultAccess'),
                               self.nonExclusiveLimit())

        self.enterHooks  = ClientSession.enterHooks[:]
        self.addEnterHook(preexec)

        self.exitHooks   = ClientSession.exitHooks[:]
        self.addExitHook(postexec)


    def setup (self, context):
        cleanupargs  = BaseSession.setup(self, context)
        scope        = context.scope
        commandscope = scope.commandPath()

        self.notify(subscription.INFO, T_CONNECT,
                    ('session',     self.sessionid),
                    ('scope',       commandscope),
                    ('accessLevel', AccessLevels[self.accessLevel]),
                    ('accessLimit', AccessLevels[self.accessLimit]),
                    ('authLimit',   AccessLevels[self.authLimit]),
                    ('ifname',      self.ifname),
                    ('ifaddr',      "%s:%s"%self.interface),
                    ('ipaddr',      "%s:%s"%self.peer))

        if self.runHooks(self.enterHooks, context, "enter hook"):
            keys   = 'product', 'version', 'build', 'serialnumber', 'hostname', 'nickname'
            values = sysconfig.get(keys)
            items  = zip(keys, values)
            if commandscope:
                items.append(('scope', commandscope))
            items.append(('interface', self.ifname))
            self.sendReady(*items)

        return (scope,) + cleanupargs


    def cleanup (self, context, scope, *cleanupargs):
        self.clearSubscriptions()
        self.notify(subscription.INFO, T_DISCONNECT,
                    ('scope',      context.scope.commandPath()),
                    ('ifname',     self.ifname),
                    ('ifaddr',     "%s:%s"%self.interface),
                    ('ipaddr',     "%s:%s"%self.peer))

        thread = currentThread()
        for subcontext, subthread, func, args, argmap, asynchronous in self.jobs:
            if not asynchronous and subthread is not thread:
                self.debug("Client disconnected, aborting command: %s"%(commandtext.strip(),))
                subthread.abort(recursive=False)

        context.scope = scope
        if self.runHooks(self.exitHooks, context, "exit hook"):
            return BaseSession.cleanup(self, context, *cleanupargs)


    def addEnterHook (self, hook):
        if hook:
            self.enterHooks.append(hook)


    def addExitHook (self, hook):
        if hook:
            self.exitHooks.append(hook)


    def runHooks (self, hooks, context, kind, access=ADMINISTRATOR):
        originalAccess = self.accessLevel
        self.accessLevel = access

        try:
            for text in hooks:
                try:
                    self.runBlock(text, context, catchReturn=True)
                except Error, e:
                    e.insertContext(text)
                    e.insertContext("In %s %s"%(self.description, kind))
                    self.logException(e)
                    self.respondError(text, e)
                    return False
            else:
                return True
        finally:
            self.accessLevel = originalAccess

    def handleInput (self, instream, context):
        while True:
            reply = exception = None
            try:
                commandtext, index, command, args = self.getCommand(instream, context)
                if command is None:
                    continue

            except EOFError:
                break

            except self.ParseError, e:
                self.respondError(e.expression[:e.pos].rstrip(), e)

            else:
                self.debug('C: %s'%commandtext.rstrip().replace('\n', '\nc: '))
                context.update(text=commandtext, index=index)
                runargs = (context, command, args)
                self.handleExceptions(context, self._run, runargs, {}, subscription.debug)


    def handleExceptions (self, context, func, args=(), argmap={}, notify=subscription.info, asynchronous=False):
        echo  = context.index or context.text.strip()
        job   = context, currentThread(), func, args, argmap, asynchronous

        self.addJob(job)
        try:
            func(*args, **argmap)
            self.respondOK(echo, context.getOutputs(alwaysNamed=False))

        except NextCommand, e:
            # Nested NextCommand exceptions are caught in runStream();
            # we only see this when invoked directly in ClientSession.
            self.respondOK(echo)

        except NextReply, e:
            if not asynchronous:
                self.respondNext(echo)
            self.startThread(context, e.leaf, e.method, e.methodArgs, e.methodKwargs, notify)

        except Break, e:
            self.respondOK(echo)

        except ReturnValue, e:
            self.respondOK(echo, e.args)

        except ReturnCall, e:
            # Nested ReturnCall exceptions are caught in runParts();
            # we only see this when invoked directly in ClientSession.
            leaf, method, args, argmap = e.args
            self.respondOKWithCallback(echo, method, args, argmap)

        except Exc, e:
            self.logException(e, context.text.strip())
            self.respondError(echo, e)

        except Exception, e:
            exception = scpiException(e, exc_info(), (func, args, argmap))
            self.logException(exception, context.text.strip())
            self.respondError(echo, exception)

        self.finishJob(job)



    ####################################################################
    ### Responses to client

    def respondOK (self, echo, parts=()):
        words = [OK, echo]
        if parts:
            words.extend(parser.collapseParts(parts, tag='reply'))
        output = ' '.join(words) + '\n'
        self.sendOutput(output)

    def respondOKWithCallback (self, echo, function, args, argmap):
        output = ' '.join((OK, echo))
        self.sendOutput(output, function, args, argmap)

    def respondNext (self, echo):
        output = ' '.join((NEXT, echo)) + '\n'
        self.sendOutput(output)

    def respondError (self, echo, error):
        response = error.format()
        output = ' '.join((ERROR, echo, error.format())) + '\n'
        self.sendOutput(output)

    def processMessage (self, message, messageFormat, includeSession):
        if includeSession or message.topic != self.debugTopic:
            text = message.format(messageFormat)
            self.sendMessage(text)


    ####################################################################
    ### Notification support

    def notify (self, _notifyLevel, _trigger, *items, **properties):
        parts = ['N:', Triggers[_trigger]]
        parts.extend(filter(None, items))
        parts.extend([(k,v) for (k,v) in properties.items() if v])
        self.publish(self.debugTopic, parts, level=_notifyLevel, literaltag=None)

    ########################################################################
    ### Client input/output

    def sendReady (self, *items, **properties):
        items = [READY] + list(items) + properties.items()
        text  = parser.collapseArgs(items, tag=None)
        self.sendOutput(text+"\n")

    def sendMessage (self, *text):
        output = ' '.join((MESSAGE,) + text) + '\n'
        self.send(output)

    def sendOutput (self, text, *callback):
        self.send(text, callback)
        self.debug("S: "+text.rstrip().replace("\n", "\ns: "))

    def send (self, text, callback=None):
        try:
            if callback:
                prefix   = '%s <quote.output>\n'%(text,)
                postfix  = '</quote.output>\n'
                function, args, argmap = callback
                self.outstream.write(prefix)
                try:
                    function(self.outstream, *args, **argmap)
                except Exception, e:
                    self.outstream.write(postfix)
                    error   = InternalError(e, exc_info(), (function.__name__, args, argmap))
                    message = error.format(showContext=True)
                    self.warning("Exception in output callback: %s"%(message,))
                else:
                    self.outstream.write(postfix)
            else:
                self.outstream.write(text)

        except SocketError, e:
            error   = ExternalError(e)
            message = error.format(showContext=True)
            self.warning("Failed to send output to %s: %s"%(self.description, message))
            self.close()

    ####################################################################
    ### PUBLish/SUBScribe support

    def subscribe (self, topic, level, messageFormat, future, createMissing, ignoreMissing, regex, includeSession):
        subscription.subscribe(topic, level, self.processMessage, args=(messageFormat, includeSession),
                               future=future, createMissing=createMissing, ignoreMissing=ignoreMissing, regex=regex)

    def unsubscribe (self, topic):
        return subscription.unsubscribe(topic, self.processMessage)

    def clearSubscriptions (self):
        subscription.clearSubscriptions(self.processMessage)

    def getSubscriptions (self, future=False):
        if future:
            return subscription.getSubscriptionMasks(self.processMessage)
        else:
            return subscription.getSubscribedTopics(self.processMessage)

    ####################################################################
    ### Access Control

    def interfaceLimit (self, limittype):
        limit = None
        if self.ifname:
            limit = self.accessinfo.get(limittype, {}).get(self.ifname, None)

        if limit is None:
            host, port = self.interface
            limit = self.accessinfo.get(limittype, {}).get(host, None)

        if limit is None:
            limit = self.accessinfo.get(limittype, {}).get('default', None)

        if limit is None:
            limit = GUEST
        else:
            limit = self.accessLevelIndex(limit)

        return limit

    def clientAddressLimit (self, limitthype):
        addr   = self.connection.getpeername()[0]
        limit  = None

        for hostspec, accesslimit in self.accessinfo.items(limittype):
            if isInValidRange(addr, (hostspec, )):
                limit = accesslimit

        return limit and self.accessLevelIndex(limit) or GUEST

    def maptoif (self, address):
        for provider in netconfig.getProviders('interface'):
            try:
                interfaces = provider.getInterfaces()
                break
            except AttributeError:
                continue
        else:
            if address.startswith('127.'):
                return 'lo'
            else:
                return None

        for ifname in interfaces:
            ifaddr = netconfig.get('address', interface=ifname, current=True)
            if ifaddr == address:
                return ifname

    def nonExclusiveLimit (self):
        if BaseSession.exclusive in (self, None):
            return self.accessLimit
        else:
            return min(self.accessLimit, max(GUEST, BaseSession.exclusive.accessLevel-1))

    def setAccessLevel (self, level, exclusive=False, stealth=False):
        if (not stealth and
            not BaseSession.exclusive in (self, None) and
            (exclusive or (level >= BaseSession.exclusive.accessLevel))):
            raise self.ExclusiveAccessGiven(level=BaseSession.exclusive.getLevelName().lower(),
                                            client=BaseSession.exclusive.description)

        elif exclusive:
            for othersession in self.getInstances(ClientSession):
                if (othersession != self) and \
                   (othersession.accessLevel >= level) and \
                   (not othersession.stealthAccess):
                    raise self.AccessGiven(level=othersession.getLevelName(),
                                           client=othersession.description)

        BaseSession.setAccessLevel(self, level, exclusive, stealth)

        self.notify(subscription.DEBUG, T_ACCESS,
                    session=self.sessionid,
                    level=AccessLevels[self.accessLevel],
                    stealth=str(stealth),
                    exclusive=str(BaseSession.exclusive is self))

    def getExclusiveFlag (self):
        return BaseSession.exclusive == self

class SocketSession (ClientSession):
    '''
    Handle connections on plain TCP sockets
    '''

    def __init__ (self, *args, **kwargs):
        ClientSession.__init__(self, *args, **kwargs)
        self.writeQueue   = Queue()

    def setup (self, context):
        cleanupargs = ClientSession.setup(self, context)
        outputThread = ControllableThread(None, self._outputHandler,
                                               "%s-Output"%self.sessionid, (), {})

        outputThread.setDaemon(True)
        outputThread.setAbortable(IGNORE)
        outputThread.start()
        return (outputThread,) + cleanupargs

    def cleanup (self, context, outputThread, *args):
        self.writeQueue.put(None)
        outputThread.join()
        ClientSession.cleanup(self, context, *args)

    def send (self, text, callback=None):
        self.writeQueue.put((text, callback))

    def _outputHandler (self):
        item = self.writeQueue.get()
        while item is not None:
            ClientSession.send(self, *item)
            item = self.writeQueue.get()

class TelnetSession (ClientSession):
    '''
    Handle connections from interactive/telnet clients
    '''
    def autocomplete (self, text):
        return [ text+"a", text+"b" ]

class NestedSession (BaseSession):
    '''
    Nested command execution.
    '''

    def __init__ (self, parent, input, access=None, **argmap):
        BaseSession.__init__(self, input, **argmap)

        if access is not None:
            self.accessLimit = self.accessLevel = self.authLimit = access

        elif parent:
            self.accessLimit = parent.accessLimit
            self.accessLevel = parent.accessLevel
            self.authLimit   = parent.authLimit
            self.jobs        = parent.jobs

        self.parent = parent

    ####################################################################
    ### Property functions for access to <instance>.parent

    def setparent (self, parent):
        if parent:
            self._parent = weakref.ref(parent)
        else:
            self._parent = None

    def getparent (self):
        if self._parent:
            return self._parent()
        else:
            return None

    def delparent (self):
        self._parent = None

    parent = property(getparent, setparent, delparent)

    def handleInput (self, input, context, nextReply=ASYNC, nextCommand=ASYNC, catchReturn=True):
        try:
            return self.runBlock(input, context,
                                 nextReply=nextReply,
                                 nextCommand=nextCommand,
                                 catchReturn=catchReturn)
        except Error, e:
            e.insertContext("In %s"%(self.description,))
            e.throw()


    ####################################################################
    ### PUBLish/SUBScribe support

    def subscribe (self, *args, **kwargs):
        parent = self.parent
        if parent:
            parent.subscribe(*args, **kwargs)

    def unsubscribe (self, *args, **kwargs):
        parent = self.parent
        if parent:
            parent.unsubscribe(*args, **kwargs)

    def clearSubscriptions (self, *args, **kwargs):
        parent = self.parent
        if parent:
            parent.clearSubscriptions (*args, **kwargs)

    def getSubscriptions (self, *args, **kwargs):
        parent = self.parent
        if parent:
            return parent.getSubscriptions(*args, **kwargs)



class MacroSession (NestedSession):
    '''
    Macro command session; process NEXT and RETurn
    '''

    def handleInput (self, input, context, nextReply=ASYNC, nextCommand=RAISE, catchReturn=True):
        return NestedSession.handleInput(self, input, context,
                                         nextReply=nextReply, nextCommand=nextCommand, catchReturn=catchReturn)

class DetachedSession (MacroSession):
    '''
    Command execution detached from any controlling sessions
    '''
    def handleInput (self, input, context=None, scope=None, nextReply=ASYNC, nextCommand=ASYNC, catchReturn=True):
        if context is None:
            context = Context(self, scope)
        args = (input, context)
        kwargs = dict(nextReply=nextReply, nextCommand=nextCommand, catchReturn=catchReturn,
                      where='In %s'%(self.description,))
        self.handleExceptions(context, self.runBlock, args, kwargs, subscription.info)



class HandlerSession (DetachedSession):
    '''
    Session to handle messages
    '''

    messageThread = None

    def addMessageHandler (self, handle, mask, future, createMissing, ignoreMissing,
                           level, regex, queuesize, filters, action, scope, preempt):
        self.messageQueue = Queue(maxsize=queuesize)
        rxfilters = self.compiledFilters(filters, regex)
        subscription.subscribe(mask, level, self._messageReceiver,
                               args=(rxfilters, action, scope, preempt), regex=regex,
                               future=future, createMissing=createMissing,
                               ignoreMissing=ignoreMissing)

        name = '|'.join((currentThread().name, "MessageHandler-"+handle))
        thread = self.messageThread = ControllableThread(None, self._messageHandler, name, (self.messageQueue,), {})
        thread.setDaemon(True)
        thread.setAbortable(IGNORE)
        thread.start()

    def clearSubscriptions (self):
        if self.messageQueue:
            count = subscription.clearSubscriptions(self._messageReceiver)
            self.messageQueue.cancel()

    def waitForCompletion (self):
        if self.messageThread != currentThread():
            self.messageThread.join()

    def getHandlerRecord (self):
        records = subscription.getSubscriptionRecords(self._messageReceiver)
        try:
            mask, level, callback, args = records[0]
        except IndexError, e:
            pass
        else:
            rxfilters, action, scope, preempt = args
            return mask, level, rxfilters, action, scope, preempt

    def _messageReceiver (self, message, rxfilters, action, scope, preempt):
        if self.matchingMessage(message, rxfilters):
            self.messageQueue.put((message, rxfilters, action, scope))
            if preempt:
                raise StopIteration

    def _messageHandler (self, queue):
        try:
            while True:
                (message, rxfilters, action, scope) = queue.get()
                text = message.format(format=action)
                self.handleInput(StringIO(text), Context(self, scope, data=message))
        except Empty:
            pass

    def matchingMessage (self, message, rxfilters):
        for key, rx in rxfilters.items():
            try:
                if key is None:
                    value = message.text
                else:
                    value = message[key]
            except KeyError:
                return False
            else:
                if not rx.match(value or ""):
                    return False
        else:
            return True

    def compiledFilters (self, filters, regex=False):
        result = {}
        for option, mask in filters.items():
            if not regex:
                mask = fnmatch.translate(mask)

            result[option] = re.compile(mask, re.I|re.S)

        return result

class ModuleSession (NestedSession):
    '''
    Module file session.
    '''

    class NoSuchModule (RunError):
        '''Unable to locate module %(filename)r'''

    defaultSuffixes = ('.scpi', '.mod')

    def __init__ (self, module, **argmap):
        if hasattr(module, 'read'):
            instream = module
        else:
            filepath = self.filepath(module)
            instream = open(filepath)

        NestedSession.__init__(self, input=instream, **argmap)

    @classmethod
    def filepath (cls, filename, ignoreMissing=False):
        root, ext = splitext(filename)
        candidates = [ filename ]
        if not ext in cls.defaultSuffixes:
            candidates.extend([ filename+suffix for suffix in cls.defaultSuffixes ])

        for d in getModulePath():
            for candidate in candidates:
                filepath = join(d, candidate)
                if isfile(filepath):
                    return filepath

        if not ignoreMissing:
            subscription.debug("Module %r not found. Candidate names: %s. Search path:%s"%
                               (filename, ", ".join(candidates), ''.join([ "\n\t"+d for d in getModulePath()])))
            raise cls.NoSuchModule(filename=filename)

    def handleInput (self, instream, context, nextReply=ASYNC, nextCommand=RAISE, catchReturn=True):
        commandPath = context.scope.commandPath()
        self.debug("Running module in command scope %s: %r" % (commandPath or "(ROOT)", instream.name))
        return NestedSession.handleInput(self, instream, context, nextReply=nextReply, nextCommand=nextCommand, catchReturn=catchReturn)


class InitSession (DetachedSession, ModuleSession):
    '''
    Initialization module session.  These are run at a higher access
    level than modules invoked by a client.
    '''

    def __init__ (self, module, *args, **argmap):
        ModuleSession.__init__(self, module=module, parent=None, access=FULL, *args, **argmap)
        subscription.info('Loading init module: %s'%(module,))

    def handleInput (self, instream, context, nextReply=ASYNC, nextCommand=ASYNC, catchReturn=True):
        return DetachedSession.handleInput(self, instream, context, nextReply=nextReply, nextCommand=nextCommand, catchReturn=catchReturn)


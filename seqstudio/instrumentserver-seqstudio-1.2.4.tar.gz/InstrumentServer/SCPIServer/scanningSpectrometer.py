########################################################################
### FILE:	capillaryScan.py
### PURPOSE:	Spectrometer acquisition correlated with capillary axis
###             position
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2015 ThermoFisher Scientific.  All rights reserved.
########################################################################

from spectrometerBase import SpectrometerBase
from llacBase         import LLACRegisterBranch, _LLACReadLeaf
from scpiLeaf         import SYNCHRONOUS, ASYNCHRONOUS, Controlling, Singleton, Leaf, Background
from scpiExceptions   import CommandError, RunError
from llacMotionBranch import LLACMotionControlBranch, LinearMotionAxis

class ScanningAxis (LinearMotionAxis):
    '''Motion axis for capillary scanning'''

    exclusive = True

class ScanningSpectrometer (SpectrometerBase, LLACMotionControlBranch):
    '''
    Abstract spectrometer branch, with LLAC polling support.
    '''

    class NoScanningAxis (RunError):
        'There is no scanning axis in %(robot)s'


    pollItems    = ()
    pollsPending = []
    posititonRegister = None

    axisTypes = {
        None              : ScanningAxis,
        'scanning'        : ScanningAxis }


    def __init__ (self, *args, **kwargs):
        SpectrometerBase.__init__(self, *args, **kwargs)
        LLACMotionControlBranch.__init__(self, *args, **kwargs)


    def getScanningAxis (self, ignoreMissing=False):
        for axis in self.axes:
            if axis.istype(ScanningAxis):
                return axis
        else:
            if not ignoreMissing:
                raise self.NoScanningAxis(robot=self.commandPath())


    def setPoll (self, tag=None):
        self.clearDataColumns()

        if tag:
            axis    = self.getScanningAxis()
            axis.checkConfig()
            regspec = axis.registers[axis.R_CURRENTPOS]
            self.pollItems = ((tag, regspec),)
            self.addDataColumns(tag)
        else:
            self.pollItems = ()


    def waitForData (self, index):
        pending = [ self.sendRead(**reg) for (key, reg) in self.pollItems ]
        result  = SpectrometerBase.waitForData(self, index)

        if pending:
            replies = self.getResponseList(pending)
            self.framedata.extend([ (item[0], reply) for (item, reply) in zip(self.pollItems, replies) ])

        return result


    def getData (self, index):
        timestamp, data = self.device.GetData(index)
        #if self.pollItems:
        #    self.framedata.append(('Score', self.alignmentScore(data)))
        return timestamp, data


    def alignmentScore (self, data):
        delta = sum([ max(p)-min(p) for p in zip(*data) ])
        total = sum([ sum(points) for points in data ])
        score = float(total) / float(delta)
        return score


    class START (SpectrometerBase.START):
        '''
        Start data acquisition.

        Data is grouped into spectral bands as specified with the "-bands" option,
        then published published in real time on the specified message topic.
        The following information is published at the start of the acquisition:

          ChannelRegion -<channelName>=<x1>,<x2>,<y1>,<y2> ...
          Coefficients -<channelName>=<fixed>,<linear>,<quadratic>,<cubic>... ...
          PixelsPerBand -<channelName>=<bin0width>,<bin1width>,... ...
          CenterPixels -<channelName>=<bin0center>,<bin1center>,... ...
          Wavelengths -<channelName>=<bin0wavelength>,<bin1wavelength>,... ...
          Signal -index=1 -timestamp=<sec.ms> -<channelName>=<bin0average>,<bin1average>,... [-<positionTag>=<pos>] ...
          Signal -index=2 -timestamp=<sec.ms> -<channelName>=<bin0average>,<bin1average>,... [-<positionTag>=<pos>] ...
          ...

        Optionally, data is also saved to a file, in a CSV format suitable
        for subsequent use in simulation and/or offline analysis applications.
        Note that this data is not grouped into spectral bands, but includes
        individual data columns for all analog bins.
        '''


        def declareInputs (self):
            SpectrometerBase.START.declareInputs(self)
            self.setInput('positionTag', type=str, default=None, named=True,
                          description='LLAC register from which to poll capillary axis position. '
                          'If set, the contents of that register is included in each published data frame.')


        def run (self, _session, _context,
                 count=int, duration=float, synchronous=False,
                 startIndex=1, exposure=int, speed=int, gain=int,
                 inputTrigger=0, outputSignal=0,
                 openShutter=bool, dark=False,
                 minCorrectionRatio=None, minCorrectionThreshold=None, alignmentShift=None,
                 binning=None, dataBinning=None, maxDataBins=None,
                 minDataWavelength=None, maxDataWavelength=None,
                 topic=str, outputFile=None, description=None, positionTag=None):

            self.parent.setPoll(positionTag)

            return self.start(_session, _context,
                              count, duration, startIndex,
                              exposure, speed, gain,
                              inputTrigger, outputSignal, openShutter, dark,
                              minCorrectionRatio, minCorrectionThreshold,
                              alignmentShift, binning, dataBinning, maxDataBins,
                              minDataWavelength, maxDataWavelength,
                              topic, outputFile, description)


        def estimateTime (self, _session, _context,
                          count=int, duration=float, synchronous=False,
                          startIndex=1, exposure=int, speed=int, gain=int,
                          inputTrigger=0, outputSignal=0,
                          openShutter=None, dark=bool,
                          minCorrectionRatio=None, minCorrectionThreshold=None,
                          alignmentShift=None,
                          binning=None, dataBinning=None, maxDataBins=None,
                          minDataWavelength=None, maxDataWavelength=None,
                          topic=str, outputFile=None, description=None,
                          positionTag=None):


            if not duration and count:
                exposure = self.parent.getValue(exposure, self.parent.ExposureTime, 0)
                duration = ((exposure+5) / 1000.0) * count

            if synchronous:
                self.addTime(_context, synchronous=(duration or 0)+3)
            else:
                self.addTime(_context, synchronous=3, asynchronous=duration or 0)



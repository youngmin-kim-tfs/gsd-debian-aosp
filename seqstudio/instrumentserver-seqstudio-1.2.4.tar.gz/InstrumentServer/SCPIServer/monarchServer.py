#!/usr/bin/python -O
###############################################################################
### FILE:	monarchServer.py
### PURPOSE:	Instrument Command Server for Monarch
###
### AUTHOR:	Tor Slettnes <tor@slett.net>
###         Richard D. Morris -- Monarch
### Copyright (C) 2005-2014 Thermo Fisher Scientific, Inc. All rights reserved.
###############################################################################

from scpiTop      import Top
from scpiServer   import getStartupOption

import llacBranch          # Branch type "LLAC"
import llacFluidicsBranch  # Branch type "Fluidics"
import replaySpectrometer  # Branch type "DataAcquisition", "ReplaySpectrometer"
import serialSCPIDevice    # Branch Type "SerialSCPIDevice"
import llacTagBranch       # Branch type "ThermoTag"

spectrometer = getStartupOption('acquisition')
if spectrometer:
    __import__(spectrometer)


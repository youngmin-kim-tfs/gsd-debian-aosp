########################################################################
### FILE:	scpiSubscriptionBranch.py
### PURPOSE:	Publish/Subscribe commands
### HISTORY:
###  2013-11-13 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

from scpiMinimalBranch  import MinimalBranch
from scpiLeaf           import Leaf, Controlling, Observing
from scpiExceptions     import RunError, CommandError
from commandParser      import QuoteStyle, QUOTE_ATTRIBUTES
from scpiSession        import HandlerSession
from weakref            import ref
from data               import DynamicData

from subscription     import LogLevels, DEBUG, publish, publishPending, \
    topicExists, addTopic, deleteTopic, getTopics, getLevel, getSubscribers,  \
    NoSuchTopic, RegExError
from cStringIO        import StringIO



class MESSage (MinimalBranch):
    '''
    Support for asynchronous messages.

    Messages are typically generated ("published") as a result of:
      * external events (e.g. hardware state changes),
      * scheduled tasks (e.g. periodic polling of temperature sensors),
      * processing of commands (for logging/diagnostic purposes)
      * explicitly by external clients.

    Messages are categorized by:
      * topic - an arbitrary word that categorizes its nature
      * level - importance/severity: Trace, Debug, Info, Notice, Warning, Error

    Clients may listen ("subscribe") to such messages accordingly.
    '''

    class NoSuchTopic (RunError):
        '''No match for topic %(topic)r'''

    class TopicExists (RunError):
        '''Topic %(topic)r already exists'''

    class NotSubscribed (RunError):
        '''You were not subscribing to %(topic)r'''

    class NoSuchTrigger (RunError):
        '''There are no pending messages associated with trigger %(trigger)r'''

    class NoSuchHandler (RunError):
        '''No such message handler exists: %(name)r'''

    class RegExSyntax (RunError):
        '''Invalid syntax in regular expression pattern %(pattern)s'''


    def __init__(self, *args, **kwargs):
        MinimalBranch.__init__(self, *args, **kwargs)
        self.handlerSessions = DynamicData()


    def topicPath (self, scope, path, topic):
        if path:
            scope = scope.find(path)

        return scope.commandPath(topic or None, short=True)


    def getHandlerSession (self, handle, ignoreMissing=False):
        try:
            sessionref = self.handlerSessions[handle]
        except KeyError:
            session = None
        else:
            session = sessionref()

        if not session and not ignoreMissing:
            raise self.NoSuchHandler(name=handle)

        return session


    def addHandlerSession (self, handle, session):
        self.handlerSessions[handle] = ref(session)


    def removeHandlerSession (self, handle, ignoreMissing=False, waitForCompletion=False):
        try:
            sessionref = self.handlerSessions.pop(handle)
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchHandler(name=handle)
        else:
            session = sessionref()
            if session:
                session.clearSubscriptions()
                if waitForCompletion:
                    session.waitForCompletion()
                del session



    class TOPic_Add (Controlling, Leaf):
        '''Add a new message topic.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('replaceExisting', named=True, type=bool, default=False,
                          description='If the topic already exists, recreate it '
                          'instead of returning an error.')

            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')
            self.setInput('context', type=str, named=True, default=None, hidden=True)

            self.setInput('level', named=True,
                          type=LogLevels,
                          default=DEBUG,
                          description='Default severity level.  '
                          'This may be overridden for individual messages.')

            self.setInput('topics', type=str, repeats=(1, None))


        def run (self, _scope, replaceExisting=False, scope=None, context=None, level=LogLevels, *topics):
            for topic in topics:
                topic = self.parent.topicPath(_scope, scope or context, topic)
                if not replaceExisting and topicExists(topic):
                    raise self.parent.TopicExists(topic=topic)

                addTopic(topic, level)


    class TOPic_Remove (Controlling, Leaf):
        '''Remove an existing message topic'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')
            self.setInput('context', type=str, named=True, default=None, hidden=True)

        def run (self, _scope, ignoreMissing=False, scope=None, context=None, topic=str):
            topic = self.parent.topicPath(_scope, scope or context, topic)

            try:
                deleteTopic(topic, ignoreMissing)
            except NoSuchTopic:
                raise self.parent.NoSuchTopic(topic=topic)



    class TOPic_Enumerate (Observing, Leaf):
        '''Return list message topics defined at the specified level or above.'''

        def declareInptus (self):
            Leaf.declareInputs(self)

            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')
            self.setInput('context', type=str, named=True, default=None, hidden=True)


            self.setInput('level', named=True, type=LogLevels, default=DEBUG,
                          description='Minimum severity level')

            self.setInput('mask', named=False, type=str, description='Topic name mask')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("topic", type=str, repeats=(0, None))


        def run (self, _scope, scope=None, context=None, level=DEBUG, mask='*'):
            prefix = self.parent.topicPath(_scope, scope or context, '')
            mask   = self.parent.topicPath(_scope, scope or context, mask)
            topics = getTopics(mask, level)

            for index, topic in enumerate(topics):
                if topic.startswith(prefix):
                    topics[index] = topic[len(prefix):]

            topics.sort()
            return tuple(topics)


    class TOPic_Query (Observing, Leaf):
        '''Return information about the specified message topic'''

        def declareInputs(self):
            Leaf.declareInputs(self)
            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')
            self.setInput('context', type=str, named=True, default=None, hidden=True)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('level', type=LogLevels, named=True, default=None)
            self.addOutput('subscriptions', type=int, named=True, default=0)

        def run (self, _scope, ignoreMissing=False, scope=None, context=None, topic=str):
            topic = self.parent.topicPath(_scope, scope or context, topic)

            try:
                level = getLevel(topic, ignoreMissing)
                subscriptions = getSubscribers(topic, DEBUG, ignoreMissing=ignoreMissing)

            except NoSuchTopic:
                raise self.parent.NoSuchTopic(topic=topic)

            return level, len(subscriptions)



    class PUBLish (Controlling, Leaf):
        '''Publish a message on the specified topic.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('level', type=LogLevels, named=True, default=None)
            self.setInput('time', type=float, named=True, default=None,
                          description='Timestamp of published message; default is current time')
            self.setInput('quoted', type=QuoteStyle, named=True, default=QUOTE_ATTRIBUTES,
                          description='Use quotes to protect arguments in published text')
            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')
            self.setInput('context', type=str, named=True, default=None, hidden=True)
            self.setInput('trigger', type=str, default=None,
                          description="If specified, message publication will be delayed until "
                          "a PUBLish= command is issued with the corresponding trigger")
            self.setInput('message', type=tuple, repeats=(0, None))

        def run (self, _scope, _session, createMissing=False, level=LogLevels, quoted=QuoteStyle, time=None,
                 trigger=None, scope=None, context=None, topic=str, *message):
            topic   = self.parent.topicPath(_scope, scope or context, topic)
            try:
                publish(topic, message, createMissing=createMissing, trigger=trigger, quoting=quoted, level=level)
            except NoSuchTopic:
                raise self.parent.NoSuchTopic(topic=topic)


    class PUBLish_Set (Controlling, Leaf):
        '''Publish pending messages associated with the specified trigger.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False)


        def run (self, ignoreMissing=False, trigger=""):
            count = publishPending(trigger)
            if not ignoreMissing and trigger and not count:
                raise self.parent.NoSuchTrigger(trigger=trigger)


    class SUBScription_Add (Observing, Leaf):
        '''
        Subscribe to the specified topic(s).  After this point, you
        will receive messages that are published on these topics,
        with the specified severity level or above.

        Topic names are case insensitive, and may contain the following wildcard
        characters:
          *      matches anything
          ?      matches any single character
          [seq]  matches any character in "seq"
          [!seq] matches any character not in "seq"

        Alternatively, with the "-regex" option, topics are interpreted as
        Perl-Compatible Regular Expressions (PCREs).

        The following substitutions takes place in the "format" string:
          $topic$       - the topic on which the message was published
          $timestamp$   - timestamp given as seconds since epoch.
                          By default, 3 digits after decimal point is used.

          $localdate$   - Local date in ISO format (YYYY-MM-DD)
          $localtime$   - Local time in ISO format (HH:MM:SS.sss)
          $local$       - Local date/time in ISO format
          $localyear$   - Local year (YYYY)
          $localmonth$  - Local month (MM)
          $localday$    - Local day (DD)
          $localhour$   - Local hour (00-23)
          $localminute$ - Local minute (00-59)
          $localsecond$ - Local second (00-59)

          $utcdate$     - Universal date in ISO format (YYYY-MM-DD)
          $utctime$     - Universal time in ISO format (HH:MM:SS.sss)
          $utc$         - Universal date/time in ISO format
          $utcyear$     - Universal year (YYYY)
          $utcmonth$    - Universal month (MM)
          $utcday$      - Universal day (DD)
          $utchour$     - Universal hour (00-23)
          $utcminute$   - Universal minute (00-59)
          $utcsecond$   - Universal second (00-59)

          $ms$          - Millisecond (000-999)
          $timezone$    - Local time zone (e.g. GMT, PST, PDT)

          $level$       - severity level: Debug, Info, Notice, Warning, Error
          $level#$      - numeric severity level: 0=Debug, 4=Error
          $message$     - Message text

        An optional colon followed by a positive or negative integer can be used
        to specify right- and left- adjustment, and in the case of timestamp,
        number of digits before and after the decimal point:
              $timestamp:.3$ $topic:15$ [$level:1$]: $message$

    Examples:
        # Subscribe to "MyTopic" with timestamps enabled, then publish
        # the message "My Message" on that same topic.

          C: 01 SUBSription+ -timestamp MyTopic
          S: OK 01
          C: 02 PUBLish MyTopic My Message
          S: MESSage MyTopic 1132353184.120 My Message
          S: OK 02

        # Subscribe to "MyTopic" with local date and time plus milliseconds:
          C: 03 SUBScription+ -format='$topic$ $local$ $message$'
          S: OK 03
          C: 04 PUBLish MyTopic "Happy New Year"
          S: MESSage MyTopic 2010-12-31 23:59:59.999 Happy New Year
          S: OK 04
        '''

        _format_default = "$topic$ $message$"
        _format_ts      = "$topic$ $timestamp$ $message$"
        _format_lt      = "$topic$ $localtime$ $message$"


        class FormatConflict (CommandError):
            '''Only one of "-format", "-timestamp" or "-localtime" may be specified'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('future',
                          type=bool, named=True, default=None,
                          description="Also subscribe to any matching topics subsequently created")

            self.setInput('createMissing', named=True, type=bool, default=False,
                          description='Create the topic if it does not already exist')

            self.setInput('ignoreMissing',
                          type=bool, named=True, default=False,
                          description="Do not complain if the specified topic does not exist")

            self.setInput('includeSession',
                          type=bool, named=True, default=None,
                          description='Include own session topic in wildcard masks.')

            self.setInput('timestamp',
                          description='Shorthand for -format="%s"'%(self._format_ts,))

            self.setInput('localtime',
                          description='Shorthand for -format="%s"'%(self._format_lt,))

            self.setInput('format',
                          type=str,
                          default=self._format_default,
                          named=True,
                          description='Message format')

            self.setInput('level',
                          type=LogLevels,
                          named=True,
                          default=0,
                          description='Subscribe to messages with the the specified severity level and above')

            self.setInput('regex',
                          type=bool,
                          named=True,
                          default=False,
                          description='Interpret topics as regular expression patterns')

            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')

            self.setInput('context', type=str, named=True, default=None, hidden=True)

            self.setInput('masks', type=str, repeats=(1, None),
                          description='Message topics.')


        def run (self, _scope, _session, regex=False, future=False, createMissing=False, ignoreMissing=False,
                 includeSession=False,  timestamp=False, localtime=False, format=_format_default,
                 level=LogLevels, scope=None, context=None, *masks):

            if (format != self._format_default) + localtime + timestamp > 1:
                raise self.FormatConflict(timestamp=timestamp, localtime=localtime, format=format)

            if localtime:
                format = self._format_lt
            elif timestamp:
                format = self._format_ts

            for mask in masks:
                mask = self.parent.topicPath(_scope, scope or context, mask)
                owntopic = (mask.lower() == _session.debugTopic.lower())
                _session.unsubscribe(mask)
                try:
                    _session.subscribe(mask, level, format.rstrip("\r\n"),
                                       future=future,
                                       createMissing=createMissing,
                                       ignoreMissing=ignoreMissing,
                                       regex=regex,
                                       includeSession=includeSession or owntopic)
                except NoSuchTopic, e:
                    raise self.parent.NoSuchTopic(topic=e.topic)

                except RegExError, e:
                    raise self.parent.RegExSyntax(pattern=mask)


    class SUBScription_Remove (Observing, Leaf):
        '''Unsubscribe from the specified topic(s)'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignoreMissing',
                          type=bool, named=True, default=False,
                          description="Do not complain if you are not subscribed to the specified topic(s)")

            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')
            self.setInput('context', type=str, named=True, default=None, hidden=True)

            self.setInput('masks', type=str, repeats=(1, None),
                          description='Message topics.')

        def run (self, _scope, _session, ignoreMissing=False, scope=None, context=None, *masks):
            missing = []
            for mask in masks:
                mask = self.parent.topicPath(_scope, scope or context, mask)
                if not _session.unsubscribe(mask):
                    missing.append(mask)

            if missing and not ignoreMissing:
                raise self.parent.NotSubscribed(topic=missing[0])




    class SUBScription_Enumerate (Observing, Leaf):
        '''
        By default, return list of topics to which you are subscribed.

        With the "-future" option, instead return list of masks for
        automatic subscription of subsequently generated topics.
        '''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('future', type=bool, default=False, named=True,
                          description='')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('topic', type=str, repeats=(0, None))


        def run (self, _session, future=False):
            return tuple(_session.getSubscriptions(future=future))




    class HANDler_Add (Controlling, Leaf):

        '''Add a message handler, to be invoked upon publication of a message
        matching the specified topic and filter(s).

        Topic names are case insensitive, and may contain wildcards or
        regular expression syntax; see the "SUBScription+" command for
        details.

        You may specify additional filters on the message contents in
        the same fashion.

          * Any mask or regular expression supplied via the "-filter"
            option is applied to the message text, i.e. any unnamed
            arguments to the "PUBLish" command

          * Any "-<key>=<value>" items in the message contents can be
            matched with a corresponding "-<key>=<mask>" specification.

        Substitutions are performed on the "action" text in the same
        fashion as on the format string of the "SUBScription+"
        command.  For instance, $timestamp$ expands to the timestamp
        of the published message, with millisecond resolution (3
        digits after the decimal point).

        Additionally, named arguments in the published message are
        available via corresponding local variable, i.e. if the
        message contains the item "-mykey=myvalue", the local variable
        "${mykey}" will contain the value "myvalue".


    Examples:
        # Add message handler "ProcessRun" to be invoked whenever a
          message is published on the "Run" topic with the argument
          "-state=Completed":
          > MESSage:HANDler+ ProgressRun Run -state=Completed <<<
                ...
            >>>
        '''

        class HandlerExists (RunError):
            '''Message handler already exists: %(name)r'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('replaceExisting',
                          type=bool,
                          named=True,
                          default=False,
                          description='Replace any existing handler by the same name')

            self.setInput('topic',
                          type=str,
                          named=True,
                          default=None,
                          description='Subscription topic mask')

            self.setInput('regex',
                          type=bool,
                          named=True,
                          default=False,
                          description='Interpret topics and filters as regular expression patterns')

            self.setInput('level',
                          type=LogLevels,
                          named=True,
                          default=0,
                          description="Handle messages with the the specified "
                          "severity level and above")

            self.setInput('ignoreMissing',
                          type=bool,
                          named=True,
                          default=False,
                          description="Do not complain if the specified topic "
                          "does not exist")

            self.setInput('createMissing', named=True, type=bool, default=False,
                          description='Create the topic if it does not already exist')

            self.setInput('future',
                          type=bool,
                          named=True,
                          default=None,
                          description="Also subscribe to any matching topics "
                          "subsequently created")

            self.setInput('preempt',
                          type=bool,
                          named=True,
                          default=False,
                          description='Once the message is processed, do not propagate it to additional subscribers.')

            self.setInput('scope',
                          type=str,
                          named=True,
                          default=None,
                          description="Command scope under which the message topic "
                          "exists")

            self.setInput('context', type=str, named=True, default=None, hidden=True)

            self.setInput('queue',
                          type=int,
                          named=True,
                          default=None,
                          description="Maximum number of messages to be queued "
                          "up in the event that they are received faster than "
                          "they are handled. (Default is unlimited.)")

            self.setInput('filter',
                          type=str,
                          named=True,
                          default=None,
                          description="Mask against which messsage text is "
                          "compared.  Depending on the '-regex' option, "
                          "this is either a shell 'glob' mask or a regular "
                          "expression.")


        def run (self, _session, _scope, handle=str, replaceExisting=False,
                 topic=str, level=LogLevels, regex=False,
                 future=False, preempt=False, createMissing=False, ignoreMissing=False,
                 scope=None, context=None, queue=None, filter=None, action=str, **filters):


            mask   = self.parent.topicPath(_scope, scope or context, topic or handle)

            if scope or context:
                runscope = _scope.find(scope or context)
            else:
                runscope = _scope

            if self.parent.getHandlerSession(handle, ignoreMissing=True):
                if replaceExisting:
                    self.parent.removeHandlerSession(handle, True)
                else:
                    raise self.HandlerExists(name=handle.lower())

            if filter:
                filters[None] = filter

            session = HandlerSession(parent=_session, input=None,
                                     description="Message Handler %r"%(handle,))

            try:
                session.addMessageHandler(handle, mask, future,
                                          createMissing, ignoreMissing,
                                          level, regex, queue,
                                          filters, action, runscope, preempt)

            except NoSuchTopic, e:
                raise self.parent.NoSuchTopic(topic=e.topic)

            except RegExError, e:
                raise self.parent.RegExSyntax(pattern=mask)

            self.parent.addHandlerSession(handle, session)
            self.debug("Added message handler %r on topic %r, filters %s: %s"%(handle, topic or handle, filters, action))



    class HANDler_Remove (Controlling, Leaf):
        '''
        Remove an existing message handler.
        '''

        def run (self, ignoreMissing=False, immediate=False, handle=str):
            self.parent.removeHandlerSession(handle, ignoreMissing, not immediate)



    class HANDler_Query (Observing, Leaf):
        '''
        Return definition of a specific message handler
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('mask',  type=str, named=True, default=None)
            self.addOutput('level', type=LogLevels, named=True, default=None)
            self.addOutput('future', type=bool, named=True, default=None)
            self.addOutput('scope', type=str, named=True, default=None)
            self.addOutput('preempt', type=bool, named=True, default=None)
            self.addOutput('action', type=str, named=True, default=None)
            self.addOutput('filter', type=str, named=True, default=None)
            self.addOutput('filters', type=tuple, named=False, repeats=(0, None))

        def run (self, ignoreMissing=False, handle=str):
            session = self.parent.getHandlerSession(handle, ignoreMissing)
            if session:
                mask, level, rxfilters, action, scope, preempt = session.getHandlerRecord()

                commandPath = scope.commandPath()
                tagfilters = []
                textfilter = None
                for opt, rx in rxfilters.items():
                    rxmask = rx.pattern
                    if opt is None:
                        textfilter = rxmask
                    else:
                        tagfilters.append((opt, rxmask))

                return (mask, level, True, commandPath, action, textfilter) + tuple(tagfilters)



    class HANDler_Enumerate (Observing, Leaf):
        '''
        Return a list of currently existing message handlers.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('handle', type=str, repeats=(0, None))

        def run (self):
            return tuple(self.parent.handlerSessions)




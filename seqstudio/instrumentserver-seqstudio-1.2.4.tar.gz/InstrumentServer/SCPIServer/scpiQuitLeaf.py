########################################################################
### FILE:	scpiQuitLeaf.py
### PURPOSE:	QUIT command
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.   All rights reserved.
########################################################################

from scpiBase       import Hidden
from scpiBranch     import Branch
from scpiLeaf       import Leaf, Controlling, Administrative, Public
from scpiSession    import SYNC
from scpiExceptions import RunError
from subscription   import info
from sys            import exit


class QUIT (Public, Leaf):
    """
    Shut down the current socket connection.
    """

    def run (self, _session):
        _session.close()


class SHUTdown (Hidden, Administrative, Leaf):
    '''
    Shut down the instrument controller.
    '''

    def run (self):
        exit(0)


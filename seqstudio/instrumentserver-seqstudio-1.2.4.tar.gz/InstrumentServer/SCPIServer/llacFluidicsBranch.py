########################################################################
### FILE:       llacFluidicsBranch.py
### PURPOSE:    Control of LLAC-based fluidics boards
### AUTHORS:    Tor Slettnes
###
### Copyrights (C) 2010-2015 Life Technologies.  All rights reserved.
########################################################################

from scpiBranch        import branchTypes
from scpiFullBranch    import FullBranch
#from llacMotionBase    import LLACMotionBase, LLACMotionAxis
from llacMotionBranch  import LinearMotionAxis, LLACMotionControlBranch
from locationBase      import LocationSystem
from fluidicsBase      import VerticalAxis, Syringe, Robot, FluidicsBase


class LLACLateralAxis (LinearMotionAxis):
    pass

class LLACVerticalAxis (LinearMotionAxis, VerticalAxis):
    pass


class LLACSyringeAxis (LinearMotionAxis, Syringe):
    '''Syringe Axis'''

    def __init__ (self, *args, **kwargs):
        LinearMotionAxis.__init__(self, *args, **kwargs)
        Syringe.init(self)


    def getCurrentVolume (self):
        steppos = self.getRawPosition()

        try:
            os, ostarget = self.overshoot
        except TypeError:
            pass
        else:
            if steppos < ostarget:
                steppos = min(steppos + os, ostarget)
            else:
                steppos = min(steppos - os, ostarget)

        return self.fromRawPosition(steppos, steps=False)


class LLACRobot (LLACMotionControlBranch, Robot):
    '''Robotic Arm'''

    axisTypes = {
        None      : LLACLateralAxis,
        'lateral' : LLACLateralAxis,
        'vertical': LLACVerticalAxis,
        'syringe' : LLACSyringeAxis
        }



    def __init__ (self, *args, **kwargs):
        LLACMotionControlBranch.__init__(self, *args, **kwargs)
        LocationSystem.init(self)
        Robot.init(self)


    class POSition_Query (LLACMotionControlBranch.POSition_Query):
        '''
        Return the axis coordinates of the current position
        '''


        def declareOutputs (self):
            LLACMotionControlBranch.POSition_Query.declareOutputs(self)
            self.addOutput('locations', type=str, named=True, default=None,
                           description="Current location name, if any")


        def run (self, steps=False, absolute=False, reference=None, cached=False, location=False, *axes):
            axes = self.parent.getAxisSelection(axes) or self.getSupportedAxes()
            rawposition = self.parent.getRawPosition(axes=axes, cached=cached)
            poslist  = [ (axis.name,
                          axis.fromRawPosition(pos, steps=steps, absolute=absolute, reference=reference))
                         for (axis, pos) in rawposition.items() ]

            if location:
                locations = self.parent.getLocationsOfCoordinates(rawposition, axes=axes)
                names = ','.join([self.parent.locationName(context, location)
                                  for (context, location) in locations ])
                poslist.append(('locations', names))

            return dict(poslist)


class LLACFluidicsBranch (FluidicsBase):
    '''
    Fluidics Branch
    '''

    robotTypes = { None        : LLACRobot,
                   'LLACRobot' : LLACRobot }



branchTypes['Fluidics'] = LLACFluidicsBranch

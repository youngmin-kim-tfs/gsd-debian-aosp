########################################################################
### FILE:	rfidTagBase.py
### PURPOSE:	Interface to ThermoFisher consumable tags
### HISTORY:
###  2016-11-20 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from thermoTag           import ThermoTag, ThermoTable, TagError
from scpiBranch          import branchTypes
from scpiFullBranch      import FullBranch
from scpiLeaf            import Leaf, Observing, Controlling
from scpiParameter       import autoType
from scpiExceptions      import RunError
from scpiConfigBase      import ConfigBase
from config              import getConfigPath

import os.path, threading

ParameterType = {
    ThermoTable.UINT     : abs,
    ThermoTable.INT      : int, 
    ThermoTable.FLOAT    : float,
    ThermoTable.STRING   : str
}


class TagLeaf (Leaf):
    class TagError (RunError):
        '''Tag Error: %(message)s'''

    def invoke (self, *args, **kwargs):
        try:
            return Leaf.invoke(self, *args, **kwargs)
        except TagError, e:
            raise self.TagError(message=e)


class RFIDTagBranch (ThermoTag, FullBranch):
    '''Commands to read/write ThermoFisher RFID Tags'''

    class NoTags (RunError):
        '''No tags discovered'''

    class NoSuchTag (RunError):
        '''Cannot select tag %(index)s, only %(discovered)s tag(s) available.'''

    class NoSuchKey (RunError):
        '''Unknown entry key %(key)r'''

    class DuplicateKey (RunError):
        '''The entry key %(key)r already exists'''

    class NotInTable (RunError):
        '''This tag does not contain a %(key)r entry'''


    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        ThermoTag.__init__(self)
        RFIDTagBranch.init(self)

    def init (self):
        self.entryhooks = []
        self.dirty = False
        self._mutex = threading.Lock()
        
    def discover (self):
        raise NotImplementedError

    def acquireMutex (self):
        if not self._mutex.acquire(0):
            self.debug("Waiting for other tag operation to complete")
            self._mutex.acquire()

        self.debug("Acquired RFID tag lock")
        

    def releaseMutex (self):
        self.debug("Releasing RFID tag lock")
        self._mutex.release()

    def startRead (self, tagindex):
        self.acquireMutex()

    def finishRead (self, tagindex):
        self.releaseMutex()

    def startWrite (self, tagindex):
        self.acquireMutex()

    def finishWrite (self, tagindex):
        self.releaseMutex()

    def getCapacity (self, tagindex):
        return 888

    def selectTag (self, index):
        discovered = self.discover()
        if not discovered:
            raise self.NoTags()
            
        elif not 0 < index <= discovered:
            raise self.NoSuchTag(index=index, discovered=discovered)


    def addEntryHook (self, addmethod, removemethod):
        self.entryhooks.append((addmethod, removemethod))
        for entry in self.table.getKnownTypes():
            addmethod(*entry)


    def addEntryType (self, entrykey, entrycode, datatype, datasize, replaceExisting=False):
        try:
            self.table.getKnownType(entrykey)
        except TagError:
            pass
        else:
            if replaceExisting:
                self.removeEntryType(entrykey, ignoreMissing=True)
            else:
                raise self.DuplicateKey(key=entrykey)

        entry = (entrykey, entrycode, datatype, datasize)
        self.table.addKnownType(*entry)
        for addmethod, removemethod in self.entryhooks:
            addmethod(*entry)


    def removeEntryType (self, entrykey, ignoreMissing=False):
        entry = self.table.popKnownType(entrykey)
        if entry:
            for addmethod, removemethod in self.entryhooks:
                removemethod(*entry)
        elif not ignoreMissing:
            raise self.NoSuchKey(key=entrykey)


    def dump (self, numeric=True, text=True, nonprint="."):
        output  = []

        for b16 in range(0, len(self.tagdata), 16):
            parts = []
            if numeric and text:
                parts.append('%04X:  '%(b16,))

            if numeric:
                chunks = []
                for b4 in range(b16, b16+16, 4):
                    data     = self.tagdata[b4:b4+4]
                    numbers  = " ".join(["%02X"%byte for byte in data])
                    chunks.append(numbers)
                
                parts.append('  '.join(chunks).ljust(52))

            if text:
                parts.append(''.join([(nonprint, c)[' ' <= c <= '~']
                                      for c in str(self.tagdata[b16:b16+16])]))

            if numeric:
                parts.append('\n')

            output.append(''.join(parts))

        return output
        

    class STRucture_Load (Controlling, ConfigBase, TagLeaf):
        '''Load ThermoTag data structures from the specified configuration file/section'''

        class StructureExists (RunError):
            "Data structure %(name)r is already defined"

        class NoSuchStructure (RunError):
            "Data structure %(name)r is not defined"

        class MismatchedSizes (RunError):
            "Mismatched number of sizes: %(numTypes)d data types, %(numSizes)d sizes"

            
        def run (self, filename=str, section=str):
            types = dict([(name, name) for name in ThermoTable.FieldTypes])
            structs = self.getConfigItems(filename, section, literal=True, valuetype=(tuple, list), vars=types)
            self.parent.table.structures.update(structs)

                

    class STRucture_Add (Controlling, TagLeaf):
        '''Define a new ThermoTag data structure'''

        class StructureExists (RunError):
            "Data structure %(name)r is already defined"

        class NoSuchStructure (RunError):
            "Data structure %(name)r is not defined"

        class MismatchedSizes (RunError):
            "Mismatched number of sizes: %(numTypes)d data types, %(numSizes)d sizes"


        def declareInputs (self):
            TagLeaf.declareInputs(self)
            self.setInput('types', type=ThermoTable.FieldTypes, split=(",", 1, None))
            self.setInput('sizes', type=abs, split=(",", 1, None))
            
        def run (self, replaceExisting=False, repeats=False, name=str, types=ThermoTable.FieldTypes, sizes=abs):
            if not replaceExisting and name.lower() in self.parent.table.structures:
                raise self.StructureExists(name=name)
            
            if len(types) != len(sizes):
                raise self.MismatchedSizes(numTypes=len(types), numSizes=len(sizes))

            typenames = [ ThermoTable.FieldTypes[t] for t in types ]
            s = tuple(zip(typenames, sizes))

            if repeats:
                s = [s]

            self.parent.table.structures[name] = s
                

    class STRucture_Remove (Controlling, TagLeaf):
        '''Remove an existing ThermoTag data structure'''

        def run (self, ignoreMissing=False, name=str):
            try:
                self.parent.table.structures[name]
            except KeyError:
                if not ignoreMissing:
                    raise self.NoSuchStructure(name=name)


    class STRucture_Query (Observing, TagLeaf):
        '''Return data types and sizes of an existing ThermoTag data structure.'''

        def declareOutputs (self):
            TagLeaf.declareOutputs(self)
            self.addOutput('repeats', type=bool, named=True, default=False)
            self.addOutput('types', type=ThermoTable.FieldTypes, split=(",", 1, None), named=True, default=None)
            self.addOutput('sizes', type=abs, split=(",", 1, None), named=True, default=None)

        def run (self, ignoreMissing=False, name=str):
            try:
                s = self.parent.table.structures[name]
            except KeyError:
                if not ignoreMissing:
                    raise self.NoSuchStructure(name=name)
            else:
                repeats = isinstance(s, list)
                if repeats:
                    s = s[0]

                return (repeats,)+tuple(zip(*s))
                  

    class STRucture_Enumerate (Observing, TagLeaf):
        '''Return names of existing ThermoTag data structures'''

        def declareOutputs (self):
            TagLeaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self):
            return tuple(sorted(self.parent.table.structures))


    class ENTRy_Add (Controlling, TagLeaf):
        '''Define a new tag entry'''

        def declareInputs (self):
            TagLeaf.declareInputs(self)
            self.setInput('key', type=str)
            self.setInput('code', type=hex, range=(0x00, 0xFF))
            self.setInput('type', type=str)
            self.setInput('length', type=int, named=True, default=None, range=(0x00, 0xFF))

        def run (self, replaceExisting=False, key=str, code=hex, type=str, length=None):
            self.parent.addEntryType(key, code, type, length, replaceExisting=replaceExisting)


    class ENTRy_Remove (Controlling, TagLeaf):
        '''Remove an existing entry type'''

        def run (self, ignoreMissing=False, key=str):
            self.parent.removeEntryType(key, ignoreMissing=ignoreMissing)


    class ENTRy_Enumerate (Observing, TagLeaf):
        '''Enumerate known entry types'''

        def declareOutputs(self):
            TagLeaf.declareOutputs(self)
            self.addOutput('key', type=str, repeats=(0, None))

        def run (self):
            return tuple([ key for (key, code, type, size) in self.parent.table.getKnownTypes() ])


    class ENTRy_Query (Observing, TagLeaf):
        '''Return entry code, data type and data size for the specified tag key'''

        def declareOutputs (self):
            TagLeaf.declareOutputs(self)
            self.addOutput('code', type=hex, format="0x%02X", named=True, default=None)
            self.addOutput('type', type=self.parent.table.FieldTypes, named=True, default=None)
            self.addOutput('size', type=int, named=True, default=None)

        def run (self, ignoreMissing=False, key=str):
            try:
                return self.parent.table.getKnownType(key)[1:]
            except TagError:
                if not ignoreMissing:
                    raise self.parent.NoSuchKey(key=key)
                

    class ENTRy_Load (Controlling, ConfigBase, TagLeaf):
        '''Load entry types from the specified configuration file'''

        class InvalidEntry (RunError):
            '''Entry %(name)r specification %(spec)r is invalid'''

        def run (self, filename=str, section=str):
            types = dict([(name, name) for name in ThermoTable.FieldTypes])
            types.update([(name, name) for name in self.parent.table.structures])
            
            entries = self.getConfigItems(filename, section, literal=True, valuetype=tuple, vars=types)

            for key, value in entries:
                try:
                    entrycode, datatype, datalength = value
                except ValueError:
                    try:
                        entrycode, datatype = value
                        datalength = None
                    except ValueError, e:
                        raise self.InvalidEntry(key, value)

                self.parent.addEntryType(key, entrycode, datatype, datalength, replaceExisting=True)


    class DETect_Query (Observing, TagLeaf):
        '''Discover nearby RFID/NFC tags, and return the number found'''

        def declareOutputs(self):
            TagLeaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self):
            return self.parent.discover()


    class DIRTy_Query (Observing, TagLeaf):
        '''Return True if the tag data has been modified since last read/write, False otherwise.'''

        def declareOutputs(self):
            TagLeaf.declareOutputs(self)
            self.addOutput('dirty', type=bool)

        def run (self):
            return self.parent.dirty


    class RAW_Query (Observing, Leaf):
        '''Return the raw tag data from the most recent read.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('numeric', type=bool, named=True, default=False,
                          description='Return the contents only in numeric form, '
                          'with each byte represented as two hexadecimal digits (00 - FF)')
            self.setInput('text', type=bool, named=True, default=False,
                          description='Return the contents as a text string, '
                          'with non-printable characters represented as specified '
                          'with the "-nonprint" option.')
            self.setInput('nonprint', type=str, named=True, default='.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('values', type=list, format="%s", default=None)

        def run (self, numeric=False, text=False, nonprint="."):
            return self.parent.dump(numeric=numeric or not text,
                                    text=text or not numeric,
                                    nonprint=".")
            

    class NDEF_Query (Observing, Leaf):
        '''Return the NDEF structure of the most recent read.'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('tnf', type=int, named=True, default=None)
            self.addOutput('type', type=str, named=True, default=None)
            self.addOutput('id', type=int, named=True, default=None)
            self.addOutput('payload', type=int, format="%02X", range=(0x00, 0xFF), repeats=(0, None))

        def run (self):
            return (self.parent.tnf, self.parent.recordtype, self.parent.recordid) + tuple(self.parent.payload)



    class DATA_Query (Observing, TagLeaf):
        '''Return data from the most recent tag read'''

        def declareInputs (self):
            TagLeaf.declareInputs(self)
            self.setInput('default', type=str, named=True, default='')
            self.setInput('named', type=bool, named=True, default=False)

            self.entryCodes = {}
            self.parent.addEntryHook(self.addInputEntry, self.removeInputEntry)

        def addInputEntry (self, key, code, type, length):
            self.entryCodes[key] = code
            self.setInput('items', type=self.entryCodes)

        def removeInputEntry (self, key, code, type, length):
            del self.entryCodes[key]
            self.setInput('items', type=self.entryCodes)

        def declareOutputs (self):
            TagLeaf.declareOutputs(self)
            self.addOutput('item', type=tuple, repeats=(0, None))


        def convertToString (self, value):
            if isinstance(value, list):
                return ';'.join([self.convertToString(v) for v in value])

            elif isinstance(value, tuple):
                return ','.join([self.convertToString(v) for v in value])

            else:
                return str(value)

        def run (self, default='', named=False, *items):
            return tuple(self.query(items, default, named))

        def query (self, items, default='', named=False):
            response  = []
            if not items:
                named = True

            for code in items or sorted(self.parent.table):
                if not named:
                    key   = None
                    value = self.parent.table.get(code, default)

                elif code in self.parent.table.knownEntryTypes:
                    key, datatype, datasize = self.parent.table.knownEntryTypes[code]
                    value = self.parent.table.get(code)

                else:
                    key = "unknown-0x%02X"%(code,)
                    value = self.parent.table.get(code)

                if value is not None:
                    response.append((key, self.convertToString(value)))

            return response


    class DATA_Set (Controlling, TagLeaf):
        '''Set data to be written into the tag.'''

        def clearInputs (self):
            TagLeaf.clearInputs(self)
            self.tagcodes   = []

        def declareInputs (self):
            self.clearInputs()
            self.parent.addEntryHook(self.addEntryType, self.removeEntryType)

        def addEntryType (self, key, code, type, length):
            if type in ParameterType:
                self.addInput(key, type=ParameterType[type], named=True, default=None)
                if length and type in self.parent.table.ValueRanges:
                    self.setInput(key, range=self.parent.table.ValueRanges[type](length))

            else:
                structure = self.parent.table.structures[type]
                split     = (None, ";")[isinstance(structure, list)]
                self.addInput(key, type=str, split=split, named=True, default=None)

            self.tagcodes.append(code)

        def removeEntryType (self, key, code, type, length):
            self.tagcodes.remove(code)
            self.removeInput(key)

        def convertToStructure (self, value):
            if isinstance(value, list):
                values = []
                for item in value:
                    items = [ autoType(v) for v in item.split(",") ]
                    values.append(tuple(items))
                return values
            else:
                return value

        def run (self, *values):
            self.setdata(values)

        def setdata (self, values):
            for code, value in zip(self.tagcodes, values):
                if value is not None:
                    self.parent.table[code] = self.convertToStructure(value)
                    self.parent.dirty = True
                    self.parent.packTable()


    class DATA_Remove (Controlling, TagLeaf):
        '''Clear the specified data items from the tag data.'''

        def declareInputs (self):
            TagLeaf.declareInputs(self)
            self.setInput('ignoreMissing', named=True)
            self.entryCodes = {}
            self.parent.addEntryHook(self.addEntryType, self.removeEntryType)

        def addEntryType (self, entryKey, entryCode, dataType, dataSize):
            self.entryCodes[entryKey] = entryCode
            self.setInput('entry', type=self.entryCodes)

        def removeEntryType (self, entryKey, entryCode, dataType, dataSize):
            del self.entryCodes[entryKey]
            self.setInput('entry', type=self.entryCodes)

        def run (self, ignoreMissing=False, *entry):
            for code in entry:
                try:
                    del self.parent.table[code]
                    self.parent.dirty = True
                except KeyError:
                    if not ignoreMissing:
                        _key, _type, _length = self.parent.table.knownEntryTypes[code]
                        raise self.parent.NotInTable(key=_key, code=code)


    class DATA_Clear (Controlling, TagLeaf):
        '''Clear all data from the table.'''

        def run (self, ignoreMissing=False):
            self.parent.table.clear()


    class DATA_Exists (Observing, TagLeaf):
        '''Return data from the most recent tag read'''

        def declareInputs (self):
            TagLeaf.declareInputs(self)
            self.entryCodes = {}
            self.setInput('items', repeats=(1, None))
            self.parent.addEntryHook(self.addInputEntry, self.removeInputEntry)

        def addInputEntry (self, key, code, type, length):
            self.entryCodes[key] = code
            self.setInput('items', type=self.entryCodes)

        def removeInputEntry (self, key, code, type, length):
            del self.entryCodes[key]
            self.setInput('items', type=self.entryCodes)

        def declareOutputs (self):
            TagLeaf.declareOutputs(self)
            self.addOutput('exists', type=bool)

        def run (self, *items):
            for code in items:
                if not code in self.parent.table:
                    return False
            else:
                return True


    class SIZe_Query (Observing, TagLeaf):
        '''Return the size of the tag data'''

        def declareOutputs (self):
            TagLeaf.declareOutputs(self)
            self.addOutput('size', type=int)

        def run (self):
            return len(self.parent.tagdata)
        

    class CAPacity_Query (Observing, Leaf):
        '''Return the capacity of the RFID tag'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('capacity', type=int)

        def run (self, tagindex=1):
            return self.parent.getCapacity(tagindex)
        

    class READ_Query (DATA_Query):
        '''Read table data from a ThermoFisher consumable NFC tag'''

        def declareInputs (self):
            self.parent.DATA_Query.declareInputs(self)
            self.setInput('ignoreEmpty', type=bool, named=True, default=False,
                          description='Do not complain if tag is empty')
            self.setInput('ignoreMismatch', type=bool, named=True, default=False,
                          description='Do not complain tag contains unrecognized data')
            self.setInput('tagindex', type=int, named=True, default=1)

        def run (self, ignoreEmpty=False, ignoreMismatch=False, tagindex=1, default='', named=False, *items):
            try:
                table = self.parent.readTable(tagindex, ignoreEmpty=ignoreEmpty, ignoreMismatch=ignoreMismatch)
            except TagError, e:
                self.debug("Failed to read ThermoTag structure: [%s] %s\n    %s"%
                           (e.__class__.__name__, e, "    ".join(self.parent.dump())))
                raise

            if table:
                self.debug("Read table from tag #%d: %s"%
                           (tagindex, " ".join(["-%s=%r"%item for item in table.namedItems()])))
            else:
                self.debug("Read empty table from tag #%d"%(tagindex))

            self.parent.dirty = False
            return tuple(self.query(items, default, named))



    class WRITe (DATA_Set):
        '''Write ThermoFisher consumable data into an NFC tag'''

        class TooMuchData (RunError):
            '''Data size %(size)s exceeds capacity %(capacity)s'''
            

        def declareInputs (self):
            self.clearInputs()
            self.addInput('tagindex', type=int, named=True, default=1)
            self.parent.addEntryHook(self.addEntryType, self.removeEntryType)

        def run (self, tagindex=1, *values):
            self.setdata(values)

            capacity = self.parent.getCapacity(tagindex)
            if len(self.parent.tagdata) > capacity:
                raise self.TooMuchData(size=len(self.parent.tagdata), capacity=capacity)
                
            self.debug("Writing table to tag #%d: %s"%
                       (tagindex, " ".join(["-%s=%r"%item for item in self.parent.table.namedItems()])))
            self.parent.writeTable(tagindex)
            self.parent.dirty = False



class FileTagBranch (RFIDTagBranch):
    '''Thermo Tag table saved to file on disk'''
    
    def discover (self):
        return 1

    def startRead (self, tagindex):
        '''Prepare to read a tag'''
        self.rawdata = bytearray()

        for folder in getConfigPath():
            path = os.path.join(folder, self.name.lower() + '.bin')
            if os.path.exists(path):
                self.rawdata.extend(open(path, 'rb').read())
                break

        RFIDTagBranch.startRead(self, tagindex)


    def readBytes (self, start, stop):
        '''Return the next <count> or more available bytes, starting at <address>.'''
        return self.rawdata[start:stop]


    def writeBytes (self, address, bytes):
        '''Write <bytes> bytes, starting at address <address>'''

        path = os.path.join(getConfigPath()[0], self.name.lower() + '.bin')
        fp   = open(path, 'wb')
        if address:
            fp.write('\x00'*address)
        fp.write(bytes)
        fp.close()



branchTypes['FileTag'] = FileTagBranch

########################################################################
### FILE:	scpiTopics.py
### PURPOSE:	Help Topic Class
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase       import Base
from scpiLeaf       import Leaf, Public
from scpiExceptions import RunError


########################################################################
### "Topic" class definition
###
### A help topic is not a standard SCPI command, but an item which
### shows up in "HELP?" and "XMLHelp?" command outputs.   A sample
### topic declaration would be:
###
### class Syntax (HelpTopic):
###     """
###     <Description of command syntax>
###     """


class HelpTopic (Public, Leaf):

    class UsageError (RunError):
        'Not a command; use \'HELP? %(topic)s\' instead.'

    def run (self, _command):
        raise self.UsageError(topic=_command)

    def getSyntax (self, margin, columns, defaults=None):
        return Base.getSyntax(self, margin, columns, defaults=None)




class OVERVIEW (HelpTopic):
    '''
    This command interface provides control of the operation of this
    instrument.

    For a list of available commands and help topics, use "HELP?".
    For info on a specific command or help topic, use "HELP? <command>".
    For more information on using the help system, use "HELP? HELP?".

    The following help topics are available:

      COMMANDS       - structure of the command language
      REPLIES        - format of responses from this server
      ARGUMENTS      - syntax for arguments passed to a command
      SUBSTITUTIONS  - how the command line is expanded prior to invocation
      QUOTATIONS     - how to prevent substitution of literal text
      MACROS         - how to group several commands into macros
      BOOLEANS       - how boolean values are interpreted
      FILESYSTEM     - how file paths are specified
      STATES         - uniform interface to instrument conditions 

    '''
    



class COMMANDS (HelpTopic):
    '''
    This instrument implements a command set that is loosely based on
    SCPI, "Standard Commands for Programmable Instruments", a product
    of the SCPI Consortium (http://www.scpiconsortium.org/).

    Commands are organized hierarchically in a "tree", where a given
    command is made up of one or more colon-separated elements.
    Each element minus the last is called a "branch", and the last one
    is a "leaf":

        BRANch:SUBBranch:LEAF

    A branch is a subdivision of the command namespace, and functions
    mainly as a container for related subcommands.  It may represent
    a particular instrument subsystem, or a particular aspect of a
    subsystem.

    A leaf is the last and operative element of a command.

    Traditionally, each command element is capitalized as follows:
      - The first three letters are capitalized
      - The fourth letter is capitalized if it is a consonant.
      - Remaining letters are in lowercase.

    This implementation does NOT enforce this convention.  For
    instance, the following is allowed here:

        Branch:SubBranch:Leaf

    However, capitalization still matters.  A given command element
    may be addressed in three different ways:

      - By its full name (e.g. "SubBranch")
      - By removing all lowercase letters ("SB")
      - By removing INTERMEDIATE lowercase letters, but leaving
        the TRAILING ones intact ("SBranch")

    Therefore, all of the following are equivalent:

        Branch:SubBranch:Leaf    (The full command)
        Branch:SBranch:L         (Partially abbreviated)
        B:SB:L                   (Fully abbreviated)

    The following, however, are NOT equivalent with the above:

        Branch:SUBBranch:Leaf    (Wrong capitalization)
        Branch:SubB:Leaf         (Invalid abbreviation of "SubBranch")
        Branch:SB:Lea            (Invalid abbreviation of "Leaf")


    A command (leaf) name may end with a question mark, indicating that
    this is a query - i.e. a command that does not perform any control,
    but that has a return value:

        BRANch:...:LEAF?

    '''


class REPLIES (HelpTopic):
    '''
    For every command that is sent to the SCPI server, there will be
    at least one reply.  Each reply has these elements, each separated
    by a single space (" ") character:

      - A status word: "OK", "NEXT", or "ERRor".
      - Either of the following to help match the reply to the original command:
         * If the original command started with an index, that same index
         * Otherwise, the original command text, including any arguments
      - Any reply value or error message returned by the server, if any.

    The meaning of the status words are as follows:

      OK    means that the command was successfully executed.
            This word is followed by the command text, and then
            any reply value from the command.

      NEXT  means that the command was successfully parsed, but that
            it is executing asynchronously.  Once the command has
            completed, an "OK" or "ERRor" response is given.

      ERRor means that the command could not be executed.
            The error response consists of a unique identifier
            enclosed in square brackets ([]), followed by a sequence
            of keys and values specific to this error.

    If the command text started with an index (see: "COMMANDS"), that
    same index is included in the reply.  The idea is to make it
    easier for client software to match responses with original
    replies - especially if there are asynchronous commands pending.

Examples:
    * Sample dialogue between a client (C) and this server (S):

        C: TBC:SETTing 30
        S: NEXT TBC:SETTing 30
        C: FOO:BAR
        S: ERRor FOO:BAR [UnknownCommand] -command=FOO
        S: OK TBC:SETTing 30

      The client issues an asynchronous command ("TIMer 30"), and
      receives "NEXT" response.  While this command is executing
      asynchronously, the client issues the invalid command "FOO:BAR",
      and receives an ERRor response.  Finally, once the original
      "TIMer" command completes, the server issues the "OK" response.

    * The same dialogue, but this time the client prepends a numeric
      index prior to each command:

        C: 10 TBC:SETTing 30
        S: NEXT 10
        C: 20 FOO:BAR
        S: ERRor 20 [UnknownCommand] -command=FOO
        S: OK 10
    '''




class STATES (HelpTopic):
    '''
    The "State:" branch provides a functionality and a unified command
    interface to access information about various instrument states,
    such as initialization status, doors, interlocks, motion
    readiness, etc.  It also includes information about any errors
    encountered during state transitions, e.g. while initializing the
    instrument.

    A "State" is a logical construct which:

    * May have one of three values: True, False, or Error.

    * May have dependencies on other states -- one state may require
      or conflict with another.  Where state B depends on state A,
      state B is said to be a descendant of state A, whereas state A
      is an ancestor of state B.

    * May have input triggers associated with transitions to each of
      these states - for instance, to initalize motion systems once
      the front door is locked.
    
    The following is a partial list of commands that can be used to
    observe and manage the State subsystem:

    State:NOTify= <topic>   (Commonly: "State")
      Start publishing information about state changes on <topic>.
      Clients can then subscribe to this topic to be notified of updates.


    State:NEW <state> [<initialValue>] [-requires=...] [-conflicts=...] [-nick=...]
      Create a new state.

    State:SETTing*                            (Commonly aliased to "State*")
      List all currently managed states.
    
    State:SETTing? [-<options>...]  <state>   (Commonly aliased to "State?")
      List the current value of the specified state; options exist to
      also list current values of ancestor/descendant states.
      
    State:SETTing <state> <value>             (Commonly aliased to "State=")
      Set the value of the associated state to value (True/False).
      If the state has ancestors, this may temporarily break any
      dependency/conflict with those states.

    State:HOOK+ [-edge={set|clear|error}] <states> <handle> <commandblock>
      Add a hookto the specified state transition; whenever the state
      value changes to True, False or Error, respectively, the specified
      commandblock is executed.

    State:HOOK* [-edge={set|clear|error}] <state>
      List hook (handles) associated with the specified state transition.

    State:HOOK? <state> <handle>
      Return the command block that is associated with the specified
      hook, i.e. that gets executed once the associated state
      transition takes place.

    State:EXISTS? <state>
      Return True or False, depending on whether the specified state exists.

    State:DEPendency+ <State> [-requires=<ancestor> | -conflicts=<ancestor>]
      Add a new dependency between one state and another.

    State:DEPendency* [-ancestors] [-descendants] [-recursive]
                      [-required] [-conflicts] <state>

      List dependencies associated with the specified state. By
      default, all ancestor states (both conflicting and required) are
      listed.

    State:CULPrits? <state>
      Return the names of ancestor states that are currently
      preventing this state from being set. This includes required
      states that are not set as well as conflicting states that are
      set, or any state in error.

    State:ERRor? state
      Return any error associated with this state, or "-" for no error.
      Additional options are available; see documentation.


    State:ERRor= <state> <errorID> <message>
      Set an error state on this state. Useful for simulation/debugging.


Examples:

    * Create states corresponding to firmware/board availability, and
      nicknames corresponding to their LLAC device IDs:

      > State:NEW TBC
      > State:NEW MCB -nick=MMCB,DMCB

    * Create descendant states:

      > State:NEW Instrument:Online -requires=MCB,TBC
      > State:NEW ThermalControl:Ready -requires=TBC
      > State:NEW Stage:Ready -requires=MCB
      > State:NEW FrontDoor:Locked
      > State:NEW Instrument:Initialized -requires=ThermalControl:Ready,Stage:Ready,FrontDoor:Locked

    * Create transition hooks:

      > State:HOOK+ -states=Stage:Ready -edge=Set HomeStage <<<
      >    STAGE:HOME
      > >>>

      > State:HOOK+ -states=FrontDoor:Locked -edge=Set LockDoor     "(code to lock door)"
      > State:HOOK+ -states=FrontDoor:Locked -edge=Clear UnLockDoor "(code to unlock door)"

      > State:HOOK+ -states=Instrument:Initialized -edge=Set GreenLED    "(turn on green LED)"
      > State:HOOK+ -states=Instrument:Initialized -edge=Clear YellowLED "(turn on yellow LED)"
      > State:HOOK+ -states=Instrument:Initialized -edge=Error RedLED    "(turn on red LED)"

    * Determine why instrument is not initialized:
      > State:CULPRITS? Instrument:Initialized
      OK State:CULPRITS? Instrument:Initialized -FrontDoor:Locked=False
    
    '''
        

    
class ARGUMENTS (HelpTopic):
    '''

    Each command expects zero or more arguments, separated by
    whitespace:

        BRANch:SUBBranch:LEAF <argument> ...

    An argument is either "named" or "positional" (a.k.a. "unnamed").
      * Named arguments are supplied in the form "-name=value", and
        can occur anywhere in the argument list.
      * Positional arguments is supplied as just the value by itself,
        and must appear in the correct order following the command
        header.
        
    
    A argument may be optional.  Positional/optional arguments always
    appear after positional/required arguments.

    Each argument is converted to one of the following value types,
    as expected by the command:

      * An integer value, consisting of:
          - an optional "+" or "-" sign, followed by
          - one or more digits 0-9
        OR:
          - prefix "0x", indicating a hexadecimal number
          - one or more hexadecimal digits 0-F

      * A real number, consisting of:
          - an optional "+" or "-" sign
          - one or more digits 0-9
          - an optional decimal point ".", followed by
            additional digits 0-9
          - an optional "e" (mantissa/exponent separator), followed
            by an optional "+" or "-" sign, followed by additional
            digits 0-9

      * A boolean indicator (flag), consisting of
          - one of "True", "Yes", "On" or a non-zero value
        OR:
          - one of "False", "No", "Off", or a zero value

        For named boolean arguments, the value is optional.  If missing,
        "True" is assumed.  Thus, "-arg" is the same as "-arg=True"

      * An enumerated value, consisting of one of several alternate
        keywords.

      * A text string, consisting of one or more characters.

    Normally, argument values supplied are expanded according to various
    substitution rules before being passed to the command.  For instance,
    single or double quote characters can be used to group arguments,
    "$0" is replaced with the return value from the prior command, etc. 
    For more information, see: "SUBSTITUTIONS".

    To prevent expansion on a given argument, it can be enclosed
    in a pair of matching quotation tags:  <quote>argument</quote>.
    This is particularly useful when supplying nested command expressions,
    such as when defining a macro or a sequence of subcommands for
    commands like RUN/IF/UNLess/WHILe/UNTil/REPeat/SCHedule.
    Such expressions may consist of several lines of commands, and should
    normally not be expanded until executed.   For more information,
    see "QUOTATIONS".


Examples:
    * The following command has one named enumerated argument and one
      positional string argument:
      > FILe:READ? -encoding=base64 images/scan1-filter1.tiff
        
    '''




class SUBSTITUTIONS (HelpTopic):
    '''.

    Each element of a command line (i.e. both the command header and
    each argument) is subject to the following substitutions:

    $1, $2, ..., ${1}, ${2}, ...
        is replaced by the corresponding output argument from the
        previous command

    $0 or ${0}
        is replaced by the entire reply from the previous commmand, as
        a single unquoted string.

    $@ or ${@} 
        is replaced by the entire reply from the previous command,
        with special characters quoted.

    ${VAR}
        is replaced by the contents of the local, global or persistent
        variable "VAR" (in that search order).  Parts of multi-part
        variables are separated by space.

    ${VAR[INDEX]}
        is replaced by the contents of part #INDEX of the variable
        "VAR", starting from 0. A negative INDEX referes to the
        corresponding part from the end.

    ${DICT[KEY]}
        is replaced by the contents of the element named "KEY" of the
        dictionary "DICT".

    ${DICT}
        is replaced by all keys of the dictionary "DICT", separated by
        space.

    ${#ID}
        is replaced by the length of the the reply argument, variable,
        dictionary, or specific sub-item specified by "ID".

    ${ID:+ALTERNATE}
        is replaced by the string "ALTERNATE" if and only if the reply
        argument, variable, dictionary, or specific sub-item specified
        by "ID" exists and is non-empty.

    ${ID:-ALTERNATE} 
        is replaced by the contents of the reply argument, variable,
        dictionary, or specific sub-item specified by "ID" as above,
        except that if this does not exist or contains nothing, the
        string "alternate" is inserted instead.

    ${ID?+TEXT}
        is replaced by the string "TEXT" if and only if the boolean
        value of the reply argument, variable, dictionary, or specific
        sub-item specified by "ID" is true. See also: "HELP? BOOLEANS".

    ${ID?-TEXT}
        is replaced by the string "TEXT" if and only if the boolean
        value of the reply argument, variable, dictionary, or specific
        sub-item specified by "ID" is false.

    ${ID?IFTRUE:IFFALSE}
        is replaced by the string "IFTRUE" or "IFFALSE", depending on
        the boolean value of the reply argument, variable, dictionary,
        or specific sub-item specified by "ID".

    ${ID:STARTPOS}
        is replaced by the substring from STARTPOS to the end of the
        contents of the reply argument, variable, dictionary, or
        specific sub-item specified by "ID".

    ${ID:STARTPOS:LENGTH}
        is replaced by the substring from STARTPOS and spanning LENGTH
        characters of the reply argument, variable, dictionary, or
        specific sub-item specified by "ID".

    ${ID/SEARCH/REPLACE}
        is replaced by the reply argument, variable, dictionary, or
        specific sub-item specified by "ID", where any occurrence of
        SEARCH in is replaced with REPLACE.  If SEARCH begins with a
        "/", it is interpreted as a regular expression
        (${ID//REGEX/REPLACE}), and correspondingly REPLACE may then
        contain back-references (e.g. "\\1").

    $(COMMAND ...)
        is replaced with the return value from the nested command
        "COMMAND ...".  Even the command is asynchronous, this
        substitution will not take place until it completes.

    $[EXPRESSION]
        Evaluates "EXPRESSION" using the Python interpreter.
        Functions from within Python "math" module (such as "sin()"
        and "log()") are available.

    $<SECRET>
        is replaced by the string SECRET, however SECRET is not logged
        or echoed back in the command response.  Note that any
        occurrence of ">" or "\\" within secret must be escaped with an
        (additional) backslash: "\\>", "\\\\".

    \\0, \\n, \\r, \\t, \\b
        are is replaced by a null, newline, carriage return, tab,
        or backspace character, respectively.

    \\xNN, \\NNN
        are replaced by the character with the given hexadecimal
        or octal ordinal value, respectively.

    \\ at the end of a line
        continues the current command onto the next input line.
    
    \\C
        is replaced with the character C.  This can be used to
        prevent substitutions of special characters, such as "$", or
        before a space character to prevent separation of arguments.

    "TEXT" (double quote)
        encapsulates TEXT into a single argument; however
        substitutions are still performed on TEXT.

    \'TEXT\' (single quote)
        encapsulates TEXT into a single argument, and prevents further
        substitutions on TEXT.

    <TAG>TEXT</TAG>
        encapsulates TEXT into a single argument, and prevents
        substitutions on TEXT.  The argument may span several lines.
        "TAG" may contain letters, optionally followed by a single
        period (.) and more letters.  Commonly, a pair of <MULTILINE>
        / </MULTILINE> tags are used to encapsulate text that spans
        several lines, e.g. when defining a macro.  See also the
        "QUOTATIONS" topic.


    <<<TEXT>>>
        similary encapulates TEXT into a single argument with no
        substitutions within. The TEXT may span multiple lines and
        contain nested <<< / >>> blocks.


Examples:
  * Say you have a variable named "MyVar" containing the value "mine".
    The following statements will publish "mine" on the topic "MyTopic":
         VAR? MyVar
         PUBLish MyTopic $0

  * The following is a shorter way of saying the same thing:
         PUBLish MyTopic $(VAR? MyVar)

  * The following is yet shorter:
         PUBLish MyTopic ${MyVar}

  * A backslash prevents substitution on the "$" sign in the
    following example:
         PUBlish Debt Current national debt is \\$(8 trillion)

  * Pass "My Own Module File" as a single argument:
         MODule My\\ Own\\ Module\\ File

  * Before an initial hyphen to prevent an unnamed argument from
    being interpreted as a named argument:
         PUBLish MyTopic \\-this message starts with hyphen

  * Prior to another backslash to produce a single backslash:
         FILe:LIST? C:\\\\Documents\\ and\\ Settings

  * The same result, with double quotes:
         FILe:LIST? "C:\\\\Documents and Settings"

  * The same result, with single quote:
         FILe:LIST? \'C:\\Documents and Settings\'

    '''


class QUOTATIONS (HelpTopic):
    '''
    Normally, each argument is expanded according to various
    substitution rules (see the SUBSTITUTIONS topic), and the command
    is terminated with the NEWLINE character.

    In some cases, it may be neccessary to pass in literal text, often
    spanning several lines (such as when defining a macro, or a block
    of code following commands like IF/WHILe/REPeat/SCHedule.  For
    this purpose, a specific syntax is provided, wherein the argument
    would be given between a pair of matching XML-like tags:

        REPeat -counter=idx 10 <quote>
            PUBLish MyTopic Counter is now ${idx}
            VAR lastcount ${idx}
        </quote>

    The tag name must contain letters, with an optional embedded
    period character (".").  Conventionally, "<quote.identifier>"
    is used for multi-line input, where "identifier" is a word that
    gives some context for the programmer to visually match the
    open/close tags.

    Tags can be nested:

        MACRo+ CYCLe $count $command <quote>
            REPeat -counter=CycleCount $count <quote>
                PUBLish Cycle "Starting cycle ${CycleCount}"
                $command
                PUBLish Cycle "Ending cycle ${CycleCount}"
            </quote>
        </quote>

    For readability, it may be desirable to uniquely identify each
    pair of tags:

        MACRo+ CYCLe $count $command <quote.macro>
            REPeat -counter=CycleCount $count <quote.repeat>
                PUBLish Cycle "Starting cycle ${CycleCount}"
                $command
                PUBLish Cycle "Ending cycle ${CycleCount}"
            </quote.repeat>
        </quote.macro>

    Similarly, multiline replies from the server (such as the reply
    to the "HELP?" and "XMLHelp?" commands) are wrapped in a pair of
    "<quote.reply>" / "</quote.reply>" tags - but if these
    tags exist in the actual reply text, "reply" is replaced with
    a unique name starting with "reply2", "reply3", and so on.

    '''


class MACROS (HelpTopic):
    '''
    Macros are collections of commands that are executed in order
    until completion.  To define a macro for later execution, use
    the following syntax:

         MACRo+ MacroName $argument ... <quote>
             ...
             COMMand $argument ...
             ...
         </quote>

    Arguments may be declared immediately following the macro name,
    prior to the macro text, each typically enclosed in dollar signs
    ("$").  The last argument to the MACRo+ command is the body of the
    macro.

    If the last macro argument (i.e. the second last argument to the
    "MACRo+" command) ends with an asterisk ("*") or a plus sign
    ("+"), it will swallow all remaining arguments that are supplied
    to the macro when excecuted.  In the former case, it will accept
    zero or more arguments, in the latter case, one or more arguments.

    Upon invocation, any occurence of these arguments in the macro
    text is replaced with the corresponding command line argument
    prior to invoking the macro:

      MACRo+ MyMacro $one$ $two$ $* <quote>
          PUBLish MacroTopic One is $one$, Two is $two$, Remainder is $*
      </quote>

      MyMacro 1 2 3 4 5  --> One is 1, Two is 2, Remainder is 3 4 5.

    Normally, argument values are expanded as described in the
    SUBSTITUTIONS topic before such subtitution takes place, however
    this can be prevented by prefixing the argument name with a "@"
    sign:

      MACRo+ -raw MyMacro2 @values* <quote>
          MyMacro @values*
      </quote>

    This can be useful, for instance, to ensure that empty variables
    are passed on as separate arguments to commands within the macro
    itself:

      MyMacro2 "A B" "" C D E
      MESSage MacroTopic One is A B, Two is , Remainder is C D E

    There are also "unnamed" (or "inline") macros; these are groupings
    of commands passed in as arguments to commands like "RUN", "IF",
    "UNLess", "WHILe", "UNTil", "REPeat", "SCHedule".  See these
    commands for details.
    '''



class BOOLEANS (HelpTopic):
    '''
    Conditions are boolean expressions, passed in as arguments to
    commands like "IF" and "WHILe".  Such expressions may contain:

     - The case-insensitive words "yes", "true", and "on" yield TRUE,
       whereas "no", "false" and "off" yield FALSE.

     - Numeric values yield FALSE if they are zero, TRUE otherwise.

     - Anything else yields an error.

    Substitutions (see the \"SUBSTITUTIONS\" topic) work normally,
    so you can use expressions like:

       IF $[${counter} > 0] ....

    '''


class FILESYSTEM (HelpTopic):
    '''
    File locations (paths) are specified as follows:

       [<context>:] [<folder>{/|\\}] ... [ <base> ]

    where:
       <context>
          is a predefined mapping to a location in the filesystem.
          Contexts may be added or removed using the "ConteXT+"
          and "ConteXT-" subcommands.  If no context is specified,
          a default context is used; the default context can be
          set using the "ConteXT=" command.

          Conversely, when the "LIST?" command is invoked without
          any arguments, it returns a list of files/folders in ALL
          available contexts. Items not in the default context
          are prefixed with the context name, so that they can
          subsequently be addressed using the same syntax.

       <folder>
          is one or more subfolders, separated by one of the 
          directory separators "/" or "\\".

       <base>
          is the "base name" of the file or folder that is being
          addressed.

Examples:
  * Let us say that there are 3 contexts defined in the FILe branch:
    "default", "usbdrive", and "dbserver".  Let us also say that
    there are 2 data folders in the "default" context, named "data1"
    and "data2" respectively, and 1 data folder in each of the other
    contexts, named "data3" and "data4", respectively.  The client
    issues a "FILe:LIST?" command without arguments:

       C: FILe:LIST?
       S: OK FILe:LIST? <multiline.reply>
          data1/
          data2/
          dbserver:data4/
          usbdrive:data3/
          </multiline.reply>

  * Now let us say that the client wants to list the contents of the
    "data4" folder:

       C: FILe:LIST? dbserver:data4/
       S: OK FILe:LIST? dbserver:data4/ <multiline.reply>
          folder1/
          file2
          file3
          ...
          </multiline.reply>

  * Now the client wants to create the subfolder "Foo" inside the
    "data2"  folder:

       C: FILe:MKDIR data2/Foo
       S: OK FILe:MKDIR data2/Foo

  * Finally, it tries to do so again, in a different way:

       C: FILe:MKDIR DEFAULT:data2/Foo
       S: ERRor FILe:MKDIR DEFAULT:data2/Foo --> File exists: \'Foo\'
    '''

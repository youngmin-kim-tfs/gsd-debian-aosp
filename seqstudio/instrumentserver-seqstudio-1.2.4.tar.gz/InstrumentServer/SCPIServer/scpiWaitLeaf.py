########################################################################
### FILE:	scpiWaitLeaf.py
### PURPOSE:	Wait/Timer commands
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase       import Base
from scpiLeaf       import Leaf, AsynchLeaf, Observing, Controlling, SYNCHRONOUS
from scpiExceptions import RunError
from locking        import Queue, Empty
from threading      import currentThread
from schedule       import sleep, setSleep, willSleep, setSpeedFactor, getSpeedFactor
from re             import compile, escape
from subscription   import subscribe, unsubscribe, LogLevels, DEBUG

class SPEED_Set (Controlling, Leaf):
    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('speed',
                      type=float,
                      range=(0.1, 50.0),
                      description='speed factor')

    def run (self, speed):
        setSpeedFactor(speed)


class SPEED_Query (Observing, Leaf):
    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('speedfactor',
                       type=float,
                       description='speed factor')

    def run (self):
        return getSpeedFactor()



class WAIT_Set (Controlling, Leaf):
    '''
    Specify whether the WAIT command should actually wait as
    specified; if not, it does nothing.  This may be useful
    for simulation.
    '''

    def run (self, setting=bool):
        setSleep(setting)

class WAIT_Query (Observing, Leaf):
    '''
    Indicate whether the WAIT command is currently functional,
    or whether it does nothing.  Change with "WAIT=".
    '''

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('setting', type=bool)


    def run (self):
        return willSleep()


class WAIT (Observing, Leaf):
    '''
    Do nothing for the specified duration.

    To run a timer in the background, use the "FLAG" command:
        FLAG -asynchronous Timer "WAIT <duration>"
        ...
        SYNC Timer
    '''

    def run (self, _context, always=False, seconds=float):
        sleep(seconds, always=always)

    def estimateTime (self, _context, always=False, seconds=float):
        self.addTime(_context, seconds)


class _MessageWaitLeaf (Observing, Leaf):
    '''
    Abstract superclass for EWAit, TWAit, NWAit -- below.
    '''

    class MessageTimeout (RunError):
        'Timed out waiting for message after %(time)ss'


    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('timeout', type=float, default=None, units='seconds',
                      description='Maximum time wait for a message on the specified topic')
        self.setInput('suspendable', type=bool, default=False,
                      description='Suspendable timeout; see OPerationConTroL command')
        self.setInput('ignoreTimeout', type=bool, default=False,
                      description='If set, no error is generated even if timeout period elapses')
        self.setInput('level', type=LogLevels, named=True, default=DEBUG)
        self.setInput('topic', type=str,
                      description='Topic on which to wait for a message publication')


    def wait (self, timeout, suspendable, ignoreTimeout, level, topic, matchFunc, *args):
        thread    = currentThread()
        queue     = Queue()
        function  = self.processMessage

        try:
            subscribe(topic, level, function, args=(queue, matchFunc) + args)
            try:
                queue.get(True, timeout, suspendable=suspendable)
            except Empty:
                if not ignoreTimeout:
                    raise self.MessageTimeout(time=timeout)
        finally:
            unsubscribe(topic, function, queue, matchFunc, *args)
            

    def matchAll (self, message):
        return True

    def processMessage (self, topic, level, timestamp, message, parts, queue,
                        matchFunc, *args):
        if matchFunc(message, *args):
            queue.put(None)



class ExpressionWAit (_MessageWaitLeaf):
    '''
    Wait for a published message on the specified topic, whose
    body matches the given regular expression.

    If "-timeout" is given, give up after the specified number of
    seconds.  An error is then returned unless "-ignoreTimeout" is
    set.

Examples:
    * Wait up to 60 seconds for a message on topic "Event", where the
      message contents start with 0x82XX, and "X" is a hexadecimal digit:
        ExpressionWAit -timeout=60 Event (0x82[0-9A-Fa-f][0-9A-Fa-f])
    '''

    class InvalidExpression (RunError):
        'Invalid regular expression syntax'


    def run (self, timeout=None, suspendable=False, ignoreTimeout=False, level=DEBUG, topic=str, *expression):
        try:
            regex  = compile(' '.join(expression))
        except Exception:
            raise self.InvalidExpression

        return self.wait(timeout, suspendable, ignoreTimeout, level, topic, regex.match)



class MessageWAit (_MessageWaitLeaf):
    '''
    Wait for a published message on the specified topic.

    If "-timeout" is non-zero, give up after the specified number of
    seconds.  An error is then returned unless "-ignoreTimeout" is
    set.


Examples:
    * Wait up to 60 seconds for a message to be published on the topic
      "Event":
        MessageWAit -timeout=60 Event
    '''

    def run (self, timeout=None, suspendable=False, ignoreTimeout=False, level=DEBUG, topic=str):
        return self.wait(timeout, suspendable, ignoreTimeout, level, topic, self.matchAll)




class TextWAit (_MessageWaitLeaf):
    '''
    Wait for a published message on the specified topic, whose body is
    equal to the given text string.

    Whitespace characters are normalized, meaning that the comparison
    is performed word by word.

    If "-ignoreCase" is set, a case-insensitive comparison is performed.

    If "-timeout" is non-zero, give up after the specified number of
    seconds.  An error is then returned unless "-ignoreTimeout" is
    set.


Examples:
    * Wait up to 2 hours for the message "Completed" to be published on
      the topic "Run":
        TextWAit -timeout=7200 Run Completed
    '''

    def run (self, timeout=None, suspendable=False, ignoreTimeout=False, ignoreCase=False, level=DEBUG, topic=str, *text):
             

        text = ' '.join(text)
        return self.wait(timeout, suspendable, ignoreTimeout, level, topic, self.match, text, ignoreCase)


    def match (self, message, text, ignoreCase):
        if ignoreCase:
            message = message.lower()
            text    = text.lower()

        return message.split() == text.split()



class NumericWAit (_MessageWaitLeaf):
    '''
    Wait for a published message on the specified topic, whose body
    contains a number that matches the specified value, within the
    specified tolerance.  If no tolerance is specified, the published
    number must be equal to the target.

    The first numeric value found in the message body is used.

Examples:
    * Wait until a temperature sensor reaches 35.0 +/- 0.5 degrees C.
        NWAit -timeout=60 Temperature 35.0 0.5
    '''

    matchX = compile(r'((?:^|\s)[+-]?(?:\d+\.|0x)?\d+)')

    def run (self, timeout=None, suspendable=False, ignoreTimeout=False, level=DEBUG, topic=str,
             value=float, tolerance=0.0):

        return self.wait(timeout, suspendable, ignoreTimeout, level,
                         topic, self.match, value, abs(tolerance))


    def match (self, message, target, tolerance):
        m = self.matchX.search(message)
        if m:
            value = float(m.group(1))
            return (target-tolerance) <= value <= (target+tolerance)
        else:
            return False

#!/usr/bin/python
########################################################################
### FILE:	scpiServer.py
### PURPOSE:	Instrument Command Server & Request Handler
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from socket           import error as SocketError, gethostname
from SocketServer     import TCPServer, StreamRequestHandler
from select           import select
from types            import ClassType
from time             import time, sleep
from sys              import exit, platform, version, stdout, stderr, argv
from os               import getenv, getpid, remove, _exit, devnull, dup2, stat, sep
from optparse         import OptionParser
#from ssl              import SSLContext, PROTOCOL_SSLv23

from subscription     import info, warning, error, TRACE, DEBUG, INFO, WARNING, \
    initlogging, setDefaultLogLevel
from threadControl    import ControllableThread, invoke
from telnetServer     import TelnetHandler
from config           import setConfigPath, getConfigPath, Config


from scpiExceptions   import Error
from scpiSession      import SocketSession, TelnetSession, InitSession, setModulePath, getModulePath

import os, signal, errno, ssl

### Private symbols
_pidfile       = None
_options       = None
_args          = None
_trunk         = None
_exitmodules   = []
listeners      = {}
listenerConfig = Config("listeners.ini")


class SCPIServer (TCPServer):
    daemon_threads      = True
    allow_reuse_address = True

    def __init__ (self, server_address, RequestHandlerClass, **opts):
        TCPServer.__init__(self, server_address, RequestHandlerClass)
        addr, port = self.server_address
        self.session_prefix = RequestHandlerClass.prefix
        self.session_id     = 0
        self.options        = opts
        info('Attached %s to %s port %s'%(RequestHandlerClass.__name__, addr or "TCP", port))

    def get_request (self):
        try:
            return TCPServer.get_request(self)
        except SocketError:
            raise EOFError

    def process_request_thread (self, request, client_address):
        try:
            try:
                self.finish_request(request, client_address)
            except (SystemExit, KeyboardInterrupt):
                shutdown(reason="Initiated from %s"%(self.RequestHandlerClass.__name__))
            except:
                self.handle_error(request, client_address)
        finally:
            self.shutdown_request(request)


    def process_request (self, request, client_address):
        self.session_id += 1
        t = ControllableThread(target=self.process_request_thread,
                               args=(request, client_address),
                               name="%s%d"%(self.session_prefix, self.session_id))
        t.setDaemon(True)
        t.start()



class InstrumentRequestHandler (StreamRequestHandler):
    """
    Request handler for incoming client connections.
    """

    top = None
    prefix = 'S'
    TypeName = 'plain'
    OptionNames = (PREEXEC, POSTEXEC) = ('preexec', 'postexec')

    @classmethod
    def setTop (cls, top):
        cls.top = top

    def option (self, name, default=None):
        return self.server.options.get(name, default)

    def setup (self):
        StreamRequestHandler.setup(self)

        description   = 'network client at %s:%d'%self.connection.getpeername()
        self.session  = SocketSession(connection=self.connection,
                                      instream=self.rfile,
                                      outstream=self.wfile,
                                      description=description,
                                      **self.server.options)

    def handle (self):
        self.session.handle(self.top)


class SSLRequestHandler (InstrumentRequestHandler):
    """
    Request handler for incoming SSL client connections.
    """

    prefix   = 'SSL'
    TypeName = 'ssl'
    keyfile  = None
    certfile = None

    _options = (CERTFILE, KEYFILE) = ('certfile', 'keyfile')
    OptionNames = InstrumentRequestHandler.OptionNames + _options


    #@classmethod
    #def setDefaultCertificate (cls, certfile, keyfile):
    #    certpath = keypath = None
    #    certpath = cls.findcert(getConfigPath(), certfile, 'SSL certificate file')
    #    if keyfile:
    #        keypath = cls.findcert(getConfigPath(), keyfile, 'SSL key file')
    #
    #    cls.certfile = certpath
    #    cls.keyfile = keypath

    #@classmethod
    def findcert (self, filename, what):
        if filename is None:
            return None

        elif sep in filename and os.path.exists(filename):
            return filename

        for folder in searchpath:
            candidate = os.path.join(folder, filename)
            if os.path.exists(candidate):
                return candidate
        else:
            raise OSError(errno.ENOENT, "%s not found"%(what,), filename)


    def setup (self):
        options = self.server.options.copy()
        certfile = self.findcert(options.pop(self.CERTFILE, None), 'SSL certificate')
        keyfile  = self.findcert(options.pop(self.KEYFILE, None), 'SSL key')

        self.connection = ssl.wrap_socket(self.request,
                                          certfile=certfile,
                                          keyfile=keyfile,
                                          ssl_version=ssl.PROTOCOL_SSLv23,
                                          server_side=True)

        self.rfile = self.connection.makefile('rb', self.rbufsize)
        self.wfile = self.connection.makefile('wb', self.wbufsize)

        description  = 'secure socket client at %s:%d'%self.connection.getpeername()
        self.session = SocketSession(connection=self.request,
                                     instream=self.rfile,
                                     outstream=self.wfile,
                                     description=description,
                                     **options)


class TelnetRequestHandler (InstrumentRequestHandler):
    """
    Request handler for incoming telnet clients.
    """

    prefix = 'T'
    TypeName = 'telnet'
    initstring  = '''\r
--- Type "HELP? OVERVIEW" for help on commands and syntax.\r
--- Press [ESC] then [H] for a list of editing keys.\r
'''

    def setup (self):
        StreamRequestHandler.setup(self)
        telnetHandler = TelnetHandler(self.connection, self.initstring)
        description   = 'telnet client at %s:%d'%self.connection.getpeername()
        self.session  = TelnetSession(connection=self.connection,
                                 instream=telnetHandler,
                                 outstream=telnetHandler,
                                 description=description,
                                 **self.server.options)

        telnetHandler.setAutoComplete(self.session.autocomplete)



RequestHandlerClasses = {None : InstrumentRequestHandler}
for cls in InstrumentRequestHandler, SSLRequestHandler, TelnetRequestHandler:
    RequestHandlerClasses[cls.TypeName] = cls



def runModule (scope, path):
    session = InitSession(module=path, description="init module %r"%path)
    session.handle(scope)


def loadModulesThread (scope, modules, description):
    start = time()
    for module in modules:
        invoke(runModule, (scope, module), {}, "init module %r"%(module,))


    elapsed = time() - start
    info('%s processed in %.3f seconds'%(description, elapsed))


def loadModules (scope, modules, description):
    t = ControllableThread(None, loadModulesThread, description,
                           (scope, modules, description), {})
    t.setDaemon(True)
    t.start()
    return t



def createPidFile (filename, pid=None):
    global _pidfile
    if filename:
        try:
            file(filename, "w").write("%s\n"%(pid or getpid()))
            _pidfile = filename
        except EnvironmentError, e:
            warning('Unable to save PID file "%s": %s (errno=%s)'%
                    (e.filename, e.args[-1], e.errno))

def removePidFile (filename=None):
    global _pidfile
    if _pidfile:
        try:
            remove(_pidfile)
        except EnvironmentError, e:
            warning('Unable to remove PID file "%s": %s (errno=%s)'%
                    (e.filename, e.args[-1], e.errno))
        else:
            _pifile = None


def background (closeInput=True, closeOutput=True, closeError=True, pidfile=None):
    try:
        pid = os.fork()
    except (AttributeError, EnvironmentError) as e:
        warning("Cannot fork to background: [%s] %s"%(e.__class__.__name__, e))
    else:
        if pid:
            createPidFile(pidfile, pid=pid)
            exit(0)
        else:
            if closeInput:
                infile  = file(devnull, 'r')
                dup2(infile.fileno(), 0)

            if closeOutput or closeError:
                outfile = file(devnull, 'w')

                if closeOutput:
                    dup2(outfile.fileno(), 1)

                if closeError:
                    dup2(outfile.fileno(), 2)



def shutdown (signal=None, action=None, reason=None, exit=True):
    info('Shutting down (%s)'%(reason or "signal %s"%(signal,)))

    if _exitmodules:
        loadModules(_trunk, _exitmodules, 'Shutdown modules').join()

    t = ControllableThread(None, _trunk.shutdown, 'Shutdown', (), {})
    t.setDaemon(True)
    t.start()
    t.join()

    removePidFile()

    if exit:
        _exit(0)


def fatal (message):
    stderr.write("%s\n"%message)
    exit(2)


def interface (address, defhost="", defport=7000):
    try:
        host, port = address.split(':')
    except ValueError:
        try:
            port = int(address)
        except ValueError:
            host = address
            port = defport
        else:
            host = defhost
    else:
        try:
            port = int(port)
        except ValueError:
            fatal('Invalid port number: %r'%(port,))

    return (host, port)


def addListener (address, requestHandlerClass, default=False, **options):
    listener = listeners[address] = SCPIServer(address, requestHandlerClass, **options)
    if default:
        listeners[None] = listener
    return listener

def removeListener (address):
    if listeners.pop(address) == listeners.get(None):
        listeners.pop(None)


def serve ():
    try:
        while listeners:
            try:
                (inlist, outlist, errlist) = select(listeners.values(), [], [], 2.0)
            except SocketError:
                pass
            else:
                if inlist:
                    takers = 0
                    for listener in inlist:
                        try:
                            listener.handle_request()
                            takers += 1
                        except EOFError, e:
                            pass

                    if not takers:
                        sleep(1.0)

    except KeyboardInterrupt:
        shutdown(reason="Keyboard Interrupt")

    except SystemExit:
        shutdown(reason="System Exit")

    except Exception, e:
        shutdown(reason="Exception: [%s] %s"%(type(e).__name__, e))



def runServer (top=None, modulename='scpiTop', classname='Top', **options):
    global _trunk, _exitmodules

    try:
        SIGTERM, SIGHUP, SIGSEGV = signal.SIGTERM, signal.SIGHUP, signal.SIGSEGV
    except AttributeError:
        pass
    else:
        signal.signal(SIGTERM, shutdown)
        signal.signal(SIGHUP, shutdown)
        signal.signal(SIGSEGV, shutdown)

    if top is None:
        m   = __import__(modulename)
        top = getattr(m, classname)

    if _options.output in ("", "-"):
        redirected = False
    else:
        try:
            output = file(_options.output, 'w')
            dup2(output.fileno(), 1)
            dup2(output.fileno(), 2)
            redirected = True
        except EnvironmentError, e:
            fatal('Unable to redirect output to %r: %s'%(e.filename, e))


    try:
        default=True
        if _options.bindplain:
            host, port = address = interface(_options.bindplain)
            if port:
                addListener(address, InstrumentRequestHandler, default=default)
                default = False

        if _options.bindssl:
            host, port = address = interface(_options.bindssl)
            if port:
                addListener(address, SSLRequestHandler, default=default,
                            certfile=_options.sslcertifiate,
                            keyfile=_options.sslkey)
                default = False

        if _options.bindtelnet:
            host, port = address = interface(_options.bindtelnet)
            if port:
                addListener(address, TelnetRequestHandler, default=default)


    except (SocketError, EnvironmentError), e:
        fatal('Could not bind to %s%d: %s'%(host and host+':' or 'port ', port, e))


    setDefaultLogLevel(_options.loglevel)

    if _options.fork:
        background(closeOutput=not redirected, pidfile=_options.pidfile)
    else:
        initlogging(_options.loglevel, _options.outputformat)
        createPidFile(_options.pidfile)

    if callable(top):
        servername = ' '.join(filter(None, (top.__name__, _options.flavor)))
        info('Starting %s server'%servername)
        start = time()
        top = top()
        elapsed  = time() - start
        info('Commands constructed in %ss'%elapsed)

    InstrumentRequestHandler.setTop(top)

    _trunk = top
    _exitmodules = _options.exitmodules

    if _options.preload:
        loadModules(top, _options.preload, 'Synchronous startup modules').join()

    if _options.postload:
        loadModules(top, _options.postload, 'Asynchronous startup modules')

    serve()


def setStartupOptions (args, options):
    global _options, _args
    _options = options
    _args = args


def getStartupOption (name, default=Exception):
    try:
        return getattr(_options, name)
    except AttributeError:
        if default is Exception:
            raise
        return default

def getStartupOptions ():
    return [ name for name in dir(_options) if name.isalpha() ]

def getStartupArgs ():
    return _args

def getTrunk ():
    return _trunk

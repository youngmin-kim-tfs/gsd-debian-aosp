########################################################################
### FILE:	scpiQueueBranch.py
### PURPOSE:	General purpose queueing/dequeuing
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

from scpiMinimalBranch import MinimalBranch
from scpiLeaf          import Controlling, Observing, Leaf
from scpiExceptions    import RunError
from locking           import Queue, Empty



class QUEue (MinimalBranch):

    class QueueExists (RunError):
        'The queue %(name)r already exists'

    class NoSuchQueue (RunError):
        'No such queue exists: %(name)r'

    class NoSuchElement (RunError):
        'Element index %(index)d is beyond queue %(name)r size (%(size)d)'

    class EmptyQueue (RunError):
        'Queue %(name)r is empty'


    def __init__ (self, *args, **kwargs):
        MinimalBranch.__init__(self, *args, **kwargs)
        self.queues = {}


    class NEW (Controlling, Leaf):
        '''Add a new Queue'''

        def run (self, replaceExisting=False, name=str):
            if not replaceExisting and name.lower() in self.parent.queues:
                raise self.parent.QueueExists(name=name)

            self.parent.queues[name.lower()] = (name, Queue())



    class DELete (Controlling, Leaf):
        '''Remove an existing Queue'''

        def run (self, ignoreMissing=False, name=str):
            try:
                del self.parent.queues[name.lower()]
            except KeyError:
                if not ignoreMissing:
                    raise self.parent.NoSuchQueue(name=name)



    class ITEMS_Query (Observing, Leaf):
        '''Return size of an existing queue'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)


        def run (self, name=str):
            try:
                name, queue = self.parent.queues[name.lower()]
            except KeyError:
                raise self.parent.NoSuchQueue(name=name)

            return len(queue.queue)
            

    class ITEM_Query (Observing, Leaf):
        '''Return an element element from an existing queue without removing it'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('item', type=str)

        def run (self, ignoreMissing=False, name=str, index=0):
            try:
                name, queue = self.parent.queues[name.lower()]
                item = queue.queue[index]
            except KeyError:
                if not ignoreMissing:
                    raise self.parent.NoSuchQueue(name=name)
            except IndexError:
                if not ignoreMissing:
                    raise self.parent.NoSuchElement(name=name, size=len(queue.queue), index=index)

            return item
        

    class ITEM_Enumerate (Observing, Leaf):
        '''Return all items in a queue'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('item', type=str, repeats=(0, None))


        def run (self, ignoreMissing=False, name=str):
            try:
                name, queue = self.parent.queues[name.lower()]
            except KeyError:
                if not ignoreMissing:
                    raise self.parent.NoSuchQueue(name=name)

            return tuple(queue.queue)


    class LIST_Enumerate (Observing, Leaf):
        '''List available queues, or items in a specific queue'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self, ignoreMissing=False, name=None):
            if name:
                try:
                    name, queue = self.parent.queues[name.lower()]
                except KeyError, e:
                    if not ignoreMissing:
                        raise self.parent.NoSuchQueue(name=name)
                else:
                    return tuple(queue.queue)

            else:
                names = [ name for name, q in self.parent.queues.itervalues() ]
                return tuple(names)

                    


    class PUT (Controlling, Leaf):
        '''
        Append an item to the specified Queue.  
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('items', type=tuple, repeats=(0, None))
            self.setInput('ignoreMissing', type=bool, named=True, default=False)

        def run (self, ignoreMissing=False, createMissing=False, name=str, *items):
            if not createMissing and not name.lower() in self.parent.queues:

                if not ignoreMissing:
                    raise self.parent.NoSuchQueue(name=name)

            name, queue = self.parent.queues.setdefault(name.lower(), (name, Queue()))
            queue.put(items)


    class GET_Query (Controlling, Leaf):
        '''
        Retrieve an element from the specified queue.  By default, items
        are retrieved in FIFO (First In, First Out) order; however if the
        "-last" option is set, the item is popped in LIFO (Last In, First
        Out) fashion.
        '''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('last', type=bool, default=False, named=True,
                          description="Pop from the rear of the queue (Last In, First Out)")
            self.setInput('timeout', type=float, default=None, units="seconds", named=True,
                          description="Give up waiting after the specified timeout (default: indefinitely)")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('items', type=tuple, repeats=(0, None))


        def run (self, ignoreMissing=False, ignoreTimeout=False, last=False, timeout=None, name=str):
            try:
                name, queue = self.parent.queues[name.lower()]
                return queue.get(timeout=timeout, last=last)

            except KeyError:
                if not ignoreMissing:
                    raise self.parent.NoSuchQueue(name=name)

            except Empty:
                if not ignoreTimeout:
                    raise self.parent.EmptyQueue(name=name)

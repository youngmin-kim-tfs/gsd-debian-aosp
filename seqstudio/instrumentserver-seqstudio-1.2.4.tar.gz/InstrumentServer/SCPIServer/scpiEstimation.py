########################################################################
### FILE:	scpiEstimation.py
### PURPOSE:	support for resource estimation (e.g. time, reagents...)
###
### Copyrights (C) 2011 Life Technologies.  All rights reserved.
########################################################################

from scpiLeaf        import Leaf, Controlling, Observing, CommandWrapper, EstimationCriteria
from scpiMacro       import Macro
from scpiSession     import SYNC, ASYNC
from scpiDynamicBase import DynamicCommandLeaf
from scpiExceptions  import CommandError, RunError
from subscription    import info
from data            import DynamicData



class ESTimation_Enumerate (Observing, Leaf):
    '''
    If no command is specified, return list of availble estimation criteria.
    Otherwise, return a list of custom test commands for the specified command.
    '''


    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('criteria', type=str, repeats=(0, None))


    def run (self, command=""):
        if command:
            pass
        else:
            return tuple(EstimationCriteria.keys())


class ESTimation_Set (Controlling, DynamicCommandLeaf):
    '''
    Specify a test command to use when testing specific metrics of
    "command" (for instance, time, reagents, etc) using "ESTimation".  It
    may be used, for instance, to estimate run time or reagent use for
    a command that is relies on hardware behavior, and for which the
    built-in test produces incorrect results.

    This replaces any built-in test method; specifically, if "command"
    is a macro, that macro will no longer be parsed and evaluated when
    invoking "ESTimation".

    The specified test command should expect the same inputs as the
    command being tested or a subset; it should also return one named
    output for every criterion being tested, except that if only a
    single criterion (e.g. "time") is being specified, a single
    unnamed output value is acceptable.

    '''

    class MismatchedInputs (CommandError):
        '''Estimation command %(estimationCommand)r takes different inputs from original command %(command)r'''

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('criterion',  type=EstimationCriteria, named=True,
                      description='Metric for which this estimation is being used; by default, all.')

        self.setInput('command',  type=str, description='Command being tested')
        self.setInput('text', type=str, description='Command block to perform the estimation')

    def run (self, _session, criterion=None, command=str, text=str):
        macro = self.findModifiableCommand(_session, command, searchType=Macro, parent=self.parent)

        if criterion:
            methodname, methodargs = criterion
            macro.estimationRoutines[methodname] = text
        else:
            for methodname, methodargs in EstimationCriteria.values():
                macro.estimationRoutines[methodname] = text


class ESTimation_Clear (Controlling, DynamicCommandLeaf):
    '''
    Clear any custom estimation commands to use for estimating the specified metric of "command",
    and revert to its default/native method of estimation.
    '''

    class NoEstimationRoutine (RunError):
        '''Macro %(macro)r does not have any custom estimation routine for %(criterion)r.'''

    def declareInputs (self):
        DynamicCommandLeaf.declareInputs(self)

        self.setInput('criterion', type=EstimationCriteria, named=True,
                      description='Metric for which this estimation is being used; by default, all.')
        self.setInput('command', type=str, description='Command being estimated')


    def run (self, _session, ignoreMissing=False, criterion=None, command=str):
        macro = self.findModifiableCommand(_session, command, searchType=Macro, parent=self.parent)

        if criterion:
            methodname, methodargs = criterion

            try:
                del macro.estimationRoutines[methodname]
            except KeyError:
                if not ignoreMissing:
                    raise self.NoEstimationRoutine(macro=macro.commandPath(), criterion=criterion)

        else:
            macro.estimationRoutines.clear()

    
class ESTimation_Query (Observing, DynamicCommandLeaf):
    '''
    Return any custom commands used to estimate the specified metric of "command".
    '''

    class NoEstimationRoutine (RunError):
        '''Macro %(macro)r does not have any custom estimation routine for %(criterion)r.'''

    def declareInputs (self):
        DynamicCommandLeaf.declareInputs(self)

        self.setInput('criterion', type=EstimationCriteria, named=True, 
                      description='Metric for which this test is being used; by default, all.')

        self.setInput('command', type=str, description='Command being tested')

    def run (self, _session, ignoreMissing=False, criterion=EstimationCriteria, command=str):
        macro = self.findDynamicCommand(command, searchType=Macro, parent=self.parent)
        try:
            methodname, methodargs = criterion
            return macro.estimationRoutines[methodname]
        except KeyError:
            for name, candidate in EstimationCriteria.items():
                if candidate == criterion:
                    break
            else:
                name = None
            if not ignoreMissing:
                raise self.NoEstimationRoutine(macro=macro.commandPath(), criterion=name)


class ESTimate (Observing, CommandWrapper, Leaf):
    '''
    Perform a "test run" of the specified command block.
    '''

    def declareInputs (self):
        Leaf.declareInputs(self)

        self.setInput('criterion', type=EstimationCriteria, 
                      description='What metric is being estimated')
        self.setInput('command', type=str,
                      description='Command to test')
        self.setInput('arguments', type=tuple,
                      description='Command arguments.')

    invocation = ('estimate', ())

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('result', repeats=(0, None), type=tuple, named=True)


    def run (self, _session, _context, 
             criterion=EstimationCriteria, command=str, *arguments):

        methodname, methodargs = criterion
        context = _context.clone(invocation=self.invocation,
                                 estimationMethod=methodname,
                                 estimationResults=DynamicData(methodargs),
                                 estimationData=DynamicData(),
                                 data=_context.data.copy())
                                 
        context = _session.runParts(context, command, arguments, self.parent, nextReply=SYNC)
        outputs = [ (key, context.estimationResults.pop(key, value)) for (key, value) in methodargs ]
        outputs.extend(context.estimationResults.iteritems())
        return tuple(outputs)


########################################################################
### FILE:	llacMotionBase.py
### PURPOSE:	Motion control via LLAC based motion control systems (FCB, MCB)
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiFullBranch  import FullBranch
from scpiLeaf        import Leaf, Asynchronous, Observing, Controlling
from scpiExceptions  import Error, RunError, NextReply, ComponentError, Aborted
from motionBase      import SimpleAxis, MotionAxis, MotionBase
from llacBase        import LLACFullBranch, LLACRegisterBranch, _LLACLeaf, _LLACRegisterLeaf
from llacCommandBase import LLACCommandBranch
from subscription    import debug, info, publish, warning


class LLACAxis (LLACCommandBranch, SimpleAxis):
    '''Abstract superclass for MCB Axes (motion, autofocus, ...)'''

    Statuses = ()

    class CommandNotAvailable (RunError):
        '''Command %(command)s is not implemented for %(axis)s axis'''


    def __init__ (self, node=None, base=None, llacConfig=None, *args, **kwargs):
        SimpleAxis.__init__(self, *args, **kwargs)
        LLACCommandBranch.init(self, node=node, base=base, llacConfig=llacConfig)

    def sendToTarget (self, target, *args, **kwargs):
        self.checkConfig()
        pending = []

        refs = self.sendTarget(target, *args, **kwargs)
        pending.extend(self.waitAck(refs))

        try:
            refs = self.moveToTarget(target, *args, **kwargs)
        except Exception, e:
            self.finishRequests(pending)
            raise
        else:
            pending.extend(self.waitAck(refs, abortable=False))

        return pending

    def sendCommandSequence (self, sequence, longCommand=False, optional=False, abortable=True, **regsettings):
        for command in sequence:
            if not optional or self.commands[command]:
                ref = self.sendCommand(command, longCommand, **regsettings)
                pending = self.waitAck((ref,), abortable=abortable)
                self.waitSync(pending, abortable=abortable)

    def sendStop (self, force):
        self.checkConfig()

        if force or self.isActive(cached=False):
            ref = self.sendCommand(self.C_STOP)
            return [ ref ]

    def waitStop (self, ref):
        pending = self.waitAck(ref, abortable=False)
        self.waitSync(pending, abortable=False)
            

    def loadRegisters (self):
        LLACCommandBranch.loadRegisters(self)
        self.commands = self.getConfigSection(self.CmdSection, self.Commands)
        self.statuses = self.getConfigSection(self.StatusSection, self.Statuses)

    def clearRegisters (self):
        LLACCommandBranch.clearRegisters(self)
        self.commands = None


    class ACTive_Query (Observing, Leaf):
        '''
        Indicate whether the axis is current active/moving.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('cached', type=bool, named=True, default=True)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('state', type=bool)

        def run (self, cached=True):
            return self.parent.isActive(cached=cached)



class LLACMotionAxis (LLACAxis, MotionAxis):
    '''Abstract MCB motion axis'''
    
    LLACCONFIGFILE = "motionaxis.ini"
    (RegSection, CmdSection, StatusSection) = \
                 ("Registers", "Command", "Status")

    Registers = ("COMMand", "LongCOMmand", "STATus?", "ERRor?", "SPeeD", "ACCeleration",
                 "CurrentPos", "EncoderPos?",
                 "AbsoluteTarget", "RelativeTarget",
                 "TravelLimitPositive", "TravelLimitNegative")
    (R_COMMAND, R_LONGCOMMAND, R_STATUS, R_ERROR, R_SPEED, R_ACCELERATION,
     R_CURRENTPOS, R_ENCODERPOS, R_ABSTARGET, R_RELTARGET,
     R_TRAVELLIMITPOSITIVE, R_TRAVELLIMITNEGATIVE) = range(len(Registers))

    Commands = ("Disable", "Enable", "Off", "On", "Home", "Stop", "AbsMove", "RelMove")
    (C_DISABLE, C_ENABLE, C_OFF, C_ON, C_HOME, C_STOP, C_ABSMOVE, C_RELMOVE) = range(len(Commands))

    Statuses = ("Enabled", "On", "Homed", "HomeSwitch", "Moving")
    (S_ENABLED, S_ON, S_HOMED, S_HOMESWITCH, S_MOVING) = range(len(Statuses))


    def __init__ (self, name, node=None, base=None, llacConfig=None, skiphome=False, safe=False, *args, **kwargs):
        LLACAxis.__init__(self, name=name, node=node, base=base, llacConfig=llacConfig,
                          skiphome=skiphome, safe=safe, *args, **kwargs)
        MotionAxis.init(self)
        LLACMotionAxis.init(self)
        

    def init (self):
        pass

    def setPowerState (self, state):
        if state:
            sequence = (self.C_ENABLE, self.C_ON)
        else:
            sequence = (self.C_OFF, self.C_DISABLE)

        self.sendCommandSequence(sequence, optional=True)

    def getPowerState (self):
        return self.statusBits(self.S_ENABLED, self.S_ON)

    def readRawPosition (self):
        self.checkConfig()
        return self.readValue(self.R_CURRENTPOS)

    def sendHome (self):
        self.checkConfig()
        ref = self.sendCommand(self.C_HOME, longCommand=True)
        return self.waitAck((ref,))

    def isHome (self, cached=False):
        if cached:
            return self._isHome
        else:
            return self.statusBits(self.S_ENABLED, self.S_HOMESWITCH)

    def isHomed (self, cached=False):
        if cached:
            return self._isHomed
        else:
            return self.statusBits(self.S_ENABLED, self.S_HOMED)

    def isActive (self, cached=True):
        if cached:
            return self._moving
        else:
            return self.statusBits(self.S_ENABLED, self.S_MOVING)
    
    def sendTarget (self, target, steps=True, relative=False):
        self.checkConfig()
        
        if relative:
            reg     = self.R_RELTARGET
            mode    = 'relative'

        else:
            reg     = self.R_ABSTARGET
            mode    = 'absolute'

        self.checkValidRange(target, steps=steps, relative=relative)
        return (self.sendValue(reg, target, debug=False),)


    def moveToTarget (self, target, steps=True, relative=False, **regsettings):
        command = self.C_ABSMOVE
        if relative:
            command = self.C_RELMOVE
        else:
            command = self.C_ABSMOVE
        return (self.sendCommand(command, longCommand=True, **regsettings), )


class LLACMotionBase (MotionBase, LLACFullBranch):
    '''Motion Controller Board Branch'''

    axisTypes = { None : LLACMotionAxis }

    def isActive (self, axes=None, cached=True):
        if axes is None:
            axes = self.axes

        for axis in axes:
            if axis.isActive(cached=cached):
                return True
        else:
            return False
        

    class AXIS_Add (Controlling, Leaf):
        '''Add a new motion control axis'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('type',  type=self.parent.axisTypes, named=True,
                          description="Type of motion axis")

            self.setInput('llacConfig', type=str, named=True, default=None)
                          

            self.setInput('node',   type=hex, format="0x%02X",
                          range=(0x00,   0xFF), default=None)

            self.setInput('base',   type=hex, format="0x%04X",
                          range=(0x0000, 0xFFFF), default=None)


        def run (self, _session, _branch, type=None, llacConfig=str, name=str, node=hex, base=hex):
            self.parent.addAxis(_session, name, type, node=node, base=base, llacConfig=llacConfig)


    class AXIS_Remove (Controlling, Leaf):
        '''Remove an axis'''

        def run (self, _session, ignoreMissing=False, name=str):
            self.parent.removeAxis(_session, name, ignoreMissing=ignoreMissing)
        


    class AXIS_Enumerate (Observing, Leaf):
        '''List defined axes'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('axis', type=str, repeats=(0, None))

        def run (self):
            return tuple([axis.name for axis in self.parent.axes])


    class ACTive_Query (Observing, Leaf):
        '''
        Indicate whether any axis in this motion system current active/moving.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('cached', type=bool, named=True, default=True)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('state', type=bool)

        def run (self, cached=True):
            return self.parent.isActive(cached=cached)

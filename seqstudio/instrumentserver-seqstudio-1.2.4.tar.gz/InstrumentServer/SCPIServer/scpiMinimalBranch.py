########################################################################
### FILE:	scpiMinimalBranch.py
### PURPOSE:	Branch with a minmal set of 'standard' commands/leaves
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBranch          import Branch, branchTypes
from scpiDynamicBase     import Dynamic
from scpiDynamicCommands import DynamicBranch

class MinimalBranch (Branch):
    __slots__ = ()
    
    from scpiHelpLeaf import \
         HELP, HELP_Query, _Enumerate, _List, _Query, _Exists

    from scpiModuleLeaf import \
         MODule, RUN

    from scpiVariableLeaf import \
        VARiable_Set, VARiable_Clear, VARiable_Query, VARiable_Enumerate, VARiable_Exists, \
        VariableCapture, VariableRun, ReturnVariable, \
        ADDValue, PERSist, PERSist_Query
    
    from scpiDictionary import \
        DICTionary_Add, DICTionary_Remove, DICTionary_Set, DICTionary_Clear, \
        DICTionary_Query, DICTionary_Enumerate, DICTionary_Exists, \
        DictionaryCapture, DictionaryRun, ReturnDictionary

    from scpiDynamicCommands import \
         DESCription_Add, DESCription_Remove, DESCription_Query,\
         ALIas_Add, ALIas_Remove, ALIas_Query, ALIas_Enumerate, ALIas_Load

    from scpiWaitLeaf import \
        WAIT


class DynamicMinimalBranch (DynamicBranch, MinimalBranch):
    TypeName = 'dynamic minimal branch'

branchTypes['Minimal'] = DynamicMinimalBranch

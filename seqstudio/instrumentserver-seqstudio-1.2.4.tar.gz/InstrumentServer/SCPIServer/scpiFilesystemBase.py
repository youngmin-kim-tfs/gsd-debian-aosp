########################################################################
### FILE:	scpiFilesystemBase.py
### PURPOSE:	Abstract Leaf class for filesystem operations
###
########################################################################

from scpiBase           import Base
from scpiLeaf           import Leaf, Observing
from scpiExceptions     import RunError, CommandError, Aborted
from scpiSession        import NestedSession, AccessLevels, OBSERVER, CONTROLLER, ADMINISTRATOR, FULL
from scpiFileContexts   import NotSupported, ContextSchemes, Location, AttributeFile, \
    FilePermissions, P_READ, P_WRITE, P_EXECUTE, \
    FileOps, OP_READ, OP_WRITE, OP_APPEND, \
    FileTypes, ANY, \
    T_MODIFICATION, INCL_VISIBLE
from scpiParameter      import Missing
from config             import Config
from cStringIO          import StringIO
from re                 import compile as rxcomp
from os                 import sep
from sys                import exc_info
from fnmatch            import filter as fnfilter
from logging            import info, warning
from select             import select
from base64             import encodestring
from threadControl      import currentThread


class FilesystemBase (Base):
    class NoMatch (RunError):
        'No match for %(location)r'

    class NotAFile (RunError):
        '''Location %(location)r is not a file, and '-recursive' was not specified'''

    class TargetExists (RunError):
        'Target location %(location)r already exists.'

    class SameFile (RunError):
        'Source location %(source)r and target location %(target)r are the same file.'

    class CannotOverwrite (RunError):
        'Cannot overwrite target %(targettype)s %(location)r with %(sourcetype)s.'

    ########################################################################
    ### CONTEXT MANAGEMENT

    validContextX = rxcomp(r'[\w\-\.@_]+$')
    defaultspecs  = Config('locations')
    savedspecs    = Config('savedlocations')


    class InvalidContext (CommandError):
        'Location context name %(name)r contains invalid characters'

    class InvalidScheme (CommandError):
        'Location scheme %(scheme)r is not known'

    class NoSuchContext (RunError):
        'No such location context: %(name)r'

    class ContextExists (RunError):
        'A location context named %(name)r already exists'

    class NoDefaultContext (RunError):
        'A default location context has not been set'


    @classmethod
    def newContext (cls, name='', scheme='file', **specs):
        try:
            return ContextSchemes[scheme](name=name, **specs)
        except KeyError:
            raise cls.InvalidScheme(name=name, scheme=scheme)


    @classmethod
    def addContext (cls, name, scheme='file', replaceExisting=False, session=None, **specs):
        if name:
            name = name.rstrip(':')
            if not cls.validContextX.match(name):
                raise cls.InvalidContext(name=name)

        if session or not replaceExisting:
            try:
                context = cls._contexts[name.lower()]
            except KeyError:
                pass
            else:
                if not replaceExisting:
                    raise cls.ContextExists(name=context.name)
                else:
                    session.checkAccess(context.replace)

        cls._contexts[name and name.lower()] = cls.newContext(name=name, scheme=scheme, **specs)


    @classmethod
    def removeContext (cls, name, session, ignoreMissing=False):
        key = name.lower().rstrip(":")
        if session:
            try:
                context = cls._contexts[key]
            except KeyError:
                pass
            else:
                session.checkAccess(context.replace)

        try:
            del cls._contexts[key]
            cls.savedspecs.remove_section(name.rstrip(":"))
            cls.savedspecs.save()
        except KeyError:
            if not ignoreMissing:
                raise cls.NoSuchContext(name=name)

    @classmethod
    def loadContexts (cls, replaceExisting=False):
        for config, standard in (cls.defaultspecs, True), (cls.savedspecs, False):
            for cxtname in config.sections():
                if not cxtname.lower() in cls._contexts:
                    specs = config[cxtname]
                    try:
                        cls.addContext(cxtname, replaceExisting=replaceExisting, **config[cxtname])
                    except Exception, e:
                        warning("Unable to load location context %r: [%s] %s"%
                                (cxtname, e.__class__.__name__, e))

    @property
    def contexts (self):
        try:
            return FilesystemBase._contexts
        except AttributeError:
            FilesystemBase._contexts = {}
            FilesystemBase.loadContexts()
            return FilesystemBase._contexts



    def saveContext (self, name):
        context = self.getContext(name)
        self.savedspecs[context.name] = context.properties(omit=())
        self.savedspecs.save()


    def getContext (self, name=None, ignoreMissing=False):
        if name:
            key = name.rstrip(':').lower()
        else:
            key = self.getDefaultContextName()

        try:
            return self.contexts[key]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchContext(name=name)

    def getDefaultContextName (self):
        default = ""
        obj = self
        while obj and not default:
            try:
                default = obj.defaultContext
                break
            except AttributeError:
                obj = obj.parent

        return default or 'default'


    def setDefaultContextName (self, context):
        default = None
        obj = self
        while obj and default is None:
            try:
                default = obj.defaultContext
                break
            except AttributeError:
                obj = obj.parent

        obj.defaultContext = context.lower()


    def getContexts (self):
        ctxts   = sorted(self.contexts.keys())

        try:
            default = self.getDefaultContextName()
            ctxts.remove(default)
            ctxts.insert(0, default)
        except ValueError:
            pass

        return [ self.contexts[ctxt] for ctxt in ctxts ]


    def splitLocation (self, location, defaultContext=Missing):
        try:
            cxtname, relpath = (location or "").split(':', 1)
        except ValueError:
            if defaultContext is Missing:
                defaultContext = self.getDefaultContextName()
            cxtname, relpath = defaultContext, location

        return cxtname, relpath


    def joinLocation (self, context, path, defaultContext=Missing):
        if context:
            context = context.rstrip(":")
        elif defaultContext is Missing:
            context = self.getDefaultContextName()
        else:
            context = defaultContext

        return "".join((context and context+":" or "", path))


    def openLocation (self, location, session=None, operation=None,
                      runTriggers=True, defaultContext=Missing, *args, **kwargs):

        contextname, path = self.splitLocation(location, defaultContext)
        context = self.openContext(contextname, session, operation)
        return Location(context, path, runTriggers, *args, **kwargs)


    def enterLocations (self, *locations):
        entered = []
        try:
            for loc in locations:
                entered.append(loc.__enter__())
        except Exception, e:
            self.exitLocations(*entered)
            raise
        return entered


    def exitLocations (self, *locations):
        exc = None
        for loc in locations:
            try:
                loc.__exit__()
            except Exception, e:
                if not exc:
                    exc = e
        if exc:
            raise exc


    def openContext (self, contextname, session=None, operation=None, ignoreMissing=False):
        context = self.getContext(contextname, ignoreMissing)
        if context and session and (operation is not None):
            attribute = FilePermissions[operation]
            requiredAccess = getattr(context, attribute)
            session.checkAccess(requiredAccess)

        return context

    def enterContexts (self, contexts, runTriggers=True, ignoreErrors=False):
        entered = set()
        try:
            for context in contexts:
                context.enter(ignoreErrors=ignoreErrors, runTrigger=runTriggers)
                entered.add(context)
        except Exception:
            self.exitContexts(entered, ignoreErrors=True, runTriggers=runTriggers)
            raise

        return entered

    def exitContexts (self, contexts, runTriggers=True, ignoreErrors=False):
        exc = None
        for context in contexts:
            try:
                context.exit(runTrigger=runTriggers, ignoreErrors=ignoreErrors)
            except Exception, e:
                if not exc:
                    exc = e

        if exc:
            raise exc


    def guessLocation (self, abspath):
        bestContext = None
        bestPath    = ''

        for cxtname, context in self.contexts.items():
            try:
                path = context.localpath()
            except NotSupported:
                continue
            else:
                if (abspath + sep).startswith(path + sep) and len(path) >= len(bestPath):
                    bestContext = context
                    bestPath    = path

        if bestContext:
            return Location(context, abspath[len(bestPath):])


    def checkTarget (self, src, dst, replaceExisting=False, createParents=False, overwrite=False, recursive=False, followLinks=False):
        if replaceExisting or not dst.exists(followLinks=followLinks):
            pass

        elif overwrite and (dst.isdir(followLinks) == src.isdir(followLinks)):
            pass

        elif dst.isdir(followLinks) or (dst.exists(followLinks) and src.isdir(followLinks)):
            locationTypes = ("non-directory", "directory")
            raise self.CannotOverwrite(location=dst.vfspath(),
                                       sourcetype=locationTypes[src.isdir(followLinks)],
                                       targettype=locationTypes[dst.isdir(followLinks)])

        else:
            raise self.TargetExists(location=dst.vfspath())

        dstdir = dst.dirname()
        if createParents and not dst.context.isdir(dstdir, followLinks):
            dst.context.makedir(dstdir, createParents=True)


    def recurse (self, src, dst, times, permissions, attributes, localtime, method, args=(), kwargs={}, exclude=(AttributeFile,)):
        queue = [ [] ]

        for top, foldernames, filenames in src.context.walk(src.path, topdown=True):
            relpath = queue[0]
            queue[:1] = [ relpath+[name] for name in foldernames ]

            srcdir = Location(src.context, src.filepath(*relpath))
            dstdir = Location(dst.context, dst.filepath(*relpath))

            if not dstdir.isdir():
                dstdir.context.makedir(dstdir.path)

            self.copyprops(srcdir, dstdir, times, permissions, attributes, localtime)

            excludednames = set()
            for mask in exclude:
                excludednames -= set(fnfilter(filenames, mask))

            for filename in filenames:
                if not filename in excludednames:
                    srcloc = Location(src.context, srcdir.filepath(filename))
                    dstloc = Location(dst.context, dstdir.filepath(filename))
                    method(srcloc, dstloc, *args, **kwargs)

    def move (self, src, dst, localtime=True):
        if src.context is dst.context:
            src.context.move(src.path, dst.path)

        else:
            self.copy(src, dst, recursive=True,
                      times=True, permissions=True, attributes=True, localtime=localtime)
            src.remove(recursive=True, ignoreMissing=True)


    def copy (self, src, dst, recursive=False, times=False, permissions=True, attributes=True, update=False, skipExisting=False, localtime=True):
        if src.context.samefile(src.path, dst.context, dst.path):
            raise self.SameFile(source=src.vfspath(), target=dst.vfspath())

        args = (times, permissions, attributes, localtime, update, skipExisting)
        if recursive and src.isdir(followLinks=True):
            return self.recurse(src, dst, times, permissions, attributes, localtime, self.copyfile, args=args)
        else:
            return self.copyfile(src, dst, *args)


    def copyfile (self, src, dst, times=False, permissions=True, attributes=True, localtime=True, update=False, skipExisting=False):
        intro = "copy: %s -> %s"%(src.vfspath(), dst.vfspath())

        if update or skipExisting:
            try:
                dsttime = dst.getTimes(localtime)[T_MODIFICATION]
                if skipExisting:
                    self.trace("%s skipped"%(intro,))
                    return

                srctime = src.getTimes(localtime)[T_MODIFICATION]
                if (dsttime >= srctime):
                    self.trace("%s skipped (not newer)"%(intro,))
                    return

            except EnvironmentError:
                pass

        if src.context is dst.context:
            try:
                copyfile = src.context.copyfile
            except AttributeError:
                pass
            else:
                self.trace("%s (delegating to %s context)"%(intro, src.context.scheme))
                return copyfile(src.path, dst.path, times, permissions, attributes, localtime)

        self.trace(intro)
        srcfile = dstfile = None
        try:
            try:
                srcfile = src.open(OP_READ)
                dstfile = dst.open(OP_WRITE)
                self.copyfileobj(srcfile, dstfile)
            finally:
                if srcfile:
                    srcfile.close()
                if dstfile:
                    dstfile.close()

            self.copyprops(src, dst, times, permissions, attributes, localtime)

        except Aborted:
            try:
                dst.remove()
            except EnvironmentError, e:
                self.notice("Failed to remove destination file %r after aborted copy operation: %s"%
                            (dst.vfspath(), scpiException(e).format()))
            raise



    def copyfileobj (self, infile, outfile, chunksize=1024*4):
        text = infile.read(chunksize)
        thread = currentThread()
        while text:
            outfile.write(text)
            thread.check()
            text = infile.read(chunksize)

    def copyprops (self, src, dst, times=False, permissions=True, attributes=True, localtime=True):
        if permissions:
            perms = src.getPermissions()
            dst.setPermissions(ignoreErrors=True, **perms)

        if times:
            times = src.getTimes(localtime=localtime)
            dst.setTimes(localtime=localtime, ignoreErrors=True, **times)

        if attributes:
            attributes = src.getAttributes()
            dst.setAttributes(attributes)


    def link (self, src, dst, symbolic=False, recursive=False, replaceExisting=False, attributes=True):
        method = lambda src, dst, *args, **kwargs: \
                 src.context.linkfile(src.path, dst.context, dst.path, *args, **kwargs)
        kwargs = dict(symbolic=symbolic, replaceExisting=replaceExisting, attributes=attributes)

        if recursive and src.isdir(followLinks=True):
            return self.recurse(src, dst, True, True, attributes, False, method=method, kwargs=kwargs)
        else:
            return method(src, dst, **kwargs)


    def glob (self, patterns, session=None, operation=None, followLinks=False, include=INCL_VISIBLE,
              filetype=ANY, descend=False, attributefilter=None, verify=False, ignoreMissing=False, runTriggers=True):

        results      = []
        #openContexts = set()
        openContexts = {}

        try:
            for pattern in patterns or  [""]:
                cxtmask, pathmask = self.splitLocation(pattern)
                cxtlist = fnfilter(self.contexts, cxtmask.lower())

                if not cxtlist and not ignoreMissing:
                    raise self.NoSuchContext(name=cxtmask)

                locations = discarded, accepted = [], []
                for cxtname in cxtlist:
                    if not cxtname in openContexts:
                        context = self.openContext(cxtname, session, operation)
                        context.enter(runTrigger=runTriggers)
                        openContexts[cxtname] = context

                    top = Location(context, "")
                    for loc in top.glob(pathmask, include, descend, verify=verify, ignoreMissing=ignoreMissing):
                        ismatch = (filetype == ANY) or (filetype == loc.filetype(followLinks, ignoreMissing=True))

                        if ismatch and attributefilter:
                            attributes = loc.getAttributes(ignoreMissing=True)
                            ismatch = loc.attributeMatch(attributes, attributefilter)

                        locations[ismatch].append(loc)

                if discarded and not accepted and not ignoreMissing:
                    attributefilter.update(location=pattern)
                    raise self.NoMatch(**attributefilter)

                results.extend(accepted)

        except Exception, e:
            self.exitContexts(openContexts.values(), ignoreErrors=True, runTriggers=runTriggers)
            raise

        else:
            return results, openContexts.values()


class FilesystemLeaf (FilesystemBase, Leaf):
    pass



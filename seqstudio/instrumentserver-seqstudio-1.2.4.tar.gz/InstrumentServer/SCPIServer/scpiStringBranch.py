########################################################################
### FILE:	scpiStringBranch.py
### PURPOSE:	String processing commands
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2018 ThermoFisher Scientific.  All rights reserved.
########################################################################

from scpiMinimalBranch import MinimalBranch
from scpiLeaf          import Leaf, Public, Observing, Administrative
from scpiBase          import Hidden
from scpiExceptions    import RunError
from commandParser     import parser
import urlparse, re, json, ast

class STRing (MinimalBranch):
    '''String processing commands'''

    class JOIN_Query (Observing, Leaf):
        '''
        Join the supplied strings and return the result.

    Examples:
        * Store the text "Some things" in the local variable "Things",
          then read the contents of that variable, and concatenate to
          the result the text " to ponder".  Finally, publish the result.

            LVAR Things "Some things"
            LVAR? Things
            CONCatenate? $@ " to ponder"
            PUBLish Topic $@
        '''

        def declareInputs (self):
           Leaf.declareInputs(self)
           self.setInput('delimiter', type=str, named=True, default='')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('strings', type=str)

        def run (self, delimiter='', includeEmpty=False, *strings):
            if not includeEmpty:
                strings = filter(None, strings)
            return delimiter.join(strings)


    class CONCatenate_Query (Hidden, JOIN_Query):
        '''Deprecated. See "JOIN?".'''

    class FILTer_Query (Observing, Leaf):
        '''
        Identify strings from a list that match a specified filter, and
        return corresponding output strings if specified, or their
        relative position in the input list if not.

    Examples:
        C: 1 FILTer? -mask=active -inputs=active,inactive,active -outputs=Lane1,Lane2,Lane3
        S: OK 1 Lane1,Lane3
        '''

        class MismatchedLists (RunError):
            "Mismatched number of items: %(inputs)d inputs, %(outputs)d outputs"


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("delimiter", type=str, default=",",
                          description=
                          "Delimiter between items in the input and output lists")
            self.setInput("mask", type=str,
                          description=
                          "A sequence of strings, separated by the delimiter, "
                          "each of which is matched against each item in the input list")
            self.setInput("inputs", type=str,
                          description=
                          "A sequence of strings, separated by the delimiter, "
                          "to be matched against the mask. For each matching string, "
                          "either its relative position in the list or its corresponding "
                          "item in the 'outputs' list is included in the result")
            self.setInput("outputs", type=str, default="",
                          description=
                          "A sequence of strings, separated by the delimiter. "
                          "If supplied, these should correspond to to items in the "
                          "input list; these will then be used instead of the numeric "
                          "position of each matching input string in the input list.")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("result", type=str,
                           description=
                           "Those items from 'outputs' which correspond to items in 'inputs' "
                           "that match the specified mask")


        def run (self, delimiter=",", mask=str, inputs=str, outputs=str):
            if delimiter:
                ilist = inputs.lower().split(delimiter)
                olist = outputs.split(delimiter)
                mlist = mask.lower().split(delimiter)
            else:
                ilist = list(inputs.lower())
                olist = list(outputs)
                mlist = [ mask.lower() ]


            if not outputs:
                olist = range(len(ilist))
            elif len(ilist) != len(olist):
                raise self.MismatchedLists(inputs=len(ilist), outputs=len(olist))

            result = [ str(o) for (i, o) in zip(ilist, olist) if i in mlist ]
            return delimiter.join(result)




    class ITEM_Query (Observing, Leaf):
        '''
        Pick one item from a list, separated by the specified delimiter
        '''

        class OutOfRange (RunError):
            "Item number %(index)s is not in the specified list"

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('last', type=bool, named=True, default=False,
                          description='Count from the end of the sequence towards the beginning')
            self.setInput('index', type=int, range=(1, None), description='Item number.')
            self.setInput('delimiter', type=str, default=None,
                          description='Separator between items in sequence; default is whitespace')
            self.setInput('default', type=str, named=True, default=None,
                          description='Value to return if the specified index is not contained in the list, rather tha raising error.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("item", type=str, default=None)


        def run (self, _session, checkRange=False, default=None, delimiter=None, last=False, index=int, sequence=str):
            try:
                if last:
                    nindex = -index
                else:
                    nindex = index-1

                if delimiter is None:
                    text, parts = _session.expandArgs(sequence)
                    opt, cooked, raw = parts[nindex]
                    return raw.strip() or default
                else:
                    return sequence.split(delimiter)[nindex] or default
            except IndexError:
                if default is None:
                    raise self.OutOfRange(index=index, sequence=sequence)
                return default

    class CONTAINS_Query (Observing, Leaf):
        '''
        Checks if there is at least one occurrence within the supplied string
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)

            self.setInput('regex', type=bool, default=False, named=True,
                          description='if contains is a regular expression')
            self.setInput('ignoreCase', type=bool, default=False, named=True,
                          description='ignores the case')
            self.setInput('value', type=str,
                          description='The string to check against')
            self.setInput('contains', type=str,
                          description='The string to check if there is an occurrence of')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("found", type=bool,
                           description='True if at least one occurrence was found')


        def run (self, regex=False, ignoreCase=False, value=str, contains=str):

            if ignoreCase:
                contains = contains.lower()
                value = value.lower()

            if regex:
                if re.match(contains, value):
                    return True
                else:
                    return False

            return contains in value


    class INDEX_Query (Observing, Leaf):
        '''
        Return position of the specified item in a sequence, starting with 1
        '''

        class NotFound (RunError):
            "Item %(item)r is not in the specified list"


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('delimiter', type=str, default=None,
                          description='Separator between items in sequence; default is whitespace')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput("index", type=int,
                           description='Position of item in the specified sequence, or 0 if not found')


        def run (self, ignoreMissing=False,
                 delimiter=None, item=str, sequence=str):

            try:
                return sequence.lower().split(delimiter).index(item.lower())+1
            except ValueError:
                if ignoreMissing:
                    return 0
                else:
                    raise self.NotFound(item=item, sequence=sequence)

    class REPLACE (Observing, Leaf):
        '''
        Replaces the all occurrences of the term with the value in the string provided

        :STR:REPLACE geeks Geeks "We are all geeks"

        returns "We are all Geeks"

        For more complex replacements substitution replacements can also be used.
        ${id/term/value} see help? substitutions for more information
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('value', type=str, named=False)
            self.setInput('term', type=str, named=False)
            self.setInput('string', type=str)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=str)

        def run (self, term=str, value=str, string=str):
            return string.replace(term, value)

    class COUNT_Query (Observing, Leaf):
        '''
        Count number of instances of a specified substring within a string
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('delimiter', type=str, default=None, named=True)
            self.setInput('match', type=str, default=None, named=True)
            self.setInput('string', type=str)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int)

        def run (self, ignoreMissing=False, includeEmpty=False, delimiter=None, match=None, string=str):
            items = string.lower().split(delimiter and delimiter.lower())
            if not includeEmpty:
                items = filter(None, items)

            if match:
                return items.count(match.lower())
            else:
                return len(items)


    class SPLIT_Query (Observing, Leaf):
        '''
        Split a string into individual arguments
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('delimiter', type=str, default=None, named=True)
            self.setInput('maxsplit', type=int, default=None, named=True)
            self.setInput('string', type=str)


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('argument', type=str, repeats=(0, None))


        def run (self, _session, _context, _branch,
                 includeEmpty=False, delimiter=None, maxsplit=None, ignoreCase=False, string=str):

            if maxsplit:
                args = (maxsplit,)
            else:
                args = ()

            if delimiter:
                if ignoreCase:
                    outputs = []
                    pos   = 0
                    for item in string.lower().split(delimiter.lower(), *args):
                        outputs.append(string[pos:pos+len(item)])
                        pos += len(item)+len(delimiter)
                else:
                    outputs = string.split(delimiter, *args)

            else:
                text, args = parser.expandArgs(string, context=_context)
                outputs = [ raw.strip() for (opt, val, raw) in args ]

            if not includeEmpty:
                outputs = filter(lambda output: bool(output), outputs)

            return tuple(outputs)


    class RegularEXpression_Enumerate (Observing, Leaf):
        '''
        Find all matches of a regular expression in a string.
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('delimiter', type=str, named=True, default=None,
                          description='Delimiter for discrete groups within each match. '
                          'If not provided, each group is returned as a separate output '
                          'argument, so the number of outputs will be an integer multiple '
                          'of the number of groups in the regular expression.')

            self.setInput('pattern', type=str,
                          description='PCRE-compatible regular expression pattern. '
                          'Groups to be matches should be enclosed in parenthesis. '
                          'For more documentiation, see: '
                          '<https://docs.python.org/library/re#re.findall>.')

            self.setInput('string', type=str,
                          description='String to be matched')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('matches', type=str, split=",", repeats=(0, None))

        def run (self, delimiter=None, pattern=str, string=str):
            matches = re.findall(pattern, string)
            if delimiter is None and matches and isinstance(matches[0], tuple):
                allgroups = []
                for groups in matches:
                    allgroups.extend(groups)
                return tuple(allgroups)
            else:
                return tuple(matches)


    class UniformResourceIdentifierSplit_Query (Observing, Leaf):
        '''
        Split an URI into individual components
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('defaultScheme', type=str, named=True, default='http')
            self.setInput('uri', type=str)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('scheme', type=str, named=True, default=None)
            self.addOutput('netloc', type=str, named=True, default=None)
            self.addOutput('path',   type=str, named=True, default=None)
            self.addOutput('query',  type=str, named=True, default=None)
            self.addOutput('fragment', type=str, named=True, default=None)
            self.addOutput('username', type=str, named=True, default=None)
            self.addOutput('password', type=str, named=True, default=None)
            self.addOutput('hostname', type=str, named=True, default=None)
            self.addOutput('port', type=str, named=True, default=None)

        def run (self, defaultScheme, uri):
            result = urlparse.urlsplit(uri, defaultScheme)
            outputs = [ getattr(result, output) for output in self.getOutputNames() ]
            return tuple(outputs)


    class UniformResourceIdentifierJoin_Query (Observing, Leaf):
        '''
        Split an URI into individual components
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('defaultScheme', type=str, named=True, default='http')
            self.setInput('base', type=str)
            self.setInput('addition', type=str)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('uri', type=str)

        def run (self, defaultScheme, base, addition):
            return urlparse.urljoin(base, addition)


    class JavaScriptObjectNotationDECode_Query (Observing, Leaf):
        '''
        Extract a single value from a JSON string.
        '''

        class InvalidJSON (RunError):
            '''Input is not a valid JSON representation'''

        class NoSuchElement (RunError):
            '''The specified element was not found in the provided JSON string.'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('string', type=str)
            self.setInput('element', type=str, repeats=(1,None))


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('output', type=tuple, default=None, repeats=(0, None))


        def run (self, ignoreMissing=False, string=str, *element):
            try:
                obj = json.loads(string)
            except Exception, e:
                raise self.InvalidJSON(string=string, message=str(e))

            path = []
            for e in element:
                try:
                    path.append(e)
                    obj = obj[e]
                except KeyError:
                    if ignoreMissing:
                        obj = None
                        break

                    raise self.NoSuchElement(string=string, element="/".join(path))

            if isinstance(obj, dict):
                items = [ (k,str(v)) for (k,v) in obj.items() if isinstance(v, basestring) ]

            elif isinstance(obj, (tuple, list)):
                items = [ (None, str(v)) for v in obj ]

            else:
                items = [ (None, str(obj)) ]

            return tuple(items)


    class JavaScriptObjectNotationENCode_Query (Observing, Leaf):
        '''
        Format string representation of Python objects into a JSON string
        '''


        class InvalidElement (RunError):
            '''Named input "%(input)s" is an invalid element'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('elements', type=tuple, repeats=(1, None), description='Each element is passed in as a named input: -<name>=<value>')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('json', type=str)


        def run (self, *elements):
            output = []

            for name, value, raw in elements:
                # Name is required
                if (name == None):
                    input = '-<None>=' + str(value)
                    raise self.InvalidElement(input=input)

                # Get JSON string representation of value
                try:
                    # Convert string representation of Python object to Python object
                    obj = ast.literal_eval(value)
                except (ValueError, SyntaxError):
                    # Treat failures as a string
                    obj = value
                finally:
                    # Convert Python object to JSON string
                    string = json.dumps(obj)

                # Append string to output
                output.append('"%s":%s'%(name, string))

            return ",".join(output).join("{}")

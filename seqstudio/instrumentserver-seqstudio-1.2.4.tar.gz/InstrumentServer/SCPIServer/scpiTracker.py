########################################################################
### FILE:	scpiTracker.py
### PURPOSE:	Run control/tracking for macros
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from sys                 import exc_info
from scpiBranch          import Branch, branchTypes
from scpiHelpLeaf        import HELP_Query
from scpiLeaf            import Observing, Controlling, Leaf, CommandWrapper, Singleton, Background
from scpiMacro           import Macro, MacroLeaf
from scpiDynamicBase     import Dynamic, DynamicCommandLeaf
from scpiExceptions      import RunError, NextReply, Error, InternalError, ExternalError
from scpiSession         import MacroSession
from subscription        import info, publish
from locking             import Event, Lock
from data                import DynamicData
from threadControl       import currentThread, Aborted

### Tracking triggers
TrackerEvents = ('Step', 'Paused', 'Resumed', 'Aborted', 'Stopped', 'Failed')
(T_STEP, T_PAUSED, T_RESUMED, T_ABORTED, T_STOPPED, T_FAILED) = range(len(TrackerEvents))


class TrackerSession (MacroSession):
    '''
    Macro session with tracking support.
    '''

    class NotRunning (RunError):
        "The tracker %(name)r is not currently running"


    def __init__ (self, name, parent, instream, access=None, **argmap):
        MacroSession.__init__(self, parent=parent, input=instream, access=access, **argmap)

        self.name       = name
        self.events     = [ None ] * len(TrackerEvents)
        self.action     = None
        self.notice     = None
        self.gotoindex  = None
        self.rewind     = False
        self.thread     = None
        self.exception  = None
        self.currentCommand = None
        self.currentIndex  = None


    def abort (self, index=None, exception=None):
        if self.thread:
            self.exception = exception
            self.setAction(index, (T_ABORTED, T_FAILED)[exception is not None], self.thread.abort, self.thread.check)

    def pause (self, index=None):
        if self.thread:
            self.setAction(index, T_PAUSED, self.thread.suspend, self.thread.check)

    def resume (self, index=None):
        if index:
            self.rewind, self.gotoindex = True, index

        if self.thread:
            self.setAction(index, T_RESUMED, self.thread.resume, None)

    def stop (self, index=None):
        if self.thread:
            self.setAction(index, T_STOPPED, self.thread.resume, self._stop)

    def _stop (self):
        self.gotoindex = "*END"


    def setAction (self, index, event, callbefore, callafter):
        if index is None and self.thread:
            if callbefore:
                callbefore()
            self.action = (index, event, None, callafter)
        else:
            self.action = (index, event, callbefore, callafter)


    def takeAction (self, index, **substitutions):
        try:
            (step, notice, callbefore, callafter) = self.action
        except TypeError:
            return False
        else:
            if step in (index, None):
                self.action = None
                self.trackNotice(notice, index=index or "-", **substitutions)
                if callbefore: callbefore()
                if callafter: callafter()
                return True
            else:
                return False


    def setAbort (self):
        if self.thread:
            self.thread.abort()


    def checkAbort (self):
        if self.thread:
            self.thread.check()


    def setNotice (self, event, topic, message):
        self.events[event] = (topic, message)

    def clearNotice (self, event):
        self.events[event] = None


    def lastNotice (self):
        return self.notice

    def trackNotice (self, event, **substitutions):
        try:
            topic, message = self.events[event]
        except TypeError:
            return

        parts = []
        for part in message:
            option, value = part[:2]
            for k, v in substitutions.items():
                value = value.replace("$"+k, str(v))
            parts.append((option, value))

        publish(topic, parts)
        self.notice = parts


    def handle (self, scope, *args, **kwargs):
        try:
            self.thread = currentThread()
            self.thread.addAbortAction(self.thread.resume)
            return MacroSession.handle(self, scope, *args, **kwargs)
        finally:
            self.thread.delAbortAction(self.thread.resume)
            self.thread = None


    def setFailure (self, error, event=T_FAILED, replace=True):
        if replace or self.exception is None:
            self.exception = error

        if self.exception:
            self.trackNotice(event, index=self.currentIndex, 
                             command=self.currentCommand or "",
                             error=self.exception.format())


    def getCommand (self, instream, *args, **kwargs):
        command = None
        while not command or self.rewind:
            if self.rewind:
                instream.seek(0)
                self.rewind = False

            try:
                commandtext, index, command, commandargs = \
                             parts = \
                             self.expandParts(instream, *args, **kwargs)
                self.currentCommand = commandtext.strip()
                self.currentIndex   = index or ""
            except self.ParseError, e:
                self.currentCommand = None
                self.currentIndex  = None
                if not self.gotoindex:
                    raise

            if self.gotoindex:
                if self.gotoindex != index:
                    command = None
                    continue
                else:
                    self.gotoindex = None

            while self.takeAction(index, command=commandtext or ""):
                pass


        self.trackNotice(T_STEP, index=(index or "-"), command=commandtext.strip())
        return parts



class TrackerBranch (Dynamic, CommandWrapper, Branch):
    TypeName           = 'tracker branch'
    session            = None

    def __init__ (self, text, parentSession, macro, parameters, *args, **opts):
        Branch.__init__(self, *args, **opts)
        self.text     = text
        self.idle     = Event()
        self.idle.set()
        self.macro    = macro
        self.parameters = parameters

        stream = self.commandStream(text)
        self.session  = TrackerSession(name=self.name,
                                       parent=parentSession,
                                       description='Macro %r tracker %r'%(self.macro, self.name),
                                       instream=stream)


    from scpiHelpLeaf import HELP_Query


    class RUN (Singleton, Controlling, Background, Leaf):
        '''
        Start running the tracker.
        '''

        def run (self, _context):
            self.parent.idle.clear()
            self.parent.session.instream.seek(0)
            self.parent.session.setFailure(None)
            return (_context,)

        def next (self, _context):
            parent = self.parent
            try:
                try:
                    return self.parent.session.handle(scope=self.parent.parent,
                                                      invocation=_context.invocation,
                                                      localdata=DynamicData(self.parent.parameters))

                except Error, e:
                    parent.session.setFailure(e)
                    raise

                except Aborted, e:
                    error = ExternalError(e)
                    parent.session.setFailure(error, T_ABORTED, replace=False)
                    raise

                except Exception, e:
                    error = InternalError(e, exc_info())
                    parent.session.setFailure(error)
                    raise 

            finally:
                parent.idle.set()
                    
                


    class WAIT (Observing, Leaf):
        '''
        Wait for the tracker to complete
        '''

        class Timeout (RunError):
            '''Timed out waiting for tracker %(tracker)r after %(timeout).1f seconds'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignoreTimeout', type=bool, default=False, named=True)
            self.setInput('ignoreErrors', type=bool, default=False, named=True)
            self.setInput('timeout', type=float, units='seconds')

        def run (self, ignoreTimeout=False, ignoreErrors=False, timeout=None):
            self.parent.idle.wait(timeout)

            if self.parent.session.exception and not ignoreErrors:
                raise self.parent.session.exception
            
            elif timeout is not None and not ignoreTimeout and not self.parent.idle.isSet():
                raise self.Timeout(timeout=timeout, tracker=self.parent.name)

        

    class PAUSE (Controlling, Leaf):
        '''
        Pause the tracker at the specified step.
        If no step is specified, pause before the next step.
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=str, default=None,
                          description='If specified, do not pause immediately, but at '
                          'the specified command index')

        def run (self, index):
            self.parent.session.pause(index or None)


    class RESUME (Controlling, Leaf):
        '''
        Resume the tracker from the specified step.
        If no step is specified, resume from where it was last paused.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=str, default=None,
                          description='If specified, indicates a command index '
                          'from which to resume')

        def run (self, index):
            self.parent.session.resume(index or None)
        

    class ABORT (Controlling, Leaf):
        '''
        Abort the execution of the specified tracker at the specified step.
        If no step number is specifed, abort immediately
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=str, default=None,
                          description='If specified, indicates a command index '
                          'at which to abort')

        def run (self, index):
            self.parent.session.abort(index or None)


    class ERRor_Set (Controlling, Leaf):
        '''
        Fail execution of this tracker at the specified step, with the specified error code and text.
        If no step number is specifed, abort immediately
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=str, default=None,
                          description='If specified, indicates a command index '
                          'at which to abort')


        def run (self, index, state=str, id=str, *message, **options):
            obj = self.parent.getState(state)

            if id and id[0] + id[-1] == '[]':
                id = id[1:-1]

            message = list(message)
            while message and message[0] == Error.contextSeparator:
                del message[0]

            error = UserError(id, ' '.join(message), **options)
            self.parent.session.abort(index or None, error)



    class STOP (Controlling, Leaf):
        '''
        End the execution of the specified tracker at the specified step.
        If no step number is specified, end after the current step.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('index', type=str, default=None,
                          description='If specified, indicates a command index at '
                          'which to end')

        def run (self, index):
            self.parent.session.stop(index or None)


    class INPuts_Query (Observing, Leaf):
        '''
        Return the macro input arguments for this tracker
        '''
        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('output', type=tuple, repeats=(0, None))

        def run (self):
            return tuple(self.parent.parameters.items())

    class TEXT_Query (Observing, Leaf):
        '''
        Return the body of the macro executed by this tracker
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('text', type=str)

        def run (self):
            return (self.parent.text,)


    class MACRo_Query (Observing, Leaf):
        '''
        Return the name of the macro executed by this tracker
        '''

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('name', type=str)

        def run (self):
            return (self.parent.macro,)


    class TRACK (Controlling, Leaf):
        '''
        Publish messages upon the occurance of specific events related
        to the execution of this tracker.

        Prior to publication, the following substitutions are
        performed in the message text:

            $index - The command index, i.e. the optional prefix, for
                     each command in the associated macro.   If a command
                     is not indexed, no message is published.
            $command - The entire command, including any leading index and arguments.
        
        '''
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('message', type=tuple, repeats=(1, None))

        def run (self, event=TrackerEvents, topic=str, *message):
            self.parent.session.setNotice(event, self.parent.parent.commandPath(topic), message)


    class TRACK_Clear (Controlling, Leaf):
        '''
        Stop publishing events related to this tracker
        '''

        def run (self, event=TrackerEvents):
            self.parent.session.clearNotice(event)



    class TRACK_Query (Observing, Leaf):
        '''
        Return current tracking status
        '''
        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('message', type=str, default=None)

        def run (self):
            return self.parent.session.lastNotice()



class TrackerLeaf (DynamicCommandLeaf):
    _dynamicCommandType = TrackerBranch



class TRACKer_Add (Controlling, TrackerLeaf):
    '''
    Create a new tracker to control the execution of the specified
    macro.  A tracker is represented as a branch, containing commands
    to start, pause, resume, and abort execution, as well as to
    publish information about the progress.
    '''


    def declareInputs (self):
        TrackerLeaf.declareInputs(self)
        self.setInput('replaceExisting',
                      description=
                      'If another tracker by the same name already exists, '
                      'replace it')

        self.setInput('name',
                      type=str,
                      description='Name of the new tracker')

        self.setInput('macro',
                      type=str,
                      description='Name of the macro to track')

        self.setInput('arguments',
                      type=tuple,
                      repeats=(0, None),
                      description='Arguments to the macro')


    def run (self, _session,
             replaceExisting=False, hidden=False, name=str, macro=str, *arguments):
        obj  = self.findDynamicCommand(macro, searchType=Macro, parent=self.parent)
        args, opts, argmap = obj.parseInputs(arguments, externalOnly=True)
        text, parameters = obj.substituteArgs(args, opts)
        new  = self.incarnate(name, TrackerBranch, parent=self.parent,
                              text=text, parentSession=_session, macro=macro, parameters=parameters)
        self.addinstance(_session, name, new,
                         replaceExisting=replaceExisting, hidden=hidden, parent=self.parent)



class TRACKer_Remove (Controlling, TrackerLeaf):
    '''
    Delete a dynamic branch previously created within this scope.
    '''
    def run (self, _session, ignoreMissing=False, name=str):
        self.delinstance(_session, name, ignoreMissing, parent=self.parent)



class TRACKer_Query (Observing, TrackerLeaf):
    '''
    List the contents of a branch.
    '''
    
    def declareOutputs (self):
        TrackerLeaf.declareOutputs(self)
        self.addOutput('text', type=str, default='')


    def run (self, ignoreMissing=False, name=str):
        
        obj = self.findDynamicCommand(name, parent=self.parent, allowMissing=ignoreMissing)
        if obj:
            return obj.text



class TRACKer_Enumerate (Observing, TrackerLeaf):
    '''
    Return a list of dynamic subbranches in this branch.
    '''

    def declareOutputs (self):
        TrackerLeaf.declareOutputs(self)
        self.addOutput('name', type=str, repeats=(0, None))

    def run (self):
        return tuple(self.listinstances(parent=self.parent))


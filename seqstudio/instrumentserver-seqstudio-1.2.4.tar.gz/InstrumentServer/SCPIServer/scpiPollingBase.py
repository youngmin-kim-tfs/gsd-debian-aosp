########################################################################
### FILE:	scpiPollingBase.py
### PURPOSE:	Instrument State Framework
### HISTORY:
###  2016-06-30 Tor Slettnes
###             Created.
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from scpiMinimalBranch import MinimalBranch
from scpiLeaf          import Controlling, Observing, Leaf
from scpiExceptions    import RunError, NextControl, SessionControl, Error, InternalError
from scpiParameter     import autoType
from scpiSession       import Context, MacroSession, RAISE
from scpiVariableLeaf  import VariableLeaf
from data              import DynamicData, Container
from schedule          import schedule, unschedule, scheduleList
from subscription      import addTopic, topicExists, publish, info, notice, warning
from commandParser     import parser, QUOTE_AUTO, QUOTE_ALWAYS, CookedValue
from threading         import RLock
from time              import time
from re                import compile as rxcomp
from sys               import exc_info

PollItemTypes = {}
TimeKey = 'timestamp'

class PollItem (object):
    typename = 'string'

    class StringConversionError (RunError):
        "Unable to convert value %(value)r to string using format %(format)r"

    def __init__ (self, name, args, session, scope, format):
        self.name      = name
        self.args      = args
        self.scope     = scope
        self.format    = format
        self.value     = name

    def update (self, value):
        self.value = [value]

    def acquire (self):
        pass

    def collect (self, ref):
        return [self.value]

    def clear (self, ref):
        pass

    def string (self, value, formatted=True):
        if self.format and formatted:
            try:
                return self.format%(value,)
            except TypeError, e:
                raise self.StringConversionError(format=self.format, value=value)

        elif value is None:
            return ""

        elif isinstance(autoType(value), basestring):
            return '"%s"'%(value,)

        else:
            return str(value)


class Timestamp (PollItem):
    typename = 'timestamp'

    def acquire (self):
        pass

    def collect (self, ref):
        return time(),


class CommandQuery (PollItem, MacroSession):
    typename = 'command'

    class NoOutputs (RunError):
        "Cannot include %(command)r in poll, because it does not return any outputs"


    def __init__ (self, name, args, session, scope, format):
        PollItem.__init__(self, name, args, session, scope, format)
        MacroSession.__init__(self, session, None, description="poll %r"%(self.name,), )
        scope.locate(name)
        self.context = Context(self, scope)

    def acquire (self):
        try:
            context = self.runParts(self.context, self.name, self.args, nextReply=RAISE, catchReturn=True)
            return context.outputs
        except NextControl, e:
            return e

    def collect (self, ref):
        if isinstance(ref, NextControl):
            leaf, method, args, kwargs = ref.args
            response = method(*args, **kwargs)
            outputs = leaf.formatOutputs(response)
        else:
            outputs = ref

        return [part[CookedValue].strip() for part in outputs]



class VariablePoll (PollItem, VariableLeaf):
    typename = 'variable'

    def __init__ (self, name, args, session, scope, format):
        PollItem.__init__(self, name, args, session, scope, format)

        try:
            branch, variable = name.rsplit(":", 1)
        except ValueError:
            self.branch   = scope
            self.variable = name
        else:
            if branch:
                self.branch    = scope.find(branch)
            else:
                self.branch    = scope.top

            self.variable = variable

    def clear (self):
        scope, data, value = self.dataProxy(None, None, self.variable, datatype=list, ignoreMissing=True, branch=self.branch)
        if data:
            data[self.variable] = []


    def collect (self, ref):
        scope, data, value = self.dataProxy(None, None, self.variable, datatype=list, default=[], branch=self.branch)
        return [ autoType(v) for v in value ]



class Poll (object):

    def __init__(self, name, interval, capturesize, topic, retries, delimiter=","):
        self._mutex      = RLock()
        self.name        = name
        self.schedulekey = 'Poll-%s'%(name,)
        self.interval    = interval
        self.retries     = retries
        self.failures    = {}
        self.delimiter   = delimiter
        self.items       = []
        self.captures    = []
        self.captureSize = capturesize
        self.topic       = topic
        if not topicExists(self.topic):
            addTopic(self.topic)

    def start (self, interval=None, topic=None, retries=None):
        if interval is None:
            interval = self.interval

        if topic is None:
            topic = self.topic

        if retries is None:
            retries = self.retries

        schedule(self.schedulekey, interval, self.pollAndPublish, args=(topic,), retries=retries, waitstart=True)


    def stop (self, wait=False):
        try:
            unschedule(self.schedulekey, wait=wait)
        except KeyError:
            pass


    def poll (self):
        try:
            previous = self.captures[-1].copy()
        except IndexError:
            previous = {}

        readings = {}

        with self._mutex:
            pending = []

            for item in self.items:
                if item.static:
                    try:
                        readings[item.name.lower()] = previous[item.name.lower()]
                        continue
                    except KeyError:
                        pass

                try:
                    pending.append((item, [ (obj, obj.acquire()) for obj in item.objects ]))
                except Error, e:
                    pending.append((item, e))


        for item, requests in pending:
            failures = self.failures.pop(item.name, 0)
            outputs  = []

            try:
                if isinstance(requests, Exception):
                    raise requests

                for obj, ref in requests:
                    for value in obj.collect(ref) or ():
                        outputs.append((obj, value))

            except Error, e:
                if failures < self.retries:
                    action = "%d retries remaining"%(self.retries - failures)
                    log    = info
                    self.failures[item.name] = failures+1
                else:
                    action = "removing from poll"
                    log    = notice
                    self.removeItem(item.name)

                log('Poll %r failed to get item %r, %s: %s'%
                    (self.name, item.name, action, e.format(showID=True, showArgs=True, showContext=True)))

            except Exception, e:
                error = InternalError(e, exc_info())
                self.removeItem(item.name)

                notice("Poll %s encountered internal error while getting item %s, removing: %s"%
                       (self.name, item.name, error.format(showID=True, showArgs=True, showContext=True)))

            else:
                readings[item.name.lower()] = outputs

        with self._mutex:
            self.captures.append(readings)
            if self.captureSize and len(self.captures) > self.captureSize:
                del self.captures[:len(self.captures) - self.captureSize]

        return readings


    def getParts (self, captures=None, short=False, count=None, clear=False, formatted=False, alwaysNamed=False):
        with self._mutex:
            if captures is None:
                captures = self.captures

            if count:
                captures = captures[-count:]

            parts = []
            for item in self.items:
                if not (item.named or alwaysNamed):
                    key = None
                elif short:
                    key = item.shortname
                else:
                    key = item.name

                strings = []
                values  = []
                for readings in captures:
                    for obj, output in readings.get(item.name.lower(), ()):
                        strings.append(obj.string(output, formatted=formatted))
                        values.append(output)
                    if item.single:
                        break

                string = item.delimiter.join(strings)
                if not item.single:
                    part = (key, string, values)
                elif values:
                    part = (key, string, values[0])
                else:
                    part = (key, string, None)

                parts.append(part)

            if clear:
                self.clearCapture()

            return parts

    def publish (self, topic):
        captures = self.captures[-1:]
        try:
            obj, timestamp = captures[0][TimeKey][0]
        except (KeyError, ValueError, IndexError):
            timestamp = time()

        publish(topic or self.topic, self.getParts(captures), timestamp=timestamp)

    def pollAndPublish (self, topic):
        self.poll()
        self.publish(topic)

    def addItem (self, name, shortname, objects=None, delimiter=",", named=True, static=False, single=False, autoClear=False):
        item = Container(name=name, shortname=shortname, named=named,
                         objects=objects or [], delimiter=delimiter, static=static, single=single, autoClear=autoClear)

        with self._mutex:
            self.items.append(item)

        return item

    def removeItem (self, name):
        with self._mutex:
            index = self._tagIndex(name)
            if index is not None:
                del self.items[index]
                return True
            else:
                return False

    def getItem (self, name):
        with self._mutex:
            index = self._tagIndex(name)
            if index is not None:
                return self.items[index]

                
    def getObjects (self, name):
        item = self.getItem(name)
        if item:
            return item.objects

    def setValues (self, name, values):
        item = self.getItem(name)
        if item:
            for (obj, value) in zip(item.objects, values):
                obj.value = value

        return bool(item)

    def _tagIndex (self, name):
        tagkey = name.lower()
        for index, item in enumerate(self.items):
            if item.name.lower() == tagkey:
                return index
        else:
            return None

    def startCapture (self, size=0, keep=0):
        del self.captures[:-keep]
        self.captureSize = size

    def stopCapture (self):
        self.captureSize = 1

    def clearCapture (self):
        del self.captures[:]
        with self._mutex:
            for item in self.items:
                if item.autoClear:
                    for obj in item.objects:
                        obj.clear()


    def getFromCapture (self, tags, indices=None):
        if tags is None:
            keys = [ item.name.lower() for item in self.items ]
        else:
            keys = [ tag.lower() for tag in tags ]

        if indices is None:
            indices = [ None ] * len(keys)

        records = []

        with self._mutex:
            for capture in self.captures:
                record = []
                for (key, index) in zip(keys, indices):
                    try:
                        items = capture[key]
                        if index is not None:
                            items = [items[index]]
                    except (KeyError, IndexError):
                        break
                    else:
                        record.extend(items)
                else:
                    records.append(record)

        return records
 
    def getValuesFromCapture (self, tags, indices=None):
        return [ tuple([ output for obj, output in items ])
                 for items in self.getFromCapture(tags, indices) ]

    def getCaptureByTags (self, tags, indices=None):
        if tags is None:
            tags = [ item.name for item in self.items ]

        records        = self.getFromCapture(tags, indices)
        valuesbytag    = zip(*records)
        captureByTags  = zip(tags, valuesbytag)
        return captureByTags

    def getCaptureAsParts (self, tags, indices=None, formatted=True):
        parts = []
        for tag, items in self.getCaptureByTags(tags, indices):
            strings = []
            for obj, value in items:
                if obj:
                    string = obj.string(value, formatted=formatted)
                else:
                    string = str(value)

                strings.append(string)

            parts.append((tag, ",".join(strings)))
        return parts


class POLL (MinimalBranch):
    '''Commands to poll and publish data values at regular intervals'''

    class PollExists (RunError):
        '''A poll named %(poll)r already exists'''

    class NoSuchPoll (RunError):
        '''No such poll poll exists %(poll)r'''

    class ItemExists (RunError):
        '''The poll %(poll)r already has any data item named %(key)r'''

    class NoSuchItem (RunError):
        '''The poll %(poll)r does not have any data item named %(key)r'''

    class NoSuchItemValue (RunError):
        '''The poll %(poll)r item %(key)r does not have any value named %(item)r'''



    def __init__ (self, *args, **kwargs):
        MinimalBranch.__init__(self, *args, **kwargs)
        self.polls = DynamicData()


    def addPoll (self, name, interval, capturesize, delimiter, topic, retries, timestamped=True, replaceExisting=False):
        if not replaceExisting and name in self.polls:
            raise self.PollExists(poll=name)

        poll = Poll(name, interval=interval, capturesize=capturesize, topic=topic,
                    retries=retries, delimiter=delimiter)

        if timestamped:
            obj = Timestamp(None, (), None, None, "%.3f")
            poll.addItem(TimeKey, TimeKey, objects=[obj], delimiter=delimiter, named=True, single=True)
            
        self.polls[name] = poll


    def removePoll (self, name, ignoreMissing=False):
        try:
            poll = self.polls.pop(name)
            poll.stop()
        except KeyError, e:
            if not ignoreMissing:
                raise self.NoSuchPoll(poll=name)
            

    def getPoll (self, name, ignoreMissing=False):
        try:
            return self.polls[name]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchPoll(poll=name)

            
    def addItem (self, pollname, name, shortname, objectclass, objectname, objectargs,
                 session, scope, keep, replace, append, named, static, single, autoClear, format, delimiter):
                  

        poll  = self.getPoll(pollname)

        #if replace:
        #    poll.removeItem(name)

        objects = poll.getObjects(name)
        if objects is None:
            item = poll.addItem(name, shortname, 
                                delimiter=delimiter, named=named, static=static, single=single, autoClear=autoClear)
            objects = item.objects

        elif replace:
            del objects[:]

        elif not append and not keep:
            raise self.parent.ItemExists(poll=pollname, key=name)

        if not keep or not objects:
            obj = objectclass(objectname, objectargs, session, scope, format)
            objects.append(obj)


    def removeItems (self, pollname, name, itemname, ignoreMissing=False):
        poll  = self.getPoll(pollname)

        try:
            item = poll.getItem(name)

        except TypeError:
            if not ignoreMissing:
                raise self.NoSuchItem(poll=pollname, key=name)

        else:
            if itemname:
                for index, candidate in enumerate(item.objects):
                    if candidate.name.lower() == itemname.lower():
                        del items[index]
                        break

                else:
                    if not ignoreMissing:
                        raise self.NoSuchItemValue(poll=pollname, key=name, item=itemname)

            else:
                poll.removeItem(name)
        


    def getLastPoll (self, pollname, names, tagged=True, short=False, ignoreMissing=False):
        poll  = self.getPoll(pollname)
        items = poll.getParts(poll.captures[-1:], short=short)

        if names:
            outputs = []
            for name in names:
                for item in items:
                    key, string, value = item
                    if key.lower() == name.lower():
                        outputs.append(((None, key)[tagged], string))
                        break
                else:
                    if not ignoreMissing:
                        raise self.NoSuchItem(poll=pollname, key=name)
            items = outputs

        return items

    class POLL_Add (Controlling, Leaf):
        '''Create a new poll'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('topic', type=str, named=True, default=None,
                          description='Publication topic')

        def run (self, _scope, replaceExisting=False, interval=1.0, capturesize=1,
                 delimiter=",", topic=None, retries=2, name=str):
            if topic is None:
                topic = _scope.commandPath(name, short=True)

            self.parent.addPoll(name, interval, capturesize,
                                delimiter, topic, retries, replaceExisting=replaceExisting)


    class POLL_Remove (Controlling, Leaf):
        '''Create a new poll'''

        def run (self, ignoreMissing=False, name=str):
            self.parent.removePoll(name, ignoreMissing)


    class POLL_Query (Observing, Leaf):
        '''Return information about an existing poll'''


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('running', type=bool, named=True, default=None)
            self.addOutput('interval', type=float, named=True, default=None)
            self.addOutput('capturesize', type=int, named=True, default=None)
            self.addOutput('delimiter', type=str, named=True, default=None)
            self.addOutput('topic', type=str, named=True, default=None)
            self.addOutput('retries', type=int, named=True, default=None)
            self.addOutput('items', type=str, named=True, split=',')

        def run (self, ignoreMissing=False, name=str):
            poll = self.parent.getPoll(name, ignoreMissing=ignoreMissing)
            if poll:
                running  = poll.schedulekey in scheduleList()
                names    = [item.name for item in poll.items]
                return (running, poll.interval, poll.captureSize, poll.delimiter, poll.topic, poll.retries, names)
            

    class POLL_Enumerate (Observing, Leaf):
        '''Return a list of pollers'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))

        def run (self):
            return tuple(sorted(self.parent.polls.keys()))


    class ITEM_Add (Controlling, Leaf):
        '''Add a one or more data items to be included in a poll'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('format', type=str, named=True, default=None)
            self.setInput('static', type=bool, named=True, default=False,
                          description='Perform only an initial reading; '
                          'value is retained in subsequent captures until explicitly cleared (see "CAPTure~"). '
                          'Implies "-single"')
            self.setInput('single', type=bool, named=True, default=False,
                          description='Include only the first available reading capture summary.')
            self.setInput('autoClear', type=bool, named=True, default=False,
                          description='Clear the contents of this variable with the "CAPTure~" command.')
            self.setInput('short', type=str, named=True, default=None,
                          description="Short key name, for 'VALue? -short' and 'JSON? -short' queries")
            self.setInput('item', type=tuple, repeats=(1, None))


        def run (self, _session, _scope, keepExisting=False, replaceExisting=False, named=True, append=True, 
                 delimiter=",", format=None, static=False, single=False, autoClear=False,
                 poll=str, short=str, key=str, type=PollItemTypes, *item):

            args = list(item)
            opt, item, raw = args.pop(0)

            self.parent.addItem(poll, key, short or key, type, item, args, _session, _scope,
                                keepExisting, replaceExisting, append, named, static, static or single, autoClear, format, delimiter)


    class ITEM_Remove (Controlling, Leaf):
        '''Remove one or more data items from a poll'''
        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('item', type=str, default=None)


        def run (self, ignoreMissing=False, delimiter=",", poll=str, key=str, item=''):
            self.parent.removeItems(poll, key, item, ignoreMissing)

            
    class ITEM_Enumerate (Observing, Leaf):
        '''Return names of items being queried in this poll'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('key', type=str, default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('keys', type=str, repeats=(0, None))

        def run (self, ignoreMissing=False, poll=str, key=''):
            poll = self.parent.getPoll(poll, ignoreMissing=ignoreMissing)
            if not poll:
                items = []

            if key:
                items = [obj.name for obj in poll.getItem(key).objects if obj.name]
            else:
                items = [item.name for item in poll.items]

            return tuple(items)


    class ITEM_Exists (Observing, Leaf):
        '''Indicate whether the specified item exists in this poll'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('key', type=str, default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('exists', type=bool)

        def run (self, poll=str, key=''):
            poll = self.parent.getPoll(poll, ignoreMissing=True)
            if not poll:
                return False
            elif not key:
                return True
            elif poll.getItem(key):
                return True
            else:
                return False


    class ITEM_Query (Observing, Leaf):
        '''Return information about item values '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('short', type=str, named=True, default=None)
            self.addOutput('named', type=bool, named=True, default=None)
            self.addOutput('single', type=bool, named=True, default=None)
            self.addOutput('delimiter', type=str, named=True, default=None)
            self.addOutput('data', type=str, named=True, split=",", default=None)
            self.addOutput('types', type=str, named=True, split=",", default=None)

        def run (self, ignoreMissing=False, poll=str, key=str):
            poll = self.parent.getPoll(poll, ignoreMissing=ignoreMissing)
            if poll:
                item = poll.getItem(key)
                if item:
                    return (item.shortname, item.named, item.single, item.delimiter, 
                            [obj.name for obj in item.objects],
                            [obj.typename for obj in item.objects])

                elif not ignoreMissing:
                    raise self.parent.NoSuchItem(poll=poll.name, key=key)


    class CAPTure_Add (Controlling, Leaf):
        '''Start capturing data from the specified poll, for later retrieval or processing.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('keep', type=int, default=0,
                          description="Number of existing items to keep in capture history")

            self.setInput('count', type=int, default=None, range=(0, None),
                          description="Maximum number of polls to capture (0 means unlimited)")

        def run (self, keep=0, poll=str, count=0):
            poll = self.parent.getPoll(poll)
            poll.startCapture(count, keep=keep)


    class CAPTure_Remove (Controlling, Leaf):
        '''Stop capturing data from the specified poll.'''

        def run (self, poll=str):
            poll = self.parent.getPoll(poll)
            poll.stopCapture()
        

    class CAPTure_Clear (Controlling, Leaf):
        '''Clear captured data from the specified poll.'''

        def run (self, poll=str):
            poll = self.parent.getPoll(poll)
            poll.clearCapture()
        

    class CAPTure_Count (Observing, Leaf):
        '''Return number of data points in the specified poll.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('size', type=bool, named=True, default=False,
                          description='Return configured size instead of current number of items.')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('count', type=int, default=0)

        def run (self, size=False, poll=str):
            poll = self.parent.getPoll(poll, ignoreMissing=True)
            if poll:
                if size:
                    return poll.captureSize
                else:
                    return len(poll.captures)


    class CAPTure_Query (Observing, Leaf):
        '''Obtain captured data from the specified poll.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('tags', type=str, split=",", default=None)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('data', type=tuple, repeats=(0, None))

        def run (self, tags=None, formatted=False, poll=str):
            poll  = self.parent.getPoll(poll)
            items = poll.getCaptureAsParts(tags, formatted=formatted)
            return tuple(items)


    class START (Controlling, Leaf):
        '''Start the specified poll'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('interval', type=float, named=True, default=None,
                          description='Polling interval. '
                          'If not specified, use the default interval for this poll')

            self.setInput('retries', type=int, named=True, default=None,
                          description='Numbe of retries after failed attempts. '
                          'If not specified, use the default interval for this poll')

            self.setInput('topic', type=str, named=True, default=None,
                          description='Message topic. '
                          'If not specified, use the default interval for this poll')


        def run (self, poll=str, interval=None, retries=None, topic=None):
            poll = self.parent.getPoll(poll)
            poll.start(interval=interval, retries=retries, topic=topic)
            

    class STOP (Controlling, Leaf):
        '''Stop the specified poll, if running'''

        def run (self, ignoreMissing=False, wait=False, poll=str):
            poll = self.parent.getPoll(poll, ignoreMissing)
            if poll:
                try:
                    poll.stop(wait=wait)
                except KeyError:
                    pass

    class PUBLish (Controlling, Leaf):
        '''Publish a single reading from this poll.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('capture', type=bool, named=True, default=False,
                          description='Capture current values before publishing')

            self.setInput('topic', type=str, named=True, default=None,
                          description='Message topic. '
                          'If not specified, use the default interval for this poll')


        def run (self, capture=False, topic=None, poll=str):
            poll = self.parent.getPoll(poll)
            if capture:
                poll.poll()
            poll.publish(topic)
            

    class SUM_Query (Observing, Leaf):
        '''
        Return the sum of data points from captured data.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('tag', type=str, 
                          description='Poll item containing data points')

            self.setInput('index', type=int, range=(0,None), default=0,
                          description="Index to desired data items")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('coefficients', type=float, repeats=(1,None))

        
        def run (self, poll=str, tag=str, index=0):
            poll   = self.parent.getPoll(poll)
            values = [ value for (value,) in poll.getValuesFromCapture((tag,), (index,)) ]
            return sum(values)


    class AVeraGe_Query (Observing, Leaf):
        '''
        Return the average of data points from captured data.
        '''

        class NoData (RunError):
            '''There is no data available for the specified poll item(s)'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('tag', type=str, 
                          description='Poll item containing data points')

            self.setInput('index', type=int, range=(0,None), default=0,
                          description="Index to desired data items")


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('coefficients', type=float, repeats=(1,None))

        
        def run (self, poll=str, tag=str, index=0):
            poll   = self.parent.getPoll(poll)
            values = [ value for (value,) in poll.getValuesFromCapture((tag,), (index,)) ]
            if not values:
                raise self.NoData(poll=poll.name, tag=tag)
            return sum(values) / len(values)




    class REGRession_Query (Observing, Leaf):
        '''
        Perform a least-squares fit of a Nth degree polynomial
        (default is 1 == linear) to one set of data points with
        respect to another.  Return coefficients for each term,
        starting with the constant term.

        Domain and range data comes from captured data polls;
        see the "CAPTure+" and "CAPTure-" commands.
        '''

        Methods = ("LeastSquaresFit",)
        (MTD_LEASTSQUARES,) = range(len(Methods))

        class NoData (RunError):
            '''There is no data available for the specified poll item(s)'''

        class InsufficientEntropy (RunError):
            '''There are not enough distinct data points availble for a regression of degree %(degree)s'''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('degree', type=int, named=True, default=1,
                          description='Polynomial degree (0=constant, 1=linear, ...)')

            self.setInput('domain', type=str, named=True, default=TimeKey,
                          description='Poll item containing domain data, i.e. points on "X" axis')

            self.setInput('default', type=float, named=True, split=",", default=None)

            self.setInput('indices', type=int, named=True, range=(0,None), default=(0, 0), split=(","),
                          description="Index to desired data items within domain data and range data, respectively")

            self.setInput('range', type=str,
                          description='Poll item containing range data, i.e. points on "Y" axis')



        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('coefficients', type=float, repeats=(1,None))


        def run (self, poll=str, degree=1, default=None, indices=None, domain=TimeKey, range=str):
            poll = self.parent.getPoll(poll)
            tags = (domain, range)
            pairs = poll.getValuesFromCapture((domain, range), indices)

            if not pairs:
                if default:
                    return tuple(default)
                else:
                    raise self.NoData(poll=poll.name, domain=domain, range=range)


            xdata, ydata = zip(*pairs)
            xSum  = sum(xdata)
            ySum  = sum(ydata)
            xSquaredSum = sum([x**2 for x in xdata])
            xySum = sum([x*y for x,y in pairs])

            denominator = len(pairs)*xSquaredSum - xSum**2
            if denominator:
                constant = (ySum*xSquaredSum - xSum*xySum) / denominator
                slope    = (len(pairs)*xySum - xSum*ySum) / denominator
                return constant, slope

            elif default:
                return tuple(default)

            else:
                raise self.InsufficientEntropy(degree=degree)
        


    class VALue_Query (Observing, Leaf):
        '''Return the specified data items from the most recent reading of this poll'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('shortKeys', description='Use "short" key names')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('value', type=tuple, repeats=(0, None));
            
        def run (self, named=False, ignoreMissing=False, shortKeys=False, poll=str, *items):
            lastpoll = self.parent.getLastPoll(poll, items,
                                               tagged=named or not items,
                                               short=shortKeys,
                                               ignoreMissing=ignoreMissing)

            return tuple(lastpoll)


    class JSON_Query (Observing, Leaf):
        '''Return the values from the specified poll in JSON format.'''

        literals = { None:"null", False:"false", True:"true" }
        literalTypes = (type(None), bool)

        caseConversions = {
            'None'  : None,
            'Upper' : lambda s: s.upper(),
            'Lower' : lambda s: s.lower(),
            'Camel' : lambda s: s[:1].lower() + s[1:],
            'Capitalize' : lambda s: s.capitalize()
        }
            

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('shortKeys', description='Use "short" key names')
            self.setInput('caseConvert', type=self.caseConversions, named=True, default=None)
            self.setInput('clear',
                          description='Clear captured data from internal buffer after retrieving')
            self.setInput('count',
                          type=int, named=True, default=None, range=(0, None),
                          description='Maximum number of data points to include')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('json', type=str);


        def run (self, ignoreMissing=False, shortKeys=False, clear=False, count=None, caseConvert=None, poll=str, *items):
            poll     = self.parent.getPoll(poll)
            parts    = poll.getParts(short=shortKeys, count=count, clear=clear, formatted=True, alwaysNamed=True)
            json     = []

            for option, value, raw in parts:
                if isinstance(raw, (tuple, list)):
                    string = value.join("[]")

                elif isinstance(raw, self.literalTypes):
                    string = self.literals.get(raw, str(raw))

                else:
                    string = str(value)

                key = (caseConvert or str)(option)
                json.append('"%s":%s'%(key, string))

            return ",".join(json).join("{}")


for cls in CommandQuery, PollItem, VariablePoll:
    PollItemTypes[cls.typename] = cls



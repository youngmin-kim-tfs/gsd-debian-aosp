########################################################################
### FILE:	scpiMTSSBranch.py
### PURPOSE:	Branch for MTSS specific commands
### HISTORY:
###  2019-10-23 Richard Stokes
###             Created
###
### Copyrights (C) 2019 ThermoFisher Scientific.  All rights reserved.
########################################################################

from scpiFullBranch import FullBranch
from scpiLeaf import Leaf, Observing, Controlling
from scpiParameter import autoType
from scpiExceptions import RunError
from scpiConfigBase import ConfigBase
from config import getConfigPath

import os.path, threading
class MTSS(FullBranch):
    '''Commands to related to MTSS functionality'''
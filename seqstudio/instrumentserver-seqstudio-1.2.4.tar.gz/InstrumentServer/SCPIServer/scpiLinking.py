########################################################################
### FILE:	scpiLinking.py
### PURPOSE:	Connect a new branch to a cascaded SCPI server
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiBase            import querySuffixes
from scpiBranch          import Branch
#from scpiMinimalBranch   import MinimalBranch
from scpiFullBranch      import FullBranch
from scpiLeaf            import Controlling, Observing, Leaf, FULL
from scpiFilesystemBase  import FilesystemBase
from scpiExceptions      import NextReply, RunError, ComponentError
from scpiDynamicBase     import Dynamic, DynamicCommandBase, DynamicCommandLeaf
from scpiConfigBase      import ConfigBase
from scpiSession         import ClientSession, AccessLevels, MESSAGE
from scpiClient          import SCPIClient, SCPIError, SCPIErrorResponse, \
    ACCESS_LEVELS, OK, NEXT, ERROR, \
    ARG_TOPIC, ARG_TIMESTAMP, ARG_LEVEL, ARG_PARTS, ARG_RAW
from commandParser       import parser, QUOTE_AUTO, QUOTE_ATTRIBUTES, QUOTE_NEVER
from locking             import Lock
from data                import DynamicData
from new                 import classobj
from subscription        import addTopic, publish

import os, re, errno, weakref, base64


class ClientMixIn (object):
    '''Abstract superclass for leafs that send commands to remote server'''

    environmentErrors = {
        'NoMatch' : errno.ENOENT,
        'InsufficientAccess' : errno.EPERM
        }


    class EnvironmentError (ComponentError, EnvironmentError):
        def __init__ (self, _component, _errno, _text, _filename=None, _location=None, **kwargs):
            EnvironmentError.__init__(self, _errno, _text, _filename)
            self.location = _location
            errcode = errno.errorcode.get(_errno, 'UnknownError')
            ComponentError.__init__(self, _component, errcode, _text, **kwargs)


    def findErrnoFromMessage (self, message):
        for candidate in errno.errorcode:
            if os.strerror(candidate) == message:
                return candidate

    def clientWrapper (self, method, *args, **kwargs):
        try:
            return method(*args, **kwargs)

        except SCPIErrorResponse, e:
            try:
                errno = e.attributes['errno']
            except KeyError:
                try:
                    errno = self.findErrnoFromMessage(e.attributes['message'])
                except KeyError:
                    errno = None

            if errno is None and e.code:
                code = e.code.split(".")[-1]
                errno = self.environmentErrors.get(code)

            component = self.commandPath(short=True)
            if errno is not None:
                raise self.EnvironmentError(component, errno, e.message,
                                            e.attributes.get('filename'),
                                            e.attributes.get('location'),
                                            *e.args, **e.attributes)
            else:
                raise ComponentError(component, e.code, e.message, **e.attributes)

        except SCPIError, e:
            raise ComponentError(self.commandPath(short=True), type(e).__name__, e.message, *e.args, **e.attributes)


class ClientLeaf (ClientMixIn, Leaf):

    def invoke (self, *args, **kwargs):
        return self.clientWrapper(Leaf.invoke, self, *args, **kwargs)

    def invokeNext (self, *args, **kwargs):
        return self.clientWrapper(Leaf.invokeNext, self, *args, **kwargs)



class LinkedBranch (Dynamic, ClientMixIn, Branch):
    """
    This namespace is linked to an external SCPI server.
    """


    __slots__ = ('scpi', 'commandTimeout', 'lock')

    TypeName = 'linked branch'
    requiredAccess = None

    def __init__ (self, name, parent, scpiClient, commandTimeout, *args, **kwargs):
        self.scpi           = scpiClient
        self.commandTimeout = commandTimeout
        self.lock           = Lock()
        Branch.__init__(self, name=name, parent=parent, *args, **kwargs)

    def __del__ (self):
        self.scpi.disconnect()
        self.scpi = None

    def processMessage (self, topic, timestamp, level, parts, quotingstrategy=QUOTE_ATTRIBUTES):
        topic = self.commandPath(topic, short=True)
        publish(topic, parts, timestamp=timestamp, level=level, quoting=quotingstrategy)

    def forwardMessage (self, text, sessionref):
        session = sessionref()
        if session:
            session.send(text+"\n")

    def getServerAddress (self):
        if self.scpi:
            return self.scpi.serveraddr
        else:
            return None

    def _locate (self, elements, path, defaults):
        try:
            return Branch._locate(self, elements, path, defaults)
        except self.UnknownCommand:
            try:
                elements.insert(0, defaults["_subcommand"])
            except KeyError:
                pass

            defaults.update(_subcommand=":".join(elements))


    def invoke (self, _session, _parts, _subcommand, **options):
        if self.requiredAccess is not None:
            requiredAccess = self.requiredAccess
        else:
            requiredAccess = self.defaultAccess(_subcommand)
        _session.checkAccess(requiredAccess)

        cmd = ' '.join((_subcommand, parser.collapseArgs(_parts)))

        with self.lock:
            handle  = self.clientWrapper(self.scpi.sendCommand, cmd)
            return self.waitResponse(handle, timeout=self.commandTimeout)


    def waitResponse (self, handle, timeout=None):
        status, parts = self.clientWrapper(self.scpi.receiveResponse,
                                           handle,
                                           splitParts=True,
                                           timeout=timeout)

        if status == OK:
            return parts

        elif status == NEXT:
            raise NextReply(self, self.waitResponse, (handle,), {})


    def formatOutputs (self, parts, alwaysNamed=False, raw=False):
        return parts


    def getProperties (self):
        props = Branch.getProperties(self)
        props.append(('RequiredAccess', AccessLevels[self.requiredAccess]))
        props.append(('ModifyAccess',   AccessLevels[self.modifyAccess]))

        return props


    from scpiQuitLeaf import QUIT



class LinkingLeaf (DynamicCommandLeaf, ClientLeaf):
    _dynamicCommandType = LinkedBranch

    def declareInputs (self):
        DynamicCommandLeaf.declareInputs(self)
        self.setOptionalInput('scope',
                              type=str,
                              named=True,
                              default=None,
                              description=
                              'Parent branch under which the linked branch is created')

    def scope (self, scope, current):
        if scope:
            return current.find(scope)
        else:
            return current


class SCPI (ClientMixIn, FullBranch):
    '''Commands to maintain links to remote SCPI servers.'''

    connectTimeout = 15.0
    commandTimeout = 60.0

    class NoConnection (RunError):
        '''Linked branch %(link)r does not use a named connection.'''

    class NoSuchConnection (RunError):
        '''No such connection exists: %(connection)r'''

    class ConnectionExists (RunError):
        '''A connection named %(connection)s already exists'''

    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        self.connections = {}

    def connect (self, name, host, port, commandIndex, timeout=connectTimeout, autoconnect=False, replaceExisting=False):
        old = self.getConnection(name, ignoreMissing=True)
        if old and not replaceExisting:
            raise self.ConnectionExists(connection=name)

        logtopic = "Link-"+name
        logger = lambda level, msg: publish(logtopic, msg, level=level, quoting=QUOTE_NEVER, literaltag=None)

        new = SCPIClient((host, port), commandIndex=commandIndex, autoconnect=autoconnect, logger=logger)
        self.clientWrapper(new.connect, timeout=timeout)
        self.connections[name.lower()] = (name, new)
        new.links = []
        return new

    def getConnection (self, name, ignoreMissing=False):
        try:
            name, connection = self.connections[name.lower()]
            return connection
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchConnection(connection=name)

    def removeConnection (self, name, ignoreMissing=False):
        try:
            name, connection = self.connections.pop(name.lower())
            return connection
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchConnection(connection=name)


    def renameConnection (self, oldname, newname, ignoreMissing=False, replaceExisting=False):
        if not replaceExisting:
            try:
                name, conn = self.connections[newname.lower()]
            except KeyError:
                pass
            else:
                raise self.ConnectionExists(connection=name)

        try:
            name, conn = self.connections.pop(oldname.lower())
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchConnection(connection=oldname)
        else:
            self.connections[newname.lower()] = (newname, conn)



    def getConnectionOf (self, link, ignoreMissing=False):
        for (name, conn) in self.connections.values():
            if conn == link.scpi:
                return name, conn
        else:
            if ignoreMissing:
                return (None, None)
            else:
                raise self.NoConnection(link=link.name)

    def log (self, level, message):
        publish(self.debugTopic, message, level=level, quoting=QUOTE_NEVER, literaltag=None)


    def addlink (self, scope, branch, replaceExisting, conn, commandTimeout,
                 authentication, access, exclusive, stealth, role, subscribe):

        new = LinkedBranch(branch, scope, conn, commandTimeout or None)
        self.clientWrapper(conn.handshake,
                           authentication=authentication,
                           access=access,
                           role=role,
                           exclusive=exclusive,
                           stealth=stealth)
        if subscribe:
            self.clientWrapper(conn.subscribe,
                               "*", new.processMessage,
                               cbargs=(ARG_TOPIC, ARG_TIMESTAMP, ARG_LEVEL, ARG_PARTS), quotingstrategy=QUOTE_AUTO)

        conn.links.append(new)
        return new


    def dellink (self, link, disconnect=None):
        name, conn = self.getConnectionOf(link, ignoreMissing=True)
        if conn:
            conn.links.remove(link)
            self.clientWrapper(conn.unsubscribe, "*", link.processMessage,
                               ignoreMissing=True, sendUnsubscribeCommand=not disconnect)

            if disconnect and not conn.links:
                self.clientWrapper(conn.disconnect)
                self.removeConnection(name, ignoreMissing=True)



    class CONNection_Add (Controlling, ClientLeaf):
        '''Connect to a remote SCPI server.'''


        def declareInputs (self):
            ClientLeaf.declareInputs(self)
            self.setInput('replaceExisting',
                          type=bool, named=True, default=False,
                          description='Replace any existing connection by the same name.')

            self.setInput('commandIndex',
                          type=bool, named=True, default=True,
                          description=
                          'Prefix every command sent to the linked server with '
                          'a unique index.  This increases the reliability of '
                          'communications for asynchronous command execution, '
                          'but is not understood by all SCPI servers')

            self.setInput('timeout',
                          type=float, named=True, default=self.parent.connectTimeout, units='seconds',
                          description='How long to wait before giving up connecting to the server')

            self.setInput('name', type=str,
                          description='Name for the connection')

            self.setInput('host',
                          type=str,
                          description='IP address or resolvable host name of remote SCPI server')

            self.setInput('port',
                          type=int, default=7000,
                          description='Port number of remote SCPI server.')

        def run (self, replaceExisting=bool, commandIndex=bool, timeout=float, ignoreFailure=False, name=str, host=str, port=int):
            try:
                self.parent.connect(name, host, port, commandIndex=commandIndex, timeout=timeout, replaceExisting=replaceExisting)
            except ComponentError:
                if not ignoreFailure:
                    raise


    class CONNection_Remove (Controlling, LinkingLeaf):
        '''Remove an existing named connection to a remote SCPI Server.
        Note that without the "-removeLinks" option, any linked branch
        will keep the connection alive.'''

        def run (self, ignoreMissing=False, removeLinks=False, connection=str):
            conn = self.parent.removeConnection(connection, ignoreMissing)
            if conn and removeLinks:
                for instance in self.getinstances(parent=self.parent.parent):
                    self.parent.parent.delChild(instance)


    class CONNection_Enumerate (Observing, Leaf):
        '''Enumerate the names of remote SCPI server connections.'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('connection', type=str, repeats=(0, None))

        def run (self):
            names = [name for name, conn in self.parent.connections.values()]
            return tuple(names)


    class CONNection_Clear (Observing, Leaf):
        '''Enumerate the names of remote SCPI server connections.'''

        def run (self):
            self.parent.connections.clear()


    class CONNection_Query (Observing, Leaf):
        '''List properties for the specified connection'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('host', type=str, named=True)
            self.addOutput('port', type=int, named=True)

        def run (self, ignoreMissing=False, name=str):
            try:
                conn = self.parent.getConnection(name)
            except self.parent.NoSuchConnection:
                if not ignoreMissing:
                    raise
            else:
                return conn.serveraddr


    class CONNection_Exists (Observing, Leaf):
        '''List properties for the specified connection'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('exists', type=bool)

        def run (self, name=str):
            try:
                conn = self.parent.getConnection(name)
            except self.parent.NoSuchConnection:
                return False
            else:
                return True


    class INFO_Query (Observing, ClientLeaf):
        '''Return information that was provided in the remote server's READy greeting.'''

        def declareInputs (self):
            ClientLeaf.declareInputs(self)
            self.setInput('timeout',
                          type=float, named=True, default=self.parent.connectTimeout, units='seconds',
                          description='How long to wait before giving up connecting to the server')

        def declareOutputs (self):
            ClientLeaf.declareOutputs(self)
            self.addOutput('item', type=tuple, repeats=(0,None))

        def run (self, timeout=float, ignoreMissing=False, connection=str):
            conn = self.parent.getConnection(connection, ignoreMissing)
            if conn:
                conn.waitReady(timeout)
                return tuple(conn.serverinfo.items())

    class LINK_Add (Controlling, FilesystemBase, LinkingLeaf):
        '''
        Create a new command branch, and map its namespace to an external
        (cascaded) SCPI Server.  Any commands delegated to this branch are
        forwarded to the connected server.

        To delete a linked branch, use LINK-.

    Examples:
        * Create a "BreadBoard" branch, and map it to an external SCPI server
          listening on port 7100 on "bbhost".  Then, send the command "TBC:ID?"
          command to that server, and wait for the response.

            C: 1 LINK BreadBoard -host=bbhost:7100
            S: OK 1
            C: 2 BreadBoard:TBC:ZREad? 1
            S: OK 2 65.45240
        '''

        def declareInputs (self):
            LinkingLeaf.declareInputs(self)
            self.setInput('replaceExisting',
                          description=
                          'If another dynamic command by the same name already '
                          'exists, replace it')

            self.setInput('scope',
                          type=str,
                          description=
                          'Parent branch under which the linked branch is created')

            self.setInput('commandTimeout',
                          type=float,
                          units='seconds',
                          description=
                          'How long to wait for a response to commands '
                          'sent to the linked server')

            self.setInput('requiredAccess',
                          type=ACCESS_LEVELS,
                          named=True,
                          default=None,
                          description='Required access level for invocation. '
                          'By default, commands that end with a "query suffix" (one of "%s") '
                          'required OBSERVER access, others require CONTROLLER access.'%
                          ('", "'.join(querySuffixes)))

            self.setInput('authentication',
                          type=str,
                          named=True,
                          default=None,
                          description='Authentication secret. Please enclose between "$<" and ">" (e.g., "$<secret>") to mask in logs.')

            self.setInput('encoded',
                          type=bool,
                          named=True,
                          default=False,
                          description='Provided authentication secret is base64-encoded.')

            self.setInput('access',
                          type=ACCESS_LEVELS,
                          named=True,
                          default=None,
                          description='Initial access level to request on linked server')

            self.setInput('exclusive',
                          type=bool,
                          named=True,
                          default=False,
                          description='Prevent subsequent sessions from receiving this or higher access levels')

            self.setInput('stealth',
                          type=bool,
                          named=True,
                          default=False,
                          description='Ignore exclusive flag, grant access to this and other sessions.')

            self.setInput('role',
                          type=str,
                          named=True,
                          default=None,
                          description="Provide a role name for this session (e.g. UI, MTSS...)")

            self.setInput('subscribe',
                          type=bool,
                          named=True,
                          default=False,
                          description='Automatically subscribe to messages from the linked server.')

            self.setInput('forwardMessages',
                          type=bool,
                          named=True,
                          default=False,
                          description='Forward published messages from the server directly to this session.')

            self.setInput('branch',
                          type=str,
                          description='Branch name to be created.')

            self.setInput('connection',
                          type=str,
                          description='Connection name, previously created with "CONNection+"')


        def run (self, _session, _scope,
                 replaceExisting=False, scope="", commandTimeout=15.0,
                 authentication=None, encoded=False, access=None, requiredAccess=AccessLevels,
                 exclusive=False, stealth=False,
                 role=None, subscribe=False, forwardMessages=False,
                 branch=str, connection=str):

            parent = self.scope(scope, _scope)

            old = self.findModifiableCommand(_session, branch,
                                             allowMissing=True,
                                             allowExisting=replaceExisting,
                                             parent=parent)

            if encoded and authentication:
                try:
                    authentication = base64.b64decode(authentication)
                except (TypeError, KeyError), e:
                    raise self.DecodeError(e)

            scpi = self.parent.getConnection(connection)
            link = self.parent.addlink(parent, branch, replaceExisting,
                                       scpi, commandTimeout,
                                       authentication, access, exclusive, stealth,
                                       role, subscribe)

            if forwardMessages:
                session = _session.top(ClientSession)
                scpi.subscribe('*', link.forwardMessage,
                               cbargs=(ARG_RAW,),
                               sessionref=weakref.ref(session),
                               sendSubscribeCommand=False)

            self.addinstance(_session, branch, link,
                             requiredAccess=requiredAccess,
                             replaceExisting=replaceExisting,
                             parent=parent)


    class LINK_Remove (Controlling, LinkingLeaf):
        '''
        Delete a branch that was previously linked to a remote SCPI server.
        '''
        def run (self, _session, _scope, ignoreMissing=False, scope="", disconnect=False, name=str):
            parent = self.scope(scope, _scope)
            link = self.delinstance(_session, name, ignoreMissing=ignoreMissing, parent=parent)
            if link:
                link.scpi.unsubscribe('*', link.forwardMessage,
                                      ignoreMissing=True,
                                      sendUnsubscribeCommand=not disconnect)

                self.parent.dellink(link, disconnect)


    class LINK_Query (Observing, LinkingLeaf):
        """
        Return the connection name associated with the specified linked branch.
        """

        def declareInputs (self):
            LinkingLeaf.declareInputs(self)
            self.setInput('scope',
                          type=str,
                          description=
                          'Parent branch under which the linked branch exists')

            self.setInput('branch',
                          type=str,
                          description='Name of a linked branch')


        def declareOutputs (self):
            LinkingLeaf.declareOutputs(self)

            self.addOutput('commandTimeout',
                           units='seconds',
                           type=float,
                           named=True,
                           description=
                           'How long to wait for a response to commands '
                           'sent to the linked server')

            self.addOutput('requiredAccess',
                          type=ACCESS_LEVELS,
                          named=True,
                          default=None,
                          description='Required access level for invocation. '
                          'By default, commands that end with a "query suffix" (one of "%s") '
                          'required OBSERVER access, others require CONTROLLER access.'%
                          ('", "'.join(querySuffixes)))

            self.addOutput('authentication',
                          type=str,
                          named=True,
                          default=None,
                          description='Authentication secret. Please enclose between "$<" and ">" (e.g., "$<secret>") to mask in logs.')

            self.addOutput('encoded',
                          type=bool,
                          named=True,
                          default=False,
                          description='Provided authentication secret is base64-encoded.')

            self.addOutput('access',
                          type=ACCESS_LEVELS,
                          named=True,
                          default=None,
                          description='Initial access level to request on linked server')

            self.addOutput('exclusive',
                          type=bool,
                          named=True,
                          default=False,
                          description='Prevent subsequent sessions from receiving this or higher access levels')

            self.addOutput('stealth',
                          type=bool,
                          named=True,
                          default=False,
                          description='Ignore exclusive flag, grant access to this and other sessions.')

            self.addOutput('role',
                          type=str,
                          named=True,
                          default=None,
                          description="Role name provided to the server.")

            self.addOutput('subscribe',
                          type=bool,
                          named=True,
                          default=False,
                          description='Automatically subscribe to messages from the linked server.')

            self.addOutput('forwardMessages',
                          type=bool,
                          named=True,
                          default=False,
                          description='Forward published messages from the server directly to this session.')

            self.addOutput('connection',
                           type=str,
                           description='Connection name, previously created with "CONNection+"')



        def run (self, _scope, ignoreMissing=False, scope="", branch=str):
            obj = self.findDynamicCommand(branch, parent=self.scope(scope, _scope), allowMissing=ignoreMissing)
            if obj:
                name, conn = self.parent.getConnectionOf(obj, ignoreMissing)
                subscriptions = conn.getSubscriptions(obj.processMessage)
                forwardTopics = conn.getSubscriptions(obj.forwardMessage)

                return dict(commandTimeout = obj.commandTimeout,
                            requiredAccess = obj.requiredAccess,
                            authentication = conn.authentication and base64.b64encode(conn.authentication),
                            encoded = True,
                            access = conn.accessLevel,
                            exclusive = conn.exclusive,
                            stealth = conn.stealth,
                            role = conn.role,
                            subscribe = bool(subscriptions),
                            forwardMessages = bool(forwardTopics),
                            connection = name)



    class LINK_Enumerate (Observing, LinkingLeaf):
        '''
        Return a list of dynamic subbranches in this branch.
        '''

        def declareOutputs (self):
            LinkingLeaf.declareOutputs(self)
            self.addOutput('command', type=str, repeats=(0, None))

        def run (self, _scope, scope=""):
            return tuple(self.listinstances(parent=self.scope(scope, _scope)))


    class LINK_Clear (Controlling, LinkingLeaf):
        '''
        Delete all linked branches.
        '''

        def run (self, _session, _scope, scope=""):
            names = []
            scope = self.scope(scope, _scope)

            for instance in self.getinstances(parent=scope):
                _session.checkAccess(instance.modifyAccess)
                scope.delChild(instance)
                names.append(instance.commandPath(scope=scope))

            if names:
                self.debug("Deleted %s instance(s): %s"%(self._dynamicCommandType, " ".join(names)))

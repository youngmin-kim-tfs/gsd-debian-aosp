########################################################################
### FILE:	scpiEvalLeafs.py
### PURPOSE:	Evaluation commands (CONCatenate, EVALuate...)
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf       import Leaf, Public, Observing, Administrative
from scpiExceptions import RunError


class EVALuate_Query (Administrative, Leaf):
    '''
    Perform a numeric evaluation and return the result.
    Operator symbols are those that are available in the Python language.

    Local, global and persistent variable names can be used in the
    expression; they are resolved in that order.
    '''

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('import', type=str, split=",", named=True, default=("math", "re"),
                      description="Python modules to import into evaluation namespace")
                      
        self.setInput('expression', type=str, repeats=(1, None))
        

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('result', type=str)

    def run (self, _session, _context, Import='', *expression, **assignments):
        exp = ' '.join(expression)
        imports = filter(None, Import)
        return str(_session._getEvaluationResult(exp, context=_context, assignments=assignments, imports=imports))
    



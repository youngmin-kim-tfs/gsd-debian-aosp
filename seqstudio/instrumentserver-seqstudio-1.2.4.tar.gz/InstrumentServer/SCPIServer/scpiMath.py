########################################################################
### FILE:	scpiMath.py
### PURPOSE:	Math related functions
###
### Copyrights (C) 2010 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf import Observing, Leaf
from random   import random


class RANDom_Query (Observing, Leaf):
    '''
    Return a random real number between 0 and 1.
    '''

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('value', type=float, range=(0.0, 1.0))
        
    def run (self):
        return random()


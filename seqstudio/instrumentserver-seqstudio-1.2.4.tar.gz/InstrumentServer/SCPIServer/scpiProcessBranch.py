########################################################################
### FILE:	scpiProcessBranch.py
### PURPOSE:    Commands to launch subprocesses
### SCOPE:	SYSTem: branch
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2017 ThermoFisher Scientific.  All rights reserved.
########################################################################

from scpiLeaf            import Administrative, Controlling, Observing, Public, Leaf
from scpiFilesystemBase  import FilesystemBase, FilesystemLeaf
from scpiFullBranch      import FullBranch
from scpiExceptions      import RunError, Error, CommandError, NextReply
from scpiFileContexts    import P_READ, P_WRITE, P_EXECUTE, OP_READ, OP_WRITE
from commandParser       import parser, QUOTE_NEVER
from SysConfig           import sysconfig
from calendar            import timegm
from os                  import environ
from process             import launch, communicate, waitInstance, sigmap, signames, InvocationError, ExitStatus
from subprocess          import PIPE, STDOUT
from subscription        import publish, LogLevels, DEBUG
from errno               import errorcode
from re                  import compile as rxcomp
from data                import Container

class ProcessBranch (FilesystemBase, FullBranch):
    '''Subprocess commands'''

    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        self.subprocesses = {}


    class NoSuchSubprocess (RunError):
        'There is no such subprocess ID: %(id)r'

    class InvocationError (Error):
        def __init__ (self, *args, **kwargs):
            Error.__init__(self, 'IS.Subprocess.Invocation', *args, **kwargs)

    class ExitStatus (Error):
        def __init__ (self, status, message, code, **kwargs):
            Error.__init__(self, 'IS.Subprocess.%s'%(code or status), message, status=status, **kwargs)

        def __str__ (self):
            return self.text

    def addSubprocess (self, name, instance):
        self.subprocesses[name.lower()] = Container(name=name, instance=instance, out=bytearray(), err=bytearray())

    def getSubprocessNames (self):
        return [ p.name for p in self.subprocesses.values() ]

    def delSubprocess (self, name, ignoreMissing=False):
        try:
            del self.subprocesses[name.lower()]
            return True
        except KeyError, e:
            if not ignoreMissing:
                raise self.NoSuchSubprocess(id=name)
            return False


    def getSubprocess (self, name, ignoreMissing=False):
        try:
            return self.subprocesses[name.lower()]
        except KeyError, e:
            if not ignoreMissing:
                raise self.NoSuchSubprocess(id=name)


    def addSubprocessOutputs (self, name, out, err):
        try:
            p = self.subprocesses[name.lower()]
        except KeyError, e:
            return out, err
        else:
            if out:
                p.out.extend(out)
            if err:
                p.err.extend(err)
            return str(p.out), str(p.err)

    def formatInputs (self, command, translateCrLf=False):
        env   = None
        for index, part in enumerate(command):
            option, arg, raw = part
            try:
                var, value = (arg or "").split("=", 1)
            except ValueError:
                var = None
            else:
                if var.startswith('-'):
                    var = None
                else:
                    if env is None:
                        env = environ.copy()
                    env[var] = value

            if var is None:
                argv = parser.collapseParts(command[index:], tag=None, quoting=QUOTE_NEVER)
                break
        else:
            argv = []

        if translateCrLf:
            for index, arg in enumerate(argv):
                argv[index] = arg.replace("\r\n", "\n")

        return argv, env


    def extractOutput (self, output, pid, strip=False, split=False):
        if strip:
            output = output.strip()

        if split:
            try:
                string, parts = parser.expandArgs(output)
                self.debug("Output arguments from process %s: %s"%(pid, parts))
                return tuple(parts)
            except Exception:
                pass

        if output:
            return ((None, output, output),)


    def waitInstance (self, instance, input, captureOutput, captureError, id, ignoreExit, logMethod):
        out, err = communicate(instance, input, captureOutput, captureError, log=logMethod)

        if id:
            out, err = self.addSubprocessOutputs(id, out, err)

        return out, err, waitInstance(instance, out=out, err=err, ignoreExit=ignoreExit, log=logMethod)



    class EXECute (Administrative, FilesystemLeaf):
        '''
        Execute the specified system command.  This may optionally be
        preceeded by a sequence of environment variables for the command,
        in the form:

             ENVVAR1=value1 ENVVAR2=value2 ... command ...
        '''

        class NoSuchPipe (RunError):
            '''No pipe named %(name)r exists'''

        class DuplicatePipe (RunError):
            '''A pipe named %(name)r already exists'''

        class MissingCommand (RunError):
            '''Missing command'''


        def __init__(self, *args, **kwargs):
            FilesystemLeaf.__init__(self, *args, **kwargs)
            self.pipes = {}


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput("id", type=str, default=None,
                          description="Assign an identifer for this command instance; this can later be "
                          "used to send signals to and query for status on this process")

            self.setInput("shell", type=bool, default=False,
                          description="Invoke command via shell")

            self.setInput("background", type=bool, default=False,
                          description="Run command in a background process")

            self.setInput("asynchronous", type=bool, default=False,
                          description="Run command asynchronously")

            self.setInput("renice", type=int, default=0,
                          description="Increase nice level (reverse priority)")

            self.setInput("crlf", type=bool, default=False,
                          description="Translate CR+LF style line endings to plain LF in all command arguments")

            self.setInput("split", type=bool, default=False,
                          description="Parse output from command into separate output arguments")

            self.setInput("strip", type=bool, default=False,
                          description="Strip whitespace from beginning and end of output")

            self.setInput("input", type=str, named=True, default=None,
                          description="Input for command")

            self.setInput("inputFile", type=str, named=True, default=None,
                          description="Read input from the specified file.")

            self.setInput("inputPipe", type=str, named=True, default=None,
                          description='Read input from the specified pipe, which must '
                          'have been provided as "-outputPipe" or "-errorPipe" from a '
                          'previous command.')

            self.setInput("outputFile", type=str, named=True, default=None,
                          description="Redirect standard output to the specified file.")

            self.setInput("outputPipe", type=str, named=True, default=None,
                          description='Redirect standard output to the specified pipe. '
                          'The subprocess will block on output until another "EXECute" '
                          'command is invoked using this pipe as standard input.')

            self.setInput("errorFile", type=str, named=True, default=None,
                          description="Redirect standard error to the specified file. "
                          "NOTE: this will prevent any error messages from the command "
                          "from being returned. Instead, a generic system message based "
                          "on the exit status of the process will be returned.")

            self.setInput("errorPipe", type=str, named=True, default=None,
                          description='Redirect standard error to the specified pipe. '
                          'The subprocess will block on error output until another "EXECute" '
                          'command is invoked using this pipe as standard input.')

            self.setInput('outputMerge', type=bool, named=True, default=False,
                          description='Capture standard error and standard output as a single stream.')

            self.setInput('cwd', type=str, named=True, default="/",
                          description='Current working directory for running command')

            self.setInput('chroot', type=str, named=True, default=None,
                          description='Root directory for running command')

            self.setInput('autoproxy', type=bool, named=True, default=False,
                          description='If a web proxy is configured, run command inside a proxy container.')

            self.setInput("skipTriggers", type=bool, named=True, default=False,
                          description="Do not execute any pre- or post-execution hooks "
                          "for the location contexts of 'inputFile', 'outputFile', or 'errorFile'.")

            self.setInput('logTopic', type=str, default=LogLevels[DEBUG],
                          description="Topic on which to publish information about invocation, "
                          "standard output, standard error, and exit status.")

            self.setInput('ignoreExit', type=bool, default=False,
                          description='Do not raise error if the command returns with a non-zero exit status')

            self.setInput("command", type=tuple, form=None, repeats=(1, None),
                          description="Command to invoke.  Optionally, this may be preceeded by "
                          "a sequence of environment variables and values.")



        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('output', type=tuple, repeats=(0, None),
                           description="Output from command")


        def run (self, _session, id=None, shell=False, asynchronous=False,
                 renice=0, crlf=False, strip=False, split=False, background=False,
                 cwd="/", chroot=None, autoproxy=False,
                 input=None, inputFile=None, inputPipe=None,
                 outputFile=None, outputPipe=None,
                 errorFile=None, errorPipe=None, outputMerge=False,
                 skipTriggers=False, logTopic=None, ignoreExit=False,
                 *command):

            self.checkConflictingOptions(asynchronous=asynchronous, background=background)
            self.checkConflictingOptions(input=input is not None, inputFile=inputFile, inputPipe=inputPipe)
            self.checkConflictingOptions(outputFile=outputFile, outputPipe=outputPipe)
            self.checkConflictingOptions(errorFile=errorFile, errorPipe=errorPipe, outputMerge=outputMerge)

            argv, env = self.parent.formatInputs(command, crlf)

            if not argv:
                raise self.MissingCommand()

            if logTopic:
                logMethod = lambda message: publish(logTopic, message)
            else:
                logMethod = None

            proxyexec = False
            if autoproxy:
                proxyspec = sysconfig.getvalue('proxy')
                if proxyspec and proxyspec[0]:
                    proxyexec = sysconfig.getvalue('proxyexec')

            locations = []
            try:
                for path, perm in (inputFile, P_READ), (outputFile, P_WRITE), (errorFile, P_WRITE):
                    loc = path and self.openLocation(path, _session, perm, not skipTriggers).__enter__() or None
                    locations.append(loc)

                try:
                    stdin  = ((inputPipe and self.pipes.pop(inputPipe.lower())) or
                              (locations[0] and locations[0].open(OP_READ)) or
                              None)

                    stdout = ((outputPipe and PIPE) or
                              (locations[1] and locations[1].open(OP_WRITE)) or
                              None)

                    if (outputMerge or
                        (stdout and
                         ((locations[1] and locations[2] and locations[1].vfspath() == locations[2].vfspath()) or
                          (errorPipe == outputPipe != None)))):
                        stderr = STDOUT
                    else:
                        stderr = ((errorPipe and PIPE) or
                                  (locations[2] and locations[2].open(OP_WRITE)) or
                                  None)

                except KeyError, e:
                    raise self.NoSuchPipe(name=e.args[0])

                except EnvironmentError, e:
                    raise self.parent.InvocationError(e.strerror,
                                                      status=e.errno,
                                                      code=errorcode.get(e.errno, "Unknown"),
                                                      command=argv[0],
                                                      filename=e.filename)

                try:
                    instance = launch(argv,
                                      shell=shell,
                                      detached=background and not id,
                                      input=input,
                                      inputFile=stdin,
                                      outputFile=stdout,
                                      errorFile=stderr,
                                      renice=renice,
                                      cwd=cwd,
                                      chroot=chroot,
                                      proxy=proxyexec,
                                      env=env,
                                      log=logMethod)

                except InvocationError, e:
                    if inputPipe:
                        stdin.close()

                    raise self.parent.InvocationError(e.strerror, status=e.errno, **e.attributes)

            except Exception, e:
                for loc in locations:
                    if loc:
                        loc.__exit__()
                raise


            if id:
                self.parent.addSubprocess(id, instance)


            if outputPipe:
                self.pipes[outputPipe.lower()] = instance.stdout
                asynchronous = not background

            if errorPipe:
                self.pipes[errorPipe.lower()] = instance.stderr
                asynchronous = not background

            waitArgs = (locations, instance, input,
                        stdout is None, stderr is None, id, ignoreExit, logMethod, strip, split)

            if asynchronous:
                raise NextReply(self, self.wait, waitArgs, {})

            elif not background:
                return self.wait(*waitArgs)


        _binaryX = rxcomp(r'([\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F])')

        def wait (self, locations, instance, input, captureOutput, captureError, id, ignoreExit, logMethod, stripText, splitArgs):
            try:
                out, err, status = self.parent.waitInstance(instance, input, captureOutput, captureError, id, ignoreExit, logMethod)
            except ExitStatus, e:
                raise self.parent.ExitStatus(e.errno, e.strerror, **e.attributes)
            else:
                return self.parent.extractOutput(out, instance.pid, stripText, splitArgs)
            finally:
                for loc in locations:
                    if loc:
                        loc.__exit__()



    class RUNNing_Query (Observing, Leaf):
        '''
        Indicate whether the specified subprocess is running.
        '''


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('running', type=bool)


        def run (self, ignoreMissing=False, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            return p and (p.instance.poll() == None) or False



    class WAIT (Observing, Leaf):
        '''
        Wait until the specified subprocess has completed.
        Unless "-ignoreExit" is given, a non-zero status from the process yields an error.
        '''

        def run (self, ignoreMissing=False, ignoreExit=False, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            if p:
                try:
                    self.parent.waitInstance(p.instance, None, True, True, id, ignoreExit, None)
                except ExitStatus, e:
                    raise self.parent.ExitStatus(e.errno, e.strerror, **e.attributes)


    class READ_Query (Observing, Leaf):
        '''
        Read some output from the specified subprocess.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('split', type=bool, default=False,
                          description='Parse output from command into separate output arguments')

            self.setInput('strip', type=bool, default=False,
                          description='Strip whitespace from beginning and end of output')

            self.setInput('stderr', type=bool, default=False,
                          description='Read from standard error instead of standard ouptut')

            self.setInput("terminator", type=str, named=True, default=None,
                          description='Return once the specified character is received. Use "\\n" to read a line.')

            self.setInput('max', type=int, named=True, default=None, units='bytes',
                          description='Read at most this many characters.')

            self.setInput('timeout', type=float, named=True, default=None, units='seconds',
                          description='Return if subprocess has not generated any output for this number of seconds.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('output', type=tuple, repeats=(0, None))

        def run (self, _session, ignoreMissing=False, strip=False, split=False, stderr=False, max=None, terminator=None, timeout=None, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            if p:
                out, err = communicate(p.instance,
                                       captureOutput=not stderr,
                                       captureError=stderr,
                                       timeout=timeout,
                                       terminator=terminator,
                                       maxread=max)
                self.parent.addSubprocessOutputs(id, out, err)
                return self.parent.extractOutput((out, err)[stderr], p.instance.pid, strip, split)



    class STandarDOUTput_Query (Observing, Leaf):
        '''
        Return standard output from the specified subprocess.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('output', type=tuple, repeats=(0, None),
                           description="Standard output from command")


        def run (self, _session, ignoreMissing=False, strip=False, split=False, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            if p:
                return self.parent.extractOutput(str(p.out), p.instance.pid, strip, split)


    class STandarDERRor_Query (Observing, Leaf):
        '''
        Return standard output from the specified subprocess.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('error', type=str, default=None,
                           description="Diagnostic/error output from command")


        def run (self, ignoreMissing=False, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            return p and str(p.err) or None


    class RETurn_Query (Observing, Leaf):
        '''
        Return standard output from the specified subprocess.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('returncode', type=int, default=None, repeats=(0, None),
                           description="Return code from command")


        def run (self, _session, ignoreMissing=False, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            if p:
                return p.instance.wait()



    class ID_Remove (Controlling, Leaf):
        '''
        Forget the specified subprocess
        '''

        def run (self, ignoreMissing=False, id=str):
            self.parent.delSubprocess(id, ignoreMissing)



    class ID_Enumerate (Observing, Leaf):
        '''
        List subprocess identifiers that have been launched via the EXECute command
        '''


        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('running', type=bool, default=False, named=True,
                          description='List only running processes, not those that have already terminated.')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('id', type=str, repeats=(0, None))


        def run (self, running=False):
            return tuple(self.parent.subprocesses)


    class ProcessID_Query (Observing, Leaf):
        '''
        Return the process ID of the specified subprocess
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('pid', type=int, default=None)


        def run (self, ignoreMissing=False, id=str):
            p = self.parent.getSubprocess(id, ignoreMissing)
            if p:
                return p.instance.pid


    class SIGnal (Administrative, FilesystemLeaf):
        '''
        Send a signal to the specified process.
        '''


        def run (self, ignoreMissing=False, id=str, signal=sigmap):
            p = self.parent.getSubprocess(id, ignoreMissing)

            if p:
                self.debug("Sending signal %s (%s) to process %r (pid=%d)"%
                           (signal, signames[signal], p.name, p.instance.pid))
                try:
                    p.instance.send_signal(signal)
                except EnvironmentError, e:
                    if not ignoreMissing:
                        raise self.parent.NoSuchSubprocess(id=id, pid=p.instance.pid)

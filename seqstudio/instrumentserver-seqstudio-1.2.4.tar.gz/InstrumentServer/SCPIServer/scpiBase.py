########################################################################
### FILE:	scpiBase.py
### PURPOSE:	Abstract command element; superclass of Base and Leaf.
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from subscription   import publish, info, TRACE, DEBUG, INFO, NOTICE, WARNING, ERROR
from re             import compile as rxcomp, escape, MULTILINE
from config         import Config
from data           import DynamicData, PersistentData

from threading      import currentThread, enumerate as enumerateThreads
from time           import sleep, time
from cStringIO      import StringIO
from weakref        import ref
from SysConfig      import SysConfig
from scpiExceptions import CommandError
from scpiParameter  import Missing
from commandParser  import QUOTE_ATTRIBUTES
from scpiSession    import OBSERVER, CONTROLLER, SYNC, ASYNC

### Regular expression for extracting "short" version of command name
suffixMap    = { 'Set'       : '=',
                 'Add'       : '+',
                 'Remove'    : '-',
                 'Clear'     : '~',
                 'Query'     : '?',
                 'Count'     : '#',
                 'Enumerate' : '*',
                 'List'      : '@',
                 'Exists'    : '!',
                 'Load'      : '<',
                 'Save'      : '>' }

querySuffixes = ('?', '#', '*', '@', '!')
suffixRevMap = dict(zip(suffixMap.values(), suffixMap.keys()))
_lowerCaseX  = rxcomp(r'[a-z]')
_interCaseX  = rxcomp(r'[a-z]+([^a-z%s])'%''.join([escape(c) for c in suffixRevMap]))


### Mix-in class for commands that should not show up in HELP? output.
class Hidden (object):
    hidden       = True


### Base class for all command types (Branch, Leaf, Macro)
class Base (object):
    hidden         = False
    shutdownHook   = []
    persistentData = PersistentData('persistentdata.ini')
    globalData     = DynamicData()

    __slots__      = ('name', 'description', 'defaults', 'aliasrefs', '_parentref')

    def __init__ (self, name, parent, defaults=None):
        self.name         = name
        self.description  = self.__class__.__doc__
        self.defaults     = defaults or {}
        self.aliasrefs    = set()
        if parent:
            self._parentref = ref(parent)

        
    ####################################################################
    ### Property functions for access to <instance>.parent

    _parentref = None

    @property 
    def parent (self):
        if self._parentref:
            return self._parentref()

    @property
    def super (self):
        return super(self.__class__, self)



    ####################################################################
    ### Method for translating class names to SCPI commands


    _suffixX     = rxcomp('_(%s)$'%'|'.join(suffixMap.keys()))

    @classmethod
    def scpiName (cls, ident=None):
        if not ident:
            ident = cls.__name__

        match = cls._suffixX.search(ident)
        if match:
            return ident[:match.start()] + suffixMap[match.group(1)]
        else:
            return ident


    @classmethod 
    def alternateNames (cls, name):
        shortname = _lowerCaseX.sub('', name)
        intername = _interCaseX.sub(r'\1', name)
        names     = (name, intername, shortname)

        if not names[-1]:
            raise cls.NoUpperCaseLetters(name=names[0])

        return names



    @classmethod
    def className (cls, command):
        if command[-1:] in suffixRevMap:
            return '_'.join((command[:-1], suffixRevMap[command[-1]]))
        else:
            return command
        

    def getCommandClass (self, obj):
        if isinstance(obj, type):
            return obj
        else:
            return obj.__class__


    def defaultAccess (self, subcommand=None):
        path = self.commandPath(subcommand)
        return (CONTROLLER, OBSERVER)[path[-1:] in querySuffixes]


    class ConflictingOptions (CommandError):
        '''Conflicting command options: %(options)s'''

    def checkConflictingOptions (self, **options):
        provided = [ key for (key, value) in options.items() if value ]
        if len(provided) > 1:
            raise self.ConflictingOptions(options=",".join(provided))




    ####################################################################
    ### The following functions are used to support HELP?/XMLHelp?

    def getDocumentation (self, margin=0, columns=0, defaults=None):
        doc     = []
        props   = self.listProperties(margin, columns)
        syntax  = self.getSyntax(margin, columns, defaults=defaults)
        desc    = self.getDescription(margin, not columns)

        for section, lines in (('Properties:',   props),
                               ('Usage:',        syntax),
                               ('Description:',  desc)):
            if lines:
                if doc:
                    doc.append('')
                doc.append(section)
                doc.extend(lines)

        return doc


    def listProperties (self, margin, columns):
        proplist = self.getProperties()
        maxlen   = max([ len(prop) for (prop, value) in proplist ])
        proptext = []
        return [ '%*s%-*s: %s'%(margin, '', maxlen, prop, value)
                 for prop, value in proplist ]


    def getProperties (self):
        props = []

        props.append(('PrimaryName', self.name))
#        for name in self.names[1:]:
#            props.append(('AlternateName', name))

        props.append(('FullCommand', ':'+self.commandPath(short=False)))
        props.append(('ShortCommand', ':'+self.commandPath(short=True)))

        props.append(('Type',  self.getTypeName()))
        return props


    indentX    = rxcomp(r'^( +)\S+', MULTILINE)

    def getDescription (self, margin, unwrap=False, doc=None):
        if doc or self.description:
            text  = (doc or self.description or '').expandtabs()
            

            ### 'De-dent' the document string
            match  = self.indentX.search(text)
            indent = match and match.group(1) or ''
            text   = '%s%s'%(indent, text.strip())
            adjust = margin - len(indent)

            if unwrap:
                text = rxcomp(r'( +\S*)\n%s(\S)'%indent).sub(r'\1 \2', text)
                text = rxcomp(r'\n\s*\n').sub(r'\n', text)

            lines = text.splitlines()

            if adjust < 0:
                for idx, line in enumerate(lines):
                    if line[:-adjust].isspace():
                        lines[idx] = line[-adjust:]

            elif adjust > 0:
                fill = ''.ljust(adjust)
                for idx, line in enumerate(lines):
                    if line.startswith(' ') or not indent:
                        lines[idx] = fill + line

            return lines


    def getSyntax (self, margin, columns, defaults=None):
        return [ '%*s%s'%(margin, '', self.name) ]


    ########################################################################
    ### Description of command type; overwritable in subclasses

    @classmethod
    def getTypeName (cls):
        return cls.TypeName

    @classmethod
    def istype (cls, type):
        return issubclass(cls, type)

    @classmethod
    def type (cls):
        return cls

    ####################################################################
    ### The following are used to map this object to a command.

    def path (self, scope=None):
        elements = []
        obj = self
        while obj is not scope and obj.parent:
            elements.insert(0, obj)
            last = obj
            obj  = obj.parent

        return tuple(elements)


    _shortslice = {
        None  : slice(None, -1),
        False : slice(None, 0),
        True  : slice(None, None)
    }

    def commandPath (self, child=None, scope=None, delimiter=':', short=None):
        names = [ obj.name for obj in self.path(scope) ]
        slc   = self._shortslice[short]
        names[slc] = [ _lowerCaseX.sub('', name) for name in names[slc] ]

        if child is not None:
            names.append(child)

        return delimiter.join(names)


    def getDefaults (self, scope=None):
        defaults = {}

        for element in self.path(scope):
            defaults.update(element.defaults)

        return defaults


                 
    ####################################################################
    ### Logging and Debugging

    def log (self, level, message):
        publish(self.debugTopic, message, level=level)

    def trace (self, message):
        self.log(TRACE, message)

    def debug (self, message):
        self.log(DEBUG, message)

    def info (self, message):
        self.log(INFO, message)

    def notice (self, message):
        self.log(NOTICE, message)

    def warning (self, message):
        self.log(WARNING, message)

    def error (self, message):
        self.log(ERROR, message)



    #######################################################################
    ### Miscellaneous utility functions


    def num2string (self, value, precision=None, default=""):
        if value is None:
            return str(default)
        elif precision is not None and isinstance(value, (float, int)):
            return "%.*f"%(precision, value)
        else:
            return str(value)
            

    ########################################################################
    ### Abstract superclasses

    def getInputs (self):
        return []

    def getOutputs (self):
        return []


    ########################################################################
    ### The following are used to manage server startup/shutdown

    def addShutDownAction (self, method, args=(), kwargs={}, early=False):
        if early:
            self.shutdownHook.insert(0, (method, args, kwargs))
        else:
            self.shutdownHook.append((method, args, kwargs))



commandTypes = { None: Base }
def addCommandType (cls):
    commandTypes[cls.__name__] = cls

########################################################################
### FILE:	llacTagBranch.py
### PURPOSE:	Interface to ThermoFisher consumable tags
### HISTORY:
###  2016-11-20 Tor Slettnes
###             Created
###
### Copyrights (C) 2016 ThermoFisher Scientific.  All rights reserved.
########################################################################

from rfidTagBase     import RFIDTagBranch
from llacCommandBase import LLACCommandBranch
from scpiExceptions  import RunError
from scpiConfigBase  import ConfigBase
from scpiBranch      import branchTypes

import struct


class LLACTagBranch (LLACCommandBranch, RFIDTagBranch):
    '''Commands to read/write ThermoFisher RFID Tags'''


    LLACCONFIGFILE = "llactag.ini"
    (RegSection, CmdSection, StatusSection) = \
                 ("Registers", "Command", "Status")

    Registers = ("COMMand", "STATus?", "PARameter",
                 "TagCount?", "TagSELect", "TagSIZe?",
                 "BufferCAPacity?", "BufferSIZe", "BUFFer")

    (R_COMMAND, R_STATUS, R_PARAMETER,
     R_TAGCOUNT, R_TAGSELECT, R_TAGSIZE,
     R_BUFFERCAPACITY, R_BUFFERSIZE, R_BUFFER) = range(len(Registers))

    Commands = ("Disable", "Enable", "Discover", "Read", "Write", "GetVersion")
    (C_DISABLE, C_ENABLE, C_DISCOVER, C_READ, C_WRITE, C_GETVERSION) = range(len(Commands))

    Statuses = ("Enabled", "Error", "RFFieldState", "BootLoadMode", "TagOpen")
    (S_ENABLED, S_ERROR, S_RFFIELDSTATE, S_BOOTLOADMODE, S_TAGOPEN) = range(len(Statuses))

    PAGESIZE    = 4

    def __init__ (self, *args, **kwargs):
        RFIDTagBranch.__init__(self, *args, **kwargs)
        LLACCommandBranch.init(self)
        LLACTagBranch.init(self)

    def init (self):
        self.bufferCapacity = None
        self.bufferStart    = 0
        self.bufferSize     = 0


    def startRead (self, tagindex):
        RFIDTagBranch.startRead(self, tagindex)
        try:
            self.selectTag(tagindex)
        except Exception, e:
            self.finishRead(tagindex)
            raise
        else:
            self.bufferStart = 0
            self.bufferSize  = 0


    def readBytes (self, start, stop):
        data = bytearray()

        for address in range(start, stop, self.PAGESIZE):
            if address >= self.bufferStart + self.bufferSize:
                first = address - (address % self.PAGESIZE)
                self.loadBuffer(first, stop-first)

            page  = (address - self.bufferStart)/self.PAGESIZE
            value = self.readValue(self.R_BUFFER, **self.pageRegSpecs(page))
            data.extend(value[::-1]) ### FW BUG: Data arrives in reversed byte order.

        return data[start%self.PAGESIZE:]


    def getCapacity (self, tagindex):
        self.selectTag(tagindex)
        return self.readValue(self.R_TAGSIZE)


    def startWrite (self, tagindex):
        RFIDTagBranch.startWrite(self, tagindex)
        try:
            self.selectTag(tagindex)
        except Exception, e:
            self.finishWrite(tagindex)
            raise


    def writeBytes (self, address, bytes):
        ### If address is not aligned to start of page, pad with zeroes before.
        while address % self.PAGESIZE:
            bytes.insert(0, 0)
            address -= 1

        ### If data does not end at a page boundary, pad with zeroes after.
        while len(bytes) % self.PAGESIZE:
            bytes.append(0)

        remaining  = len(bytes)
        buffersize = min(remaining, self.bufferCapacity)
        self.writeValue(self.R_BUFFERSIZE, buffersize)

        page = 0
        for index in range(0, remaining, self.PAGESIZE):
            if page*self.PAGESIZE >= self.bufferCapacity:
                self.saveBuffer(address, self.bufferCapacity)
                address += self.bufferCapacity
                remaining -= self.bufferCapacity
                page = 0

            chunk = bytes[index:index+self.PAGESIZE][::-1] ### FW BUG: Data is expected in reversed byte order.
            self.writeValue(self.R_BUFFER, str(chunk), **self.pageRegSpecs(page))
            page += 1

        if page:
            self.saveBuffer(address, remaining)


    def pageRegSpecs (self, page):
        return {
            'register' : self.registers[self.R_BUFFER]['register'] + page,
            'size'     : self.PAGESIZE,
            'packing'  : "%ds"%(self.PAGESIZE,)
        }


    def loadBuffer (self, address, count=None, abortable=True):
        if count is None or count > self.bufferCapacity:
            count = self.bufferCapacity
            
        refs = [ self.sendValue(self.R_PARAMETER,  address),
                 self.sendValue(self.R_BUFFERSIZE, count),
                 self.sendCommand(self.C_READ) ]

        pending = self.waitAck(refs)

        self.bufferStart = address
        self.bufferSize  = count

        self.waitSync(pending, abortable=abortable)


    def saveBuffer (self, address, count=None, abortable=True):
        if count is None or count > self.bufferCapacity:
            count = self.bufferCapacity
        

        refs = [ self.sendValue(self.R_PARAMETER,  address),
                 self.sendValue(self.R_BUFFERSIZE, count),
                 self.sendCommand(self.C_WRITE) ]

        pending = self.waitAck(refs)
        self.bufferStart = address
        self.bufferSize  = count

        self.waitSync(pending, abortable=abortable)

        
    def discover (self):
        self.command(self.C_DISCOVER)
        return self.readValue(self.R_TAGCOUNT)


    def selectTag (self, index):
        RFIDTagBranch.selectTag(self, index)
        self.writeValue(self.R_TAGSELECT, index)


    def loadRegisters (self):
        LLACCommandBranch.loadRegisters(self)
        self.bufferCapacity = self.readValue(self.R_BUFFERCAPACITY)



class COFFEETagBranch (LLACTagBranch):
    LLACCONFIGFILE = "coffeetag.ini"


branchTypes['CoffeeTag'] = COFFEETagBranch

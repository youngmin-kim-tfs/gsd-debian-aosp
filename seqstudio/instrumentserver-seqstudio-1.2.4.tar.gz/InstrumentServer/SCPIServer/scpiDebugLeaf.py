########################################################################
### FILE:	scpiDebugLeaf.py
### PURPOSE:	"DEBug" command
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf      import Leaf, Controlling
from commandParser import QuoteStyle, QUOTE_ATTRIBUTES
from subscription  import publish, TRACE, DEBUG, INFO, NOTICE, WARNING, LogLevels

class _DebugLeaf (Controlling, Leaf):
    method = None

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('quoted', type=QuoteStyle, named=True, default=QUOTE_ATTRIBUTES,
                      description='Context under which the message topic exists')

        self.setInput('message', type=tuple, repeats=(0, None))

    def publish (self, parts, level, quoting):
        topic = LogLevels[level]
        publish(topic, parts, level=level, quoting=quoting)


class TRACe (_DebugLeaf):
    '''
    Publish/log a message on topic "Trace", with severity Trace.
    '''

    def run (self, quoted, *message):
        self.publish(message, TRACE, quoted)


class DEBug (_DebugLeaf):
    '''
    Publish/log a message on topic "Debug", with severity Debug.
    '''

    def run (self, quoted, *message):
        self.publish(message, DEBUG, quoted)

class INFo (_DebugLeaf):
    '''
    Publish/log a message on topic "Info", with severity Info.
    '''
    def run (self, quoted, *message):
        self.publish(message, INFO, quoted)


class NOTice (_DebugLeaf):
    '''
    Publish/log a message on topic "Notice", with severity Notice.
    '''
    def run (self, quoted, *message):
        self.publish(message, NOTICE, quoted)

class WARNing (_DebugLeaf):
    '''
    Publish/log a message on topic "Warning", with severity Warning.
    '''
    def run (self, quoted, *message):
        self.publish(message, WARNING, quoted)

########################################################################
### FILE:	scpiLoggerLeaf.py
### PURPOSE:	LOGGer command
########################################################################

from scpiFullBranch     import FullBranch
from scpiLeaf           import Leaf, Controlling, Observing
from scpiFilesystemBase import FilesystemBase, FilesystemLeaf
from scpiFileContexts   import OP_READ, OP_WRITE, OP_APPEND, P_READ, P_WRITE
from scpiExceptions     import RunError, ReturnCall
from commandParser      import parser
from schedule           import getAlignmentTime, TaskAlignment, A_LOCAL
from threading          import Lock
from time               import time, timezone, altzone, localtime
from fnmatch            import fnmatchcase
from gzip               import GzipFile

import subscription
import sys

class SubscriptionLog (FilesystemBase):

    def __init__ (self, format=subscription.Message.defaultFormat, maxEntries=4096, *args, **kwargs):
        self.cache           = []
        self.logfileContext  = None
        self.logfileName     = None
        self.logfileTemplate = None
        self.nextsync        = 0
        self.syncinterval    = None
        self.rotateinterval  = None
        self.rotatealign     = A_LOCAL
        self.nextrotation    = 0
        self.format          = format
        self.maxEntries      = maxEntries
        self.cacheLock       = Lock()
        self.logfile         = None


    def handleMessage (self, message):
        text = message.format(self.format)
        with self.cacheLock:
            try:
                if not self.logfileName:
                    if self.maxEntries and len(self.cache) + 1 >= self.maxEntries:
                        del self.cache[:len(self.cache)-self.maxEntries+1]

                elif message.timestamp >= self.nextrotation:
                    self._flushCache()

                    self.logfileName  = self.getFileName(message.timestamp)
                    self.nextrotation = self.getRotationTime(message.timestamp + (self.rotateinterval or 0))

                    if not self.syncinterval:
                        self.logfile = self._openFile(append=True)
                        
                elif not self.syncinterval:
                    if (message.timestamp >= self.nextsync) or not self.logfile:
                        self.nextsync = int(message.timestamp+1)
                        newfilename   = self.getFileName(message.timestamp)

                        if newfilename != self.logfileName or not self.logfile:
                            self._flushCache()
                            self.logfileName = newfilename
                            self.logfile     = self._openFile(append=True)

                elif message.timestamp >= self.nextsync:
                    self._flushCache()
                    self.nextsync    = (int(message.timestamp / self.syncinterval) + 1) * self.syncinterval
                    self.logfileName = self.getFileName(message.timestamp)


                if self.logfile:
                    self.logfile.write(text)
                    self.logfile.flush()
                else:
                    self.cache.append(text)

            except EnvironmentError, e:
                ### Flushing to file failed; temporarily disable this while recording
                ### a message about the failure to avoid infinite recursion.
                self.logfileName = None
                self.logfile = None
                subscription.warning('When attempting to flush log to %r: [%s] %s'%
                                     (self.logfileContext.vfspath(self.logfileName),
                                      e.__class__.__name__, str(e)))


    def flushCache (self):
        with self.cacheLock:
            if self.cache:
                self._flushCache()
                
            if self.logfile:
                self.logfile.close()

            self.logfile = None


    def _flushCache (self):
        fp = self.logfile

        if self.cache:
            if not fp:
                fp = self._openFile(append=True)
            if fp:
                fp.writelines(self.cache)

        if fp:
            fp.close()
            self.logfile = None
            del self.cache[:]


    def sendLog (self, output, *masks):
        with self.cacheLock:
            self._flushCache()
            if self.logfileName:
                try:
                    fp = self.logfileContext.open(self.logfileName, OP_READ)
                except EnvironmentError:
                    pass
                else:
                    self._writeLines(output, masks, fp)
            else:
                self._writeLines(output, masks, self.cache)


    def _writeLines (self, output, masks, log):
        for line in log:
            if masks:
                for mask in masks:
                    if fnmatchcase(line, mask):
                        output.write(line)
                        break
            else:
                output.write(line)
        

    def clearLog (self):
        with self.cacheLock:
            try:
                if self.logfile:
                    self.logfile.close()
                if self.logfileName:
                    self.logfileContext.remove(self.logfileName)
            except EnvironmentError, e:
                pass

            self.logfileName = None
            self.logfile = None
            del self.cache[:]


    def setLocation (self, context, path, append, syncinterval, rotateinterval, rotatealign):
        with self.cacheLock:
            #context.enter()
            timestamp = time()
            self.syncinterval    = syncinterval
            self.rotateinterval  = rotateinterval
            self.rotatealign     = rotatealign
            self.logfileContext  = context
            self.logfileTemplate = path
            self.logfileName     = self.getFileName(timestamp)
            self.nextrotation    = self.getRotationTime(timestamp + (self.rotateinterval or 0))
            self.logfile         = None
            self._flushCache()



    def clearLocation (self):
        with self.cacheLock:
            if self.logfileContext:
                try:
                    self._flushCache()
                    if self.logfile:
                        self.logfile.close()
                finally:
                    #self.logfileContext.exit(ignoreErrors=True)
                    self.logfileContext  = None
                    self.logfileTemplate = None
                    self.logfileName     = None
                    self.logfile         = None


    def _openFile (self, append=True, compress=None, compressionLevel=6):
        context, filename = self.logfileContext, self.logfileName

        if context and filename:
            if compress is None:
                compress = filename.endswith(".gz")

            fp = context.open(filename, (OP_WRITE, OP_APPEND)[append])
            if compress:
                fp = GzipFile(context.basename(filename), ("w", "a")[append], compressionLevel, fp)

            return fp



    def getRotationTime (self, timestamp):
        if self.rotateinterval:
            dstflag   = localtime(timestamp)[-1]

            aligntime = getAlignmentTime(self.rotateinterval,
                                         self.rotatealign,
                                         timestamp=timestamp)

            while (localtime(aligntime)[-1] != dstflag) and (aligntime < timestamp):
                ### We have just switched to/from daylight savings time.
                ### Bring the alignment cutoff forward one hour at a time
                ### until we are in the current DST zone.
                aligntime += 3600

            return aligntime


    def getFileName (self, timestamp=None):
        if timestamp is None:
            timestamp = time()

        rotationtime = self.getRotationTime(timestamp)
        message = subscription.Message(None, None, timestamp=rotationtime or timestamp)
        return message.format(self.logfileTemplate)



class LOGGer (FullBranch):
    """
    Commands for logging and retreiving published messages.
    """

    class NoSuchLog (RunError):
        'No such log instance exists: %(name)r'

    class NotLogged (RunError):
        'The topic %(topic)s is not being logged'


    def __init__ (self, *args, **kwargs):
        FullBranch.__init__ (self, *args, **kwargs)
        self.loglist = { None : SubscriptionLog() }
        self.addShutDownAction(self.flushLogs, early=True)


    def loggerKey (self, name, mustExist=True):
        if name is not None:
            name = name.lower()

        if mustExist and not name in self.loglist:
            raise self.NoSuchLog(name=name)

        return name

    def getLog (self, name, mustExist=True):
        return self.loglist.get(self.loggerKey(name, mustExist=mustExist))


    def flushLogs (self):
        subscription.debug("Flushing pending messages to log(s)")

        try:
            for instance in self.loglist.values():
                instance.flushCache()
        except EnvironmentError, e:
            warning("While flushing pending messages to log: [Error %s] %s"%(e.errno, e.args[-1]))


    def deleteLog (self, name, ignoreMissing=False):
        key = self.loggerKey(name, mustExist=not ignoreMissing)

        instance = self.loglist.pop(key, None)

        if instance:
            subscription.clearSubscriptions(instance.handleMessage)
            try:
                instance.flushCache()
            except EnvironmentError, e:
                warning("While flushing pending messages to log %r: [Error %s] %s"%
                        (name, e.errno, e.args[-1]))


    def topicPath (self, context, path, topic):
        if path:
            context = context.find(path)
        return context.commandPath(topic or None, short=True)


    class NEW (Controlling, Leaf):
        '''
        Create a new logger instance.

        For a description of the 'format' string, see the "FORMAT" command.

        An optional colon followed by a positive or negative integer can be used
        to specify right- and left- adjustment, and in the case of timestamp, 
        number of digits before and after the decimal point:
            ${localtime}${timestamp:0.3} ${topic:15}: ${message}
        '''

        class LogExists (RunError):
            'Log instance exists: %(log)r'

        def declareInputs(self):
            Leaf.declareInputs(self)
            self.setInput('format', type=str,
                          description='Format of entries in the log.')
                          

        def run (self, replaceExisting=False, format=subscription.Message.defaultFormat, name=str):
            key = self.parent.loggerKey(name, mustExist=False)
            if key in self.parent.loglist:
                if replaceExisting:
                    self.parent.deleteLog(name, True)
                else:                    
                    raise self.LogExists(log=key)

            if not format.endswith('\n'):
                format += '\n'

            self.parent.loglist[key] = instance = SubscriptionLog(format=format)
            

    class LOG (Controlling, Leaf):
        '''
        Add a message to the log, without publishing a corresponding message
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance. If not specified, the default log is used.')

            self.setInput('level',
                          type=subscription.LogLevels,
                          named=True,
                          default=subscription.DEBUG,
                          description='Log level')

            self.setInput('message', type=tuple, repeats=(1, None))


        def run (self, log=None, level=subscription.DEBUG, topic="LOG", *message):
            instance  = self.parent.getLog(log)
            message   = subscription.Message(topic, message, level=level)
            instance.handleMessage(message)


    class DELete (Controlling, Leaf):

        class NotAllowed (RunError):
            'Delete %(log)r instance not allowed'


        def run (self, ignoreMissing=False, name=str):
            self.parent.deleteLog(name, ignoreMissing)



    class FILe (Controlling, FilesystemLeaf):
        '''
        Use the specified file to store the subscription log.

        Until a log file has been set, all messages are retained in
        memory.  This can be a significant cause of "memory leaks"
        during operation.

        The following substitutions takes place in the supplied filename:
          ${timestamp} - timestamp given as seconds since epoch.
                         By default, 3 digits after decimal point is used.
          ${utcdate}   - Universal date in ISO format (YYYY-MM-DD)
          ${utctime}   - Universal time in ISO format (HH:MM:SS.sss)
          ${utc}       - Universal date/time in ISO format
          ${localdate} - Local date in ISO format (YYYY-MM-DD)
          ${localtime} - Local time in ISO format (HH:MM:SS.sss)
          ${local}     - Local date/time in ISO format
          ${timezone}  - Local time zone (e.g. GMT, PST, PDT)
          ${thread}    - Name of thread generating the log entry


    Example:
      * Log to a file named based on date and hour, and rotate every 2 hours:
        C: LOGGer:FILE -rotateInterval=7200 -rotateAlignment=local \
                  'LOGS:myfile-${localdate}-${localhour}-${timezone}.log'
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance. If not specified, the default log is used.')

            self.setInput('append',
                          type=bool,
                          named=True,
                          default=False,
                          description=
                          'If set, append to pre-existing log files rather than overwriting')

            self.setInput('sync',
                          units='seconds',
                          type=float,
                          default=None,
                          named=True,
                          description=
                          'Minimum interval between each synchronization to the specified file')
            
            self.setInput('rotateInterval',
                          units='seconds',
                          type=float,
                          default=None,
                          named=True,
                          range=(0, None),
                          description='If specified, rotate the log file at the specified interval')

            self.setInput('rotateAlignment',
                          default=A_LOCAL,
                          named=True,
                          type=TaskAlignment,
                          description='Align rotation of log files ')

            self.setInput('filename',
                          type=str,
                          description='Context/Path/Name of log file.')


        def run (self, _session, log, append, sync, rotateInterval, rotateAlignment, filename):
            instance = self.parent.getLog(log)
            cxtname, name = self.splitLocation(filename)
            context = self.openContext(cxtname, _session, P_WRITE)
            instance.setLocation(context, name, append, sync, rotateInterval, rotateAlignment)


    class FILe_Clear (Controlling, FilesystemLeaf):
        '''
        Stop logging published messages to file.

        All subsequent log entries will be kept in memory.  This can
        be a significant cause of "memory leaks" during operation.
        '''

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def run (self, _session, log):
            instance = self.parent.getLog(log)
            instance.clearLocation()



    class FILE_Query (Observing, FilesystemLeaf):
        '''
        Return the current log file name, if any.
        '''
        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('template',
                          type=bool,
                          named=True,
                          default=False,
                          description='Return filename template, rather than current file')

            self.setInput('basename',
                          type=bool,
                          named=True,
                          default=False,
                          description='Return only the base of the filename, excluding context and folder names')
                          
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')


        def declareOutputs (self):
            FilesystemLeaf.declareOutputs(self)
            self.addOutput('name', type=str, default=None)

        def run (self, template=bool, basename=bool, log=str):
            instance = self.parent.getLog(log)
            if template:
                name = instance.logfileTemplate
            else:
                name = instance.logfileName

            if basename and instance.logfileContext:
                name = instance.logfileContext.basename(name)

            return name


    class FLUSH (Controlling, FilesystemLeaf):
        '''
        Flush any published messages still pending in memory to the
        configured log file.
        '''

        class NoLogFile (RunError):
            'No log file has been specified; please see the "FILe" command.'

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          default=None,
                          description='Log instance')

        def run (self, ignoreMissing=False, log=str):
            if log:
                instance = self.parent.getLog(log, mustExist=not ignoreMissing)

                if not ignoreMissing and instance and not instance.logfileName:
                    raise self.NoLogFile()

                if instance:
                    instance.flushCache()
            else:
                for instance in self.parent.loglist.values():
                    instance.flushCache()


    class FORMat (Controlling, Leaf):
        """
        Set log message format.

        The following substitutions takes place in the "format" string:
          ${topic}     - the topic on which the message was published
          ${timestamp} - timestamp given as seconds since epoch.
                         By default, 3 digits after decimal point is used.
          ${utcdate}   - Universal date in ISO format (YYYY-MM-DD)
          ${utctime}   - Universal time in ISO format (HH:MM:SS.sss)
          ${utc}       - Universal date/time in ISO format
          ${localdate} - Local date in ISO format (YYYY-MM-DD)
          ${localtime} - Local time in ISO format (HH:MM:SS.sss)
          ${local}     - Local date/time in ISO format
          ${timezone}  - Local time zone (e.g. GMT, PST, PDT)
          ${message}   - Message text
        """

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')


        def run (self, log=str, format=str):
            instance = self.parent.getLog(log)

            if not format.endswith('\n'):
                format += '\n'

            instance.format = format

            

    class FORMat_Query (Observing, Leaf):
        """
        Get the current log message format.
        """

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')


        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('format', type=str, default=subscription.Message.defaultFormat)


        def run (self, log=str):
            instance = self.parent.getLog(log)

            return instance.format




    class LIMit (Controlling, Leaf):
        """
        Set maximum number of entries that will be kept in memory.
        A value of 0 indicates no limit.
        (Without a log file, this will cause a persistent memory leak).
        """
        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def run (self, log=str, maxEntries=int):
            instance = self.parent.getLog(log)
            instance.maxEntries = maxEntries
            


    class LIMit_Query (Observing, Leaf):
        """
        Get maximum number of entries that will be kept in memory.
        A value of 0 indicates no limit.
        """
        
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('limit', type=int)

        def run (self, log=str):
            instance = self.parent.getLog(log)
            return instance.maxEntries
            


    class ADD (Controlling, Leaf):
        """
        Add the specified topic to the subscription log.
        logging messages on a given topic to the subscription log.
        """
            
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

            self.setInput('level',
                          type=subscription.LogLevels,
                          named=True,
                          default=None,
                          description='Log messages at the specified level or above')

            self.setInput('scope', type=str, named=True, default=None,
                          description='Command scope under which the message topic exists')

#            self.setInput('future',
#                          type=bool,
#                          named=True,
#                          default=False,
#                          description='Add any matching message topics created in the future')

            self.setInput('masks', type=str, repeats=(1, None))


        def run (self, _scope, ignoreMissing=False, log=None, level=None, scope=None, *masks):
            instance = self.parent.getLog(log)

            if level is None:
                level = subscription.DefaultLogLevel

            for mask in masks:
                maskpath = self.parent.topicPath(_scope, scope, mask)
                subscription.subscribe(maskpath, level, instance.handleMessage,
                                       ignoreMissing=ignoreMissing, future=True)



    class REMove (Controlling, Leaf):
        """
        Stop logging messages on the given topic to the subscription log.
        """

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('result', type=str, repeats=(0, 1))

        def run (self, ignoreMissing=False, log=str, *masks):
            instance = self.parent.getLog(log)

            missing = []
            for m in masks:
                if not subscription.unsubscribe(m, instance.handleMessage):
                    missing.append(m)

            if missing:
                raise self.parent.NotLogged(topic=missing[0])



    class CLEar (Controlling, FilesystemLeaf):
        """
        Clear the subscription log.
        """
        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def run (self, log=None):
            instance = self.parent.getLog(log)
            try:
                instance.clearLog()
            except KeyError:
                raise self.parent.NoSuchLog(name=log)



    class LIST_Enumerate (Observing, Leaf):
        """
        Return a list of logger instances.
        """

        def declareOutputs (self):
            self.startOutputs()
            self.addOutput('logs', type=str, repeats=(0, None),
                           description='Logger instances')

        def run (self):
            return tuple(filter(None, self.parent.loglist))



    class LIST_Query (Observing, Leaf):
        """
        List all topics that are currently being logged.
        If "-future" is specified, list masks for future
        topic subscription.
        """

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          description='Log instance')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('topic', type=str, repeats=(0, None))

        def run (self, ignoreMissing=False, log=str):
            log = self.parent.getLog(log, mustExist=not ignoreMissing)
            return tuple(subscription.getSubscribedTopics(log.handleMessage))


    class READ_Query (Observing, FilesystemLeaf):
        """
        List messages in the subscription log.  Each entry consists of
        a topic, a timestamp, and the message contents.

        If 'topic' is specified, return only messages on that topic.
        """

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('messages', type=list, format="%s")

        def run (self, log, *masks):
            instance = self.parent.getLog(log)
            raise ReturnCall(self, instance.sendLog, masks, {})


    class SAVe (Observing, FilesystemLeaf):
        '''

        Perform a one-time save of the subscription log to the
        specified file.  (Note that this does not affect whether or
        not log messages are kept in memory - to periodically "flush"
        messages to the filesystem, use the "FILe" command instead).
        '''
        class IsActiveFile (RunError):
            'Active logger instance %(instance)s is using %(filename)s'

        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('log',
                          type=str,
                          named=True,
                          default=None,
                          description='Log instance')

        def run (self, _session, log, filename=str, mask="*"):
            instance = self.parent.getLog(log)
            with self.openLocation(filename, _session, P_WRITE) as loc:
                for n, l in self.parent.loglist.items():
                    if (l.logfileContext, l.logfileName) == (loc.context, loc.path):
                        raise self.IsActiveFile(instance=n, filename=filename)

                fp = loc.open(OP_WRITE)
                instance.sendLog(fp, mask)
                fp.close()

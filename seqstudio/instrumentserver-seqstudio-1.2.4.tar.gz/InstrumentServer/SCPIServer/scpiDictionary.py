########################################################################
### FILE:	scpiDictionary.py
### PURPOSE:	Key/value mappings
### HISTORY:
###  2013-03-11 Tor Slettnes
###             Created
###
### Copyrights (C) 2013 Life Technologies.  All rights reserved.
########################################################################

from scpiLeaf          import Leaf, Controlling, Observing
from scpiVariableLeaf  import VariableLeaf, VariableScopes
from scpiExceptions    import RunError, ReturnValue, Break
from scpiSession       import SYNC, PASSTHROUGH
from scpiParameter     import Missing
from fnmatch           import fnmatchcase
from subscription      import info
from data              import DynamicData, DataProxy


class DictionaryLeaf (VariableLeaf):

    class Exists (RunError):
        '''A dictionary named %(name)r already exists'''

    def keymatches (self, scope, name, dictionary, masks, ignoreMissing=False):
        keys = set()

        for mask in masks:
            lmask = mask.lower()
            mkeys = [ k for k in dictionary if fnmatchcase(k.lower(), lmask) ]
            if not ignoreMissing and not mkeys:
                raise self.NoSuchKey(scope=VariableScopes[scope], name=name, key=mask)
            keys.update(mkeys)

        return sorted(keys)

    def getValue (self, scope, name, data, key, ignoreMissing, default):
        try:
            return data[key]
        except KeyError:
            if ignoreMissing or default is not None:
                return default
            else:
                raise self.NoSuchKey(scope=self.scopeName(scope), name=name, key=key)

    def getItems (self, scope, localdata, name, keys, named=False, nonEmpty=False, default=None, ignoreMissing=False, branch=None):
        scope, data, d = self.dataProxy(scope, localdata, name,
                                        datatype=dict,
                                        ignoreMissing=ignoreMissing,
                                        default={},
                                        branch=branch)

        if keys:
            items = [((None, key)[named], self.getValue(scope, name, d, key, ignoreMissing, default)) for key in keys]

        elif d:
            items = sorted(d.items())

        else:
            items = []

        if nonEmpty:
            items = [(k, v) for (k, v) in items if v]

        return data, items


class DICTionary_Add (Controlling, DictionaryLeaf):
    '''Create a new dictionary.'''

    def run (self, _context, scope=VariableScopes, replaceExisting=False, name=str):
        scope, data, value = self.dataProxy(scope, _context.data, (name, None)[replaceExisting], datatype=dict, ignoreMissing=True)
        if value is not None:
            raise self.Exists(name=name)

        data[name] = DynamicData()


class DICTionary_Remove (Controlling, DictionaryLeaf):
    '''Delete an existing dictionary'''

    def run (self, _context, scope=VariableScopes, ignoreMissing=False, name=str):
        scope, data, value = self.dataProxy(scope, _context.data, name, datatype=dict, ignoreMissing=ignoreMissing)
        if value is not None:
            data.pop(name, None)



class DICTionary_Set (Controlling, DictionaryLeaf):
    '''
    Set one or values in the specified dictionary.
    Key/value pairs can be provided in three ways:
     - As alternate inputs: key1 value1 key2 value2 ...
     - As named inputs: -key1=value1 -key2=value2 ...
     - With variable names as keys and their contents as values:
         -variables var1 var2 ...
    '''

    class MismatchedItems (RunError):
        '''Key/value mismatch; need value for key %(lastkey)r'''


    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('nonEmpty', type=bool, named=True, default=False,
                      description='Set only items that have a non-empty value')
        self.setInput('variables', type=bool, named=True, default=False,
                      description='Inputs are variable names to be used as keys, with corresponding contents as values')

    def run (self, _context, scope=VariableScopes, create=False, ignoreMissing=False, prepend=False, append=False, delimiter="",
             nonEmpty=False, variables=False, dictionary=str, *inputs, **items):

        if not variables and (len(inputs) % 2 != 0):
            raise self.MismatchedItems(keys=len(inputs)/2+1, values=len(inputs)/2, lastkey=inputs[-1])

        scope, data, result = self.dataProxy(scope, _context.data, dictionary, datatype=dict, ignoreMissing=create, default=DynamicData())

        if variables:
            proxy = DataProxy(self.scopeData(_context.data, self.parent))
            for name in inputs:
                try:
                    s, d, v = proxy.getScopeDataValue(None, name)
                except KeyError:
                    if not ignoreMissing:
                        raise self.NoSuchVariable(scope=self.scopeName(scope), name=name)
                else:
                    items[name] = proxy.toString(v)
        else:
            items.update(zip(inputs[0::2], inputs[1::2]))

        if nonEmpty:
            items = dict([(k,v) for (k,v) in items.iteritems() if v])

        if append or prepend:
            for k, v in items.iteritems():
                previous = result.get(k)
                if previous:
                    parts = ((v,previous),(previous,v))[append]
                    items[k] = delimiter.join(parts)

        result.update(items)
        data[dictionary] = result


class DICTionary_Clear (Controlling, DictionaryLeaf):
    '''Delete item(s) from a dictionary'''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('keymasks', type=str, repeats=(1, None), default='*')

    def run (self, _context, scope=VariableScopes, ignoreMissing=False, dictionary=str, *keymasks):
        scope, data, d = self.dataProxy(scope, _context.data, dictionary, datatype=dict, ignoreMissing=ignoreMissing, default={})
        keys = self.keymatches(scope, dictionary, d, keymasks, ignoreMissing)
        for key in keys:
            d.pop(key, None)


class DICTionary_Query (Observing, DictionaryLeaf):
    '''Read one or more values from the specified dictionary'''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('nonEmpty', type=bool, named=True, default=False,
                      description='Return only items that have a non-empty value')
        self.setInput('default', type=str, default=None, named=True)

    def declareOutputs (self):
        DictionaryLeaf.declareOutputs(self)
        self.addOutput('item', type=tuple, repeats=(0, None))

    def run (self, _context, scope=VariableScopes, ignoreMissing=False, nonEmpty=False, default=None, named=False, dictionary=str, *keys):
        data, items = self.getItems(scope, _context.data, dictionary, keys,
                                    named=named, nonEmpty=nonEmpty, default=default,
                                    ignoreMissing=ignoreMissing)
        return tuple(items)



class DICTionary_Exists (Observing, DictionaryLeaf):
    '''Return True if the specified dictionary exists, False otherwise'''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('keys', type=str, repeats=(0, None),
                      description="Test if all of the specified keys exists in the specified "
                      "dictionary. If not provided, test if the specified dictionary exists.")

    def declareOutputs (self):
        DictionaryLeaf.declareOutputs(self)
        self.addOutput('exists', type=bool)

    def run (self, _context, scope=VariableScopes, nonEmpty=False, dictionary=str, *keys):
        try:
            scope, data, d = self.dataProxy(scope, _context.data, dictionary, datatype=dict)
        except self.NoSuchVariable:
            return False
        else:
            if nonEmpty and not keys:
                return bool(d)

            for key in keys:
                if (not key in d) or (nonEmpty and not bool(d[key])):
                    return False
            else:
                return True


class DICTionary_Enumerate (Observing, DictionaryLeaf):
    '''List dictionaries, or keys or values in a specific dictionary'''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('nonEmpty', type=bool, named=True, default=False,
                      description='Return only items that have a non-empty value')
        self.setInput('values', type=bool, default=False, named=True,
                      description='List values, not keys, of the specified dictionary')
        self.setInput('dictionary', type=str, default=None)

    def declareOutputs (self):
        DictionaryLeaf.declareOutputs(self)
        self.addOutput('items', type=str, repeats=(0, None))


    def run (self, _context, scope=VariableScopes, ignoreMissing=False, values=False, nonEmpty=False, dictionary=str, *keymasks):
        if dictionary is None:
            d = self.getData(scope, _context.data, dict)
            items = sorted(d)
        else:
            scope, data, d = self.dataProxy(scope, _context.data, dictionary, datatype=dict, ignoreMissing=ignoreMissing, default={})
            if keymasks:
                keys = self.keymatches(scope, dictionary, d, keymasks, ignoreMissing)
                if values:
                    items = [d[key] for key in keys if not nonEmpty or d[key]]
                elif nonEmpty:
                    items = [key for key in keys if d[key]]
                else:
                    items = keys
            else:
                items = sorted([(k,v)[values] for (k,v) in d.items() if not nonEmpty or v])

        return tuple(items)



class DictionaryCapture (Controlling, DictionaryLeaf):
    '''Capture named output arguments from the specified command, and assign to a dictionary'''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('nonEmpty', type=bool, named=True, default=False,
                      description='Set only items that have a non-empty value')

        self.setInput('update', type=bool, named=True, default=False,
                      description='If dictionary already exists, update instead of replace')

        self.setInput('dictionary', type=str, form=None)
        self.setInput('command', type=tuple, repeats=(1, None))


    def run (self, _session, _context, scope=VariableScopes, nonEmpty=False, update=False, dictionary=str, *command):
        (opt, cmd, raw) = command[0]
        arguments = command[1:]
        context = _session.runParts(_context, cmd, arguments, self.parent, nextReply=SYNC, catchReturn=True)

        if update:
            scope, data, d = self.dataProxy(scope, _context.data, dictionary, datatype=dict, ignoreMissing=True, default=DynamicData())
        else:
            scope, data, d = self.dataProxy(scope, _context.data)
            d = DynamicData()

        for output in context.getOutputs(alwaysNamed=True):
            option, value = output[:2]
            if option and (value or not nonEmpty):
                d[option] = value

        data[dictionary] = d


class DictionaryRun (Controlling, DictionaryLeaf):
    '''
    Run the specified command, with inputs taken from one dictionary, and optionally,
    outputs stored in another dictionary.
    '''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('ignoreExtras', type=bool, named=True, default=False,
                      description='Ignore dictionary keys that are not valid inputs for the command.')
        self.setInput('remove', type=bool, named=True, default=False,
                      description='Remove dictionary after having run the command.')
        self.setInput('dictionary', type=str)
        self.setInput('command', type=tuple, repeats=(1, None))

    def declareOutputs (self):
        DictionaryLeaf.declareOutputs(self)
        self.addOutput('output', type=tuple, repeats=(0, None),
                       description='Outputs from the original command')


    def run (self, _session, _context,
             scope=VariableScopes, ignoreExtras=False, remove=False, nonEmpty=False, dictionary=str, *command):

        scope, data, d = self.dataProxy(scope, _context.data, dictionary, datatype=dict)

        parts = list(command)
        opt, cmd, raw = parts.pop(0)

        leaf = self.parent.find(cmd)
        parts.extend([(k, v, '')
                      for (k, v) in d.items()
                      if (v or not nonEmpty) and (not ignoreExtras or leaf.hasInput(k))])

        try:
            context = _session.runParts(_context, cmd, parts, scope=self.parent,
                                         nextReply=PASSTHROUGH, catchReturn=False)
            return tuple(context.outputs)
        finally:
            if remove:
                data.pop(dictionary, None)


#    def formatOutputs (self, outputs, alwaysNamed=False, raw=False):
#        leaf, response = outputs
#        return leaf.formatOutputs(response, alwaysNamed=alwaysNamed, raw=raw)


class ReturnDictionary (Observing, DictionaryLeaf):
    '''Return the contents of the specified dictionary, e.g. from a macro'''

    def declareInputs (self):
        DictionaryLeaf.declareInputs(self)
        self.setInput('remove', type=bool, named=True, default=False,
                      description='Remove dictionary after having run the command.')
        self.setInput('default', type=str, default=None, named=True)


    def declareOutputs (self):
        DictionaryLeaf.declareOutputs(self)
        self.addOutput('item', type=tuple, repeats=(0, None))


    def run (self, _context, scope=VariableScopes, ignoreMissing=False, remove=False,
             default=None, named=False, dictionary=str, *keys):

        data, items = self.getItems(scope, _context.data, dictionary, keys,
                                    named=named, default=default,
                                    ignoreMissing=ignoreMissing)
        if remove:
            data.pop(dictionary, None)

        raise ReturnValue(*items)

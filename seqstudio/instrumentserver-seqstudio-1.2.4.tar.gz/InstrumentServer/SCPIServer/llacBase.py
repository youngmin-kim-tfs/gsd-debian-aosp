########################################################################
### FILE:	llacBase.py
### PURPOSE:	LLAC protocol support
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2006 Applied Biosystems.  All rights reserved.
########################################################################

from llacController      import LLACController
from scpiExceptions      import NextReply, Error, RunError, CommandError, ComponentError, Aborted
from scpiSession         import AccessLevels, FULL
from scpiBase            import commandTypes
from scpiDynamicBase     import DynamicCommandBase, Dynamic
from scpiDynamicCommands import DynamicBranch
from scpiBranch          import branchTypes
from scpiMinimalBranch   import MinimalBranch
from scpiFullBranch      import FullBranch
from scpiLeaf            import Leaf, Observing, Controlling, Background
from scpiParameter       import Missing
from scpiConfigBase      import ConfigBase
from scpiFilesystemBase  import FilesystemLeaf, P_READ, OP_READ
from scpiPollingBase     import PollItem, PollItemTypes
from scpiServer          import getStartupOption
from locking             import Lock
from subscription        import publish, info, debug, warning

from time                import time, sleep
from new                 import classobj
from sys                 import stderr
from struct              import pack, unpack, calcsize, error as StructError
from re                  import compile
from os                  import getenv, environ
from os.path             import getsize



regTypes = ('BOOL', 'INT', 'UINT', 'HEX', 'REAL', 'TEXT', 'DATA')
regEnums = (BOOL, INT, UINT, HEX, REAL, TEXT, DATA) = range(len(regTypes))
typeMap  = dict(zip(regTypes, regEnums))


class _LLACBase (object):
    '''Abstract superclass for LLAC:<Leaf> implementations'''

    timeout       = 5.0   # Default timeout for read/write operations
    nodename      = {}
    responseTable = {}
    eventTable    = {}
    regTable      = {}
    transport     = __import__(getStartupOption("llactransport", "llacSimulator"))
    llac          = LLACController(transport=transport)

    packCodes = {
        BOOL : {1:'B', 2:'H', 4:'I', 8:'Q'},
        INT  : {1:'b', 2:'h', 4:'i', 8:'q'},
        UINT : {1:'B', 2:'H', 4:'I', 8:'Q'},
        HEX  : {1:'B', 2:'H', 4:'I', 8:'Q'},
        REAL : {4:'f', 8:'d'},
        TEXT : ['%ds'%(n) for n in range(9)],
        DATA : ['%ds'%(n) for n in range(9)]
        }


    argTypes = {
        BOOL  : (bool,  lambda size: '%s'),
        INT   : (int,   lambda size: '%d'),
        UINT  : (abs,   lambda size: '%d'),
        HEX   : (hex,   lambda size: '0x%%0%dX'%(size*2)),
        REAL  : (float, lambda size: '%s'),
        TEXT  : (str,   lambda size: '%s'),
        DATA  : (str,   lambda size: '%s')
        }


    class InvalidSize (RunError):
        'Unsupported size for %(type)s register: %(size)d'

    class InvalidResponseLength (RunError):
        'Expected %(expected)d bytes in response, got %(actual)d'

    class OverFlowValue (RunError):
        'Value is out of range for this register type'

    class PackingError (RunError):
        'Could not write value %(value)r to register %(reg)s: %(error)s'

    class LLACTimeout (RunError):
        pass

    class ResponseTimeout (LLACTimeout):
        'Timed out after %(timeout)ss waiting for response from %(device)s'

    class OperationTimeout (LLACTimeout):
        'Timed out after %(timeout)ss waiting for %(device)s to complete operation'

    class LLACError (RunError):
        '%(message)s'



    def packing (self, type, size, count=1):
        '''
        Return a format string for pack() and unpack(), invoked by
        read() and write().
        '''
        try:
            return '!' + self.packCodes[type][size] * count
        except (KeyError, IndexError):
            raise self.InvalidSize(type=regTypes[type], size=size)


    def read (self, *args, **options):
        ref = self.sendRead(*args, **options)
        return self.getResponse(ref)


    def readList (self, regs, ignoreErrors=False):
        pending = [ self.sendRead(**reg) for reg in regs ]
        return self.getResponseList(pending, ignoreErrors=ignoreErrors)


    def sendRead (self, node, register, size, packing,
                  name=None, **otherstuff):
        '''
        Send a read request, and return the response.

        "packing" is the return value from the "packing()" method, in
        turn based on the type and size of the register to be accessed.
        '''


        try:
            msgid = self.llac.sendRead(name, node, register, size)
        except self.llac.LLACError, e:
            raise self.LLACError(str(e))

        return (msgid, packing)


    def formatValue (self, value, type=None, size=None, **junk):
        argtype, fmt = self.argTypes[type]
        fmt          = fmt(size)
        return fmt%(value,)


    def sendEvent (self, values, node, eventid, packing, control, name=None, **otherstuff):
        '''
        '''
        try:
            buf  = pack(packing, *values)
        except OverflowError:
            raise self.OverFlowValue(reg=name, value=",".join([str(v) for v in values]))
        except StructError, e:
            values = [ str(v) for v in values ]
            raise self.PackingError(reg=name, value=",".join([str(v) for v in values]), error=str(e))

        try:
            msgid = self.llac.sendEvent(name, node, eventid, buf, control)
        except self.llac.LLACError, e:
            raise self.LLACError(str(e))

        return (msgid)


    def receiveResponse (self, msgid, timeout=None, async=False, totalTimeout=None, abortable=True):
        try:
            return self.llac.receiveResponse(msgid, timeout or self.timeout,
                                             asynchronous=async,
                                             abortable=abortable,
                                             totalTimeout=totalTimeout)

        except self.llac.LLACTimeout, e:
            node     = e.request['dest']
            reg      = e.request['ref']
            regname  = e.request['name']
            control  = e.request['control']
            data     = e.request['data']
            device   = self.nodename.get(node, "0x%02X"%node)

            argmap = dict(timeout=e.timeout,
                          msgid="0x%04X"%msgid,
                          node="0x%02X"%node,
                          device=device,
                          scope=self.commandPath(),
                          register=regname,
                          address="0x%04X"%reg,
                          control="0x%02X"%control,
                          data=",".join(["0x%02X"%ord(c) for c in data]))

            if not async:
                raise self.ResponseTimeout(**argmap)
            else:
                raise self.OperationTimeout(**argmap)

        except self.llac.LLACErrorResponse, e:
            reg        = e.request['ref']
            dest       = e.response['dest']
            node       = e.response['source']
            status     = e.response['ref']
            control    = e.response['control']
            data       = e.response['data']
            regname    = e.request['name']

            device     = self.nodename.get(node, "0x%02X"%node)
            eventTable = self.eventTable.get(node, {})

            if (status == 0x000F) and (len(data) >= 2):
                ### Extended error; get error ID from first two data bytes
                errid = (ord(data[0]) << 8) | ord(data[1])
            else:
                ### Get error ID from response code
                errid = status

            if errid in self.responseTable:
                text = self.responseTable[errid]
            elif errid in eventTable:
                text = eventTable[errid]
            else:
                text = "Unknown %s response code 0x%04X"%(device, errid)

            text = self.formatEventText(text,
                                        target=dest,
                                        source=node,
                                        eventid=errid,
                                        msgid=msgid,
                                        control=control,
                                        data=data)


            argmap = dict(register=regname or '0x%04X'%reg,
                          scope=self.commandPath())
            if data:
                argmap.update(data=":".join([ '0x%02X'%ord(c) for c in data ]))

            raise ComponentError(device, "%04X"%status, text, **argmap)

        except self.llac.LLACError, e:
            raise self.LLACError(str(e))


    sExp = compile(r'(\$(target|id|msgid|source|control|severity|device|text|' +
                   r'(\d*)([hiufs]))\$?)')


    def formatEventText (self, text, target, source, eventid, msgid, control, data):
        match    = self.sExp.search(text)

        while match:
            fragments = []
            position  = 0

            while match:
                sWhole, sId, sNumber, sCode = match.groups()

                if sCode:
                    bytes = [int(i) for i in sNumber] or range(4)
                    value = self.unpackBytes(sCode, bytes, data)
                elif sId == 'target':
                    value = '0x%02X'%target
                elif sId == 'source':
                    value = '0x%02X'%source
                elif sId == 'id':
                    value = '0x%04X'%eventid
                elif sId == 'msgid':
                    value = '0x%04X'%msgid
                elif sId == 'control':
                    value = '0x%02X'%control
                elif sId == 'registration':
                    value = str(bool(control & 0x40))
                elif sId == 'severity':
                    severity = (control >> 4) & 0x03
                    value = self.parent.SeverityNames.get(severity, "[0x%X]"%severity)
                elif sId == 'device':
                    value = self.parent.nodename.get(source, "")
                elif sId == 'text':
                    table = self.parent.eventTable.get(source, {})
                    value = table.get(eventid, "")
                else:
                    value = '[substitution error]'

                fragments.append(text[position:match.start(1)])
                fragments.append(value)
                position = match.end(1)
                match = self.sExp.search(text, position)

            fragments.append(text[position:])
            text = ''.join(fragments)
            match = self.sExp.search(text)

        return text


    datatypes = { 'h':HEX, 'i':INT, 'u':UINT, 'f':REAL, 's':TEXT }

    def unpackBytes (self, code, bytes, data):
        string    = ''.join([(data[b:b+1] or '\0') for b in bytes])
        datatype  = self.datatypes[code]
        packing   = self.packing(datatype, len(string))
        value     = unpack(packing, string)
        return self.formatValue(value[0], datatype, len(string))


    def getResponseList (self, pending, ignoreErrors=False, abortable=False):
        try:
            values = []
            for request in pending:
                msgid, packing = request
                value = None
                try:
                    data = self.receiveResponse(msgid, self.timeout, False, abortable=abortable)
                    value, = unpack(packing, data)

                except StructError:
                    if not ignoreErrors:
                        raise self.InvalidResponseLength(expected=calcsize(packing),
                                                         actual=len(data))

                except Exception, e:
                    if not ignoreErrors:
                        raise

                values.append(value)

            return values

        finally:
            for msgid, packing in pending:
                self.llac.finishRequest(msgid)

    def getResponses (self, pending, ignoreErrors=False, abortable=False):
        return tuple(self.getResponseList(pending, ignoreErrors=ignoreErrors, abortable=abortable))

    def getResponse (self, request, ignoreErrors=False, abortable=False):
        return self.getResponseList([request], ignoreErrors=ignoreErrors, abortable=abortable)[0]

    def transfer (self, *args, **options):
        try:
            self.llac.transfer(*args, **options)
        except self.llac.LLACError, e:
            raise self.LLACError(str(e))


    def write (self, *args, **options):
        msgid = self.sendWrite(*args, **options)
        return self.waitAck((msgid, ))

    def syncWrite (self, *args, **options):
        msgid   = self.sendWrite(*args, **options)
        pending = self.waitAck((msgid, ))
        self.waitSync(pending)


    def sendWrites (self, regValuePairs, abortable=True):
        pending = []
        try:
            for reg, value in regValuePairs:
                pending.append(self.sendWrite((value,), **reg))

        except Exception, e:
            self.finishRequests(pending)
            raise

        else:
            return pending


    def sendWrite (self, values, node, register, packing,
                   name=None, flags=0x00, sync=None, timeout=None, type=None, **otherstuff):
        '''
        Send a write request.

        "packing" is the return value from the "packing()" method, in
        turn based on the type and size of the register to be accessed.

        If "sync" is not None, then control bit #7 will be set,
        indicating to the device that we expect a synchronization event
        once the applicable operation has completed.  A NextReply is
        raised, and the resulting "waitSync()" will then wait
        for the duration specified in "timeout" for a response.
        A value of 0.0 indicates to wait forever.
        '''

        try:
            buf  = pack(packing, *values)
        except OverflowError:
            if type is not None:
                type = regTypes[type]
            raise self.OverFlowValue(reg=name, value=",".join([str(v) for v in values]), type=type)
        except StructError, e:
            values = [str(v) for v in values]
            raise self.PackingError(reg=name, value=",".join([str(v) for v in values]), error=str(e))


        if sync:
            flags   |= 0x80
            if timeout:
                sync = timeout

        try:
            msgid = self.llac.sendWrite(name, node, register, buf, flags)
        except self.llac.LLACError, e:
            raise self.LLACError(str(e))

        return (msgid, sync)


    def waitAck (self, pending, abortable=True):
        llacError  = None
        asynchList = []
        attempt    = 0

        while pending:
            resend  = []
            endtime = time() + self.timeout

            for request in pending:
                if not request:
                    continue

                msgid, sync = request

                try:
                    timeout = endtime - time()
                    self.receiveResponse(msgid, timeout, async=False, totalTimeout=self.timeout, abortable=abortable)

                except ComponentError, e:
                    if not llacError:
                        llacError = e

                except self.LLACTimeout, e:
                    if attempt < 2:
                        self.llac.resendRequest(msgid)
                        resend.append(request)
                        continue
                    elif not llacError:
                        llacError = e

                else:
                    if sync:
                        asynchList.append(request)
                        continue

                self.llac.finishRequest(msgid)

            pending = resend
            attempt += 1


        if llacError:
            for msgid, sync in asynchList:
                self.llac.finishRequest(msgid)
            raise llacError

        return asynchList


    def waitSync (self, pending, abortable=True):
        try:
            start = time()
            for msgid, sync in pending:
                waitTime = start + sync - time()
                self.receiveResponse(msgid, timeout=waitTime, async=True, totalTimeout=sync, abortable=abortable)

        finally:
            for msgid, sync in pending:
                self.llac.finishRequest(msgid)


    def finishWrites (self, pending, abortable=True):
        pending = self.waitAck(pending, abortable)
        self.waitSync(pending, abortable)


    def finishRequests (self, pending):
        for msgid, sync in pending:
            self.llac.finishRequest(msgid)


#    def finishWrites (self, pending, waitSync=True, abortable=True):
#        asynchlist = self.waitAck(pending, abortable=abortable)
#        if waitSync:
#            self.waitSync(asynchlist, abortable=abortable)
#        else:
#            raise NextReply(self, self.waitSync, (asynclist, abortable), {})


class _LLACCommandBase (_LLACBase, DynamicCommandBase):
    readLeafs          = {}
    writeLeafs         = {}

    def getClass (self, datatype, cache, regclass, suffix=''):
        try:
            cls = cache[datatype]

        except KeyError:
            clsname = regTypes[datatype] + suffix
            cls     = self.newclass(clsname, (regclass,), (), datatype=datatype)
            cache[datatype] = cls

        return cls



class _LLACLeaf (_LLACBase, Leaf):
    pass

class _LLACRegisterLeaf (Dynamic, _LLACLeaf):
    modifyAccess = FULL
    llacType     = 'LLAC register'
    TypeName     = 'LLAC register'


    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('_defaultnode', default=None)
        self.setInput('_defaultbase', default=None)


    def getType (self):
        return self.llacType



class _LLACWriteLeaf (Controlling, Background, _LLACRegisterLeaf):
    '''
    Write a value to a specified LLAC register.
    '''
    llacType  = 'writable LLAC register'


    def __init__ (self, *args, **kwargs):
        _LLACRegisterLeaf.__init__(self, *args, **kwargs)


    def declareInputs (self):
        _LLACRegisterLeaf.declareInputs(self)
        argtype, format = self.argTypes[self.datatype]
        size            = self.defaults['size']

        self.setInput('offset',
                      named=True,
                      type=int,
                      default=None,
                      description='Device register address offset. '
                      'This overrides any default "-offset" value specified '
                      'for this register.')

        self.setInput('sync', type=float, units='seconds',
                      named=True, default=None,
                      description=
                      'A non-zero value sets the synchronization request bit, after '
                      'which this command will wait for a synchronization response '
                      'from the device for up to the specified timeout.  '
                      'A value of 0 clears the synchronization request bit, and '
                      'the command will complete as soon as it receives the '
                      'acknowledgement from the device.')

        self.setInput('value', type=argtype, format=format(size),
                      description='Register value')


    def run (self, _branch, _defaultnode, _defaultbase,
             node, base, offset, type, sync, packing, value):
        regname = _branch.commandPath(self.name)
        node, register = _branch.getaddress(self.name, _defaultnode, _defaultbase, node, base, offset)

        return self.write((value,), node, register, packing,
                          name=_branch.commandPath(self.name), sync=sync) or None

    def next (self, refs):
        return self.waitSync(refs)


class _LLACReadLeaf (Observing, _LLACRegisterLeaf):
    '''
    Read a value from a specified LLAC register.
    '''
    llacType  = 'readable LLAC register'


    def declareInputs (self):
        _LLACRegisterLeaf.declareInputs(self)

        self.setInput('offset',
                      named=True,
                      type=int,
                      default=None,
                      description='Device register address offset. '
                      'This overrides any default "-offset" value specified '
                      'for this register.')

    def declareOutputs (self):
        _LLACRegisterLeaf.declareOutputs(self)
        argtype, format = self.argTypes[self.datatype]
        size            = self.defaults['size']
        self.addOutput('value', type=argtype, format=format(size))

    def run (self, _branch, _defaultnode, _defaultbase, size, node, base, offset, packing):
        regname         = _branch.commandPath(self.name)
        node, register  = _branch.getaddress(self.name, _defaultnode, _defaultbase,
                                             node, base, offset)
        request         = self.sendRead(node, register, size, packing, name=regname)
        return self.getResponse(request)



class _LLACGroupLeaf (Dynamic, _LLACLeaf):
    __slots__ = ('registers',)
    TypeName = 'LLAC register group'

    class NotInGroup (RunError):
        "The register group %(group)r does have such a register: %(reg)r"

    def __init__ (self, *args, **kwargs):
        _LLACLeaf.__init__(self, *args, **kwargs)
        self.registers = []


    def addMember (self, name, spec):
        argtype, format = self.argTypes[spec['type']]
        self.addRegMethod(name, type=argtype, format=format(spec['size']))
        self.registers.append(spec)


    def delMember (self, name):
        try:
            idx = self.delRegMethod(name)
        except ValueError:
            raise self.NotInGroup(group=self.name, reg=name)
        else:
            del self.registers[idx]


class _LLACReadGroupLeaf (Observing, _LLACGroupLeaf):
    '''
    Read values from a group of LLAC registers simultaneously.
    '''

    llacType = 'readable LLAC register group'

    def __init__ (self, *args, **kwargs):
        _LLACGroupLeaf.__init__(self, *args, **kwargs)
        self.startOutputs()
        self.addRegMethod = self.addOutput
        self.delRegMethod = self.removeOutput

    def addOutput (self, name, **opts):
        _LLACGroupLeaf.addOutput(self, name.rstrip("?"), **opts)

    def run (self):
        pending = [ self.sendRead(**spec) for spec in self.registers ]
        return self.getResponses(pending)



class _LLACWriteGroupLeaf (Controlling, Background, _LLACGroupLeaf):
    '''
    Write values to a group of LLAC registers simultaneously
    '''

    llacType = 'writable LLAC register group'

    def __init__ (self, *args, **kwargs):
        _LLACGroupLeaf.__init__(self, *args, **kwargs)
        self.startInputs()
        self.addRegMethod = self.addInput
        self.delRegMethod = self.removeInput

    def run (self, *values):
        pending = self.sendWrites(zip(values, self.registers))
        return self.waitAcq(pending)

    def next (self, refs):
        self.waitSync(refs)


class _LLACRegisterCommandLeaf (_LLACCommandBase, Leaf):
    _dynamicCommandType = _LLACLeaf


    class NoLLACRegisterSpecified (RunError):
        'You must provide either both of "-node" and "-base", or "-offset"'


    def getInstance (self, name, datatype, cache, regclass, suffix='', **defaults):
        cls = self.getClass(datatype, cache, regclass, suffix)
        #defaults.update(type=datatype)
        return self.incarnate(name, cls, defaults=defaults)


    def addRegister (self, session, branch, replaceExisting, modifyAccess, hidden,
                     name, node, base, offset, size, type, sync=None):

        if (node is base is None) and (offset is None):
            raise self.NoLLACRegisterSpecified

        packing = self.packing(type, size)

        if not name.endswith('?'):
            obj = self.getInstance(name, type, self.writeLeafs, _LLACWriteLeaf, '',
                                   node=node, base=base, offset=offset,
                                   size=size, sync=sync, packing=packing)

            self.addinstance(session, name, obj,
                             replaceExisting, modifyAccess, hidden, parent=branch)
            name += '?'


        obj = self.getInstance(name, type, self.readLeafs, _LLACReadLeaf, '?',
                               node=node, base=base, offset=offset,
                               size=size, packing=packing)
        self.addinstance(session, name, obj,
                         replaceExisting, modifyAccess, hidden, parent=branch)



    def delRegister (self, _session, _branch, name, ignoreMissing):
        if not name.endswith('?'):
            self.delinstance(_session, name, ignoreMissing, parent=_branch)
            name += '?'

        self.delinstance(_session, name, ignoreMissing, parent=_branch)




class _LLACRegisterGroupCommandLeaf (_LLACRegisterCommandLeaf):
    _dynamicCommandType = _LLACGroupLeaf



class LLACRegisterBranch (DynamicBranch, _LLACCommandBase, ConfigBase, MinimalBranch):
    '''Commands to control one or more LLAC peripherals'''

    TypeName    = 'LLAC Branch'
    LLACCONFIG  = "llac.ini"
    S_RESPONSES, S_SEVERITY = ("responses", "severity")

    SeverityNames = {}

    class NoLLACNode (RunError):
        'There is no node address defined for the %(name)s register'

    class NoLLACRegister (RunError):
        'There is no base register defined for the %(name)s register'

    class NoLLACBaseRegister (RunError):
        'The %(name)r register is defined with an offset, but with no base register.'

    class NoLLACBaseAddress (RunError):
        'There is no device address configured for %(name)s'

    class WrongCommandType (RunError):
        'Expected %(searchType)s; %(name)r is a %(foundType)s'

    class InvalidDefinition (RunError):
        'Invalid register definition: %(name)s = %(value)r. ' \
        'Register definitions should be of the form: ' \
        '<name> = (+<offset> <size> "<type>" [synctime])'

    class InvalidDefinitionSize (RunError):
        'Invalid size of register definition: %(name)s = %(value)r. ' \
        'Expected 3 or 4 values, not %(size)d.'

    class InvalidDataType (RunError):
        'Invalid data type in register definition %(name)r: %(type)r.'


    def __init__ (self, *args, **kwargs):
        _LLACCommandBase.__init__(self)
        MinimalBranch.__init__(self, *args, **kwargs)


        if not self.SeverityNames:
            self.initSeverityTable()

        if not self.responseTable:
            self.initResponseTable()



    def initSeverityTable (self):
        items = self.getConfigItems(self.LLACCONFIG,
                                    self.S_SEVERITY,
                                    literal=True,
                                    mustExist=False)

        for severity, name in items:
            try:
                severity = int(severity, 0)
            except (ValueError, TypeError):
                pass
            else:
                self.SeverityNames[severity] = name


    def initResponseTable (self):
        for key, value in self.getConfigItems(self.LLACCONFIG,
                                              self.S_RESPONSES,
                                              literal=True,
                                              mustExist=False):
            try:
                self.responseTable[int(key, 0)] = value
            except ValueError:
                warning("Invalid response ID in %r, section [%s]: %r"%
                        (self.LLACCONFIG, self.S_RESPONSES, key))


    def setBase (self, node, base):
        self.defaults['_defaultnode'] = node
        self.defaults['_defaultbase'] = base


    def getBase (self, ignoreMissing=False):
        try:
            defaults = self.getDefaults()
            return (defaults['_defaultnode'],
                    defaults['_defaultbase'])
        except KeyError:
            if not ignoreMissing:
                raise self.NoLLACBaseAddress(name=self.commandPath())


    def clearBase (self):
        self.defaults.pop('_defaultnode', None)
        self.defaults.pop('_defaultbase', None)


#    def getRegisterLeaf (self, name, *classlist):
#        path, defaults = self.locate(name)
#        obj  = path[-1]
#
#        if not obj.istype(classlist):
#            okTypes    = [ cls.llacType for cls in classlist ]
#            raise self.WrongCommandType(name=name,
#                                        searchType=" or ".join(okTypes),
#                                        foundType=obj.getType())
#        return obj


    def getRegisterLeafSpec (self, name, classlist, ignoreMissing=False, ignoreWrongType=False):
        try:
            path, defaults = self.locate(name)

        except self.UnknownCommand:
            if not ignoreMissing:
                raise

        else:
            branch, obj    = path[-2:]

            if not obj.istype(classlist):
                if ignoreWrongType:
                    return

                if isinstance(classlist, (list, tuple)):
                    okTypes = [ cls.llacType for cls in classlist ]
                else:
                    okTypes = [ classlist.llacType ]

                raise self.WrongCommandType(name=name,
                                            searchType=" or ".join(okTypes),
                                            foundType=obj.getTypeName())

            spec = defaults
#            spec.update(attributes)
            regpath = ':'.join([ element.name for element in path[1:] ])
            spec['name'] = regpath
            spec['node'], spec['register'] = self.getaddress(**spec)
            return spec


    def getaddress (self, name, _defaultnode=None, _defaultbase=None,
                    node=None, base=None, offset=0, **junk):
        if node is None:
            if _defaultnode is None:
                raise self.NoLLACNode(name=name)
            node = _defaultnode

        if base is None:
            if _defaultbase is None:
                raise self.NoLLACRegister(name=name)
            base = _defaultbase

        return node, base + (offset or 0)


    def loadRegDefs (self, session, filename, section,
                     replaceExisting=False, modifyAccess=None, hidden=False,
                     node=None, base=None, offset=0):
        classes = self.buildRegClasses(filename, section, node, base, offset)
        self.addChildClasses(session, classes,
                             replaceExisting=replaceExisting,
                             commandType=_LLACRegisterLeaf,
                             parent=self)


    regdefs = {}


    def buildRegClasses (self, filename, section, node=None, base=None, offset=0):
        try:
            key = filename, section, node, base, offset
            classes = self.regdefs[key]
            self.debug('Used cached register map: %s'%(key,))
        except KeyError:
            items    = self.getConfigItems(filename, section, literal=True, valuetype=tuple)
            classes  = [ ]

            for name, values in items:
                try:
                   spec = self.getRegSpec(offset, *values)
                except TypeError:
                    raise self.InvalidDefinitionSize(name=name, value=values, size=len(values))

                if not name.endswith('?'):
                    cls = self.getClass(spec['type'], self.writeLeafs, _LLACWriteLeaf)
                    classes.append((cls, self.alternateNames(name),
                                    dict(node=node, base=base, **spec)))
                    name += '?'

                cls = self.getClass(spec['type'], self.readLeafs, _LLACReadLeaf, '?')
                classes.append((cls, self.alternateNames(name),
                                dict(node=node, base=base, **spec)))

            self.regdefs[key] = classes
            self.debug('Updated register map: %s'%(key,))

        return classes



    def getRegSpec (self, offset, offset2, size, typestring, synctime=None):
        try:
            regtype = typeMap[typestring.upper()]
        except KeyError:
            raise self.InvalidDataType(name=name, type=regtype)

        packing = self.packing(regtype, size)
        return { 'offset':offset + offset2, 'size':size,
                 'sync':synctime, 'packing':packing,
                 'type':regtype }


    def loadRegValues (self, filenames, section, prefix='', suffix='', classmap=None, ignoreMissing=False, reload=True):
        items = self.getConfigItems(filenames, section,
                                    literal=True,
                                    mustExist=not ignoreMissing,
                                    reload=reload)

        writes  = [ (self.getRegisterLeafSpec(prefix+regname+suffix, _LLACWriteLeaf), value)
                    for (regname, value) in items ]
        pending = self.sendWrites(writes)
        return self.waitAck(pending)


    class BASe_Set (Controlling, Leaf):
        '''
        Set the default node and register address for register
        commands in this branch.  This applies to all registers that
        are defined with a relative offset, rather than an explicit
        node and register address.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('node', type=hex, format="0x%02X", range=(0x00,   0xFF))
            self.setInput('base', type=hex, format="0x%04X", range=(0x0000, 0xFFFF))

        def run (self, _branch, node=hex, base=hex):
            _branch.setBase(node, base)


    class BASe_Clear (Controlling, Leaf):
        '''
        Clear the default node and register address for register
        commands in this branch.  This applies to all registers that
        are defined with a relative offset, rather than an explicit
        node and register address.
        '''

        def run (self, _branch):
            _branch.clearBase()


    class BASe_Query (Observing, Leaf):
        '''
        Return the default node and register address for register
        commands in this branch.  This applies to all registers that
        are defined with a relative offset, rather than an explicit
        node and register address.
        '''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, default=False, named=True)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('node', type=hex, format="0x%02X", range=(0x00, 0xFF), default=None)
            self.addOutput('base', type=hex, format="0x%04X", range=(0x0000, 0xFFFF), default=None)


        def run (self, _branch, ignoreMissing=False):
            return _branch.getBase(ignoreMissing=ignoreMissing)


    class REGister_Add (Controlling, _LLACRegisterCommandLeaf):
        '''
        Create commands to write to and read from a specific LLAC
        device register.

        Typically, two commands are created:

          * A register write command, taking one argument of the
            specified data type.  Subsequent invocations will write
            the supplied value into this register.

          * A register read command (created by appending a "?" to
            the specified command name).  Subsequent invocations will
            return the contents of the specified register.

        If the command name ends with a question mark ("?"), then only
        the register read command (the latter form) is created.

Example:
        * Define a command to read the device firmware version:
            C: LLAC:REGister+ FirmwareVersion? 0x81 0x0000 2 UINT

        * Define a command pair to read/write the device timestamp:
            C: LLAC:REGister+ Timestamp 0x81 0x0002 4 UINT

        * Then, read the firmware version:
            C: LLAC:FirmwareVersion?
            S: OK LLAC:FirmwareVersion? 10

        * And set the timestamp:
            C: LLAC:Timestamp 1134470851
        '''

        def declareInputs (self):
            _LLACRegisterCommandLeaf.declareInputs(self)

            self.setInput('modifyAccess', type=AccessLevels)

            self.setInput('sync', type=float, named=True, units='seconds',
                          description=
                          'Set the synchronization bit in write requests to this '
                          'register, then detach and wait up to the the specified '
                          'timeout for a synchronization response from the device.')

            self.setInput('name', type=str,
                          description=
                          'Register name.  If the name ends with a question mark '
                          '"?" (question mark), the a corresponding "query" '
                          'command is created to read a value from the specified '
                          'register; otherwise, both a "set" command by the '
                          'specified name, as well as a "query" command by the '
                          'same name but with a "?" appended, are created.')

            self.setInput('node',
                          type=hex,
                          named=True,
                          default=None,
                          format='0x%02X',
                          range=(0x00, 0xFF),
                          description='Device node address. '
                          'This overrides any default node address '
                          'for this branch, as specified using the '
                          '":NODe=" command.')

            self.setInput('base',
                          type=hex,
                          named=True,
                          default=None,
                          format='0x%04X',
                          range=(0x0000, 0xFFFF),
                          description='Device register base address. '
                          'This overrides any default register base '
                          'for this branch, as specified using the '
                          '":BASe=" command.')

            self.setInput('offset',
                          type=int,
                          named=True,
                          default=None,
                          description='Device register address offset. '
                          'This is added to the register base address '
                          'to come up with the final register address '
                          'used for read/write operations.')

            self.setInput('size',
                          units='bytes',
                          named=True,
                          range=(1, 4),
                          description='Register size')

            self.setInput('type',
                          named=True,
                          description=
                          'Type of value stored in the specified register')


        def run (self, _session, _branch,
                 replaceExisting=False, modifyAccess=None, hidden=False,
                 name=str, node=hex, base=hex, offset=int,
                 size=int, type=regTypes, sync=None):

            self.addRegister(_session, _branch, replaceExisting, modifyAccess, hidden,
                             name, node, base, offset, size, type, sync)




    class REGister_Remove (Controlling, _LLACRegisterCommandLeaf):
        '''
        Remove the specified LLAC register access commands.
        '''
        def run (self, _session, _branch, ignoreMissing=False, name=str):
            self.delRegister(_session, _branch, name, ignoreMissing)



    class REGister_Query (Observing, _LLACRegisterCommandLeaf):
        '''
        Show the definition of a register access command
        '''

        def declareOutputs (self):
            _LLACRegisterCommandLeaf.declareOutputs(self)

            self.addOutput('sync',     named=True, type=float, default=None)
            self.addOutput('node',     named=True, type=hex,   default=None, format='0x%02X')
            self.addOutput('base',     named=True, type=hex,   default=None, format='0x%04X')
            self.addOutput('offset',   named=True, type=int,   default=None, format='%d')
            self.addOutput('register', named=True, type=hex,   default=None, format='0x%04X')
            self.addOutput('size',     named=True, type=int)
            self.addOutput('type',     named=True, type=regTypes)


        def run (self, _session, _branch, name=str):
            return _branch.getRegisterLeafSpec(name, _LLACRegisterLeaf)


    class REGisterGroup_Add (Controlling, _LLACRegisterGroupCommandLeaf):
        '''
        Combine several LLAC register commands into a register group
        command.

        If the group name ends with a question mark ("?"), then every
        register command specified must be a register read command.
        Upon invocation, the register group command will then return the
        contents of all of the specified LLAC registers at once, separated
        by whitespace.

        Otherwise, every register command specified must be a register
        write command.  The register group command will take one argument
        of the appropriate type for each of the specified registers, and
        upon invocation, will write these values into the corresponding
        LLAC device registers.
        '''

        def declareInputs (self):
            _LLACRegisterGroupCommandLeaf.declareInputs(self)
            self.setInput('modifyAccess', type=AccessLevels)
            self.setInput('registers', split=",", repeats=(0, None), type=str,
                          description="One or more register leafs, separated by comma or as separate arguments")


        def run (self, _session, _branch,
                 append=False,
                 replaceExisting=False,
                 modifyAccess=None,
                 hidden=False,
                 name=str, *registers):

            if name.endswith('?'):
                regClass, grpClass  = _LLACReadLeaf, _LLACReadGroupLeaf
            else:
                regClass, grpClass  = _LLACWriteLeaf, _LLACWriteGroupLeaf

            if append:
                group = self.findDynamicCommand(name, allowMissing=True, parent=_branch)
            else:
                group = None

            if not group:
                group = self.incarnate(name, grpClass, parent=_branch)
                self.addinstance(_session, name, group,
                                 replaceExisting=replaceExisting,
                                 modifyAccess=modifyAccess,
                                 hidden=hidden,
                                 parent=_branch)

            for items in registers:
                for regname in filter(None, items):
                    spec = _branch.getRegisterLeafSpec(regname, regClass)
                    group.addMember(regname, spec)


    class REGisterGroup_Remove (Controlling, _LLACRegisterGroupCommandLeaf):
        '''
        If one or more register names are given, remove these from the
        specified register group.  Otherwise, remove the register
        group itself.
        '''

        def run (self, _session, _branch, ignoreMissing=False, name=str, *registers):
            if registers:
                group = self.findDynamicCommand(name, parent=_branch)
                for reg in registers:
                    try:
                        group.delMember(reg)
                    except NotInGroup:
                        if not ignoreMissing:
                            raise
            else:
                self.delinstance(_session, name, ignoreMissing, parent=_branch)



    class REGisterGroup_Query (Observing, _LLACRegisterGroupCommandLeaf):
        '''
        Show the list of LLAC registers included in the specified
        register group.
        '''
        def declareOutputs (self):
            _LLACRegisterGroupCommandLeaf.declareOutputs(self)
            self.addOutput('register', type=list, repeats=(0, None))

        def run (self, _session, _branch, name=str):
            grp = self.findDynamicCommand(name, parent=_branch)
            maxlen = max([ len(reg['name']) for reg in grp.registers ] + [0])

            regs = []
            for reg in grp.registers:
                regs.append('%-*s -node=0x%02X -reg=0x%04X -size=%d -type=%s'%
                            (maxlen,
                             reg['name'], reg['node'], reg['register'],
                             reg['size'], regTypes[reg['type']]))

            return regs


    class REGisterGroup_Enumerate (Observing, _LLACRegisterGroupCommandLeaf):
        '''
        List LLAC register groups in this branch
        '''

        def declareOutputs (self):
            _LLACRegisterGroupCommandLeaf.declareOutputs(self)
            self.addOutput('register', type=str, repeats=(0, None))

        def run (self, _session, _branch):
            return tuple(self.listinstances(parent=_branch))




    class LOADDEFinitions (Controlling, ConfigBase, _LLACRegisterCommandLeaf):
        '''
        Load register definitions from the specified configuration
        file/section, and create the corresponding register leafs.
        '''


        def declareInputs (self):
            _LLACRegisterCommandLeaf.declareInputs(self)
            self.setInput('replaceExisting', description=
                          'Replace any existing register(s) by the same name(s)')

            self.setInput('modifyAccess', type=AccessLevels)

            self.setInput('node',
                          type=hex,
                          default=None,
                          format='0x%02X',
                          range=(0x00, 0xFF),
                          description='Device node address. '
                          'This overrides any default node address '
                          'for this branch, as specified using the '
                          '":BASe=" command.')

            self.setInput('base',
                          type=hex,
                          default=None,
                          format='0x%04X',
                          range=(0x0000, 0xFFFF),
                          description='Device register base address. '
                          'This overrides any default register base '
                          'for this branch, as specified using the '
                          '":BASe=" command.')

            self.setInput('offset',
                          type=int,
                          default=0,
                          description='Device register address '
                          'starting offset.  This is added to the '
                          'offset supplied for each register in the '
                          'configuration file to come up with an offset '
                          'specification for the register. Upon a '
                          'subsequent a read/write operation, the '
                          'register and/or branch base address is '
                          'then added to come up with the final '
                          'register location in the device. ')


        def run (self, _session, replaceExisting=False, modifyAccess=None, hidden=False,
                 filename=str, section=str, node=hex, base=hex, offset=int):

            self.parent.loadRegDefs(_session, filename, section,
                                    replaceExisting, modifyAccess, hidden,
                                    node, base, offset)



    class LOAD (Controlling, Background, _LLACRegisterCommandLeaf):
        '''
        Load register values from the specified configuration file/section,
        and write these to the corresponding LLAC registers.
        '''

        def declareInputs (self):
            _LLACRegisterCommandLeaf.declareInputs(self)
            self.setInput('filename', type=str,
                          description='Configuration file from which to load the specified section')

        def run (self, _branch, ignoreMissing=False, prefix='', suffix='', filename=str, section=str):
            return _branch.loadRegValues(filename, section,
                                         prefix=prefix, suffix=suffix, ignoreMissing=ignoreMissing)

        def next (self, refs=None):
            return self.waitSync(refs)



    class PRELoad (Controlling, ConfigBase, Background, _LLACRegisterCommandLeaf):
        '''
        Using register specifications from the specified register map file/section,
        load corresponding values from the specified value map file/section, without
        having to add register leafs beforehand.
        '''

        def declareInputs (self):
            _LLACRegisterCommandLeaf.declareInputs(self)

            self.setInput('node',
                          type=hex,
                          default=None,
                          format='0x%02X',
                          range=(0x00, 0xFF),
                          description='Device node address. '
                          'This overrides any default node address '
                          'for this branch, as specified using the '
                          '":BASe=" command.')

            self.setInput('base',
                          type=hex,
                          default=None,
                          format='0x%04X',
                          range=(0x0000, 0xFFFF),
                          description='Device register base address. '
                          'This overrides any default register base '
                          'for this branch, as specified using the '
                          '":BASe=" command.')

            self.setInput('offset',
                          type=int,
                          default=0,
                          description='Device register address '
                          'starting offset.  This is added to the '
                          'offset supplied for each register in the '
                          'configuration file to come up with an offset '
                          'specification for the register. Upon a '
                          'subsequent a read/write operation, the '
                          'register and/or branch base address is '
                          'then added to come up with the final '
                          'register location in the device. ')


        def run (self, _session, _branch, _defaultnode=None, _defaultbase=None,
                 ignoreMissing=False,
                 prefix='', suffix='',
                 node=None, base=None, offset=0,
                 mapfile=str, mapsection=str,
                 valuefile=str, valuesection=str):

            valueitems = self.getConfigItems(valuefile, valuesection,
                                             session=_session, literal=True,
                                             mustExist=not ignoreMissing)

            if valueitems:
                regnames, regvalues = zip(*valueitems)
                regspecs  = self.getConfigValues(mapfile, mapsection, regnames,
                                                 session=_session,
                                                 literal=True, mustExist=not ignoreMissing,
                                                 prefix=prefix, suffix=suffix)


                requests = []
                try:
                    for regname, regspec, regvalue in zip(regnames, regspecs, regvalues):
                        spec = _branch.getRegSpec(offset, *regspec)
                        name = prefix + regname + suffix
                        node, register = _branch.getaddress(name,
                                                            _defaultnode, _defaultbase,
                                                            node, base, **spec)

                        requests.extend(self.write((regvalue,), node, register, name=name, **spec))

                except self.LLACError, e:
                    self.finishRequests(requests)
                    raise

                else:
                    return requests


        def next (self, pending):
            self.waitSync(pending)



    class DUMP_List (Observing, _LLACRegisterCommandLeaf):
        '''
        Read every LLAC register in this branch, and return its contents.
        '''

        def declareInputs (self):
            _LLACRegisterCommandLeaf.declareInputs(self)
            self.setInput('ignoreErrors', type=bool, named=True, default=False)

        def declareOutputs (self):
            _LLACRegisterCommandLeaf.declareOutputs(self)
            self.addOutput('contents', type=list, default=None)

        def run (self, _branch, _defaultnode, _defaultbase, ignoreErrors=False):
            regspecs = []
            for regname in _branch.listChildren(commandType=_LLACReadLeaf):
                spec = _branch.getRegisterLeafSpec(regname, _LLACReadLeaf)
                if spec:
                    regspecs.append(spec)

            if regspecs:
                values  = self.readList(regspecs, ignoreErrors=True)
                width   = max([len(spec['name']) for spec in regspecs])

                strings = [ "%*s = %s"%(width, spec['name'], self.formatValue(value, **spec))
                            for (spec, value) in zip(regspecs, values)
                            if value is not None ]
                return strings


    class FirmWareDownLoad (Controlling, _LLACBase, FilesystemLeaf):
        '''
        Download firmware to device.

        The supplied file is split up into 8-byte fragments, and
        downloaded into a series of LLAC registers starting with
        "register".  For each successive packet, "increment" is added
        to the register address, until the data buffer is empty.

    Examples:
        * Send multiple 8-byte download requests to LLAC node 0xB1,
          using the file "mcbfirmware.bin":
            FirmWareDownLoad -transferDelay=0.004 0xB1 UPGRADE:mcbfirmware.bin
        '''

        class DownloadFailed (RunError):
            "Download failure"

        class SwitchToBootFailed (RunError):
            "Unable to switch to boot mode"

        def __init__ (self, *args, **kwargs):
            self.UNABLE_TO_SWITCH_TO_BOOT_MODE = 0xFC1B
            self.BOOT_SUBSYSTEM_MISSING = 0xFC1C
            FilesystemLeaf.__init__(self, *args, **kwargs)
            self._mutex = Lock()


        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('transferDelay', type=float, named=True, default=0.001)
            self.setInput('node', type=hex, range=(0x00, 0xFF),
                          description='LLAC Node address')
            ### bootregister is no longer needed as an argument.  Look it up instead using the application table.
            ### self.setInput('bootregister', type=hex, range=(0x0000, 0xFFFF),
            ###              description='Boot Register address')


        def run (self, _session, transferDelay=0.001, node=int, filename=str):
            with self.openLocation(filename, _session, P_READ) as loc:
                fp = loc.open(OP_READ)
                message = ('Downloading firmware image "%s" to node 0x%02X'%(loc.vfspath(), node))

                if not self._mutex.acquire(0):
                    info("%s -- waiting for other download to complete..."%message)
                    self._mutex.acquire()

                try:
                    info('%s -- starting'%message)
                    self.download(filename=loc.vfspath(),
                                  fp=fp,
                                  node=node,
                                  transferDelay=transferDelay)
                    info('%s -- completed'%message)

                finally:
                    self._mutex.release()


        def switchToBootMode(self, node):
            # Check if the bootloader is already running
            APPLICATION_TYPE_REGISTER = 0x0008
            RESET_CONTROL_REGISTER    = 0x000A
            RETRY_COUNT_MAX = 2
            SWITCH_TO_BOOT_MODE_BIT = 0x1

            retry_count = 0
            app_type = self.read(node, APPLICATION_TYPE_REGISTER, 4, '!I')
            while app_type != 0x424F4F54: # 'BOOT'
                retry_count = retry_count + 1
                if retry_count > RETRY_COUNT_MAX:
                    raise self.SwitchToBootFailed(self.UNABLE_TO_SWITCH_TO_BOOT_MODE)

                self.write((SWITCH_TO_BOOT_MODE_BIT, ), node, RESET_CONTROL_REGISTER, '!H')
                sleep(1.5)
                app_type = self.read(node, APPLICATION_TYPE_REGISTER, 4, '!I')



        def bootBaseRegister(self, node):
            # Return the boot subsystem base register
            APPLICATION_TABLE_REGISTER = 0x0007
            app_table = self.read(node, APPLICATION_TABLE_REGISTER, 2, '!H')
            boot_table = self.read(node, app_table, 2, '!H')

            # There should be 1 and only 1 boot subsystem
            if self.read(node, boot_table, 2, '!H') != 1:
                raise self.SwitchToBootFailed(self.BOOT_SUBSYSTEM_MISSING)

            # Return the boot subsystem base register
            return self.read(node, boot_table + 1, 2, '!H')



        def download (self, filename, fp, node, transferDelay):
            CONTROL_REGISTER = 0
            BUFFER_SIZE_REGISTER = 1
            DATA_WRITTEN_REGISTER = 2

            CONTROL_RESET = 0x0
            CONTROL_COMMIT_BIT = 0x1
            CONTROL_JUMP_BIT = 0x2
            CONTROL_INITIATE_BIT = 0x4

            EVENT_ID_DOWNLOAD_BASE = 0x8034
            EVENT_ID_DOWNLOAD_MASK = 0xFFFC

            # Open the file first.  If there is no file don't switch to boot mode

            self.switchToBootMode(node)
            bootregister = self.bootBaseRegister(node)

            bufsize = self.read(node, bootregister+BUFFER_SIZE_REGISTER, 2, '!H')

            self.debug("Downloading file %r to node 0x%02X, BDB 0x%04X in chunks of %d bytes"%
                       (filename, node, bootregister, bufsize))

            self.write((CONTROL_RESET, ), node, bootregister+CONTROL_REGISTER, '!H')
            self.write((CONTROL_INITIATE_BIT, ), node, bootregister+CONTROL_REGISTER, '!H')

            data = fp.read(bufsize)
            size   = 0
            seq    = 0
            blocks = 0
            bytes_per_block = 8

            self.llac.addEventHandler(self, self.retryDownload,
                                      id=EVENT_ID_DOWNLOAD_BASE,
                                      idMask=EVENT_ID_DOWNLOAD_MASK)

            try:
                retries = 0
                while data:
                    self.debug("Sequence %d: %s bytes, transfer delay=%ss"%
                               (seq, len(data), transferDelay))
                    self.failure = {}

                    seq = self.llac.transfer(node, seq, data, delay=transferDelay)

                    self.write((((len(data) + (bytes_per_block - 1))/ bytes_per_block ),),
                               node=node, register=bootregister+DATA_WRITTEN_REGISTER, packing='!H')

                    writes = []
                    ###writes.append((dict(node=node, register=bootregister+DATA_WRITTEN_REGISTER, packing='!H'),
                    ###               ((len(data) + (bytes_per_block - 1))/ bytes_per_block )))

                    writes.append((dict(node=node, register=bootregister+CONTROL_REGISTER, packing='!H', sync=30.0),
                                  (CONTROL_COMMIT_BIT | CONTROL_INITIATE_BIT)))

                    pending = self.sendWrites(writes)
                    try:
                        pending = self.waitAck(pending)
                        self.waitSync(pending)
                    except Error, e:
                        if retries < 10:
                            self.debug("Download packet fail.  Retry count: %d.  Blocks: %d"%(retries, blocks,))
                            retries += 1
                        else:
                            raise self.DownloadFailed(**e.kwargs)
                    else:
                        size   += len(data)
                        blocks += 1
                        data    = fp.read(bufsize)
                        retries = 0

            finally:
                self.llac.removeEventHandler(self)

            self.write((CONTROL_JUMP_BIT | CONTROL_INITIATE_BIT, ), node, bootregister, '!H')
            self.debug("Wrote %d bytes in %d blocks, %d sequences"%(size, blocks, seq))



        def retryDownload (self, target, source, id, control, data):
            self.failure = dict(target=target, source=source, id=id, control=control, data=data)


    class FirmWareDownLoadCoffee (Controlling, _LLACBase, FilesystemLeaf):
        '''
        Download firmware to device.

        The supplied file is split up into 8-byte fragments, and
        downloaded into a series of LLAC registers starting with
        "register".  For each successive packet, "increment" is added
        to the register address, until the data buffer is empty.

    Examples:
        * Send multiple 8-byte download requests to LLAC node 0xd2,
          using Boot Subsystem in the Application Table.
            FirmWareDownLoad2 0xD2 UPGRADE:ocbfirmware.bin
        '''

        class DownloadFailed (RunError):
            "Download failed: %(message)s"

        class SwitchToBootFailed (RunError):
            "Unable to switch to boot mode"

        class SwitchToAppFailed (RunError):
            "Unable to switch to application mode"

        class NoBootSubsystemAddress (RunError):
            "Unable to obtain boot subsystem address"

        def __init__ (self, *args, **kwargs):
            FilesystemLeaf.__init__(self, *args, **kwargs)
            self._mutex = Lock()


        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('transferDelay', type=float, named=True, default=0.000)
            self.setInput('compare', type=bool, named=True, default=False)
            self.setInput('node', type=hex, range=(0x00, 0xFF),
                          description='LLAC Node address')


        def run (self, _session, transferDelay=0.000, compare=False, node=int, filename=str):
            with self.openLocation(filename, _session, P_READ) as loc:
                fp = loc.open(OP_READ)
                message = ('Downloading firmware image "%s" to node 0x%02X'%(loc.vfspath(), node))

                if not self._mutex.acquire(0):
                    info("%s -- waiting for other download to complete..."%message)
                    self._mutex.acquire()

                try:
                    info('%s -- starting'%message)
                    self.download(filename=loc.vfspath(),
                                  fp=fp,
                                  node=node,
                                  transferDelay=transferDelay,
                                  compare=compare)
                    info('%s -- completed'%message)

                finally:
                    self._mutex.release()


        def boot_subsystem_address(self, node):
            IDX_APPLICATION_TABLE = 0x19
            IDX_COFFEE_VERSION    = 0x2A
            SUBSYSTEM_TYPE_BOOT_MASK = 0xFFFF0000
            SUBSYSTEM_TYPE_BOOT = 0x00020000
            # COFFEE versions 0x00010031 and later have remapped and more granular subsystem types
            COFFEE_TYPE_REMAP_VERSION = 0x00010031
            SUBSYSTEM_TYPE_REMAP_BOOT_MASK = 0xFF000000
            SUBSYSTEM_TYPE_REMAP_BOOT = 0x02000000
            # Find the boot subsystem, which is of SUBSYSTEM_TYPE_BOOT
            # The structure is:
            #      App Table[0]: Table Count Subsystems in App Table
            #      App Table[1]: Subsystem Table 1
            #      App Table[2]: Address Subsystem Table 2
            #              ...
            #      Subsystem Table X[0]: Count of Subsystems in Table
            #      Subsystem Table X[1]: Subsystem 1
            #      Subsystem Table X[2]: Subsystem 2
            #              ...
            #      Subsystem X[0]: Count of Registers in Subsystem including this register
            #      Subsystem X[1]: Subsystem Type

            # Walk the tables looking for the first table that is of type SUBSYSTEM_TYPE_BOOT

            try:
                coffee_version = self.read(node, IDX_COFFEE_VERSION, 4, '!I')
            except Exception:
                coffee_version = 0
            else:
                if (coffee_version >= COFFEE_TYPE_REMAP_VERSION):
                    SUBSYSTEM_TYPE_BOOT_MASK = SUBSYSTEM_TYPE_REMAP_BOOT_MASK
                    SUBSYSTEM_TYPE_BOOT      = SUBSYSTEM_TYPE_REMAP_BOOT

            app_table = self.read(node, IDX_APPLICATION_TABLE, 4, '!I')
            app_table_size = self.read(node, app_table, 4, '!I')

            for i in range(1, app_table_size):
                subsystem_table = self.read(node, app_table + i + 1, 4, '!I')
                subsystem_table_size = self.read(node, subsystem_table, 4, '!I')
                for j in range(0, subsystem_table_size):
                    subsystem = self.read(node, subsystem_table + j + 1, 4, '!I')
                    subsystem_type = self.read(node, subsystem + 1, 4, '!I')
                    if ((subsystem_type & SUBSYSTEM_TYPE_BOOT_MASK) == SUBSYSTEM_TYPE_BOOT):
                        return subsystem

            else:
                raise self.NoBootSubsystemAddress(node="0x%02X"%(node,),
                                                  coffeeVersion="0x%08X"%(coffee_version,))



        def switch_to_boot_loader(self, node, boot_subsystem):
            # Determine if the boot loader is running.
            # If it is just return
            # if not attempt to switch to the boot loader.
            # Return once running, or raise an error
            REGISTER_COMMAND               = 0x03
            REGISTER_STATUS                = 0x04
            STATUS_IN_BOOT_LOADER_BIT      = 0x00010000

            CMD_DISABLE             = 0x01
            CMD_ENABLE              = 0x02
            CMD_SWITCH_TO_BOOT_LOADER = 0x12

            self.debug("switch_to_bootloader(node=0x%02X, boot_subsystem=0x%02X)" % (node, boot_subsystem))
            status = self.read(node, boot_subsystem + REGISTER_STATUS, 4, '!I')

            switch_count = 5
            while switch_count and not (status & STATUS_IN_BOOT_LOADER_BIT):
                self.debug("switch_to_bootloader(): Testing BOOT:STATUS? to determine if in bootloader. switch_count=0x%02X" % (switch_count,))
                self.syncWrite((CMD_DISABLE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
                self.syncWrite((CMD_ENABLE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
                self.syncWrite((CMD_SWITCH_TO_BOOT_LOADER, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)

                delay_count = 10
                while delay_count and not (status & STATUS_IN_BOOT_LOADER_BIT):
                    sleep(1)
                    try:
                        status = self.read(node, boot_subsystem + REGISTER_STATUS, 4, '!I')
                    except Exception:
                        pass
                    delay_count -= 1
                switch_count -=1

            if not (status & STATUS_IN_BOOT_LOADER_BIT):
                raise self.SwitchToBootFailed(status="0x%04X"%(status,))




        def switch_to_application(self, node, boot_subsystem):
            # Determine if the boot loader is running.
            # If it is switch to the application firmware
            # If not just return
            # if not attempt to switch to the boot loader.
            # Return once running, or raise an error
            REGISTER_COMMAND               = 0x03
            REGISTER_STATUS                = 0x04
            STATUS_IN_BOOT_LOADER_BIT      = 0x00010000

            CMD_DISABLE             = 0x01
            CMD_ENABLE              = 0x02
            CMD_EXECUTE_FIRMWARE    = 0x20

            self.debug("switch_to_application(node=0x%02X, boot_subsystem=0x%02X)" % (node, boot_subsystem))
            status = self.read(node, boot_subsystem + REGISTER_STATUS, 4, '!I')

            switch_count = 5
            while switch_count and (status & STATUS_IN_BOOT_LOADER_BIT):
                self.debug("switch_to_application(): Testing BOOT:STATUS? to determine if in bootloader. switch_count=0x%02X" % (switch_count,))
                self.syncWrite((CMD_DISABLE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
                self.syncWrite((CMD_ENABLE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
                self.syncWrite((CMD_EXECUTE_FIRMWARE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=15.0)

                delay_count = 60
                while delay_count and (status & STATUS_IN_BOOT_LOADER_BIT):
                    sleep(1)
                    try:
                        status = self.read(node, boot_subsystem + REGISTER_STATUS, 4, '!I')
                    except Exception:
                        pass
                    delay_count -= 1
                switch_count -=1

            if status & STATUS_IN_BOOT_LOADER_BIT:
                raise self.SwitchToAppFailed(status="0x%04X"%(status,))


        def log_memory_usage(self, node):
            # Log the thread and memory usage. Available in Bootloader and App firmware.
            REGISTER_COMMAND        = 0x03
            CMD_ENABLE              = 0x02
            CMD_LOG_MEMORY          = 0x12

            self.debug("log_memory_usage(node=0x%02X)" % (node,))

            self.syncWrite((CMD_ENABLE, ),     node, REGISTER_COMMAND, '!I', sync=5.0)
            self.syncWrite((CMD_LOG_MEMORY, ), node, REGISTER_COMMAND, '!I', sync=5.0)


        def download (self, filename, fp, node, transferDelay, compare):
            boot_subsystem = self.boot_subsystem_address(node)

            # Look up the boot
            REGISTER_COMMAND                         = 0x03
            REGISTER_STATUS                          = 0x04
            REGISTER_CONFIGURATION                   = 0x05
            REGISTER_SIZE_TRANSFER_BUFFER            = 0x20
            REGISTER_BYTE_COUNT_EXPECTED             = 0x21
            REGISTER_BYTE_COUNT_RECEIVED             = 0x22
            REGISTER_PACKET_SEQUENCE_NUMBER_BLOCK    = 0x23
            REGISTER_PACKET_SEQUENCE_NUMBER_EXPECTED = 0x24
            REGISTER_FLASH_PROGRAM_ADDRESS           = 0x25

            CMD_DISABLE               = 0x01
            CMD_ENABLE                = 0x02
            CMD_STOP_BOOT             = 0x10
            CMD_REBOOT                = 0x11
            CMD_SWITCH_TO_BOOT_LOADER = 0x12
            CMD_VERIFY_CRC            = 0x13
            CMD_EXECUTE_FIRMWARE      = 0x20
            CMD_START_TRANSFER        = 0x21
            CMD_COMPLETE_TRANSFER     = 0x22
            CMD_COMMIT                = 0x23
            CMD_COMPARE               = 0x24

            if compare:
                command_flush = CMD_COMPARE
            else:
                command_flush = CMD_COMMIT

            EVENT_ID_DOWNLOAD_BASE = 0x0100
            EVENT_ID_DOWNLOAD_MASK = 0xFF00

            self.switch_to_boot_loader(node, boot_subsystem)

            bufsize = self.read(node, boot_subsystem + REGISTER_SIZE_TRANSFER_BUFFER, 4, '!I')

            self.debug("Downloading file %r to node 0x%02X in chunks of %d bytes"%
                       (filename, node, bufsize))

            self.syncWrite((CMD_DISABLE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
            self.syncWrite((CMD_ENABLE, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
            self.syncWrite((CMD_START_TRANSFER, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)

            data = fp.read(bufsize)
            size   = 0
            seq    = 0
            blocks = 0
            bytes_per_block = 8

            retries = 0

            try:
                while data:
                    self.write((len(data), ), node, boot_subsystem + REGISTER_BYTE_COUNT_EXPECTED, '!I')
                    seq = self.read(node, boot_subsystem + REGISTER_PACKET_SEQUENCE_NUMBER_BLOCK, 4, '!I')

                    self.debug("Sequence %d: %s bytes, transfer delay=%ss"%
                               (seq, len(data), transferDelay))

                    newseq = self.llac.transfer(node, seq, data, delay=transferDelay)

                    try:
                        self.syncWrite((command_flush, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=15.0)

                    except Error, e:
                        if retries < 10:
                            self.debug("Download packet fail.  Retry count: %d"%(retries,))
                            retries += 1

                        else:
                            e.kwargs.update(filename=filename,
                                            sequence=seq,
                                            node="0x%02X"%(node,))

                            raise self.DownloadFailed(message=str(e), **e.kwargs)

                    else:
                        size   += len(data)
                        blocks += 1
                        data    = fp.read(bufsize)
                        retries = 0

            except self.llac.LLACError, e:
                raise self.LLACError(str(e))

            self.syncWrite((CMD_COMPLETE_TRANSFER, ), node, boot_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
            self.log_memory_usage(node)
            self.switch_to_application(node, boot_subsystem)


    class FirmWareDownLoadSkyeTek (Controlling, _LLACBase, FilesystemLeaf):
        '''
        Download firmware to SkyeTek device.

        The supplied file is parsed following the SkyeTek firmware upgrade
        protocol and downloaded to a SkyeTek device.

    Examples:
        * Downloads SkyeTek hex format file to a node supporting firmware
          upgrades
            FirmWareDownLoadSkyeTek 0xce gemini_0x0064.shf
        '''

        class DownloadFailed (RunError):
            "Download failed: %(message)s"

        class SwitchToBootFailed (RunError):
            "Unable to switch to boot mode"

        class SwitchToAppFailed (RunError):
            "Unable to switch to application mode"

        class NoSkyeTekSubsystemAddress (RunError):
            "Unable to obtain SkyeTek subsystem address"

        class BootloaderCommandFailed (RunError):
            "Unable to execute bootloader command"

        def __init__ (self, *args, **kwargs):
            FilesystemLeaf.__init__(self, *args, **kwargs)
            self._mutex = Lock()


        def declareInputs (self):
            FilesystemLeaf.declareInputs(self)
            self.setInput('transferDelay', type=float, named=True, default=0.000)
            self.setInput('node', type=hex, range=(0x00, 0xFF),
                          description='LLAC Node address')


        def run (self, _session, transferDelay=0.000, node=int, filename=str):
            with self.openLocation(filename, _session, P_READ) as loc:
                fp = loc.open(OP_READ)
                message = ('Downloading firmware image "%s" to node 0x%02X'%(loc.vfspath(), node))

                if not self._mutex.acquire(0):
                    info("%s -- waiting for other download to complete..."%message)
                    self._mutex.acquire()

                try:
                    info('%s -- starting'%message)
                    self.download(filename=loc.vfspath(),
                                  fp=fp,
                                  node=node,
                                  transferDelay=transferDelay)
                    info('%s -- completed'%message)

                finally:
                    self._mutex.release()


        def skyetek_subsystem_address(self, node):
            IDX_APPLICATION_TABLE = 0x19
            SUBSYSTEM_TYPE_NFC_MASK = 0xFF000000
            SUBSYSTEM_TYPE_NFC = 0x0A000000
            # Find the boot subsystem, which is of SUBSYSTEM_TYPE_BOOT
            # The structure is:
            #      App Table[0]: Table Count Subsystems in App Table
            #      App Table[1]: Subsystem Table 1
            #      App Table[2]: Address Subsystem Table 2
            #              ...
            #      Subsystem Table X[0]: Count of Subsystems in Table
            #      Subsystem Table X[1]: Subsystem 1
            #      Subsystem Table X[2]: Subsystem 2
            #              ...
            #      Subsystem X[0]: Count of Registers in Subsystem including this register
            #      Subsystem X[1]: Subsystem Type

            # Walk the tables looking for the first table that is of type SUBSYSTEM_TYPE_BOOT

            app_table = self.read(node, IDX_APPLICATION_TABLE, 4, '!I')
            app_table_size = self.read(node, app_table, 4, '!I')

            for i in range(1, app_table_size):
                subsystem_table = self.read(node, app_table + i + 1, 4, '!I')
                subsystem_table_size = self.read(node, subsystem_table, 4, '!I')
                for j in range(0, subsystem_table_size):
                    subsystem = self.read(node, subsystem_table + j + 1, 4, '!I')
                    subsystem_type = self.read(node, subsystem + 1, 4, '!I')
                    if ((subsystem_type & SUBSYSTEM_TYPE_NFC_MASK) == SUBSYSTEM_TYPE_NFC):
                        return subsystem
            else:
                raise self.NoSkyeTekSubsystemAddress(node="0x%02X"%(node,))


        def switch_to_boot_loader(self, node, skyetek_subsystem):
            # Determine if the boot loader is running.
            # If it is just return
            # if not attempt to switch to the boot loader.
            # Return once running, or raise an error
            REGISTER_COMMAND            = 0x03
            REGISTER_STATUS             = 0x04
            STATUS_IN_BOOT_LOADER_BIT   = 0x00000200

            CMD_DISABLE                 = 0x01
            CMD_ENABLE                  = 0x02
            CMD_SWITCH_TO_BOOT_LOADER   = 0x28

            self.debug("switch_to_bootloader(node=0x%02X, skyetek_subsystem=0x%02X)" % (node, skyetek_subsystem))
            status = self.read(node, skyetek_subsystem + REGISTER_STATUS, 4, '!I')

            switch_count = 5
            while switch_count and not (status & STATUS_IN_BOOT_LOADER_BIT):
                self.debug("switch_to_bootloader(): Testing STATUS? to determine if in bootloader. switch_count=0x%02X" % (switch_count,))
                self.syncWrite((CMD_ENABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=60.0)
                self.syncWrite((CMD_SWITCH_TO_BOOT_LOADER, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=10.0)
                self.syncWrite((CMD_DISABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
                self.syncWrite((CMD_ENABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=60.0)

                delay_count = 10
                while delay_count and not (status & STATUS_IN_BOOT_LOADER_BIT):
                    sleep(1)
                    try:
                        status = self.read(node, skyetek_subsystem + REGISTER_STATUS, 4, '!I')
                    except Exception:
                        pass
                    delay_count -= 1
                switch_count -=1

            if not (status & STATUS_IN_BOOT_LOADER_BIT):
                raise self.SwitchToBootFailed(status="0x%04X"%(status,))


        def bootloader_command(self, node, skyetek_subsystem, command, data, show_request=True):
            # Send command and data to bootloader.
            # Return response, or raise an error
            REGISTER_COMMAND               = 0x03
            REGISTER_STATUS                = 0x04
            STATUS_IN_BOOT_LOADER_BIT      = 0x00000200

            REGISTER_PARAMETER             = 0x1D
            REGISTER_BUFFER_CAPACITY       = 0x2E
            REGISTER_BUFFER_SIZE           = 0x2F
            REGISTER_BUFFER_PAGE_START     = 0x30
            BUFFER_PAGE_SIZE               = 0x04

            CMD_BOOTLOADER_COMMAND         = 0x29

            if show_request:
                self.debug("bootloader_command(node=0x%02X, skyetek_subsystem=0x%02X, command=0x%02X, data_size=%d, data=%s)"
                           % (node, skyetek_subsystem, command, len(data), data))
            else:
                self.debug("bootloader_command(node=0x%02X, skyetek_subsystem=0x%02X, command=0x%02X, data_size=%d)"
                           % (node, skyetek_subsystem, command, len(data)))

            # Check subsystem status
            status = self.read(node, skyetek_subsystem + REGISTER_STATUS, 4, '!I')
            self.debug("bootloader_command(status=0x%02X)"
                       % (status))
            if not (status & STATUS_IN_BOOT_LOADER_BIT):
                raise self.BootloaderCommandFailed(status="0x%04X"%(status,))

            # Check that data fits in buffer
            buffer_capacity = self.read(node, skyetek_subsystem + REGISTER_BUFFER_CAPACITY, 4, '!I')
            self.debug("bootloader_command(buffer_capacity=%d)"
                       % (buffer_capacity))
            if len(data) > buffer_capacity:
                raise self.BootloaderCommandFailed(message="Data size %d is greater than buffer size %d" % (len(data), buffer_capacity))

            # Write command
            self.syncWrite((command, ), node, skyetek_subsystem + REGISTER_PARAMETER, '!I', sync=5.0)

            # Write data
            self.syncWrite((len(data), ), node, skyetek_subsystem + REGISTER_BUFFER_SIZE, '!I', sync=5.0)
            for index in range(0, len(data), BUFFER_PAGE_SIZE):
                chunk = data[index:index+BUFFER_PAGE_SIZE][::-1] ### FW BUG: Data is expected in reversed byte order.
                value = int("".join(["%02X"%byte for byte in chunk]), 16)
                page  = (index%buffer_capacity)/BUFFER_PAGE_SIZE
                if show_request:
                    self.debug("bootloader_command(page=%d, value=%s, value=0x%08X)"
                               % (page, chunk, value))
                self.syncWrite((value, ), node, skyetek_subsystem + REGISTER_BUFFER_PAGE_START + page, '!I', sync=5.0)

            # Check subsystem status
            status = self.read(node, skyetek_subsystem + REGISTER_STATUS, 4, '!I')
            self.debug("bootloader_command(status=0x%02X)"
                       % (status))
            if not (status & STATUS_IN_BOOT_LOADER_BIT):
                raise self.BootloaderCommandFailed(status="0x%04X"%(status,))

            # Write bootloader command command
            self.syncWrite((CMD_BOOTLOADER_COMMAND, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=15.0)

            # Read response
            response_length = self.read(node, skyetek_subsystem + REGISTER_BUFFER_SIZE, 4, '!I')
            self.debug("bootloader_command(response_length=%d)"
                       % (response_length))
            response = bytearray()
            for index in range(0, response_length, BUFFER_PAGE_SIZE):
                page  = index/BUFFER_PAGE_SIZE
                value = self.read(node, skyetek_subsystem + REGISTER_BUFFER_PAGE_START + page, 4, '!I')
                hex_str = ("0x%08X" % value)[2:] # Hex string with prefix removed
                byte_arr = bytearray.fromhex(hex_str) # Byte array from hex string
                byte_arr = byte_arr[::-1] ### FW BUG: Data arrives in reversed byte order.
                if (response_length - index) < BUFFER_PAGE_SIZE:
                    bytes_to_trim = BUFFER_PAGE_SIZE - (response_length - index)
                    byte_arr = byte_arr[:-1 * bytes_to_trim] # Trim byte array to contain actual data
                self.debug("bootloader_command(page=%d, hex_str=0x%s, len=%d)"
                           % (page, hex_str, len(byte_arr)))
                response.extend(byte_arr)
            self.debug("bootloader_command(response=0x%s)"
                       % (''.join(format(byte, '02X') for byte in response)))

            return response


        def file_read(self, fp, length):
            data = bytearray(fp.read(length))
            if len(data) != length:
                raise self.DownloadFailed(message="Only read %dB when expecting %dB" % (len(data), length))
            else:
                return data


        def unpack_value(self, data):
            if not (type(data) is bytearray):
                raise self.DownloadFailed(message="Unable to unpack object of type %s" % (type(data)))
            else:
                return int(str(data).encode('hex'), 16)


        def debug_display_variable(self, variable, name):
            if type(variable) is bytearray:
                message = "0x%s" % (', 0x'.join(format(byte, '02X') for byte in variable))
            elif type(variable) is int:
                message = "%d (0x%X)" % (variable, variable)
            else:
                message = "%s" % (variable)

            self.debug("%s=%s" % (name, message))


        def download (self, filename, node, transferDelay):
            REGISTER_COMMAND                                = 0x03
            CMD_DISABLE                                     = 0x01
            CMD_ENABLE                                      = 0x02

            # Look up the SkyeTek firmware upgrade
            SKYETEK_BOOTLOADER_QUERY_BOOTLDR_VER            = 0x01
            SKYETEK_BOOTLOADER_PROGRAM_DEFAULTS             = 0x03
            SKYETEK_BOOTLOADER_WRITE_DATA                   = 0x04
            SKYETEK_BOOTLOADER_SELECT_ENCRYPTION_SCHEME	    = 0x05
            SKYETEK_BOOTLOADER_UPDATE_COMPLETE_RESET        = 0x07
            SKYETEK_BOOTLOADER_SETUP_BOOTLOADER             = 0x08

            SKYETEK_MIN_FILE_SIZE                           = 8
            SKYETEK_SHF_STRUCTURE_LENGTH_LENGTH             = 2
            SKYETEK_SHF_STRUCTURE_VERSION_LENGTH            = 2
            SKYETEK_BOOTLOADER_VERSION_LENGTH               = 4
            SKYETEK_ENCRYPTION_SCHEME_LENGTH                = 1
            SKYETEK_BL_INITIALIZATION_STRING_LENGTH_LENGTH  = 1
            SKYETEK_MAX_BL_INITIALIZATION_STRING            = 8
            SKYETEK_ENCRYPTED_DATA_BLOCK_OFFSET             = 2
            SKYETEK_ENCRYPTED_BLOCK_LENGTH_LENGTH           = 4
            SKYETEK_DATA_BLOCK_LENGTH_LENGTH                = 2
            SKYETEK_SYSTEM_PARAMETER_LENGTH                 = 1

            skyetek_subsystem = self.skyetek_subsystem_address(node)

            # Put subsystem in known state
            self.debug("Disabling and re-enabling subsystem 0x%02X"
                       % (skyetek_subsystem))
            self.syncWrite((CMD_DISABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
            self.syncWrite((CMD_ENABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=60.0)

            self.switch_to_boot_loader(node, skyetek_subsystem)

            abspath         = self.getPath(filename)
            fp              = file(abspath, "rb")
            file_size       = getsize(abspath)
            min_file_size   = SKYETEK_MIN_FILE_SIZE

            self.debug("Downloading file %r (%dB) to node 0x%02X, subsystem 0x%02X"
                       % (filename, file_size, node, skyetek_subsystem))

            # Make sure file has enough bytes
            if file_size < min_file_size:
                raise self.DownloadFailed(message="File size %d is less than minimum size %d" % (file_size, min_file_size))

            # Read SHF structure length
            data = self.file_read(fp, SKYETEK_SHF_STRUCTURE_LENGTH_LENGTH)
            shf_structure_length = self.unpack_value(data)
            self.debug_display_variable(shf_structure_length, "shf_structure_length")

            # Read SHF structure version
            data = self.file_read(fp, SKYETEK_SHF_STRUCTURE_VERSION_LENGTH)
            shf_structure_version = self.unpack_value(data)
            self.debug_display_variable(shf_structure_version, "shf_structure_version")

            # Read bootloader version
            data = self.file_read(fp, SKYETEK_BOOTLOADER_VERSION_LENGTH)
            bootloader_version = self.unpack_value(data)
            self.debug_display_variable(bootloader_version, "bootloader_version")

            # Read encryption scheme
            data = self.file_read(fp, SKYETEK_ENCRYPTION_SCHEME_LENGTH)
            encryption_scheme = self.unpack_value(data)
            self.debug_display_variable(encryption_scheme, "encryption_scheme")

            # Read bootlaoder initialization string length
            bl_initialization_string_length = self.file_read(fp, SKYETEK_BL_INITIALIZATION_STRING_LENGTH_LENGTH)
            bl_initialization_string_length_value = self.unpack_value(bl_initialization_string_length)
            self.debug_display_variable(bl_initialization_string_length_value, "bl_initialization_string_length_value")

            # Make sure BL initialization string is a valid length
            if bl_initialization_string_length_value > SKYETEK_MAX_BL_INITIALIZATION_STRING:
                raise self.DownloadFailed(message="BL initialization string size %d is greater than maximum size %d" % (bl_initialization_string_length_value, SKYETEK_MAX_BL_INITIALIZATION_STRING))

            # Read bootloader initialization string
            if bl_initialization_string_length_value > 0:
                # Make sure file has enough bytes
                min_file_size = min_file_size + bl_initialization_string_length_value
                if file_size < min_file_size:
                    raise self.DownloadFailed(message="File size %d is less than minimum size %d" % (file_size, min_file_size))

                # Read bootloader initialization string data
                bl_initialization_string_data = self.file_read(fp, bl_initialization_string_length_value)
                self.debug_display_variable(bl_initialization_string_data, "bl_initialization_string_data")

                # Construct bootloader initialization string from length and data
                bl_initialization_string = bytearray()
                bl_initialization_string.extend(bl_initialization_string_length)
                bl_initialization_string.extend(bl_initialization_string_data)
                self.debug_display_variable(bl_initialization_string, "bl_initialization_string")

            # Read bootloader version
            response = self.bootloader_command(node, skyetek_subsystem, SKYETEK_BOOTLOADER_QUERY_BOOTLDR_VER, [])
            self.debug_display_variable(response, "SKYETEK_BOOTLOADER_QUERY_BOOTLDR_VER")
            if len(response) == 0:
                raise self.DownloadFailed(message="Failed to send QUERY_BOOTLDR_VER command")

            # Save length of header processed
            shf_length_header_used = fp.tell() - SKYETEK_SHF_STRUCTURE_LENGTH_LENGTH
            self.debug_display_variable(shf_length_header_used, "shf_length_header_used")

            # Seek to encrypted data block portion
            fp.seek(shf_structure_length + SKYETEK_ENCRYPTED_DATA_BLOCK_OFFSET)

            # Read encrypted block length
            data = self.file_read(fp, SKYETEK_ENCRYPTED_BLOCK_LENGTH_LENGTH)
            encrypted_block_length = self.unpack_value(data)
            self.debug_display_variable(encrypted_block_length, "encrypted_block_length")

            # Make sure file has enough bytes
            min_file_size = min_file_size + encrypted_block_length
            if file_size < min_file_size:
                raise self.DownloadFailed(message="File size %d is less than minimum size %d" % (file_size, min_file_size))

            # Set encryption scheme
            response = self.bootloader_command(node, skyetek_subsystem, SKYETEK_BOOTLOADER_SELECT_ENCRYPTION_SCHEME, [encryption_scheme])
            self.debug_display_variable(response, "SKYETEK_BOOTLOADER_SELECT_ENCRYPTION_SCHEME")
            if len(response) == 0:
                raise self.DownloadFailed(message="Failed to send SELECT_ENCRYPTION_SCHEME command")

            # Program image
            if encrypted_block_length > 0:
                # Send bootloader initialization sequence
                response = self.bootloader_command(node, skyetek_subsystem, SKYETEK_BOOTLOADER_SETUP_BOOTLOADER, bl_initialization_string)
                self.debug_display_variable(response, "SKYETEK_BOOTLOADER_SETUP_BOOTLOADER")
                if len(response) == 0:
                    raise self.DownloadFailed(message="Failed to send SETUP_BOOTLOADER command")

                # Write data blocks
                bytes_written = 0
                while bytes_written < encrypted_block_length:
                    # Read length of block
                    data_block_length = self.file_read(fp, SKYETEK_DATA_BLOCK_LENGTH_LENGTH)
                    data_block_length_value = self.unpack_value(data_block_length)
                    self.debug_display_variable(data_block_length_value, "data_block_length_value")

                    # Read block data
                    data_block_data = self.file_read(fp, data_block_length_value)

                    # Construct encrypted data from length and data
                    data_block = bytearray()
                    data_block.extend(data_block_length)
                    data_block.extend(data_block_data)

                    # Send data
                    response = self.bootloader_command(node, skyetek_subsystem, SKYETEK_BOOTLOADER_WRITE_DATA, data_block, False)
                    self.debug_display_variable(response, "SKYETEK_BOOTLOADER_WRITE_DATA")
                    if len(response) == 0:
                        raise self.DownloadFailed(message="Failed to send WRITE_DATA command")
                    bytes_written = bytes_written + len(data_block)

            # Program system parameters
            if shf_structure_length > shf_length_header_used:
                # Seek to default system parameters
                fp.seek(shf_length_header_used + SKYETEK_SHF_STRUCTURE_LENGTH_LENGTH)

                # Write default system parameters
                while shf_structure_length > shf_length_header_used:
                    # Read length of system parameter
                    data = self.file_read(fp, SKYETEK_SYSTEM_PARAMETER_LENGTH)
                    system_parameter_length = self.unpack_value(data)
                    self.debug_display_variable(system_parameter_length, "system_parameter_length")
                    shf_length_header_used = shf_length_header_used + 1

                    # Validate system parameter length
                    if (system_parameter_length < 1) or (system_parameter_length > 100):
                        raise self.DownloadFailed(message="System parameter length %d is invalid" % (system_parameter_length))

                    # Read system parameter
                    system_parameter_data = self.file_read(fp, system_parameter_length)
                    self.debug_display_variable(system_parameter_data, "system_parameter_data")
                    shf_length_header_used = shf_length_header_used + system_parameter_length

                    # Send program defaults command to reader
                    response = self.bootloader_command(node, skyetek_subsystem, SKYETEK_BOOTLOADER_PROGRAM_DEFAULTS, system_parameter_data)
                    self.debug_display_variable(response, "SKYETEK_BOOTLOADER_PROGRAM_DEFAULTS")
                    if len(response) == 0:
                        raise self.DownloadFailed(message="Failed to send PROGRAM_DEFAULTS command")

            # Send update complete and reset command
            response = self.bootloader_command(node, skyetek_subsystem, SKYETEK_BOOTLOADER_UPDATE_COMPLETE_RESET, [])
            self.debug_display_variable(response, "SKYETEK_BOOTLOADER_UPDATE_COMPLETE_RESET")
            # No response is expected. Brings reader out of bootload mode

            # Put subsystem in known state
            self.debug("Disabling and re-enabling subsystem 0x%02X"
                       % (skyetek_subsystem))
            self.syncWrite((CMD_DISABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=5.0)
            self.syncWrite((CMD_ENABLE, ), node, skyetek_subsystem + REGISTER_COMMAND, '!I', sync=60.0)




class LLACFullBranch (LLACRegisterBranch, FullBranch):
    '''Commands to control one or more LLAC peripherals'''



class LLACObsoleteBranch (LLACFullBranch):

    def __init__ (self, *args, **kwargs):
        LLACFullBranch.__init__(self, *args, **kwargs)
        warning("%s branch Type 'LLAC' is deprecated; please specify '-type=LLACRegisterBranch' or '-type=LLACFullBranch'"%
                self.commandPath())



class LLACPollItem (PollItem, DynamicCommandBase):
    def __init__ (self, name, args, session, scope, format):
        path, defaults = scope.locate(name)
        branch, leaf   = path[-2:]
        self.registers = []
        self.leaf      = leaf

        if leaf.istype(_LLACReadGroupLeaf):
            self.registers.extend(leaf.registers)

        elif leaf.istype(_LLACReadLeaf):
            node, base = branch.getaddress(leaf.name, **defaults)
            name = ':'.join([obj.name for obj in path[1:]])
            defaults.update(name=name, node=node, register=base)
            self.registers.append(defaults)

        else:
            raise self.IncorrectType(foundName=leaf.commandPath(scope=scope),
                                     foundType=leaf.getTypeName(),
                                     searchType=" or ".join((_LLACReadLeaf.llacType,
                                                             _LLACReadGroupLeaf.llacType)))

        PollItem.__init__(self, name, args, session, scope, format)

    def acquire (self):
        return [ self.leaf.sendRead(**reg) for reg in self.registers ]

    def collect (self, pending):
        return self.leaf.getResponseList(pending)

    def strings (self, responses):
        strings = []
        for regspec, response in zip(self.registers, responses):
            if self.format:
                fmt = self.format
            else:
                argtype, fmt = self.argTypes[regspec['type']]
                fmt          = fmt(regspec['size'])

            try:
                strings.append(fmt%response)
            except TypeError, e:
                raise self.StringConversionError(format=self.format, value=value)

        return strings

PollItemTypes['LLAC'] = LLACPollItem

branchTypes['LLACRegisterBranch'] = LLACRegisterBranch
branchTypes['LLACFullBranch'] = LLACFullBranch

commandTypes['RegisterLeaf'] = _LLACRegisterLeaf
commandTypes['RegisterBranch'] = LLACRegisterBranch

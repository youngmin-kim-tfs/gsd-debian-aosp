########################################################################
### FILE:	scpiReturnLeaf.py
### PURPOSE:
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005 Applied Biosystems.  All rights reserved.
########################################################################

from scpiLeaf       import Leaf, Observing
from scpiExceptions import ReturnValue, NextCommand, Break
from scpiParameter  import autoType

class NEXT (Observing, Leaf):
    """
    Cause the remainder of the containing macro or module to be
    executed asynchronously, i.e. in the background.  The client
    (which in turn may be another macro or module) receives a NEXT
    reply, and may at this point issue additional commands.
    """

    def run (self):
        raise NextCommand(self)


class BREak (Observing, Leaf):
    """
    Break out of a REPeat, ITERate, or SCHedule loop.
    
    """

    def run (self, levels=1):
        raise Break(levels)


class RETurn (Observing, Leaf):
    """
    Exit out of a macro or module, and return the supplied string to the caller.
    Useful in macros.
    """

    def declareInputs (self):
        Leaf.declareInputs(self)
        self.setInput('delimiter', type=str, default=None, named=True)
        self.setInput('arguments', type=tuple)

    def declareOutputs (self):
        Leaf.declareOutputs(self)
        self.addOutput('item', type=tuple, default=None, repeats=(0, None))

    def run (self, _session, _context, split=False, delimiter=None, *arguments):
        if split:
            parts = []
            for part in arguments:
                opt, value, raw = part
                if opt:
                    parts.append(part)
                elif delimiter:
                    args = value.split(delimiter)
                    if args and not args[-1]:
                        args.pop()
                    parts.extend([(None, arg) for arg in args])
                else:
                    text, args = _session.expandArgs(value, context=_context)
                    parts.extend(args)
        else:
            parts = arguments

        raise ReturnValue(*parts)


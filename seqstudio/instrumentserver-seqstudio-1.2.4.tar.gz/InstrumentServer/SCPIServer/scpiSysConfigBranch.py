########################################################################
### FILE:	scpiSysConfigBranch.py
### PURPOSE:    Commands to set/obtain system configuration
### SCOPE:	SYSTem: branch
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2017 ThermoFisher Scientific.  All rights reserved.
########################################################################
                

from scpiLeaf           import Administrative, Controlling, Observing, Public, Leaf
from scpiSession        import ADMINISTRATOR, NestedSession
from scpiFilesystemBase import FilesystemLeaf
from scpiMinimalBranch  import MinimalBranch
from scpiExceptions     import RunError, CommandError, NextReply, EnvError
from subscription       import warning, info
from SysConfig          import sysconfig, netconfig, SysConfigDomains, SysConfigError
from cStringIO          import StringIO
from data               import DynamicData



class SysConfigLeaf (FilesystemLeaf):
    class SysConfigError (RunError):
        name = 'SysConfig.Error'

    class SysConfigMissing (SysConfigError):
        '''SysConfig domain %(domain)r requires option %(option)r.'''
        name = 'SysConfig.MissingOption'
        
    def checkArgs (self, domain, options):
        provided = [ key.lower() for key in options ]
        for arg in domain.args:
            if not arg.lower() in provided:
                raise self.SysConfigMissing(domain=domain.domain, option=arg)

    def invoke (self, *args, **kwargs):
        try:
            return Leaf.invoke(self, *args, **kwargs)
        except SysConfigError, e:
            raise self.SysConfigError(type(e).__name__, str(e), **e.kwargs)
        except EnvironmentError, e:
            raise EnvError(e, None)


class SysConfigQuery (Observing, SysConfigLeaf):
    KEY = ()

    def declareInputs (self):
        SysConfigLeaf.declareInputs(self)
        self.setInput('default', type=str, named=True)

    def declareOutputs(self):
        SysConfigLeaf.declareOutputs(self)
        self.addOutput('value', type=str, default=None)

    def run (self, default=None):
        return sysconfig.get(self.KEY) or default
    

class SysConfigSetting (Administrative, SysConfigLeaf):
    KEY = ()

    def declareInputs(self):
        SysConfigLeaf.declareInputs(self)
        self.setInput('value', type=str)

    def run (self, value):
        sysconfig.set({self.KEY:value}, save=True)
    

class NetConfigLeaf (SysConfigLeaf):
    from SysConfig.base import NetInterfaceProvider
    STATES  = NetInterfaceProvider.STATES
    METHODS = NetInterfaceProvider.METHODS

    class NoActiveInterface (RunError):
        '''There is no active network interface'''

    def getInterfaces (self):
        return netconfig.listValues('interface')


    def getDefaultInterface (self, ignoreMissing=False):
        interfaces = self.getInterfaces()

        try:
            for interface in interfaces:
                if netconfig.get('gateway', interface=interface, current=True):
                    return interface

            for interface in interfaces:
                if netconfig.get('carrier', interface=interface):
                    return interface

        except netconfig.NoProvider:
            if not ignoreMissing:
                raise

        else:
            if not ignoreMissing:
                raise self.NoActiveInterface()



class WifiConfigLeaf (NetConfigLeaf):
    class NoWirelessInterface (RunError):
        '''No wireless network interface found on this system'''


    def getWifiInterface (self, interface=None, required=True):
        for interface in self.getInterfaces():
            if netconfig.get('wireless', interface=interface):
                return interface

        else:
            if required:
                raise self.NoWirelessInterface()
        

    def getWifiProvider (self):
        return netconfig.getProvider('ssid')



class SysConfigBranch (MinimalBranch):
    '''SysConfig interface'''

    hooks = DynamicData()

    class HookExists (RunError):
        '''A SysConfig hook named %(handle)r already exists'''

    class DuplicateHooks (RunError):
        '''The SysConfig key %(key)r already '''

    class NoSuchHook (RunError):
        '''No such SysConfig hook exists: %(handle)r'''
        
    class NoHooksForKey (RunError):
        '''There are no custom hooks for SysConfig key %(key)r'''

    def addHook (self, domain, handle, keys, command, replaceExisting=False, immediate=False):
        if self.hooks is None:
            self.hooks = DynamicData()
        elif handle in self.hooks:
            if replaceExisting:
                self.removeHook(handle)
            else:
                raise self.HookExists(handle=handle)

        self.hooks[handle] = (domain, keys, command)
        for key in keys:
            try:
                method, handles = domain.hooks[key]

                assert handle not in handles, \
                    "SysConfig domain %s key %r already has callback handle %r"%\
                    (domain.domain, key, domain)

                handles.append(handle)
            except KeyError:
                domain.hooks[key] = self.runHook, [handle]

        if immediate:
            valuemap = domain.getdict(keys)
            self.runHook(handle, **valuemap)


    def removeHook (self, handle, ignoreMissing=False):
        try:
            domain, keys, command = self.hooks.pop(handle)
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchHook(handle=handle)
        else:
            for key in keys:
                method, handles = domain.hooks[key]
                handles.remove(handle)
                if not handles:
                    del domain.hooks[key]

    def getHook (self, handle, ignoreMissing=False):
        try:
            return self.hooks[handle]
        except KeyError:
            if not ignoreMissing:
                raise self.NoSuchHook(handle=handle)


    def runHook (self, *handles, **localdata):
        for handle in handles:
            domain, keys, command = self.hooks[handle]
            session = NestedSession(parent=None,
                                    input=command,
                                    access=ADMINISTRATOR,
                                    description='SysConfig hook %r'%(handle,))
            session.handle(self.parent.parent, localdata=localdata)
            

    def getHandles (self, domain, key, ignoreMissing=False):
        try:
            method, handles = domain.hooks[key]
            return handles
        except KeyError:
            if not ignoreMissing:
                raise self.NoHooksForKey(key=key)


    class ITEM_Set (Administrative, SysConfigLeaf):
        '''
        Set one or more arbitrary sysconfig items.  Mainly for debugging purposes.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('domain', type=SysConfigDomains, named=True, default=sysconfig)
            
        def run (self, domain, **valuemap):
            self.checkArgs(domain, valuemap)
            domain.set(valuemap)


    class VALue_Query  (Observing, SysConfigLeaf):
        '''
        Retrieve one or more arbitrary sysconfig items.  Mainly for debugging purposes.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('named', type=bool, named=True, default=False)
            self.setInput('domain', type=SysConfigDomains, named=True, default=sysconfig)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('item', type=tuple, named=True, repeats=(0, None))

        def run (self, named=False, domain=None, *keys, **opts):
            self.checkArgs(domain, opts)
            values = domain.getvalues(keys, **opts)
            return tuple([((None, key)[named], str(value)) for (key, value) in zip(keys, values) ])


    class DOMain_Enumerate (Observing, SysConfigLeaf):
        '''
        Return available SysConfig domains.
        '''

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('key', type=str, repeats=(0, None))

        def run (self, named=False, *keys, **opts):
            return tuple(SysConfigDomains)
        

    class KEY_Enumerate (Observing, SysConfigLeaf):
        '''
        Return available sysconfig keys.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('named', type=bool, named=True, default=False)
            self.setInput('domain', type=SysConfigDomains, named=False, default=sysconfig)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('key', type=str, repeats=(0, None))

        def run (self, named=False, domain=None):
            return tuple(domain.providers)


    class PROVider_Enumerate (Observing, SysConfigLeaf):
        '''
        Return available sysconfig keys.
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('domain', type=SysConfigDomains, named=True, default=sysconfig)
            self.setInput('key', type=str)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('provider', type=str, repeats=(0, None))

        def run (self, domain, key):
            names = [ provider.name for provider in domain.getProviders(key) ]
            return tuple(names)


    class HOOK_Add (Administrative, SysConfigLeaf):
        '''Configure a command to be executed after a successful sysconfig
        update. The values of keys that were updated are available in
        local variables by their respective key names.

        Example:
        * After a successful time update, synchronize the new system
          time with a SCPI server linked to the branch "OtherServer":
            C: SYSTem:CONFiguration:HOOK= time <<<OtherServer:SYSTem:TIME= ${time}>>>
        '''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('replaceExisting', type=bool, named=True, default=False)
            self.setInput('immediate', type=bool, named=True, default=False,
                          description='Run this hook immediately, using current values for the specified keys.')
            self.setInput('domain', type=SysConfigDomains, named=True, default=sysconfig)
            self.setInput('handle', type=str,
                          descriptpion='An identifier for this hook, for subsequent query or removal')
            self.setInput('keys', type=str, split=(",", 1, None))
            self.setInput('command', type=str,
                          description='Command block to invoke after the successful update.')


        def run (self, replaceExisting, immediate, domain, handle, keys, command):
            self.parent.addHook(domain, handle, keys, command, replaceExisting, immediate)


    class HOOK_Remove (Administrative, SysConfigLeaf):
        '''Return the hook associated with the specified sysconfig key'''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False)
            self.setInput('handles', type=str, repeats=(1,None))

        def run (self, ignoreMissing=False, *handles):
            for handle in handles:
                self.parent.removeHook(handle, ignoreMissing)

    class HOOK_Clear (Administrative, SysConfigLeaf):
        '''Remove all sysconfig hooks for the specified SysConfig keys.'''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False)
            self.setInput('domain', type=SysConfigDomains, named=True, default=sysconfig)
            self.setInput('keys', type=str, split=(",", 0, None))

        def run (self, ignoreMissing, domain, keys):
            handles = self.parent.getHandles(domain, keys, ignoreMissing)
            for handle in handles or ():
                self.parent.removeHook(handle, ignoreMissing)


    class HOOK_Query (Observing, SysConfigLeaf):
        '''Return the hook associated with the specified sysconfig key'''

        class NoSuchHook (RunError):
            '''There is no hook for the sysconfig key %(key)r'''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False)
            self.setInput('handle', type=str)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('domain', type=SysConfigDomains, named=True, default=None)
            self.addOutput('keys', type=str, split=",", named=True, default=None)
            self.addOutput('command', type=str, default=None)

        def run (self, ignoreMissing, handle):
            return self.parent.getHook(handle, ignoreMissing)


    class HOOK_Enumerate (Observing, SysConfigLeaf):
        '''Enumerate available sysconfig keys in the specified domain.'''

        def declareInputs (self):
            SysConfigLeaf.declareInputs(self)
            self.setInput('ignoreMissing', type=bool, named=True, default=False)
            self.setInput('domain', type=SysConfigDomains, named=True, default=sysconfig)
            self.setInput('key', type=str, default=None)

        def declareOutputs (self):
            SysConfigLeaf.declareOutputs(self)
            self.addOutput('handle', type=str, repeats=(0, None))
                

        def run (self, ignoreMissing, domain, key):
            if key:
                handles = self.parent.getHandles(domain, key, ignoreMissing)
            else:
                handles = sorted(self.parent.hooks)

            return tuple(handles)

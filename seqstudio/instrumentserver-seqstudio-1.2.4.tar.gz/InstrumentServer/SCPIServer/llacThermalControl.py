#######################################################################
### FILE:       llacThermalControl.py
### PURPOSE:    Commands related to the NextGen Thermal Block Controller
### AUHOR:      Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2005-2014 Applied Biosystems.  All rights reserved.
########################################################################

from scpiExceptions  import RunError, NextReply
from scpiBranch      import branchTypes
from scpiLeaf        import Leaf, Background, Observing, Controlling, Administrative
from scpiDynamicBase import DynamicCommandLeaf
from llacBase        import LLACFullBranch, _LLACLeaf, _LLACWriteLeaf, _LLACReadLeaf

from subscription    import debug, info
from schedule        import schedule
from random          import random
from time            import time
from locking         import Event
from threading       import Lock
from threadControl   import Aborted, currentThread
from thread          import error as ThreadingError


### List of elements in "zoneSpec"
NAME, CONTROLREG, TARGETREG, RATEREG, MAXRATES, SETPOINT, MASTER = range(7)


### List of values accepted by control register
DISABLED, ENABLED, PAUSED, ABORT = (0, 1, 3, 5)
ControlValues = { "disabled":DISABLED, "enabled":ENABLED, "paused":PAUSED, "abort":ABORT }
ControlLabels = dict(zip(ControlValues.values(), ControlValues.keys()))


### Indefinite time constant (for PAUSe)
INFINITY = "infinity"


class _TBCLeaf (_LLACLeaf):
    pass


class _TBCZoneLeaf (_TBCLeaf):
    def __init__ (self, *args, **kwargs):
        _TBCLeaf.__init__(self, *args, **kwargs)
        self.parent.zoneLeafs.append(self)
        for zone in self.parent.zoneSpec:
            self.addZone(zone[NAME])




class _TBCSimulationLeaf (_TBCLeaf):
    simulated   = {}
    

class ThermalControlBoardBase (LLACFullBranch):
    """
    Thermal Control Block subsystem.
    """

    class NoSuchZone (RunError):
        'There is no control zone named %(name)r'

    class ZoneExists (RunError):
        'This zone is already defined: %(name)r'


    def __init__ (self, *args, **kwargs):
        LLACFullBranch.__init__(self, *args, **kwargs)
        self.zoneLeafs   = []
        self.zoneSpec    = []
        self.masters     = []
        self.lastSetting = []
        self.speed       = 1.0
        self.oplock      = Lock()
        self.opexcept    = None
        self.unhold      = Lock()
        self.unhold.acquire()
        self._start      = None
        self._end        = None
        self._remaining  = None
        self._handle     = self
        self._pendsuspend= False


    def _holding (self):
        try:
            debug('%s _holding invoked.'%(self.commandPath()))
            self.unhold.release()
            unschedule(self._handle)
        except:
            pass
        


    def addZone (self, name, controlRegister, setPointRegister, rampRateRegister,
                 follow=False, replaceExisting=False):
                 
        try:
            self.getZone(name)
        except self.NoSuchZone:
            pass
        else:
            if replaceExisting:
                self.delZone(name)
            else:
                raise self.ZoneExists(name=name)

        creg = self.getRegisterLeafSpec(controlRegister,  _LLACWriteLeaf)
        treg = self.getRegisterLeafSpec(setPointRegister, _LLACWriteLeaf)
        rreg = self.getRegisterLeafSpec(rampRateRegister, _LLACWriteLeaf)

        try:
            setpoint = self.read(**treg)
        except self.LLACError:
            setpoint = 25.0

        zone = [ name, creg, treg, rreg, None, setpoint ]

        if follow:
            masterzone = self.getZone(follow)
            self.masters.append(self.zoneSpec.index(masterzone))
        else:
            self.masters.append(None)

        self.zoneSpec.append(zone)

        for leaf in self.zoneLeafs:
            leaf.addZone(name)



    def delZone (self, name, ignoreMissing=False):
        for index, zone in enumerate(self.zoneSpec):
            if zone[NAME].lower() == name.lower():
                del self.zoneSpec[index]
                break
        else:
            if ignoreMissing:
                return
            else:
                raise self.NoSuchZone(name=name)

        ### Adjust/remove this zone index from the "masters" list
        for mindex, mzone in enumerate(self.masters):
            if mzone == index:
                self.masters[mindex] = None
            elif mzone > index:
                self.masters[mindex] -= 1

        for leaf in self.zoneLeafs:
            leaf.delZone(name)
        

    def getZone (self, name):
        name = name.lower()
        for zone in self.zoneSpec:
            if zone[NAME].lower() == name:
                return zone
        else:
            raise self.NoSuchZone(name=name)

        return zone


    def zoneNames (self):
        return tuple([zone[NAME] for zone in self.zoneSpec])


    def zoneControl (self, zoneNames, control):
        writes = []
        text   = []
        names  = [ name.lower() for name in zoneNames ]

        for index, zone in enumerate(self.zoneSpec):
            name, creg, treg, rreg, maxrates, setpoint = zone

            if not names or (name.lower() in names):
                text.append(name)
                writes.append((creg, control))

            else:
                try:
                    zone = self.zoneSpec[self.masters[index]]
                except TypeError:
                    pass
                else:
                    if zone[NAME].lower() in names:
                        text.append(name)
                        writes.append((zone[CONTROLREG], control))


        self.debug("%s %s %s."%
                   (self.commandPath(),
                    ControlLabels[control].capitalize(),
                    ', '.join(text)))

        self.writeList(writes)


    def acquireLock (self):
        self.debug('%s acquiring operative lock'%(self.commandPath()))
        self.oplock.acquire()
        if self.opexcept:
            try:
                raise self.opexcept
            finally:
                self.opexcept = None

        if currentThread().abortflag:
            self.oplock.release()
            raise Aborted


    def releaseLock (self):
        self.debug('%s releasing operative lock'%(self.commandPath()))
        self.oplock.release()





    class ZONe_Add (Administrative, _TBCLeaf):
        '''
        Define a control zone for use with the RAMP command.
        '''

        def declareInputs (self):
            _TBCLeaf.declareInputs(self)
            self.setInput('name',
                          description=
                          'Identifier for this zone (e.g. "zone1").  This '
                          'becomes an input parameter for the RAMP command.')

            self.setInput('controlRegister',
                          description=
                          'Writable LLAC device register used to '
                          'enable/disable temperature control for this zone')

            self.setInput('setPointRegister',
                          description=
                          'Writable LLAC device register used to set the '
                          'target temperature for this zone')

            self.setInput('rampRateRegister',
                          description=
                          'Writable LLAC device register used to set the '
                          'ramp rate for this zone')

            self.setInput('follow',
                          type=str,
                          default=None,
                          named=True,
                          description='The name of another (master) zone whose control '
                          'should be implicitly applied to this zone.')


        def run (self, follow=None, replaceExisting=False, name=str,
                 controlRegister=str,
                 setPointRegister=str,
                 rampRateRegister=str):

            self.parent.addZone(name=name, 
                                controlRegister=controlRegister,
                                setPointRegister=setPointRegister,
                                rampRateRegister=rampRateRegister,
                                follow=follow)
            


    class ZONe_Remove (Administrative, _TBCLeaf):
        '''
        Remove a control zone.  This must previously have been
        added using "ZONe+".
        '''

        def run (self, ignoreMissing=False, name=str):
            self.parent.delZone(name, ignoreMissing=ignoreMissing)



    class ZONe_Query (Observing, _TBCLeaf):
        '''
        Show register mappings for a given zone.
        '''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('controlRegister',  type=str)
            self.addOutput('setPointRegister', type=str)
            self.addOutput('rampRateRegister', type=str)
            self.addOutput('follow',           type=str, named=True, default=None)

        def run (self, name=str):
            for index, zone in enumerate(self.parent.zoneSpec):
                regname, creg, treg, rreg, maxrates, setpoint = zone
                if regname.lower() == name.lower():
                    mzone = self.parent.masters[index]
                    if mzone is not None:
                        mzone = self.parent.zoneSpec[mzone][NAME]
                    return (creg['name'], treg['name'], rreg['name'], mzone)



    class ZONe_Enumerate (Observing, _TBCLeaf):
        '''
        List control zones.
        '''
        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('name', type=str, repeats=(0, None))


        def run (self):
            return self.parent.zoneNames()


    class SIMulate (Controlling, _TBCSimulationLeaf):
        '''
        Simulate temperature readings in the given sensor based on
        control parameters for the given zone.
        '''
        ambient         = 25.0

        def __init__ (self, *args, **kwargs):
            _TBCLeaf.__init__(self, *args, **kwargs)
            schedule(self, 1, self._control)

                
        def run (self, zone=str, *sensors):
            regs   = []
            writes = []
            for sensor in sensors:
                spec = self.parent.getRegisterLeafSpec(sensor, _LLACReadLeaf)
                regs.append((sensor, spec))
                writes.append(self.sendWrite((self.ambient,), **spec))

            self.simulated[zone.lower()] = regs
            self.finishWrites(writes)


        def _control (self):
            writes   = []
            for name, creg, treg, rreg, maxrates, setpoint in self.parent.zoneSpec:
                sensors  = [ reg
                             for name, reg in self.simulated.get(name.lower(), []) ]
                             
                if not sensors:
                    continue

                control, target, rate = self.readList((creg, treg, rreg))
                readings              = self.readList(sensors)

                if not control:
                    target = self.ambient
                    rate   = 1.5
                    

                for sensor, reading in zip(sensors, readings):
                    diff  = target - reading
                    if diff < 0:
                        delta = max(diff, -rate, -4.0)
                    else:
                        delta = min(diff, rate, 2.5)

                    delta = diff
                    jitter   = 1.0 + (random() - 0.5) / 10
                    change   = (delta * jitter)
                    writes.append(self.sendWrite((reading + change,), **sensor))

            if writes:
                self.finishWrites(writes)


    class SIMulate_Query (Observing, _TBCSimulationLeaf):
        '''
        List sensor registers being simulated for a given zone.
        '''

        class NotSimulated (RunError):
            'No LLAC sensors are being simulated for this zone'

        def declareOutputs (self):
            _TBCSimulationLeaf.declareOutputs(self)
            self.addOutput('sensor',
                           type=str,
                           repeats=(0, None))

        def run (self, zone=str):
            try:
                return tuple([ name for name, reg in self.simulated[zone.lower()]])
            except KeyError, e:
                raise self.NotSimulated


    class SIMulateSPeeD (Controlling, _TBCSimulationLeaf):
        '''
        Sets the speed of hold operations
        '''
        def declareInputs (self):
            _TBCLeaf.declareInputs(self)
            self.setInput('speed',
                          type=float,
                          range=(1.0, 50.0),
                          description='Simulation speed')

        def run (self, speed):
            self.parent.speed = speed


    class SIMulateSPeeD_Query (Controlling, _TBCSimulationLeaf):
        '''
        Query the speed of hold operations
        '''
        def declareOutputs (self):
            _TBCSimulationLeaf.declareOutputs(self)
            self.addOutput('speed',
                           type=float,
                           description='Simulation speed')

        def run (self):
            return self.parent.speed



    class SUSPend_Query (Controlling, _TBCSimulationLeaf):
        '''
        Query if the instrument has any pending suspend requests
        '''
        def declareOutputs (self):
            _TBCSimulationLeaf.declareOutputs(self)
            self.addOutput('pendsuspend', type=bool, description='Pending Suspend')

        def run (self):
            self.debug("Pending Suspend flag: %s"%self.parent._pendsuspend)
            return self.parent._pendsuspend


    class SUSPend_Clear (Controlling, _TBCSimulationLeaf):
        '''
        Clear pending suspend requests
        '''
        def run (self):
            self.debug("Pending Suspend flag cleared: %s"%self.parent._pendsuspend)
            self.parent._pendsuspend = False


    class SUSPend (Controlling, _TBCLeaf):
        '''
            Suspend TBC Control Loop
        '''
        def run (self):
            if self.parent._start is not None:
                if self.parent._end is not None:
                    unschedule(self.parent._handle)
                    elapsed = time() - self.parent._start
                    self.parent._remaining = self.parent._end - self.parent._start - elapsed
                    self.parent._end = None
                    self.debug('%s: Suspended. Remaining %s Start %s'%(self.commandPath(), self.parent._remaining, self.parent._start))
                else:
                    ### Infinite time hold
                    self.debug('%s: Infinite time hold'%(self.commandPath()))
            else:
                ### No hold is in operation
                self.parent._pendsuspend = True
                self.debug('%s: No hold in operation. Pending Suspend flag set %s'%(self.commandPath(), self.parent._pendsuspend))


    class RESume (Controlling, _TBCLeaf):
        '''
            Resume TBC Control Loop
        '''
        def run (self):
            if self.parent._start is not None:
                if self.parent._remaining is not None:
                    self.parent._start = time()
                    delay = self.parent._remaining
                    schedule(self.parent._handle, delay, self.parent._holding)
                    self.parent._end = self.parent._start + delay
                    self.debug('%s: Resume Paused. Delay %s Start %s'%(self.commandPath(), delay, self.parent._start))
                else:
                    ### Infinite time hold
                    self.debug('%s: Resume to Infinite time hold'%(self.commandPath()))
            else:
                ### No hold is in operation
                self.debug('%s: Ignored - No hold in operation'%(self.commandPath()))


    class HOLD_Query (Controlling, _TBCLeaf):
        '''
        Query if hold is active.
        '''
        def declareOutputs (self):
            _TBCLeaf.declareOutputs(self)
            self.addOutput('hold', type=bool, description='Hold state')

        def run (self):
            if self.parent._start is None:
                return False
            return True


    class HOLD (Controlling, Background, _TBCLeaf):
        '''
        Hold any future SETTing commands until the specified amount of
        time has elasped since any previous setpoint has been reached.

        This is more accurate than performing WAIT operations between
        SETTing invocations, since the overhead of any operations performed
        in the meantime are eliminated.

        Any currently pending HOLD operation is cancelled.
        '''

        def declareInputs (self):
            _TBCLeaf.declareInputs(self)
            self.setInput('delay', type=float, default=None, units='seconds',
                          description='Delay between completion of previous ramp '
                          'and issuing of a new setpoint to the TBC.')

        def run (self, delay=float):
            self.parent.acquireLock()
            return delay


        def next (self, delay=float):
            if delay is None:
                self.debug("%s starting infinite hold"%(self.commandPath()))
            else:
                self.debug("%s starting %fs hold"%(self.commandPath(), delay))
                
            try:
                self.parent._start = time()
                if delay is None:
                    self.parent._end = None
                else:
                    self.parent._end = self.parent._start + delay
                    schedule(self.parent._handle, delay, self.parent._holding)
                self.parent.unhold.acquire()
                self.parent.unhold.release()
                self.debug('%s: Unhold Released'%(self.commandPath()))
                self.parent._start = None
                self.parent._end = None
                self.parent._remaining = None
                ### This acquire() is prepared for next hold
                self.parent.unhold.acquire()
            finally:
                self.parent.releaseLock()



    class UNHOLD (Controlling, _TBCLeaf):
        '''
        Cancel a pending hold.
        '''
        def run (self):
            try:
                if self.parent._start is not None:
                    if self.parent._end is not None:
                        unschedule(self.parent._handle)

                    try:
                        self.parent._start = None
                        self.parent._end = None
                        self.parent._remaining = None
                        self.parent.unhold.release()
                    except:
                        pass

                    self.debug('%s: Unhold lock'%(self.commandPath()))
                else:
                    ### No hold is in operation
                    self.debug('%s: No hold in operation'%(self.commandPath()))
            finally:
                self.parent.releaseLock()




    class CONTrol (Controlling, _TBCZoneLeaf):
        '''
        Enable or disable temperature control for the specified zones.
        '''

        def declareInputs (self):
            self.startInputs()


        def addZone (self, name):
            self.addInput(name,
                          type=bool,
                          default=None,
                          description='%s control value'%name)


        def delZone (self, name):
            self.removeInput(name)

            
        def run (self, *control):
            writes   = []
            text     = []

            for index, value in enumerate(control):
                name, creg, treg, rreg, maxrates, setpoint = self.parent.zoneSpec[index]

                if value is None:
                    try:
                        value = control[self.parent.masters[index]]
                    except TypeError:
                        pass

                if value is not None:
                    text.append("%s %s"%(name, value and "On" or "Off"))
                    writes.append((creg, value))


            self.parent.acquireLock()
            try:
                self.debug("%s turning %s."%(self.commandPath(), ", ".join((text))))
                self.writeList(writes)
            finally:
                self.parent.releaseLock()



    class CONTrol_Query (Observing, _TBCZoneLeaf):
        '''
        Return control parameters for the specified zone.
        '''
            
        def addZone (self, name):
            zones = self.parent.zoneNames()
            self.setInput('zones', type=zones, repeats=(0, len(zones)))
            self.addOutput(name, type=bool, named=True, default=None,
                           description='Zone "%s" control value')


        def delZone (self, name):
            zones = self.parent.zoneNames()
            self.setInput('zones', type=zones, repeats=(0, len(zones)))
            self.removeOutput(name)


        def run (self, *zones):
            if not zones:
                zones = range(len(self.parent.zoneSpec))
                
            regs = [ self.parent.zoneSpec[idx][CONTROLREG] for idx in zones ]
            return tuple(self.readList(regs))



    class STARt (Controlling, _TBCLeaf):
        '''
        Enable temperature control in the specified temperature control zones.
        If no zones are specified; enable temperature control in all zones.
        '''


        def run (self, *zones):
            self.parent.zoneControl(zones, ENABLED)


    class STOP (Controlling, _TBCLeaf):
        '''
        Disable temperature control in the specified temperature control zones.
        If no zones are specified; disable temperature control in all zones.
        '''

        def run (self, *zones):
            self.parent.zoneControl(zones, DISABLED)


    class PAUSe (Controlling, _TBCLeaf):
        '''
        Pause TBC control of the given zones.
        To reenable control, use STARt.
        '''

        def run (self, *zones):
            self.parent.zoneControl(zones, PAUSED)


    class ABORt (Controlling, _TBCLeaf):
        '''
        Abort TBC if ramping state.
        '''

        def run (self, *zones):
            self.parent.zoneControl(zones, ABORT)


    class RATe (Controlling, _TBCLeaf):
        '''
        Specify the maximum ramp rates for this thermal zone.

        These values are subsequently scaled according to the "rate"
        argument given in the "SETTing" command, then written to the
        TBC and used in calculation of estimated ramp time and
        ramp timeout.
        '''

        def declareInputs (self):
            _TBCLeaf.declareInputs(self)

            self.setInput('zone',
                          type=str,
                          description=
                          'Thermal zone to which this rate applies')

            self.setInput('up',
                          type=float,
                          range=(0.001, None),
                          units='degrees C/second',
                          description='Maximum rate for upward ramps')

            self.setInput('down',
                          type=float,
                          range=(0.001, None),
                          units='degrees C/second',
                          description='Maxiumum rate for downward ramps')


        def run (self, zone, up, down):
            zone = self.parent.getZone(zone)
            zone[MAXRATES] = (up, down)



    class RATe_Clear (Controlling, _TBCLeaf):
        '''
        Clear maximum ramp rates for this thermal zone.
        '''

        def declareInputs (self):
            _TBCLeaf.declareInputs(self)

            self.setInput('zone',
                          type=str,
                          description=
                          'Thermal zone to which this rate applies')


        def run (self, zone):
            zone = self.parent.getZone(zone)
            zone[MAXRATES] = None




    class RATe_Query (Observing, _TBCLeaf):
        '''
        Return the maximum ramp rates for this thermal block.
        '''

        def declareOutputs (self):
            _TBCLeaf.declareOutputs(self)
            self.addOutput('up',
                           type=float,
                           range=(0.001, None),
                           units='degrees C/second',
                           description='Maximum rate for upramps')

            self.addOutput('down',
                           type=float,
                           range=(0.001, None),
                           units='degrees C/second',
                           description='Maxiumum rate for downramps')


        def run (self, zone=str):
            return self.getZone(zone)[MAXRATES]


    class SETTing (Controlling, Background, _TBCZoneLeaf):
        '''
        Ramp the sample temperatures for each of the given zones to
        the given target.  Prior to using this command, at least one
        zone must be defined using the "ZONe+" command.

        Use the "-up" and "-down" arguments to specify the maximum ramp
        rate at which the temperature will be ramped up and down,
        respectively.  In addition, the "-rate" argument specifies
        a modifier percentage to each of these.

        If temperature setpoints are given for more than a single
        zone, then the specified rates are applied to the zone that
        has the largest delta between the current temperature and the
        specified setpoint (over its specified ramp rate).  The ramp
        rates for the remaining zones are pro-rated accordingly.

        In this calculation, the current temperature for each zone is
        assumed to be the setting specified in the prior invocation of
        this command.  First time a temperature setting is applied to
        a given zone (after the "TBC:STARt" command), that zone is
        assumed to be at "ambient" temperature (25 degrees C).


Examples:
        * Define a 6-zone block
           TBC:ZONe+ zone1 Zone0Control Zone0SetPoint Zone0RampRate
           TBC:ZONe+ zone2 Zone1Control Zone1SetPoint Zone1RampRate
           TBC:ZONe+ zone3 Zone2Control Zone2SetPoint Zone2RampRate
           TBC:ZONe+ zone4 Zone3Control Zone3SetPoint Zone3RampRate
           TBC:ZONe+ zone5 Zone4Control Zone4SetPoint Zone4RampRate
           TBC:ZONe+ zone6 Zone5Control Zone5SetPoint Zone5RampRate

        * Enable all of these zones:
           TBC:STARt

        * Ramp the temperature for each zone to 95 degrees C, 3 degrees/sec.
           TBC:TARGet -rate=100.0 -up=2.5 -down=4.0 95.0 95.0 95.0 95.0 95.0 95.0
        '''



        def declareInputs (self):
            ### Do not invoke declareInputs() from superclass.
            ### Rather than building our input parameters from the
            ### arguments of the run() method, we want to build them
            ### by way of the "ZONe+" command.

            self.startInputs()

            self.addInput('rate',
                          type=float,
                          range=(0.001, 100.0),
                          default=100.0,
                          named=True,
                          units='percent',
                          description='Ramp rate modifier')

            self.addInput('increment',
                          type=float,
                          default=0.0,
                          named=True,
                          units='degrees C',
                          description='Added to each specified setpoint')

            self.addInput('enable',
                          type=bool,
                          default=False,
                          named=True,
                          description="Implicitly turn on each zone if needed")

            self.addInput('concurrent',
                          type=bool,
                          default=False,
                          named=True,
                          description='Normally, each TBC operation does not start '
                          'until the prior one has completed; this allows any subsequent '
                          'operation to start as soon as the new setpoint has been sent '
                          'to the TBC.')

            self.addInput('timeout',
                          type=float,
                          default=None,
                          range=(1.0, None),
                          named=True,
                          units='seconds',
                          description=
                          'If the ramp operation has not completed within the specified time, '
                          'generate a timeout error.  A default value may exist in the setpoint '
                          'register of each thermal zone.')

            self.addInput('adjustTimeout',
                          type=bool,
                          default=False,
                          named=True,
                          description=
                          'Adjust the timeout period according to any ramp rate previously specified for '
                          'each zone using the "RATe" command.  In this case, the timeout value supplied '
                          'with the "-timeout" option (or else, the default timeout in each setpoint '
                          'register) is divided by the nominal ramp rate for the zone.')


        def addZone (self, name):
            self.addInput(name,
                          type=float,
                          range=(0.0, None),
                          default=None,
                          units='degrees C',
                          description='Control zone "%s" setpoint'%name)


        def delZone (self, name):
            self.removeInput(name)
            

        def run (self, rate=100.0, increment=0.0,
                 enable=False, concurrent=False,
                 timeout=None, adjustTimeout=False,
                 *targetTemperatures):

            rampTime  = 0.0
            rampSpec  = []

            ### Go through each zone to gather its maximum possible ramp rate,
            ### along with its minimum ramp time.  The aggregate ramp time is
            ### taken from the zone with the longest ramp time.

            for index, target in enumerate(targetTemperatures):
                if target is None:
                    try:
                        target = targetTemperatures[self.parent.masters[index]]
                    except TypeError:
                        continue
                    else:
                        if target is None:
                            continue
                    

                name, creg, treg, rreg, maxrates, setpoint = zone = self.parent.zoneSpec[index]
                target += increment

                try:
                    maxRate = maxrates[target < setpoint]
                    minTime = abs(target - setpoint) / maxRate
                except TypeError:
                    maxRate  = None
                    minTime  = None


                if minTime > rampTime:
                    rampTime = minTime

                rampSpec.append((zone, minTime, maxRate, target))


            ### If a ramp rate below 100% is given, then adjust the ramp time

            rampTime  *= 100 / rate
            rwrites    = []
            cwrites    = []
            twrites    = []
            settings   = []

            for zone, minTime, rampRate, target in rampSpec:
                name, creg, treg, rreg, maxrates, setpoint = zone

                if minTime:
                    rampRate *= minTime / rampTime

                syncTime = timeout or treg.get('sync')

                if rampRate is not None:
                    rwrites.append((rreg, rampRate, None))

                    if adjustTimeout and syncTime:
                        syncTime /= rampRate

                if enable:
                    cwrites.append((creg, ENABLED, None))
                    
                twrites.append((treg, target, syncTime))
                settings.append((zone, target, rampRate))

            
            ### Sleep until any hold time has been reached
            self.parent.acquireLock()

            pending = [ self.sendWrite((value, ), timeout=timeout, **reg)
                        for (reg, value, timeout) in rwrites + cwrites + twrites ]


            for setting, record in zip(settings, pending[len(rwrites):]):
                zone, target, rampRate = setting
                msgid, sync = record
                self.debug('%s ramping "%s" from %s to %s (rate=%s, timeout=%s, msgid=0x%04X)'%
                           (self.commandPath(), zone[NAME], zone[SETPOINT], target,
                            (rampRate is None) and 'unspecified' or '%.1f'%rampRate,
                            (sync is None) and 'None' or '%.1f'%sync, msgid))
            
                zone[SETPOINT] = target

            self.parent.lastSetting = settings

            
            return (pending, concurrent)


        def next (self, pending, concurrent):
            try:
                if concurrent:
                    self.parent.releaseLock()

                try:
                    self.finishWrites(pending)
                except NextReply, e:
                    obj, func, args, kwargs = e.args
                    func(*args, **kwargs)
                except Exception, e:
                    self.parent.opexcept = e
            finally:
                if not concurrent:
                    self.parent.releaseLock()



    class SETTing_Query (Observing, _TBCZoneLeaf):
        '''
        Return the current temperature target for each of the specified zones.
        '''


        def addZone (self, name):
            zones = self.parent.zoneNames()
            self.setInput('zones', type=zones, repeats=(0, len(zones)))
            self.addOutput(name, type=float, named=True, default=None,
                           description='Zone "%s" setpoint')


        def delZone (self, name):
            zones = self.parent.zoneNames()
            self.setInput('zones', type=zones, repeats=(0, len(zones)))
            self.removeOutput(name)


        def run (self, *zones):
            if zones:
                zoneList = [ self.parent.zoneSpec[idx] for idx in zones ]
            else:
                zoneList = self.parent.zoneSpec

            regs = [ zone[TARGETREG] for zone in zoneList ]
            return tuple(self.readList(regs))



    class LAST_Query (Observing, _TBCLeaf):
        '''
        Return a names, setpoints and ramp rates for the zones that were
        specified in the most recent invocation of the "SETTing" command.
        '''

        def declareOutputs (self):
            _TBCLeaf.declareOutputs(self)

            self.addOutput('zones',   type=str, named=True,   default=None)
            self.addOutput('targets', type=str, named=True,   default=None)
            self.addOutput('rates',   type=str, named=True,   default=None)


        def run (self):
            names, targets, rates = [], [], []

            for zone, target, rate in self.parent.lastSetting:
                names.append(zone[NAME])
                targets.append("%.1f"%target)
                if rate:
                    rates.append("%.1f"%rate)
                else:
                    rates.append("")

            if names:
                return (",".join(names),
                        ",".join(targets),
                        ",".join(rates))


    class STATe_Query (Observing, _TBCZoneLeaf):
        '''
        Return current control state for the specified zone.
        '''

        def declareOutputs (self):
            _TBCLeaf.declareOutputs(self)
            self.addOutput('control',
                           type=ControlValues, named=True)
            self.addOutput('target',
                           type=float, units='degrees C', named=True)
            self.addOutput('rate',
                           type=float, units='degrees C/second', named=True)


        def addZone (self, name):
            self.setInput('zone', type=self.parent.zoneNames())
            
        def delZone (self, name):
            self.setInput('zone', type=self.parent.zoneNames())
            

        def run (self, zone=int):
            name, creg, treg, rreg, maxramp, setpoint = self.parent.zoneSpec[zone]
            return tuple(self.readList((creg, treg, rreg)))


branchTypes['TCB'] = branchTypes['TBC'] = ThermalControlBoardBase

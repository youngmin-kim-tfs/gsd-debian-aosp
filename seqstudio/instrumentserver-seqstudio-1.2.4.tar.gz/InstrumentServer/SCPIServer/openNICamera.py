########################################################################
### FILE:	openNICamera.py
### PURPOSE:	IS interface to OpenNI Cameras
### AUTHOR:	Tor Slettnes <tor@slett.net>
###
### Copyrights (C) 2018-2019 ThermoFisher Scientific.  All rights reserved.
########################################################################

from scpiLeaf           import Leaf, Observing, Controlling, Administrative, Background
from scpiFullBranch     import FullBranch
from scpiExceptions     import NextReply, RunError
from scpiFileBranch     import FilesystemBranch
from scpiBranch         import branchTypes
from scpiFilesystemBase import FilesystemLeaf
from scpiFileContexts   import P_WRITE, OP_WRITE

from threadControl      import ControllableThread
from subscription       import publish, addTopic, TRACE, DEBUG
from OpenNICamera       import OpenNICamera, Sensors, PixelFormats

import time, collections


try:
    from PIL import Image
    gotPIL = True
except ImportError:
    gotPIL = False


IMAGE_TOPIC = "Image"
FileFormats = ("raw", "tiff", "png", "jpeg")
(F_RAW, F_TIFF, F_PNG, F_JPEG) = range(len(FileFormats))

class OpenNICameraBranch (FilesystemBranch):
    '''OpenNI Camera'''

    DeviceProperties = ('uri', 'vendorname', 'productname', 'vendorid', 'productid')
    (P_URI, P_VENDORNAME, P_PRODUCTNAME, P_VENDORID, P_PRODUCTID) = range(len(DeviceProperties))

    FRAME_TIMEOUT = 2000        # milliseconds

    DefaultFormats = {
        PixelFormats["RGB888"] : F_TIFF,
        None                   : F_RAW }

    ImageModes = {
        PixelFormats["RGB888"]       : "RGB",
        PixelFormats["DEPTH_1_MM"]   : "I;16",
        PixelFormats["DEPTH_100_UM"] : "I;16",
        PixelFormats["GRAY16"]       : "I;16",
        PixelFormats["GRAY8"]        : "L" }

    class UnsupportedPixelFormat (RunError):
        "Sensor %(sensor)r pixel format %(format)r is not supported."

    def __init__ (self, *args, **kwargs):
        FullBranch.__init__(self, *args, **kwargs)
        self.camera = OpenNICamera()
        addTopic(IMAGE_TOPIC, level=DEBUG)


    def substitute (self, string, **substitutions):
        for k, v in substitutions.iteritems():
            string = string.replace(k.join("$$"), str(v))
        return string


    def acquire (self, count, startindex, maxindex, sensors, fileformats,
                 exposure, topic, location, mirrored, autoremove):
        sensorNames = dict([(number, name.lower()) for (name, number) in Sensors.items()])

        formats = {}
        for index, sensor in enumerate(sensors):
            ifmt, size, fps = self.camera.GetVideoMode(sensor)
            ffmt = fileformats[min(index, len(fileformats)-1)]
            try:
                formats[sensor] = (ffmt, self.ImageModes[ifmt])
            except KeyError:
                raise self.UnsupportedPixelFormat(sensor=sensor, format=fmt)

        try:
            started = []
            for sensor in sensors:
                self.camera.Start(sensor)
                started.append(sensor)
        except RuntimeError:
            for sensor in started:
                self.camera.Stop(sensor)
            raise

        nametemplate = location.path
        if not "." in nametemplate:
            nametemplate += "." + fileformat.lower()

        addTopic(topic, level=DEBUG)

        frames = {}.fromkeys(sensors, 0)
        self.debug("Will capture %s frames from sensors %s, starting at %s, camera isOpen=%s"%
                   (count, ",".join([str(sensor) for sensor in sensors]), startindex, self.camera.IsOpen()))

        queueSize = max(maxindex-startindex, 0)+1
        remove = set()

        while (count is None or (min(frames.values()) < count)) and self.camera.IsOpen():
            self.trace("Waiting for frame from camera")
            frame = self.camera.GetAnyFrame(self.FRAME_TIMEOUT)
            if frame is None:
                break

            sensor, size, data = frame
            self.trace("Received %s frame from camera"%(sensorNames.get(sensor, "unknown")))

            index = (frames[sensor]%queueSize) + startindex
            frames[sensor] += 1
            ffmt, ifmt = formats[sensor]

            props = collections.OrderedDict()
            props.update(index=str(index))
            props.update(sensor=sensorNames[sensor])
            props.update(format=FileFormats[ffmt])
            w, h  = [str(n) for n in size]
            props.update(width=w, height=h)
            filename = self.substitute(nametemplate, **dict(props))
            self.trace("Saving %s (sensor %d) frame %d (%sx%s pixels) to %r"%
                       (sensorNames[sensor], sensor, index, w, h, filename))

            try:
                outfile = location.context.open(filename, OP_WRITE)
                if autoremove:
                    remove.add(filename)
                if ffmt == F_RAW:
                    outfile.write(data)
                else:
                    image = Image.frombuffer(ifmt, size, data, 'raw', ifmt, 0, 1)
                    if mirrored:
                        image.transpose(Image.FLIP_TOP_BOTTOM)
                    else:
                        image.transpose(Image.ROTATE_180)
                    image.save(outfile, FileFormats[ffmt])
            finally:
                outfile.close()

            if (count is not None) and (frames[sensor] >= count):
                self.debug("Stopping camera sensor %d"%(sensor,))
                self.camera.Stop(sensor)

            props.update(filename=filename)
            publish(topic, props)

        for filename in remove:
            location.context.remove(filename, ignoreMissing=True)


    class SENSor_Enumerate (Observing, Leaf):
        '''Enumerate available sensors'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('sensorname', type=str, repeats=(0, None))

        def run (self):
            return tuple(Sensors.keys())

    class ForMaT_Enumerate (Observing, Leaf):
        '''Enumerate available pixel formats'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('format', type=str, repeats=(0, None))

        def run (self):
            return tuple(PixelFormats.keys())


    class VideoMODe_List (Observing, Leaf):
        '''List available video modes for the specified sensor'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('sensor', type=Sensors)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('modelist', type=list, default=[""],
                           description="List of supported video modes")

        def run (self, sensor=Sensors):
            result = []
            fmtdict = dict([(value, key) for (key, value) in PixelFormats.items()])

            for pixelformat, size, fps in self.parent.camera.GetSupportedVideoModes(sensor):
                width, height = size
                result.append("-format=%s -width=%d -height=%d -fps=%d"%
                              (fmtdict.get(pixelformat, pixelformat), width, height, fps))
            return result


    class VideoMODe_Query (Observing, Leaf):
        '''Return current video mode of the specified sensor'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('sensor', type=Sensors)

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('format', type=PixelFormats, named=True)
            self.addOutput('width', type=int, named=True)
            self.addOutput('height', type=int, named=True)
            self.addOutput('fps', type=int, named=True)

        def run (self, sensor=Sensors):
            pfmt, size, fps = self.parent.camera.GetVideoMode(sensor)
            width, height = size
            return pfmt, width, height, fps


    class VideoMODe (Observing, Leaf):
        '''Set video mode of the specified sensor'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('sensor', type=Sensors)
            self.setInput('format', type=PixelFormats, default=None)
            self.setInput('width', type=int, default=None)
            self.setInput('height', type=int, default=None)
            self.setInput('fps', type=int, default=None)


        def run (self, sensor=Sensors, format=PixelFormats, width=int, height=int, fps=int):
            cfmt, size, cfps = self.parent.camera.GetVideoMode(sensor)
            cwidth, cheight  = size

            newmode = ((format, cfmt)[format is None],
                       ((width, cwidth)[width is None],
                        (height, cheight)[height is None]),
                       (fps, cfps)[fps is None])

            self.parent.camera.SetVideoMode(sensor, newmode)


    class LIST_Enumerate (Observing, Leaf):
        '''Enumerate OpenNI Device URIs found on this system.'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('uri', type=str, repeats=(0, None),
                           description='Device URI')

        def run (self):
            uris = [ device[P_URI] for device in self.parent.camera.ListDevices() ]
            return tuple(uris)


    class OPEN (Controlling, Leaf):
        '''Open the specified OpenNI-compliant camera.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('uri', named=True, type=str, default=None,
                          description='Device URI, as returned by "LIST*" and "LIST?". '
                          'If absent, open the first available camera.')

        def run (self, uri=None):
            if (uri or not self.parent.camera.IsOpen()):
                self.parent.camera.Open(uri)


    class CLOSe (Controlling, Leaf):
        '''Close the specified OpenNI-compliant camera.'''

        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('removeImages', type=bool, named=True, default=False,
                          description='Also remove any acquired images.')

        def run (self):
            self.parent.camera.Close()



    class OPEN_Query (Observing, Leaf):
        '''Indicate whether camera is currently open'''

        def declareOutputs (self):
            Leaf.declareOutputs(self)
            self.addOutput('isopen', type=bool)

        def run (self):
            return self.parent.camera.IsOpen()



    class _AcquisitionLeaf (Controlling, Background, FilesystemLeaf):
        def declareInputs (self):
            Leaf.declareInputs(self)
            self.setInput('sensors', type=Sensors, named=True, split=(",", 1, len(Sensors)),
                          description="One or more sensors from which to acquire images")
            self.setInput('formats', type=FileFormats, named=True, split=(",", 1, len(Sensors)), default=(F_TIFF,),
                          description="File format for images from each of the specified sensors.")
            self.setInput('exposure', type=int, named=True, default=None,
                          description="IR exposure")
            self.setInput('topic', type=str, named=True, default=IMAGE_TOPIC,
                          description="Message topic on which to publish availability of images")
            self.setInput('output', type=str, named=True, default="image-$index$-$sensor$.$format$",
                          description="Image file name template. $index$ is substuted for the image index, "
                          "$sensor$ is substitute for sensor name %r, and $format$ is substituted for "
                          "image format."%(Sensors,))

            self.setInput('mirrored', type=bool, named=True, default=False,
                          description="Mirror images")

        def next (self, count, sensors, formats, exposure, topic, startIndex, maxIndex, loc, mirrored, autoremove):
            with loc:
                self.parent.acquire(count, startIndex, maxIndex, sensors, formats, exposure, topic, loc, mirrored, autoremove)


    class ACQuire (_AcquisitionLeaf):
        '''Acquire a single frame set (up to 3 frames) from the camera.'''


        def declareInputs (self):
            OpenNICameraBranch._AcquisitionLeaf.declareInputs(self)
            self.setInput('index', type=int, named=True, default=0,
                          description="Camera frame index, used in output file name and message topic.")

        def run (self, _session, sensors=Sensors, formats=FileFormats, exposure=None, topic=str, index=0, mirrored=False, skipTriggers=False, output=str):
            loc = self.openLocation(output, _session, P_WRITE, not skipTriggers)
            return (1, sensors, formats, exposure, topic, index, index, loc, mirrored, False)


    class START (_AcquisitionLeaf):
        '''Acquire multiple set (up to 3 frames per set) from the camera.'''

        def declareInputs (self):
            OpenNICameraBranch._AcquisitionLeaf.declareInputs(self)
            self.setInput('count',   type=int, range=(1, None), default=None,
                          description="Number of frame sets to capture. "
                          "By default, captures contintinue until explicitly stopped with the STOP.")
            self.setInput('startIndex', type=int, named=True, default=1,
                          description="First camera frame, used in output file name and message topic. "
                          "Subsequent frames are incremented from this value.")
            self.setInput('maxIndex', type=int, named=True, range=(1,None), default=100,
                          description="Maximum camera frame index, used in output file name and message topic. "
                          "The subsequent frame starts over from 'startIndex'.")
            self.setInput('autoremove', type=bool, named=True, default=False,
                          description="Automatically remove acquired images once the acquisition ends.")

        def run (self, _session, count, sensors=Sensors, formats=FileFormats, exposure=None, topic=str, startIndex=0, maxIndex=100, mirrored=False, autoremove=False, skipTriggers=False, output=str):
            loc = self.openLocation(output, _session, P_WRITE, not skipTriggers)
            return (count, sensors, formats, exposure, topic, startIndex, maxIndex, loc, mirrored, autoremove)


    class STOP (Controlling, Leaf):
        '''Stop camera acquisition.'''

        def run (self):
            for sensorName, sensorIndex in Sensors.items():
                self.parent.camera.Stop(sensorIndex)



branchTypes['OpenNICamera'] = OpenNICameraBranch
